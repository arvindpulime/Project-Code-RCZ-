package com.inetpsa.rcz.interfaces.rest;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.testing.junit4.SeedITRunner;
import org.seedstack.seed.undertow.LaunchWithUndertow;

@RunWith(SeedITRunner.class)
@LaunchWithUndertow
public class ClientRequestResourceTest extends AbstractRequestTest {


    String request_charging = "{\n" +
            "\"parameters\": {\"type\": \"delayed\",\n" +
            "    \"program\": {\n" +
            "      \"minute\": 50,\n" +
            "      \"hour\": 9\n" +
            "    } },\n" +
            " \"access_token\":\"XXXXXXXXXXXXXXXX\",\n" +
            " \"customer_id\": \"AC-ACNT200000240614\",\n" +
            " \"vin\": \"VR1ATTENTKW012925\",\n" +
            " \"processCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/processCallback\"},\n" +
            " \"responseCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/responseCallback\"}\n" +
            "}";

    String request_charging_bad = "{\n" +
            "\"parameters\": {\"type\": \"delayed\",\n" +
            "    \"program\": {\n" +
            "      \"minute\": 50,\n" +
            "      \"hour\": 9\n" +
            "    } },\n" +
            " \"access_token\":\"XXXXXXXXXXXXXXXX\",\n" +
            " \"customer_id\": \"AC-ACNT200000240614\",\n" +
            " \"vin\": \"VR1ATTENTKW0125464925\",\n" +
            " \"processCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/processCallback\"},\n" +
            " \"responseCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/responseCallback\"}\n" +
            "}";

    String request_chargingState = "{\n" +
            "  \"parameters\": {\n" +
            "    \"action\": \"state\"\n" +
            "  },\n" +
            "  \"access_token\": \"XXXXXXXXXXXXXXXX\",\n" +
            "  \"customer_id\": \"AC-ACNT200000240648\",\n" +
            "  \"vin\": \"VR1ATTENTJY085311\",\n" +
            "  \"processCallback\": {\n" +
            "\t\"url\" : \"http://localhost:8090/processCallback\"\n" +
            "  },\n" +
            "  \"responseCallback\": {\n" +
            "\t\"url\" : \"http://localhost:8090/responseCallback\"\n" +
            "  }\n" +
            "}";

    String request_charging_state_bad = "{\n" +
            "  \"parameters\": {\n" +
            "    \"action\": \"unlock\"\n" +
            "  },\n" +
            "  \"access_token\": \"XXXXXXXXXXXXXXXX\",\n" +
            "  \"customer_id\": \"AC-ACNT200000240648\",\n" +
            "  \"vin\": \"VR1ATTENTJY085311\",\n" +
            "  \"processCallback\": {\n" +
            "\t\"url\" : \"http://localhost:8090/processCallback\"\n" +
            "  },\n" +
            "  \"responseCallback\": {\n" +
            "\t\"url\" : \"http://localhost:8090/responseCallback\"\n" +
            "  }\n" +
            "}";

    String request_doors = "{\n" +
            "\"parameters\": {\"action\": \"unlock\"},\n" +
            " \"access_token\":\"XXXXXXXXXXXXXXXX\",\n" +
            " \"customer_id\": \"AC-ACNT200000240648\",\n" +
            " \"vin\": \"VR1ATTENTJY085311\",\n" +
            " \"processCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/processCallback\"},\n" +
            " \"responseCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/responseCallback\"}\n" +
            "}";

    String request_doors_bad = "{\n" +
            "\"parameters\": {\"action\": \"unlock\"},\n" +
            " \"access_token\":\"XXXXXXXXXXXXXXXX\",\n" +
            " \"customer_id\": \"AC-ACNT200000240648\",\n" +
            " \"vin\": \"VR1ATTE454NTJY085311\",\n" +
            " \"processCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/processCallback\"},\n" +
            " \"responseCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/responseCallback\"}\n" +
            "}";

    String request_horn = "{\n" +
            "\"parameters\": {\"action\": \"activate\",\n" +
            "    \"nb_horn\": 1},\n" +
            " \"access_token\":\"XXXXXXXXXXXXXXXX\",\n" +
            " \"customer_id\": \"AP-ACNT200000899549\",\n" +
            " \"vin\": \"VR3ATTENTJY186916\",\n" +
            " \"processCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/processCallback\"},\n" +
            " \"responseCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/responseCallback\"}\n" +
            "}";

    String request_horn_bad = "{\n" +
            "\"parameters\": {\"action\": \"activate\",\n" +
            "    \"nb_horn\": 1},\n" +
            " \"access_token\":\"XXXXXXXXXXXXXXXX\",\n" +
            " \"customer_id\": \"AP-ACNT200000899549\",\n" +
            " \"vin\": \"VR3ATTENTJY1jsksl8485486916\",\n" +
            " \"processCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/processCallback\"},\n" +
            " \"responseCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/responseCallback\"}\n" +
            "}";

    // no result sur l app
    String request_lowPowerInfo = "{\n" +
            "\"parameters\": {\"action\": \"state\"},\n" +
            " \"access_token\":\"XXXXXXXXXXXXXXXX\",\n" +
            " \"customer_id\": \"AC-ACNT200000240614\",\n" +
            " \"vin\": \"VR1ATTENTKW012925\",\n" +
            " \"processCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/processCallback\"},\n" +
            " \"responseCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/responseCallback\"}\n" +
            "}";

    String request_lowPowerInfo_bad = "{\n" +
            "  \"parameters\": {\n" +
            "    \"action\": \"unlock\"\n" +
            "  },\n" +
            "  \"access_token\": \"XXXXXXXXXXXXXXXX\",\n" +
            "  \"customer_id\": \"AC-ACNT200000240648\",\n" +
            "  \"vin\": \"VR1A44444TTENTJY085311\",\n" +
            "  \"processCallback\": {\n" +
            "\t\"url\" : \"http://localhost:8090/processCallback\"\n" +
            "  },\n" +
            "  \"responseCallback\": {\n" +
            "\t\"url\" : \"http://localhost:8090/responseCallback\"\n" +
            "  }\n" +
            "}";

    String request_requestState = "{\n" +
            "\"parameters\": {\"action\": \"state\",\n" +
            "    \"correlation_id\": \"35431408108937420181115143924\"},\n" +
            " \"access_token\":\"XXXXXXXXXXXXXXXX\",\n" +
            " \"customer_id\": \"AC-ACNT200000240614\",\n" +
            " \"vin\": \"VR1ATTENTKW012925\",\n" +
            " \"processCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/processCallback\"},\n" +
            " \"responseCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/responseCallback\"}\n" +
            "}";

    String request_requestState_bad = "{\n" +
            "\"parameters\": {\"action\": \"state\",\n" +
            "    \"correlation_id\": \"35431408108937420181115143924\"},\n" +
            " \"access_token\":\"XXXXXXXXXXXXXXXX\",\n" +
            " \"customer_id\": \"mdemmx03\",\n" +
            " \"vin\": \"VF3ATTEN45454TGL016433\",\n" +
            " \"processCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/processCallback\"},\n" +
            " \"responseCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/responseCallback\"}\n" +
            "}";

    String request_thermalPreconditioning = "{\n" +
            "\"parameters\": {\n" +
            "    \"asap\": \"deactivate\",\n" +
            "    \"programs\": {\n" +
            "      \"program4\": {\n" +
            "        \"hour\": 12,\n" +
            "        \"day\": [\n" +
            "          1,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0\n" +
            "        ],\n" +
            "        \"on\": 0,\n" +
            "        \"minute\": 0\n" +
            "      },\n" +
            "      \"program3\": {\n" +
            "        \"hour\": 12,\n" +
            "        \"day\": [\n" +
            "          1,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0\n" +
            "        ],\n" +
            "        \"on\": 0,\n" +
            "        \"minute\": 0\n" +
            "      },\n" +
            "      \"program2\": {\n" +
            "        \"hour\": 10,\n" +
            "        \"day\": [\n" +
            "          1,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0\n" +
            "        ],\n" +
            "        \"on\": 1,\n" +
            "        \"minute\": 0\n" +
            "      },\n" +
            "      \"program1\": {\n" +
            "        \"hour\": 12,\n" +
            "        \"day\": [\n" +
            "          0,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0,\n" +
            "          1,\n" +
            "          0,\n" +
            "          0\n" +
            "        ],\n" +
            "        \"on\": 1,\n" +
            "        \"minute\": 0\n" +
            "      }\n" +
            "    }\n" +
            "  },\n" +
            " \"access_token\":\"XXXXXXXXXXXXXXXX\",\n" +
            " \"customer_id\": \"AC-ACNT200000240614\",\n" +
            " \"vin\": \"VR1ATTENTKW012925\",\n" +
            " \"processCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/processCallback\"},\n" +
            " \"responseCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/responseCallback\"}\n" +
            "}";

    String request_thermalPreconditioning_bad = "{\n" +
            "\"parameters\": {\n" +
            "    \"asap\": \"deactivate\",\n" +
            "    \"programs\": {\n" +
            "      \"program4\": {\n" +
            "        \"hour\": 12,\n" +
            "        \"day\": [\n" +
            "          1,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0\n" +
            "        ],\n" +
            "        \"on\": 0,\n" +
            "        \"minute\": 0\n" +
            "      },\n" +
            "      \"program3\": {\n" +
            "        \"hour\": 12,\n" +
            "        \"day\": [\n" +
            "          1,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0\n" +
            "        ],\n" +
            "        \"on\": 0,\n" +
            "        \"minute\": 0\n" +
            "      },\n" +
            "      \"program2\": {\n" +
            "        \"hour\": 10,\n" +
            "        \"day\": [\n" +
            "          1,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0\n" +
            "        ],\n" +
            "        \"on\": 1,\n" +
            "        \"minute\": 0\n" +
            "      },\n" +
            "      \"program1\": {\n" +
            "        \"hour\": 12,\n" +
            "        \"day\": [\n" +
            "          0,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0,\n" +
            "          1,\n" +
            "          0,\n" +
            "          0\n" +
            "        ],\n" +
            "        \"on\": 1,\n" +
            "        \"minute\": 0\n" +
            "      }\n" +
            "    }\n" +
            "  },\n" +
            " \"access_token\":\"XXXXXXXXXXXXXXXX\",\n" +
            " \"customer_id\": \"AC-ACNT200000240614\",\n" +
            " \"vin\": \"VR1ATTEN5555TKW012925\",\n" +
            " \"processCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/processCallback\"},\n" +
            " \"responseCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/responseCallback\"}\n" +
            "}";

    // no result sur lapp ( no result aussi avec error)
    String request_tracking = "{\n" +
            "\"parameters\": { \n" +
            "    \"action\": \"activate\",\n" +
            "    \"period_run\": 15,\n" +
            "    \"period_shutdn\": 60 },\n" +
            " \"access_token\":\"XXXXXXXXXXXXXXXX\",\n" +
            " \"customer_id\": \"AC-ACNT200000240614\",\n" +
            " \"vin\": \"VR1ATTENTKW012925\",\n" +
            " \"processCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/processCallback\"},\n" +
            " \"responseCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/responseCallback\"}\n" +
            "}";

    String request_tracking_bad = "{\n" +
            "\"parameters\": { \n" +
            "    \"action\": \"activate\",\n" +
            "    \"period_run\": 15,\n" +
            "    \"period_shutdn\": 80 }\n" +
            " \"customer_id\": \"AP-ACNT300000527476\",\n" +
            " \"vin\": \"VF3CA5F444V8CW100631\",\n" +
            " \"processCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/processCallback\"},\n" +
            " \"responseCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/responseCallback\"}\n" +
            "}";

    String request_vehicleState = "{\n" +
            "\"parameters\": {\"action\": \"state\"},\n" +
            " \"access_token\":\"XXXXXXXXXXXXXXXX\",\n" +
            " \"customer_id\": \"AP-ACNT200000899549\",\n" +
            " \"vin\": \"VR3ATTENTJY186916\",\n" +
            " \"processCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/processCallback\"},\n" +
            " \"responseCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/responseCallback\"}\n" +
            "}";

    String request_vehicleState_bad = "{\n" +
            "\"parameters\": {\"action\": \"state\"},\n" +
            " \"access_token\":\"XXXXXXXXXXXXXXXX\",\n" +
            " \"customer_id\": \"AP-ACNT200000899549\",\n" +
            " \"vin\": \"VR3ATTENT7777JY186916\",\n" +
            " \"processCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/processCallback\"},\n" +
            " \"responseCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/responseCallback\"}\n" +
            "}";

    @Test
    public void chargingTest() throws Exception {
        assertAction("/api/customer/remote/charging", request_charging);
    }

    @Test
    public void chargingTestKo() throws Exception {
        assertActionKo("/api/customer/remote/charging", request_charging_bad);
    }

    @Test
    public void chargingStateTest() throws Exception {
        assertAction("/api/customer/remote/chargingstate", request_chargingState);
    }

    @Test
    public void chargingStateTestKo() throws Exception {
        assertActionKo("/api/customer/remote/chargingstate", request_charging_state_bad);
    }

    @Test
    public void doorsTest() throws Exception {
        assertAction("/api/customer/remote/doors", request_doors);
    }

    @Test
    public void doorsTestKo() throws Exception {
        assertActionKo("/api/customer/remote/doors", request_doors_bad);
    }

    @Test
    public void hornTest() throws Exception {
        assertAction("/api/customer/remote/horn", request_horn);
    }

    @Test
    public void hornTestKo() throws Exception {
        assertActionKo("/api/customer/remote/horn", request_horn_bad);
    }

    @Test
    public void lowPowerInfoTest() throws Exception {
        assertAction("/api/customer/remote/lowpowerinfo", request_lowPowerInfo);
    }

    @Test
    public void lowPowerInfoTestKo() throws Exception {
        assertActionKo("/api/customer/remote/lowpowerinfo", request_lowPowerInfo_bad);
    }

    @Test
    public void requestStateTest() throws Exception {
        assertAction("/api/customer/remote/requeststate", request_requestState);
    }

    @Test
    public void requestStateTestKo() throws Exception {
        assertActionKo("/api/customer/remote/requeststate", request_requestState_bad);
    }

    @Test
    public void thermalPreconditioningTest() throws Exception {
        assertAction("/api/customer/remote/thermalpreconditioning", request_thermalPreconditioning);
    }

    @Test
    public void thermalPreconditioningTestKo() throws Exception {
        assertActionKo("/api/customer/remote/thermalpreconditioning", request_thermalPreconditioning_bad);
    }

    @Test
    public void trackingTest() throws Exception {
        assertAction("/api/customer/remote/tracking", request_tracking);
    }

    @Test
    public void trackingTestKo() throws Exception {
        assertActionKo("/api/customer/remote/tracking", request_tracking_bad);
    }

    @Test
    public void vehicleStateTest() throws Exception {
        assertAction("/api/customer/remote/vehiclestate", request_vehicleState);
    }

    @Test
    public void vehicleStateTestKo() throws Exception {
        assertActionKo("/api/customer/remote/vehiclestate", request_vehicleState_bad);
    }

}
