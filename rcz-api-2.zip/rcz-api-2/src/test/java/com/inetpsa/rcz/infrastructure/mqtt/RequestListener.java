package com.inetpsa.rcz.infrastructure.mqtt;

import com.fasterxml.jackson.core.type.TypeReference;
import com.google.common.base.Charsets;
import com.inetpsa.rcz.application.service.PublisherService;
import com.inetpsa.rcz.domain.model.payload.data.Data;
import com.inetpsa.rcz.domain.model.payload.request.RequestPayload;
import com.inetpsa.rcz.domain.model.payload.response.ProcessPayload;
import com.inetpsa.rcz.domain.model.payload.response.ResponsePayload;
import com.inetpsa.rcz.domain.model.payload.topic.Topic;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.seedstack.mqtt.MqttListener;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.Date;

@MqttListener(clients = "RCZ_API_00_DEV_2",
        topics = {"psa/+/from/#"},
        qos = {"0"})
public class RequestListener implements MqttCallback {


    @Logging
    private Logger logger;
    @Inject
    @Named("mqtt")
    private PublisherService<String> publisherService;

    @Override
    public void connectionLost(Throwable cause) {

    }

    @Override
    public void messageArrived(String topic, MqttMessage message) throws Exception {
        RequestPayload requestPayload = JsonConverter.convert(new String(message.getPayload(), Charsets.UTF_8), new TypeReference<RequestPayload<Data>>() {});
        ResponsePayload responsePayload = getResponsePayload(requestPayload);
        publisherService.publish(JsonConverter.convert(responsePayload), topic.replace("from", "to"));
        ProcessPayload processPayload = getProcessPayload(requestPayload);
        publisherService.publish(JsonConverter.convert(processPayload), topic.replace("from", "to") + "/ProcessManagement");
    }

    private ProcessPayload getProcessPayload(RequestPayload requestPayload) {
        ProcessPayload processPayload = new ProcessPayload();
        processPayload.setCorrelationId(requestPayload.getCorrelationId());
        processPayload.setCode("900");
        processPayload.setDate(new Date());
        return processPayload;
    }

    private ResponsePayload getResponsePayload(RequestPayload requestPayload) {
        ResponsePayload responsePayload = new ResponsePayload<>();
        responsePayload.setCorrelationId(requestPayload.getCorrelationId());
        responsePayload.setResponseDate(new Date());
        responsePayload.setReturnCode("300");
        responsePayload.setVin(requestPayload.getVin());
        return responsePayload;
    }

    @Override
    public void deliveryComplete(IMqttDeliveryToken token) {

    }
}
