package com.inetpsa.rcz.interfaces.rest;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.inetpsa.rcz.application.representation.ResponseRepresentation;
import com.inetpsa.rcz.domain.model.api.request.RequestStatus;
import com.inetpsa.rcz.domain.services.RequestService;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.assertj.core.api.Assertions;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.seedstack.seed.Configuration;

import javax.inject.Inject;
import java.util.concurrent.TimeUnit;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.wireMockConfig;
import static io.restassured.RestAssured.given;
import static org.awaitility.Awaitility.await;

public abstract class AbstractRequestTest {

    protected static final WireMockServer wireMockServer = new WireMockServer(wireMockConfig().port(8090));

    private static final String CALLBACKPROCESS = "/processCallback";
    private static final String CALLBACKRESPONSE = "/responseCallback";
    public static final String RUNTIME_WEB_BASE_URL = "runtime.web.baseUrl";

    @Configuration(RUNTIME_WEB_BASE_URL)
    protected String baseUrl;
    @Inject
    protected RequestService requestService;

    @BeforeClass
    public static void beforeClass() {
        wireMockServer.start();
    }

    @AfterClass
    public static void afterClass() {
        wireMockServer.stop();
    }

    @Before
    public void before() {
        notifierAssertions();
    }

    protected void notifierAssertions() {
        wireMockServer.stubFor(post(urlEqualTo(CALLBACKRESPONSE))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withBody("")));

        wireMockServer.stubFor(post(urlEqualTo(CALLBACKPROCESS))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withBody("")));
    }

    protected void assertAction(String actionUrl, String request) {
        Response response = given()
                .auth().basic("demo", "demo")
                .contentType(ContentType.JSON)
                .body(request)
                .expect().statusCode(200)
                .when().post(baseUrl + actionUrl);

        ResponseRepresentation responseRepresentation = response.as(ResponseRepresentation.class);
        Assertions.assertThat(responseRepresentation.getCorrelationId()).isNotNull();
        await().atMost(3, TimeUnit.SECONDS).untilAsserted(() -> Assertions.assertThat(isStatusFinished(responseRepresentation.getCorrelationId())).isEqualTo(true));
    }

    protected void assertActionKo(String actionUrl, String request) {
        Response response = given()
                .auth().basic("demo", "demo")
                .contentType(ContentType.JSON)
                .body(request)
                .expect().statusCode(400)
                .when().post(baseUrl + actionUrl);
    }

    protected boolean isStatusFinished(String correlationId) {
        if (requestService.get(correlationId).get().getStatus().equals(RequestStatus.FINISH)) return true;
        else return false;
    }
}
