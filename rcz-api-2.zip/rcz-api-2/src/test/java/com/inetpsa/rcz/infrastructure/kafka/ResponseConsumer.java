package com.inetpsa.rcz.infrastructure.kafka;


import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.seedstack.business.domain.DomainEventPublisher;
import org.seedstack.kafka.ConsumerListener;
import org.seedstack.kafka.KafkaListener;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import javax.inject.Inject;
import java.util.concurrent.CountDownLatch;

@KafkaListener(value = "responseConsumer", topics = "response")
public class ResponseConsumer implements ConsumerListener<String, String> {

    @Logging
    private Logger logger;

    @Inject
    private DomainEventPublisher eventPublisher;


    @Override
    public void onConsumerRecord(ConsumerRecord<String, String> consumerRecord) {
        logger.info(consumerRecord.value());

    }

    @Override
    public void onException(Exception e) {
        logger.error(e.getMessage(), e);
    }
}