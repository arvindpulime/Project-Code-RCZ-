package com.inetpsa.rcz.infrastructure.kafka;

import com.salesforce.kafka.test.KafkaTestCluster;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Properties;

public class KafkaCluster {

    private static Logger log = LoggerFactory.getLogger(KafkaCluster.class);

    private KafkaTestCluster kafkaTestCluster = null;

    public void start() {
        log.info("started : initilizing Kafka Embedded Server !!!");

        Properties p = new Properties();
        p.setProperty("advertised.listeners", "PLAINTEXT://localhost:9092");
        p.setProperty("listeners", "PLAINTEXT://localhost:9092");
        p.setProperty("advertised.port", "9092");
        p.setProperty("port", "9092");

        kafkaTestCluster = new KafkaTestCluster(1, p);
        try {
            kafkaTestCluster.start();
        } catch (Exception e) {
            log.error("beforeInitialization : Kafka Embedded Server ERROR :", e);
        }
    }

    public void stop() {
        try {
            kafkaTestCluster.stop();
        } catch (Exception e) {
            log.error("stopping ERROR: ", e);
        }
    }

}