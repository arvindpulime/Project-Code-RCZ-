package com.inetpsa.rcz.infrastructure.kafka;

import org.seedstack.coffig.Coffig;
import org.seedstack.seed.spi.SeedInitializer;

public class ContextInitializer implements SeedInitializer {

    private static final KafkaCluster KAFKA_CLUSTER = new KafkaCluster();


    @Override
    public void beforeInitialization() {
        System.setProperty("jdk.http.auth.tunneling.disabledSchemes", "");
        KAFKA_CLUSTER.start();
    }

    @Override
    public void onInitialization(Coffig coffig) {
    }

    @Override
    public void afterInitialization() {

    }

    @Override
    public void afterRefresh() {

    }

    @Override
    public void onClose() {
        KAFKA_CLUSTER.stop();
    }
}