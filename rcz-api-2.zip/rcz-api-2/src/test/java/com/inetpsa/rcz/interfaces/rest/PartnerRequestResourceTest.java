package com.inetpsa.rcz.interfaces.rest;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.testing.junit4.SeedITRunner;
import org.seedstack.seed.undertow.LaunchWithUndertow;

@RunWith(SeedITRunner.class)
@LaunchWithUndertow
public class PartnerRequestResourceTest extends AbstractRequestTest {

    String request_charging = "{\n" +
            "\"parameters\": {\n" +
            "    \"type\": \"delayed\",\n" +
            "    \"program\": {\n" +
            "      \"hour\": 21,\n" +
            "      \"minute\": 45\n" +
            "    }},\n" +
            " \"partner_id\": \"mdercz00\",\n" +
            " \"customer_id\": \"AC-ACNT200000240614\",\n" +
            " \"vin\": \"VR1ATTENTJY085311\",\n" +
            " \"processCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/processCallback\"},\n" +
            " \"responseCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/responseCallback\"}\n" +
            "}";

    String request_charging_bad = "{\n" +
            "\"parameters\": {\n" +
            "    \"type\": \"delayed\",\n" +
            "    \"program\": {\n" +
            "      \"hour\": 21,\n" +
            "      \"minute\": 45\n" +
            "    }},\n" +
            " \"partner_id\": \"mdercz00\",\n" +
            " \"customer_id\": \"AC-ACNT200000240614\",\n" +
            " \"vin\": \"VR1ATTEN544545TJY085311\",\n" +
            " \"processCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/processCallback\"},\n" +
            " \"responseCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/responseCallback\"}\n" +
            "}";

    String request_chargingState = "{\n" +
            "\"parameters\": {\n" +
            "    \"action\": \"state\"\n" +
            "\t},\n" +
            " \"partner_id\": \"mdercz00\",\n" +
            " \"customer_id\": \"AC-ACNT200000240614\",\n" +
            " \"vin\": \"VR1ATTENTKW012925\",\n" +
            " \"processCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/processCallback\"},\n" +
            " \"responseCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/responseCallback\"}\n" +
            "}";

    String request_chargingState_bad = "{\n" +
            "\"parameters\": {\n" +
            "    \"action\": \"state\"\n" +
            "\t},\n" +
            " \"partner_id\": \"mdercz00\",\n" +
            " \"customer_id\": \"AC-ACNT200000240614\",\n" +
            " \"vin\": \"VR1ATTENT5454KW012925\",\n" +
            " \"processCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/processCallback\"},\n" +
            " \"responseCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/responseCallback\"}\n" +
            "}";

    String request_doors = "{\n" +
            "\"parameters\": {\n" +
            "    \"action\": \"lock\"\n" +
            "\t},\n" +
            " \"partner_id\": \"mdercz00\",\n" +
            " \"customer_id\": \"AC-ACNT200000240614\",\n" +
            " \"vin\": \"VR1ATTENTJY085311\",\n" +
            " \"processCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/processCallback\"},\n" +
            " \"responseCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/responseCallback\"}\n" +
            "}";

    String request_doors_bad = "{\n" +
            "\"parameters\": {\n" +
            "    \"action\": \"lock\"\n" +
            "\t},\n" +
            " \"partner_id\": \"mdercz00\",\n" +
            " \"customer_id\": \"AC-ACNT200000240614\",\n" +
            " \"vin\": \"VR1ATT555ENTJY085311\",\n" +
            " \"processCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/processCallback\"},\n" +
            " \"responseCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/responseCallback\"}\n" +
            "}";

    String request_horn = "{\n" +
            "\"parameters\": {\n" +
            "   \"action\": \"activate\",\n" +
            "    \"nb_horn\": \"2\"\n" +
            "\t},\n" +
            " \"partner_id\": \"mdercz00\",\n" +
            " \"customer_id\": \"AC-ACNT200000240614\",\n" +
            " \"vin\": \"VR1ATTENTJY085311\",\n" +
            " \"processCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/processCallback\"},\n" +
            " \"responseCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/responseCallback\"}\n" +
            "}\n" +
            "\t";

    String request_horn_bad = "{\n" +
            "\"parameters\": {\n" +
            "   \"action\": \"activate\",\n" +
            "    \"nb_horn\": \"2\"\n" +
            "\t},\n" +
            " \"partner_id\": \"mdercz00\",\n" +
            " \"customer_id\": \"AC-ACNT200000240614\",\n" +
            " \"vin\": \"VR1ATTENT4684JY085311\",\n" +
            " \"processCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/processCallback\"},\n" +
            " \"responseCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/responseCallback\"}\n" +
            "}\n" +
            "\t";

    String request_lights = "{\n" +
            "\"parameters\": {\n" +
            "   \"action\": \"activate\",\n" +
            "    \"duration\": \"30\"\n" +
            "\t},\n" +
            " \"partner_id\": \"mdercz00\",\n" +
            " \"customer_id\": \"AC-ACNT200000240614\",\n" +
            " \"vin\": \"VF3DunaDataCol003\",\n" +
            " \"processCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/processCallback\"},\n" +
            " \"responseCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/responseCallback\"}\n" +
            "}";

    String request_lights_bad = "{\n" +
            "\"parameters\": {\n" +
            "   \"action\": \"activate\",\n" +
            "    \"duration\": \"30\"\n" +
            "\t},\n" +
            " \"partner_id\": \"mdercz00\",\n" +
            " \"customer_id\": \"AC-ACNT200000240614\",\n" +
            " \"vin\": \"VF3DunaDat85576aCol003\",\n" +
            " \"processCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/processCallback\"},\n" +
            " \"responseCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/responseCallback\"}\n" +
            "}";

    // no result sur lapp (error aussi no result)
    String request_lowPowerInfo = "{\n" +
            "\"parameters\": {\"action\": \"state\"},\n" +
            " \"partner_id\": \"mdercz00\",\n" +
            " \"customer_id\": \"AC-ACNT200000240614\",\n" +
            " \"vin\": \"VR1ATTENTJY085311\",\n" +
            " \"processCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/processCallback\"},\n" +
            " \"responseCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/responseCallback\"}\n" +
            "}";

    String request_lowPowerInfo_bad = "{\n" +
            "  \"parameters\": {\n" +
            "    \"action\": \"unlock\"\n" +
            "  },\n" +
            "  \"partner_id\": \"mdercz00\",\n" +
            " \"customer_id\": \"AC-ACNT200000240614\",\n" +
            "  \"vin\": \"VR1ATT88888ENTJY085311\",\n" +
            "  \"processCallback\": {\n" +
            "\t\"url\" : \"http://localhost:8090/processCallback\"\n" +
            "  },\n" +
            "  \"responseCallback\": {\n" +
            "\t\"url\" : \"http://localhost:8090/responseCallback\"\n" +
            "  }\n" +
            "}";

    // no result sur lapp (error aussi so result)
    String request_requestState = "{\n" +
            "\"parameters\": {\"action\": \"state\",\n" +
            "    \"correlation_id\": \"35431408108937420181115143924\"},\n" +
            "  \"partner_id\": \"mdercz00\",\n" +
            " \"customer_id\": \"AC-ACNT200000240614\",\n" +
            "  \"vin\": \"VR1ATTENTJY085311\",\n" +
            "  \"processCallback\": {\n" +
            "\t\"url\" : \"http://localhost:8090/processCallback\"\n" +
            "  },\n" +
            "  \"responseCallback\": {\n" +
            "\t\"url\" : \"http://localhost:8090/responseCallback\"\n" +
            "  }\n" +
            "}";

    String request_requestState_bad = "{\n" +
            "  \"parameters\": {\n" +
            "    \"action\": \"unlock\"\n" +
            "  },\n" +
            "  \"partner_id\": \"mdercz00\",\n" +
            " \"customer_id\": \"AC-ACNT200000240614\",\n" +
            "  \"vin\": \"VjhkjhR1ATTENTJY085311\",\n" +
            "  \"processCallback\": {\n" +
            "\t\"url\" : \"http://localhost:8090/processCallback\"\n" +
            "  },\n" +
            "  \"responseCallback\": {\n" +
            "\t\"url\" : \"http://localhost:8090/responseCallback\"\n" +
            "  }\n" +
            "}";


    String request_thermalPreconditioning = "{\n" +
            "\"parameters\": {\n" +
            "    \"asap\": \"activate\",\n" +
            "    \"programs\": {\n" +
            "      \"program1\": {\n" +
            "        \"on\": 1,\n" +
            "        \"hour\": 12,\n" +
            "        \"minute\": 30,\n" +
            "        \"day\": [\n" +
            "          1,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0\n" +
            "        ]\n" +
            "      },\n" +
            "      \"program2\": {\n" +
            "        \"on\": 0,\n" +
            "        \"hour\": 12,\n" +
            "        \"minute\": 30,\n" +
            "        \"day\": [\n" +
            "          0,\n" +
            "          1,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0\n" +
            "        ]\n" +
            "      },\n" +
            "      \"program3\": {\n" +
            "        \"on\": 0,\n" +
            "        \"hour\": 12,\n" +
            "        \"minute\": 30,\n" +
            "        \"day\": [\n" +
            "          0,\n" +
            "          0,\n" +
            "          1,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0\n" +
            "        ]\n" +
            "      },\n" +
            "      \"program4\": {\n" +
            "        \"on\": 0,\n" +
            "        \"hour\": 12,\n" +
            "        \"minute\": 30,\n" +
            "        \"day\": [\n" +
            "          0,\n" +
            "          0,\n" +
            "          0,\n" +
            "          1,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0\n" +
            "        ]\n" +
            "      }\n" +
            "    }\n" +
            "},\n" +
            " \"partner_id\": \"mdercz00\",\n" +
            " \"customer_id\": \"AC-ACNT200000240614\",\n" +
            " \"vin\": \"VR1ATTENTJY085311\",\n" +
            " \"processCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/processCallback\"},\n" +
            " \"responseCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/responseCallback\"}\n" +
            "}\n";

    String request_thermalPreconditioning_bad = "{\n" +
            "\"parameters\": {\n" +
            "    \"asap\": \"activate\",\n" +
            "    \"programs\": {\n" +
            "      \"program1\": {\n" +
            "        \"on\": 1,\n" +
            "        \"hour\": 12,\n" +
            "        \"minute\": 30,\n" +
            "        \"day\": [\n" +
            "          1,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0\n" +
            "        ]\n" +
            "      },\n" +
            "      \"program2\": {\n" +
            "        \"on\": 0,\n" +
            "        \"hour\": 12,\n" +
            "        \"minute\": 30,\n" +
            "        \"day\": [\n" +
            "          0,\n" +
            "          1,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0\n" +
            "        ]\n" +
            "      },\n" +
            "      \"program3\": {\n" +
            "        \"on\": 0,\n" +
            "        \"hour\": 12,\n" +
            "        \"minute\": 30,\n" +
            "        \"day\": [\n" +
            "          0,\n" +
            "          0,\n" +
            "          1,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0\n" +
            "        ]\n" +
            "      },\n" +
            "      \"program4\": {\n" +
            "        \"on\": 0,\n" +
            "        \"hour\": 12,\n" +
            "        \"minute\": 30,\n" +
            "        \"day\": [\n" +
            "          0,\n" +
            "          0,\n" +
            "          0,\n" +
            "          1,\n" +
            "          0,\n" +
            "          0,\n" +
            "          0\n" +
            "        ]\n" +
            "      }\n" +
            "    }\n" +
            "},\n" +
            " \"partner_id\": \"mdercz00\",\n" +
            " \"customer_id\": \"AC-ACNT200000240614\",\n" +
            " \"vin\": \"VR1ATT55ENTJY085311\",\n" +
            " \"processCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/processCallback\"},\n" +
            " \"responseCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/responseCallback\"}\n" +
            "}\n";

    String request_tracking = "{\n" +
            "  \"parameters\": {\n" +
            "    \"action\": \"activate\",\n" +
            "    \"period_run\": 15,\n" +
            "    \"period_shutdn\": 80\n" +
            "  },\n" +
            " \"partner_id\": \"mdercz00\",\n" +
            " \"customer_id\": \"AC-ACNT200000240614\",\n" +
            " \"vin\": \"VR1ATTENTJY085311\",\n" +
            " \"processCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/processCallback\"},\n" +
            " \"responseCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/responseCallback\"}\n" +
            "}";

    String request_stolenVin = "{\n" +
            "  \"parameters\": {\n" +
            "    \"partner_id\": \"partnerTest\",\n" +
            "    \"stolen_state\": 0\n" +
            "  },\n" +
            " \"partner_id\": \"mdercz00\",\n" +
            " \"customer_id\": \"AC-ACNT200000240614\",\n" +
            " \"vin\": \"VR1ATTENTJY085311\",\n" +
            " \"processCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/processCallback\"},\n" +
            " \"responseCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/responseCallback\"}\n" +
            "}";

    String request_tracking_bad = "{\n" +
            "\"parameters\": { \n" +
            "    \"action\": \"activate\",\n" +
            "    \"period_run\": 15,\n" +
            "    \"period_shutdn\": 80 }\n" +
            " \"partner_id\": \"mdercz00\",\n" +
            " \"customer_id\": \"AC-ACNT200000240614\",\n" +
            " \"vin\": \"VF3CA5FV8CjhkjhlW100631\",\n" +
            " \"processCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/processCallback\"},\n" +
            " \"responseCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/responseCallback\"}\n" +
            "}";

    String request_vehicleState = "{\n" +
            "  \"parameters\": {\n" +
            "    \"action\": \"state\"\n" +
            "  },\n" +
            " \"partner_id\": \"mdercz00\",\n" +
            " \"customer_id\": \"AC-ACNT200000240614\",\n" +
            " \"vin\": \"VR1ATTENTJY085311\",\n" +
            " \"processCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/processCallback\"},\n" +
            " \"responseCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/responseCallback\"}\n" +
            "}";

    String request_vehicleState_bad = "{\n" +
            "\"parameters\": { \n" +
            "    \"action\": \"state\" }\n" +
            " \"partner_id\": \"mdercz00\",\n" +
            " \"customer_id\": \"AC-ACNT200000240614\",\n" +
            " \"vin\": \"VF3BT61E09L6994khj568\",\n" +
            " \"processCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/processCallback\"},\n" +
            " \"responseCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/responseCallback\"}\n" +
            "}";

    String request_immobilization = "{\n" +
            "\"parameters\": {\n" +
            "    \"action\": \"activate\"\n" +
            "},\n" +
            " \"partner_id\": \"mdercz00\",\n" +
            " \"customer_id\": \"AC-ACNT200000240614\",\n" +
            " \"vin\": \"VF3CA5FV8CW100631\",\n" +
            " \"processCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/processCallback\"},\n" +
            " \"responseCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/responseCallback\"}\n" +
            "}";

    String request_immobilization_bad = "{\n" +
            "\"parameters\": {\n" +
            "    \"action\": \"activate\"\n" +
            "},\n" +
            " \"partner_id\": \"mdercz00\",\n" +
            " \"customer_id\": \"AC-ACNT200000240614\",\n" +
            " \"vin\": \"VF443CA5F00CW100631\",\n" +
            " \"processCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/processCallback\"},\n" +
            " \"responseCallback\" : {\n" +
            "    \"url\": \"http://localhost:8090/responseCallback\"}\n" +
            "}";


    @Test
    public void chargingTest() throws Exception {

        assertAction("/api/partner/remote/charging", request_charging);
    }

    @Test
    public void chargingTestKo() throws Exception {
        assertActionKo("/api/partner/remote/charging", request_charging_bad);
    }

    @Test
    public void chargingStateTest() throws Exception {

        assertAction("/api/partner/remote/chargingstate", request_chargingState);
    }

    @Test
    public void chargingStateTestKo() throws Exception {
        assertActionKo("/api/partner/remote/chargingstate", request_chargingState_bad);
    }

    @Test
    public void doorsTest() throws Exception {

        assertAction("/api/partner/remote/doors", request_doors);
    }

    @Test
    public void doorsTestKo() throws Exception {
        assertActionKo("/api/partner/remote/doors", request_doors_bad);
    }

    @Test
    public void hornTest() throws Exception {

        assertAction("/api/partner/remote/horn", request_horn);
    }

    @Test
    public void hornTestKo() throws Exception {
        assertActionKo("/api/partner/remote/horn", request_horn_bad);
    }

    @Test
    public void lightsTest() throws Exception {

        assertAction("/api/partner/remote/lights", request_lights);
    }

    @Test
    public void lightsTestKo() throws Exception {
        assertActionKo("/api/partner/remote/lights", request_lights_bad);
    }

    @Test
    public void lowPowerInfoTest() throws Exception {

        assertAction("/api/partner/remote/lowpowerinfo", request_lowPowerInfo);
    }

    @Test
    public void lowPowerInfoTestKo() throws Exception {
        assertActionKo("/api/partner/remote/lowpowerinfo", request_lowPowerInfo_bad);
    }

    @Test
    public void requestStateTest() throws Exception {
        assertAction("/api/partner/remote/requeststate", request_requestState);
    }

    @Test
    public void requeststateTestKo() throws Exception {
        assertActionKo("/api/partner/remote/requeststate", request_requestState_bad);
    }

    @Test
    public void thermalPreconditioningTest() throws Exception {
        assertAction("/api/partner/remote/thermalpreconditioning", request_thermalPreconditioning);
    }

    @Test
    public void thermalPreconditioningTestKo() throws Exception {
        assertActionKo("/api/partner/remote/thermalpreconditioning", request_thermalPreconditioning_bad);
    }

    @Test
    public void trackingTest() throws Exception {

        assertAction("/api/partner/remote/tracking", request_tracking);
    }

    @Test
    public void trackingTestKo() throws Exception {
        assertActionKo("/api/partner/remote/tracking", request_tracking_bad);
    }

    @Test
    public void vehicleStateTest() throws Exception {

        assertAction("/api/partner/remote/vehiclestate", request_vehicleState);
    }

    @Test
    public void vehiclestateTestKo() throws Exception {
        assertActionKo("/api/partner/remote/vehiclestate", request_vehicleState_bad);
    }

    @Test
    public void stolenVinTest() throws Exception {
        assertAction("/api/partner/stolen", request_stolenVin);
    }

    @Test
    public void stolenVinTestKo() throws Exception {
        String actionUrl = "/api/partner/stolen";
        assertActionKo(actionUrl, request_tracking_bad);
    }


    @Test
    public void immobilizationStolenTest() throws Exception {

        String actionUrl = "/api/partner/stolen/immobilization";
        assertAction(actionUrl, request_immobilization);
    }


    @Test
    public void immobilizationStolenTestKo() throws Exception {
        assertActionKo("/api/partner/stolen/immobilization", request_immobilization_bad);
    }

    @Test
    public void immobilizationTest() throws Exception {

        String actionUrl = "/api/partner/remote/immobilization";
        assertAction(actionUrl, request_immobilization);
    }


    @Test
    public void immobilizationTestKo() throws Exception {
        assertActionKo("/api/partner/remote/immobilization", request_immobilization_bad);
    }


}
