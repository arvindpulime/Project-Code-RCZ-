DO
$$
    DECLARE
        startDate date := current_date - interval '38 month';
    BEGIN
        delete from rczqtexchange where receiveddate <startDate;

        delete
        from rczqtlog
        where exchangeid in (
            select log.exchangeid
            from rczqtlog log
            where log.exchangeid not in (
                select ex.id
                from rczqtexchange ex
            )
        );
    END
$$;