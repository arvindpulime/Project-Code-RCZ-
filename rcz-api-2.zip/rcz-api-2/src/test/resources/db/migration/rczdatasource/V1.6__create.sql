alter table RCZQTPARAMETER add messageBinary boolean;
UPDATE rczqtvehicle SET provider = 'OFR' WHERE btaType = 'BSRF' and updateDate < '2022-02-05';
