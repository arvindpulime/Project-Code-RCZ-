create table if not exists rczqtmonitoringinfo
(
    instance       varchar(255) not null,
    "type"         varchar(255) not null,
    updateDate     timestamp,
    "data"      text,
    constraint rczqtmonitoring_pkey
        primary key (instance, "type")
);