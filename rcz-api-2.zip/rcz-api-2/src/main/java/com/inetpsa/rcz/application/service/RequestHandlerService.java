package com.inetpsa.rcz.application.service;

import com.inetpsa.rcz.application.exception.ApplicationException;
import com.inetpsa.rcz.application.representation.ClientRequestRepresentation;
import com.inetpsa.rcz.application.representation.PartnerRequestRepresentation;
import com.inetpsa.rcz.domain.model.action.Action;
import com.inetpsa.rcz.domain.model.api.request.Request;
import org.seedstack.business.Service;

@Service
public interface RequestHandlerService {

    <T> Request handle(ClientRequestRepresentation<T> clientRequestRepresentation, Action action) throws ApplicationException;

    <T> Request handle(PartnerRequestRepresentation<T> partnerRequestRepresentation, Action action) throws ApplicationException;

}
