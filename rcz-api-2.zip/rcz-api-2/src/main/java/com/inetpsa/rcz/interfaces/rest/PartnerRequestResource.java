package com.inetpsa.rcz.interfaces.rest;

import com.inetpsa.rcz.application.exception.ApplicationException;
import com.inetpsa.rcz.application.representation.PartnerRequestRepresentation;
import com.inetpsa.rcz.application.representation.ResponseRepresentation;
import com.inetpsa.rcz.application.service.RequestHandlerService;
import com.inetpsa.rcz.domain.model.action.Action;
import com.inetpsa.rcz.domain.model.api.request.Request;
import com.inetpsa.rcz.domain.model.payload.data.*;
import com.inetpsa.rcz.interfaces.shared.ErrorResponse;
import com.inetpsa.rcz.interfaces.shared.ApiDescriptions;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import static com.inetpsa.rcz.interfaces.rest.ClientRequestResource.getErrorResponse;

@Api
@Path("partner")
public class PartnerRequestResource {

    @Inject
    private RequestHandlerService requestHandlerService;

    protected <T> javax.ws.rs.core.Response handlePartnerRemote(PartnerRequestRepresentation<T> partnerRequestRepresentation, Action action) {
        try {
            Request request = requestHandlerService.handle(partnerRequestRepresentation, action);
            return javax.ws.rs.core.Response.ok(new ResponseRepresentation().setCorrelationId(request.getId())).build();
        } catch (ApplicationException e) {
            return getErrorResponse(e);
        }
    }

    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("remote/charging")
    @POST
    @ApiOperation(value = ApiDescriptions.CHARGING)
    @ApiResponses({@ApiResponse(response = ResponseRepresentation.class, code = 200, message = ApiDescriptions.CHARGING_RESPONSE),
            @ApiResponse(response = ErrorResponse.class, code = 400, message = ApiDescriptions.BAD_REQUEST),
            @ApiResponse(code = 401, message = ApiDescriptions.UNAUTHORIZED),
            @ApiResponse(response = ErrorResponse.class, code = 500, message = ApiDescriptions.INTERNAL_SERVER_ERROR)})
    public Response charging(PartnerRequestRepresentation<Charging> partnerRequestRepresentation) {
        return handlePartnerRemote(partnerRequestRepresentation, Action.CHARGING);
    }

    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("remote/chargingstate")
    @POST
    @ApiOperation(value = ApiDescriptions.CHARGINGSTATE)
    @ApiResponses({@ApiResponse(response = ResponseRepresentation.class, code = 200, message = ApiDescriptions.CHARGINGSTATE_RESPONSE),
            @ApiResponse(response = ErrorResponse.class, code = 400, message = ApiDescriptions.BAD_REQUEST),
            @ApiResponse(code = 401, message = ApiDescriptions.UNAUTHORIZED),
            @ApiResponse(response = ErrorResponse.class, code = 500, message = ApiDescriptions.INTERNAL_SERVER_ERROR)})
    public Response chargingState(PartnerRequestRepresentation<VehicleChargingState> partnerRequestRepresentation) {
        return handlePartnerRemote(partnerRequestRepresentation, Action.CHARGING_STATE);
    }

    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("remote/doors")
    @POST
    @ApiOperation(value = ApiDescriptions.DOORS)
    @ApiResponses({@ApiResponse(response = ResponseRepresentation.class, responseContainer = "List", code = 200, message = ApiDescriptions.DOORS_RESPONSE),
            @ApiResponse(response = ErrorResponse.class, code = 400, message = ApiDescriptions.BAD_REQUEST),
            @ApiResponse(code = 401, message = ApiDescriptions.UNAUTHORIZED),
            @ApiResponse(response = ErrorResponse.class, code = 500, message = ApiDescriptions.INTERNAL_SERVER_ERROR)})
    public Response doors(PartnerRequestRepresentation<DoorsRequest> partnerRequestRepresentation) {
        return handlePartnerRemote(partnerRequestRepresentation, Action.DOORS);
    }

    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("remote/horn")
    @POST
    @ApiOperation(value = ApiDescriptions.HORN)
    @ApiResponses({@ApiResponse(response = ResponseRepresentation.class, code = 200, message = ApiDescriptions.HORN_RESPONSE),
            @ApiResponse(response = ErrorResponse.class, code = 400, message = ApiDescriptions.BAD_REQUEST),
            @ApiResponse(code = 401, message = ApiDescriptions.UNAUTHORIZED),
            @ApiResponse(response = ErrorResponse.class, code = 500, message = ApiDescriptions.INTERNAL_SERVER_ERROR)})
    public Response horn(PartnerRequestRepresentation<Horn> partnerRequestRepresentation) {
        return handlePartnerRemote(partnerRequestRepresentation, Action.HORN);
    }

    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("remote/lights")
    @POST
    @ApiOperation(value = ApiDescriptions.LIGHTS)
    @ApiResponses({@ApiResponse(response = ResponseRepresentation.class, code = 200, message = ApiDescriptions.LIGHTS_RESPONSE),
            @ApiResponse(response = ErrorResponse.class, code = 400, message = ApiDescriptions.BAD_REQUEST),
            @ApiResponse(code = 401, message = ApiDescriptions.UNAUTHORIZED),
            @ApiResponse(response = ErrorResponse.class, code = 500, message = ApiDescriptions.INTERNAL_SERVER_ERROR)})
    public Response lights(PartnerRequestRepresentation<Lights> partnerRequestRepresentation) {
        return handlePartnerRemote(partnerRequestRepresentation, Action.LIGHTS);
    }

    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("remote/lowpowerinfo")
    @POST
    @ApiOperation(value = ApiDescriptions.LOWPOWERINFO)
    @ApiResponses({@ApiResponse(response = ResponseRepresentation.class, code = 200, message = ApiDescriptions.LOWPOWERINFO_RESPONSE),
            @ApiResponse(response = ErrorResponse.class, code = 400, message = ApiDescriptions.BAD_REQUEST),
            @ApiResponse(code = 401, message = ApiDescriptions.UNAUTHORIZED),
            @ApiResponse(response = ErrorResponse.class, code = 500, message = ApiDescriptions.INTERNAL_SERVER_ERROR)})
    public Response lowPowerInfo(PartnerRequestRepresentation<LowPowerInfoRequest> partnerRequestRepresentation) {
        return handlePartnerRemote(partnerRequestRepresentation, Action.LOW_POWER_INFO);
    }

    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("remote/requeststate")
    @POST
    @ApiOperation(value = ApiDescriptions.REQUESTSTATE)
    @ApiResponses({@ApiResponse(response = ResponseRepresentation.class, code = 200, message = ApiDescriptions.REQUESTSTATE_RESPONSE),
            @ApiResponse(response = ErrorResponse.class, code = 400, message = ApiDescriptions.BAD_REQUEST),
            @ApiResponse(code = 401, message = ApiDescriptions.UNAUTHORIZED),
            @ApiResponse(response = ErrorResponse.class, code = 500, message = ApiDescriptions.INTERNAL_SERVER_ERROR)})
    public Response requestState(PartnerRequestRepresentation<RequestState> partnerRequestRepresentation) {
        return handlePartnerRemote(partnerRequestRepresentation, Action.REQUEST_STATE);
    }

    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("remote/thermalpreconditioning")
    @POST
    @ApiOperation(value = ApiDescriptions.THERMALPRECONDITIONING)
    @ApiResponses({@ApiResponse(response = ResponseRepresentation.class, code = 200, message = ApiDescriptions.THERMALPRECONDITIONING_RESPONSE),
            @ApiResponse(response = ErrorResponse.class, code = 400, message = ApiDescriptions.BAD_REQUEST),
            @ApiResponse(code = 401, message = ApiDescriptions.UNAUTHORIZED),
            @ApiResponse(response = ErrorResponse.class, code = 500, message = ApiDescriptions.INTERNAL_SERVER_ERROR)})
    public Response thermalPreconditioning(PartnerRequestRepresentation<Preconditioning> partnerRequestRepresentation) {
        return handlePartnerRemote(partnerRequestRepresentation, Action.THERMAL_PRECONDITIONING);
    }

    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @POST
    @ApiOperation(value = ApiDescriptions.TRACKING)
    @Path("remote/tracking")
    @ApiResponses({@ApiResponse(response = ResponseRepresentation.class, responseContainer = "List", code = 200, message = ApiDescriptions.TRACKING_RESPONSE),
            @ApiResponse(response = ErrorResponse.class, code = 400, message = ApiDescriptions.BAD_REQUEST),
            @ApiResponse(code = 401, message = ApiDescriptions.UNAUTHORIZED),
            @ApiResponse(response = ErrorResponse.class, code = 500, message = ApiDescriptions.INTERNAL_SERVER_ERROR)})
    public Response tracking(PartnerRequestRepresentation<Tracking> partnerRequestRepresentation) {
        return handlePartnerRemote(partnerRequestRepresentation, Action.TRACKING);
    }

    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("remote/vehiclestate")
    @POST
    @ApiOperation(value = ApiDescriptions.VEHICLESTATE)
    @ApiResponses({@ApiResponse(response = ResponseRepresentation.class, code = 200, message = ApiDescriptions.VEHICLESTATE_RESPONSE),
            @ApiResponse(response = ErrorResponse.class, code = 400, message = ApiDescriptions.BAD_REQUEST),
            @ApiResponse(code = 401, message = ApiDescriptions.UNAUTHORIZED),
            @ApiResponse(response = ErrorResponse.class, code = 500, message = ApiDescriptions.INTERNAL_SERVER_ERROR)})
    public Response vehicleState(PartnerRequestRepresentation<VehicleState> partnerRequestRepresentation) {
        return handlePartnerRemote(partnerRequestRepresentation, Action.VEHICLE_STATE);
    }

    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("remote/immobilization")
    @POST
    @ApiOperation(value = ApiDescriptions.IMMOBILIZATION)
    @ApiResponses({@ApiResponse(response = ResponseRepresentation.class, code = 200, message = ApiDescriptions.IMMOBILIZATION_RESPONSE),
            @ApiResponse(response = ErrorResponse.class, code = 400, message = ApiDescriptions.BAD_REQUEST),
            @ApiResponse(code = 401, message = ApiDescriptions.UNAUTHORIZED),
            @ApiResponse(response = ErrorResponse.class, code = 500, message = ApiDescriptions.INTERNAL_SERVER_ERROR)})
    public Response immobilization(PartnerRequestRepresentation<Immobilization> partnerRequestRepresentation) {
        return handlePartnerRemote(partnerRequestRepresentation, Action.IMMOBILIZATION);
    }

    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("stolen")
    @POST
    @ApiOperation(value = ApiDescriptions.STOLENVIN)
    @ApiResponses({@ApiResponse(response = ResponseRepresentation.class, code = 200, message = ApiDescriptions.STOLENVIN_RESPONSE),
            @ApiResponse(response = ErrorResponse.class, code = 400, message = ApiDescriptions.BAD_REQUEST),
            @ApiResponse(code = 401, message = ApiDescriptions.UNAUTHORIZED),
            @ApiResponse(response = ErrorResponse.class, code = 500, message = ApiDescriptions.INTERNAL_SERVER_ERROR)})
    public Response stolenVin(PartnerRequestRepresentation<StolenVin> partnerRequestRepresentation) {
        return handlePartnerRemote(partnerRequestRepresentation, Action.STOLEN_VIN);
    }


    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("stolen/immobilization")
    @POST
    @ApiOperation(value = ApiDescriptions.IMMOBILIZATION)
    @ApiResponses({@ApiResponse(response = ResponseRepresentation.class, code = 200, message = ApiDescriptions.IMMOBILIZATION_RESPONSE),
            @ApiResponse(response = ErrorResponse.class, code = 400, message = ApiDescriptions.BAD_REQUEST),
            @ApiResponse(code = 401, message = ApiDescriptions.UNAUTHORIZED),
            @ApiResponse(response = ErrorResponse.class, code = 500, message = ApiDescriptions.INTERNAL_SERVER_ERROR)})
    public Response immobilizationStolen(PartnerRequestRepresentation<Immobilization> partnerRequestRepresentation) {
        return handlePartnerRemote(partnerRequestRepresentation, Action.IMMOBILIZATION_STOLEN);
    }

    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("stolen/lowpowerinfo")
    @POST
    @ApiOperation(value = ApiDescriptions.LOWPOWERINFO)
    @ApiResponses({@ApiResponse(response = ResponseRepresentation.class, code = 200, message = ApiDescriptions.LOWPOWERINFO_RESPONSE),
            @ApiResponse(response = ErrorResponse.class, code = 400, message = ApiDescriptions.BAD_REQUEST),
            @ApiResponse(code = 401, message = ApiDescriptions.UNAUTHORIZED),
            @ApiResponse(response = ErrorResponse.class, code = 500, message = ApiDescriptions.INTERNAL_SERVER_ERROR)})
    public Response stolenLowPowerInfo(PartnerRequestRepresentation<LowPowerInfoRequest> partnerRequestRepresentation) {
        return handlePartnerRemote(partnerRequestRepresentation, Action.LOW_POWER_INFO_STOLEN);
    }

    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("stolen/requeststate")
    @POST
    @ApiOperation(value = ApiDescriptions.REQUESTSTATE)
    @ApiResponses({@ApiResponse(response = ResponseRepresentation.class, code = 200, message = ApiDescriptions.REQUESTSTATE_RESPONSE),
            @ApiResponse(response = ErrorResponse.class, code = 400, message = ApiDescriptions.BAD_REQUEST),
            @ApiResponse(code = 401, message = ApiDescriptions.UNAUTHORIZED),
            @ApiResponse(response = ErrorResponse.class, code = 500, message = ApiDescriptions.INTERNAL_SERVER_ERROR)})
    public Response stolenRequestState(PartnerRequestRepresentation<RequestState> partnerRequestRepresentation) {
        return handlePartnerRemote(partnerRequestRepresentation, Action.REQUEST_STATE_STOLEN);
    }

    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("stolen/vehiclestate")
    @POST
    @ApiOperation(value = ApiDescriptions.VEHICLESTATE)
    @ApiResponses({@ApiResponse(response = ResponseRepresentation.class, code = 200, message = ApiDescriptions.VEHICLESTATE_RESPONSE),
            @ApiResponse(response = ErrorResponse.class, code = 400, message = ApiDescriptions.BAD_REQUEST),
            @ApiResponse(code = 401, message = ApiDescriptions.UNAUTHORIZED),
            @ApiResponse(response = ErrorResponse.class, code = 500, message = ApiDescriptions.INTERNAL_SERVER_ERROR)})
    public Response stolenVehicleState(PartnerRequestRepresentation<VehicleState> partnerRequestRepresentation) {
        return handlePartnerRemote(partnerRequestRepresentation, Action.VEHICLE_STATE_STOLEN);
    }

}
