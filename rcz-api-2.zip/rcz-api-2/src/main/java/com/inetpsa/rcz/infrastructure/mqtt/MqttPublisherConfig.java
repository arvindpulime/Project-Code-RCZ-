package com.inetpsa.rcz.infrastructure.mqtt;

import org.seedstack.coffig.Config;

import java.util.ArrayList;
import java.util.List;

@Config("mqttPublisherConfig")
public class MqttPublisherConfig {

    private int qos = 0;
    private String partnerId;
    private boolean retained = false;
    private List<String> clientNames = new ArrayList<>();

    public int getQos() {
        return qos;
    }

    public MqttPublisherConfig setQos(int qos) {
        this.qos = qos;
        return this;
    }


    public boolean isRetained() {
        return retained;
    }

    public MqttPublisherConfig setRetained(boolean retained) {
        this.retained = retained;
        return this;
    }

    public List<String> getClientNames() {
        return clientNames;
    }

    public MqttPublisherConfig setClientNames(List<String> clientNames) {
        this.clientNames = clientNames;
        return this;
    }

    public String getPartnerId() {
        return partnerId;
    }

    public MqttPublisherConfig setPartnerId(String partnerId) {
        this.partnerId = partnerId;
        return this;
    }
}
