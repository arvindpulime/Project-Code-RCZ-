package com.inetpsa.rcz.interfaces.shared;

public final class ApiDescriptions {

    public static final String CHARGING = "Charging";
    public static final String CHARGING_RESPONSE = "Charging report";
    public static final String CHARGINGSTATE = "ChargingState";
    public static final String CHARGINGSTATE_RESPONSE = "ChargingState report";
    public static final String HORN = "Horn";
    public static final String HORN_RESPONSE = "Horn response";
    public static final String LIGHTS = "Lights";
    public static final String LIGHTS_RESPONSE = "Lights response";
    public static final String DOORS = "Doors";
    public static final String DOORS_RESPONSE = "Doors response";
    public static final String IMMOBILIZATION = "Immobilization";
    public static final String IMMOBILIZATION_RESPONSE = "Immobilization response";
    public static final String LOWPOWERINFO = "LowPowerInfo";
    public static final String LOWPOWERINFO_RESPONSE = "LowPowerInfo response";
    public static final String TRACKING = "Tracking";
    public static final String TRACKING_RESPONSE = "Tracking response";
    public static final String REQUESTSTATE = "RequestState";
    public static final String REQUESTSTATE_RESPONSE = "RequestState response";
    public static final String STOLENVIN = "StolenVin";
    public static final String STOLENVIN_RESPONSE = "StolenVin response";
    public static final String VEHICLESTATE = "VehicleState";
    public static final String VEHICLESTATE_RESPONSE = "VehicleState response";
    public static final String THERMALPRECONDITIONING = "ThermalPreconditioning";
    public static final String THERMALPRECONDITIONING_RESPONSE = "ThermalPreconditioning response";

    public static final String RESPONSE_MESSAGE = "Response message";
    public static final String RESPONSE_CODE = "Response code";
    public static final String BAD_REQUEST = "Bad request";
    public static final String INTERNAL_SERVER_ERROR = "Internal server error ";
    public static final String UNAUTHORIZED = "Unauthorized";
}

