package com.inetpsa.rcz.application.service;

import org.seedstack.business.Service;

@Service
public interface PublisherService<T> {
    void publish(String message, T target);
}
