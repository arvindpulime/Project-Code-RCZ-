package com.inetpsa.rcz.application.exception;

public class WebExeption extends RuntimeException {

    public WebExeption() {
    }

    public WebExeption(String message) {
        super(message);
    }

    public WebExeption(String message, Throwable cause) {
        super(message, cause);
    }

    public WebExeption(Throwable cause) {
        super(cause);
    }

    public WebExeption(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
