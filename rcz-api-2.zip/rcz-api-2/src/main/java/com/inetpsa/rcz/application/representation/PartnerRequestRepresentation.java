package com.inetpsa.rcz.application.representation;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.inetpsa.rcz.domain.model.payload.ValidationPattern;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PartnerRequestRepresentation<R> extends RequestRepresentation<R> {
    @NotNull
    @Pattern(regexp = ValidationPattern.PATTERN_ID_PARTNER)
    @JsonProperty("partner_id")
    private String partnerId;

    public String getPartnerId() {
        return partnerId;
    }


    public PartnerRequestRepresentation<R> setPartnerId(String partnerId) {
        this.partnerId = partnerId;
        return this;
    }
}
