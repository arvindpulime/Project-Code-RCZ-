package com.inetpsa.rcz.infrastructure.kafka;

import org.seedstack.coffig.Config;

@Config("kafka")
public class KafkaConfig {
    private String responseTopic;

    public KafkaConfig() {
    }

    public String getResponseTopic() {
        return responseTopic;
    }

    public KafkaConfig setResponseTopic(String responseTopic) {
        this.responseTopic = responseTopic;
        return this;
    }
}
