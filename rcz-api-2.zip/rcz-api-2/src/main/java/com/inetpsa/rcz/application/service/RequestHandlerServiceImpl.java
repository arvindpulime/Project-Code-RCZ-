package com.inetpsa.rcz.application.service;

import com.inetpsa.rcz.application.exception.ApplicationException;
import com.inetpsa.rcz.application.representation.ClientRequestRepresentation;
import com.inetpsa.rcz.application.representation.PartnerRequestRepresentation;
import com.inetpsa.rcz.application.representation.RequestRepresentation;
import com.inetpsa.rcz.domain.model.action.Action;
import com.inetpsa.rcz.domain.model.api.request.Request;
import com.inetpsa.rcz.domain.model.enums.CallerType;
import com.inetpsa.rcz.domain.model.payload.request.RequestPayload;
import com.inetpsa.rcz.domain.model.payload.topic.Topic;
import com.inetpsa.rcz.domain.model.shared.Payload;
import com.inetpsa.rcz.domain.services.RequestService;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;
import com.inetpsa.rcz.infrastructure.mqtt.MqttPublisherConfig;
import org.seedstack.business.domain.Factory;
import org.seedstack.seed.Configuration;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.Date;

public class RequestHandlerServiceImpl implements RequestHandlerService {

    @Inject
    @Named("mqtt")
    public PublisherService<String> publisherService;

    @Inject
    RequestService requestService;

    @Inject
    Factory<Request> requestFactory;

    @Inject
    private ValidationService validationService;

    @Configuration
    private MqttPublisherConfig mqttPublisherConfig;

    @Override
    public <T> Request handle(ClientRequestRepresentation<T> clientRequestRepresentation, Action action) throws ApplicationException {
        validationService.validateRequest(clientRequestRepresentation);
        Request request = buildClientRequest(clientRequestRepresentation, action);
        requestService.save(request);
        RequestPayload<T> requestPayload = buildClientRequestPayload(clientRequestRepresentation, request);
        String payload = JsonConverter.convert(requestPayload);
        String topic = buildTopic(request);
        publisherService.publish(payload, topic);
        return request;
    }


    @Override
    public <T> Request handle(PartnerRequestRepresentation<T> partnerRequestRepresentation, Action action) throws ApplicationException {
        validationService.validateRequest(partnerRequestRepresentation);
        Request request = buildPartnerRequest(partnerRequestRepresentation, action);
        requestService.save(request);
        RequestPayload<T> requestPayload = buildPartnerRequestPayload(partnerRequestRepresentation, request);
        String payload = JsonConverter.convert(requestPayload);
        String topic = buildTopic(request);
        publisherService.publish(payload, topic);
        return request;
    }

    private String buildTopic(Request request) {
        StringBuilder stringBuilder = new StringBuilder("psa");
        stringBuilder.append("/")
                .append(request.getAction().getActionService().literal())
                .append("/")
                .append(Topic.Direction.FROM.literal())
                .append("/")
                .append(CallerType.PARTNER.code())
                .append("/")
                .append(mqttPublisherConfig.getPartnerId())
                .append("/")
                .append(request.getAction().getActionType().literal());
        return stringBuilder.toString();
    }

    private <T> RequestPayload<T> buildClientRequestPayload(ClientRequestRepresentation<T> clientRequestRepresentation, Request request) {
        RequestPayload<T> requestPayload = buildRequestPayload(clientRequestRepresentation, request);
        requestPayload.setAccessToken(clientRequestRepresentation.getAccessToken());
        requestPayload.setCustomerId(clientRequestRepresentation.getCustomerId());
        return requestPayload;
    }

    private <T> RequestPayload<T> buildPartnerRequestPayload(PartnerRequestRepresentation<T> partnerRequestRepresentation, Request request) {
        RequestPayload<T> requestPayload = buildRequestPayload(partnerRequestRepresentation, request);
        requestPayload.setCustomerId(partnerRequestRepresentation.getPartnerId());
        return requestPayload;
    }

    private <T> RequestPayload<T> buildRequestPayload(RequestRepresentation<T> clientRequestRepresentation, Request request) {
        RequestPayload<T> requestPayload;
        requestPayload = new RequestPayload<>();
        requestPayload.setCorrelationId(request.getId());
        requestPayload.setRequestDate(new Date());
        requestPayload.setVin(clientRequestRepresentation.getVin());
        requestPayload.setRequestParameters(clientRequestRepresentation.getParameters());
        return requestPayload;
    }

    private <T> Request buildClientRequest(ClientRequestRepresentation<T> clientRequestRepresentation, Action action) {
        Request request = buildRequest(clientRequestRepresentation, action);
        request.setCallerType(CallerType.CLIENT);
        request.setCallerId(clientRequestRepresentation.getCustomerId());
        request.setRequest(new Payload(new Date(), JsonConverter.convert(clientRequestRepresentation)));
        return request;
    }


    private <T> Request buildPartnerRequest(PartnerRequestRepresentation<T> partnerRequestRepresentation, Action action) {
        Request request = buildRequest(partnerRequestRepresentation, action);
        request.setCallerType(CallerType.PARTNER);
        request.setCustomerId(partnerRequestRepresentation.getPartnerId());
        request.setCallerId(partnerRequestRepresentation.getPartnerId());
        request.setRequest(new Payload(new Date(), JsonConverter.convert(partnerRequestRepresentation)));
        return request;
    }

    private <T> Request buildRequest(RequestRepresentation<T> requestRepresentation, Action action) {
        Request request = requestFactory.create();
        request.setAction(action);
        request.setVin(requestRepresentation.getVin());
        return request;
    }

}
