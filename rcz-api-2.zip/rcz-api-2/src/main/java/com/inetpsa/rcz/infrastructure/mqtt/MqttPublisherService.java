package com.inetpsa.rcz.infrastructure.mqtt;

import com.google.inject.Injector;
import com.google.inject.Key;
import com.google.inject.name.Names;
import com.inetpsa.rcz.application.service.PublisherService;
import org.eclipse.paho.client.mqttv3.IMqttClient;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.MqttTopic;
import org.seedstack.seed.Application;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;

@Named("mqtt")
public class MqttPublisherService implements PublisherService<String> {


    @Configuration
    private MqttPublisherConfig mqttPublisherConfig;

    @Inject
    private Injector injector;

    @Logging
    private Logger logger;

    public MqttPublisherService() {
    }

    public void publish(final MqttMessage message, String topic) {
        mqttPublisherConfig.getClientNames().forEach(client -> {
            IMqttClient mqttClient = injector.getInstance(Key.get(IMqttClient.class, Names.named(client)));
            try {
                MqttTopic mqttTopic = mqttClient.getTopic(topic);
                mqttTopic.publish(message);
                logger.debug("PUBLISH TO SERVER : [{}], TOPIC [{}]", client, topic);
            } catch (Exception e) {//NOSONAR
                logger.error(client, e);
            }
        });
    }

    @Override
    public void publish(String message, String topic) {
        MqttMessage mqttMessage = new MqttMessage();
        mqttMessage.setPayload(message.getBytes());
        mqttMessage.setQos(mqttPublisherConfig.getQos());
        mqttMessage.setRetained(mqttPublisherConfig.isRetained());
        publish(mqttMessage, topic);
    }


}
