package com.inetpsa.rcz.application.service;

import com.inetpsa.rcz.application.exception.ApplicationException;
import org.seedstack.business.Service;

@Service
public interface ResponseHandlerService {
    void handle(String response, String topic) throws ApplicationException;
}
