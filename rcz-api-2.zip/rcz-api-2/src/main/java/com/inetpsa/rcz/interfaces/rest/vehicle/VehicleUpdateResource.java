package com.inetpsa.rcz.interfaces.rest.vehicle;

import com.inetpsa.rcz.application.exception.WebExeption;
import com.inetpsa.rcz.domain.model.vehicle.Vehicle;
import com.inetpsa.rcz.domain.repository.VehicleRepository;
import com.inetpsa.rcz.domain.services.PayloadValidationService;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;
import io.swagger.annotations.Api;
import org.seedstack.business.assembler.Assembler;
import org.seedstack.business.domain.Factory;
import org.seedstack.business.modelmapper.ModelMapper;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.Logging;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.text.MessageFormat;
import java.util.Date;
import java.util.Optional;
import java.util.Set;

@Api
@Path("/vehicle")
@JpaUnit("rcz")
@Transactional
public class VehicleUpdateResource {

    public static final String ERROR_FOR_VEHICLE_REQUEST = "Vehicles updates ERROR : [{0}]";
    public static final String VEHICLE_VALIDATION_ERROR = "Vehicle validation ERROR";
    @Logging
    private Logger logger;

    @Inject
    private VehicleRepository vehicleRepository;

    @Inject
    @ModelMapper
    private Assembler<Vehicle, VehicleUpdateRepresentation> vehicleAssembler;

    @Inject
    private PayloadValidationService validationService;

    @Inject
    private Factory<Vehicle> vehicleFactory;


    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    public Response save(Set<VehicleUpdateRepresentation> vehicleRepresentations) {
        try {
            if (vehicleRepresentations == null || vehicleRepresentations.isEmpty()) {
                return Response.status(Response.Status.BAD_REQUEST).build();
            }
            if (vehicleRepresentations.size() > 1) {
                updateVehiclesAsynchronously(vehicleRepresentations);
            } else {
                updateVehicles(vehicleRepresentations);
            }
        } catch (WebExeption e) {
            logger.error(e.getMessage(), e);
            return Response.serverError().build();
        }
        return Response.ok().build();
    }

    protected void updateVehiclesAsynchronously(Set<VehicleUpdateRepresentation> vehicleRepresentations) {
        vehicleRepresentations.parallelStream().forEach(vehicleRepresentation -> {
            try {
                save(vehicleRepresentation);
            } catch (WebExeption e) {
                logger.error(MessageFormat.format(ERROR_FOR_VEHICLE_REQUEST, JsonConverter.convert(vehicleRepresentation)), e);
            }
        });
    }

    protected void updateVehicles(Set<VehicleUpdateRepresentation> vehicleRepresentations) throws WebExeption {
        for (VehicleUpdateRepresentation vehicleRepresentation : vehicleRepresentations) {
            save(vehicleRepresentation);
        }
    }

    //TODO TEST
    protected void save(VehicleUpdateRepresentation vehicleRepresentation) throws WebExeption {
        try {
            validationService.validateRequest(vehicleRepresentation);
            Optional<Vehicle> vehicle = vehicleRepository.get(vehicleRepresentation.getUin());
            if (!vehicle.isPresent()) {
                vehicle = Optional.of(vehicleFactory.create(vehicleRepresentation.getUin()));
            }
            vehicleAssembler.mergeDtoIntoAggregate(vehicleRepresentation, vehicle.get());
            vehicle.get().setUpdateDate(new Date());
            vehicleRepository.addOrUpdate(vehicle.get());
        } catch (Exception e) {
            throw new WebExeption(VEHICLE_VALIDATION_ERROR, e);
        }
    }

}
