package com.inetpsa.rcz.interfaces.rest;

import com.inetpsa.rcz.application.exception.ApplicationException;
import com.inetpsa.rcz.application.exception.ErrorCode;
import com.inetpsa.rcz.application.representation.ClientRequestRepresentation;
import com.inetpsa.rcz.application.representation.ResponseRepresentation;
import com.inetpsa.rcz.application.service.RequestHandlerService;
import com.inetpsa.rcz.domain.model.action.Action;
import com.inetpsa.rcz.domain.model.api.request.Request;
import com.inetpsa.rcz.domain.model.payload.data.*;
import com.inetpsa.rcz.interfaces.shared.ErrorResponse;
import com.inetpsa.rcz.interfaces.shared.ApiDescriptions;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Api
@Path("customer/remote")
public class ClientRequestResource {

    @Inject
    private RequestHandlerService requestHandlerService;

    protected <T> Response handleClientRemote(ClientRequestRepresentation<T> clientRequestRepresentation, Action action) {
        try {
            Request request = requestHandlerService.handle(clientRequestRepresentation, action);
            return Response.ok(new ResponseRepresentation().setCorrelationId(request.getId())).build();
        } catch (ApplicationException e) {
            return getErrorResponse(e);
        }
    }

    public static Response getErrorResponse(ApplicationException e) {
        if (ErrorCode.VALIDATION_ERROR.equals(e.getErrorCode())) {
            return Response.status(Response.Status.BAD_REQUEST).entity(new ErrorResponse().setCode(e.getErrorCode()).setMessage(e.getMessage())).build();
        }
        return Response.serverError().entity(new ErrorResponse().setCode(e.getErrorCode()).setMessage(e.getMessage())).build();
    }

    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("charging")
    @POST
    @ApiOperation(value = ApiDescriptions.CHARGING)
    @ApiResponses({@ApiResponse(response = ResponseRepresentation.class, code = 200, message = ApiDescriptions.CHARGING_RESPONSE),
            @ApiResponse(response = ErrorResponse.class, code = 400, message = ApiDescriptions.BAD_REQUEST),
            @ApiResponse(code = 401, message = ApiDescriptions.UNAUTHORIZED),
            @ApiResponse(response = ErrorResponse.class, code = 500, message = ApiDescriptions.INTERNAL_SERVER_ERROR)})
    public Response charging(ClientRequestRepresentation<Charging> clientRequestRepresentation) {
        return handleClientRemote(clientRequestRepresentation, Action.CHARGING);
    }


    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("chargingstate")
    @POST
    @ApiOperation(value = ApiDescriptions.CHARGINGSTATE)
    @ApiResponses({@ApiResponse(response = ResponseRepresentation.class, code = 200, message = ApiDescriptions.CHARGINGSTATE_RESPONSE),
            @ApiResponse(response = ErrorResponse.class, code = 400, message = ApiDescriptions.BAD_REQUEST),
            @ApiResponse(code = 401, message = ApiDescriptions.UNAUTHORIZED),
            @ApiResponse(response = ErrorResponse.class, code = 500, message = ApiDescriptions.INTERNAL_SERVER_ERROR)})
    public Response chargingState(ClientRequestRepresentation<VehicleChargingState> clientRequestRepresentation) {
        return handleClientRemote(clientRequestRepresentation, Action.CHARGING_STATE);
    }

    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("doors")
    @POST
    @ApiOperation(value = ApiDescriptions.DOORS)
    @ApiResponses({@ApiResponse(response = ResponseRepresentation.class, responseContainer = "List", code = 200, message = ApiDescriptions.DOORS_RESPONSE),
            @ApiResponse(response = ErrorResponse.class, code = 400, message = ApiDescriptions.BAD_REQUEST),
            @ApiResponse(code = 401, message = ApiDescriptions.UNAUTHORIZED),
            @ApiResponse(response = ErrorResponse.class, code = 500, message = ApiDescriptions.INTERNAL_SERVER_ERROR)})
    public Response doors(ClientRequestRepresentation<DoorsRequest> clientRequestRepresentation) {

        return handleClientRemote(clientRequestRepresentation, Action.DOORS);
    }

    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("horn")
    @POST
    @ApiOperation(value = ApiDescriptions.HORN)
    @ApiResponses({@ApiResponse(response = ResponseRepresentation.class, code = 200, message = ApiDescriptions.HORN_RESPONSE),
            @ApiResponse(response = ErrorResponse.class, code = 400, message = ApiDescriptions.BAD_REQUEST),
            @ApiResponse(code = 401, message = ApiDescriptions.UNAUTHORIZED),
            @ApiResponse(response = ErrorResponse.class, code = 500, message = ApiDescriptions.INTERNAL_SERVER_ERROR)})
    public Response horn(ClientRequestRepresentation<Horn> clientRequestRepresentation) {

        return handleClientRemote(clientRequestRepresentation, Action.HORN);
    }

    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("light")
    @POST
    @ApiOperation(value = ApiDescriptions.LIGHTS)
    @ApiResponses({@ApiResponse(response = ResponseRepresentation.class, code = 200, message = ApiDescriptions.LIGHTS_RESPONSE),
            @ApiResponse(response = ErrorResponse.class, code = 400, message = ApiDescriptions.BAD_REQUEST),
            @ApiResponse(code = 401, message = ApiDescriptions.UNAUTHORIZED),
            @ApiResponse(response = ErrorResponse.class, code = 500, message = ApiDescriptions.INTERNAL_SERVER_ERROR)})
    public Response lights(ClientRequestRepresentation<Lights> clientRequestRepresentation) {

        return handleClientRemote(clientRequestRepresentation, Action.LIGHTS);
    }

    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("lowpowerinfo")
    @POST
    @ApiOperation(value = ApiDescriptions.LOWPOWERINFO)
    @ApiResponses({@ApiResponse(response = ResponseRepresentation.class, code = 200, message = ApiDescriptions.LOWPOWERINFO_RESPONSE),
            @ApiResponse(response = ErrorResponse.class, code = 400, message = ApiDescriptions.BAD_REQUEST),
            @ApiResponse(code = 401, message = ApiDescriptions.UNAUTHORIZED),
            @ApiResponse(response = ErrorResponse.class, code = 500, message = ApiDescriptions.INTERNAL_SERVER_ERROR)})
    public Response lowPowerInfo(ClientRequestRepresentation<LowPowerInfoRequest> clientRequestRepresentation) {

        return handleClientRemote(clientRequestRepresentation, Action.LOW_POWER_INFO);
    }

    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("requeststate")
    @POST
    @ApiOperation(value = ApiDescriptions.REQUESTSTATE)
    @ApiResponses({@ApiResponse(response = ResponseRepresentation.class, code = 200, message = ApiDescriptions.REQUESTSTATE_RESPONSE),
            @ApiResponse(response = ErrorResponse.class, code = 400, message = ApiDescriptions.BAD_REQUEST),
            @ApiResponse(code = 401, message = ApiDescriptions.UNAUTHORIZED),
            @ApiResponse(response = ErrorResponse.class, code = 500, message = ApiDescriptions.INTERNAL_SERVER_ERROR)})
    public Response requestState(ClientRequestRepresentation<RequestState> clientRequestRepresentation) {

        return handleClientRemote(clientRequestRepresentation, Action.REQUEST_STATE);
    }

    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("thermalpreconditioning")
    @POST
    @ApiOperation(value = ApiDescriptions.THERMALPRECONDITIONING)
    @ApiResponses({@ApiResponse(response = ResponseRepresentation.class, code = 200, message = ApiDescriptions.THERMALPRECONDITIONING_RESPONSE),
            @ApiResponse(response = ErrorResponse.class, code = 400, message = ApiDescriptions.BAD_REQUEST),
            @ApiResponse(code = 401, message = ApiDescriptions.UNAUTHORIZED),
            @ApiResponse(response = ErrorResponse.class, code = 500, message = ApiDescriptions.INTERNAL_SERVER_ERROR)})
    public Response thermalPreconditioning(ClientRequestRepresentation<Preconditioning> clientRequestRepresentation) {

        return handleClientRemote(clientRequestRepresentation, Action.THERMAL_PRECONDITIONING);
    }

    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @POST
    @Path("tracking")
    @ApiOperation(value = ApiDescriptions.TRACKING)
    @ApiResponses({@ApiResponse(response = ResponseRepresentation.class, responseContainer = "List", code = 200, message = ApiDescriptions.TRACKING_RESPONSE),
            @ApiResponse(response = ErrorResponse.class, code = 400, message = ApiDescriptions.BAD_REQUEST),
            @ApiResponse(code = 401, message = ApiDescriptions.UNAUTHORIZED),
            @ApiResponse(response = ErrorResponse.class, code = 500, message = ApiDescriptions.INTERNAL_SERVER_ERROR)})
    public Response tracking(ClientRequestRepresentation<Tracking> clientRequestRepresentation) {

        return handleClientRemote(clientRequestRepresentation, Action.TRACKING);
    }

    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    @Path("vehiclestate")
    @POST
    @ApiOperation(value = ApiDescriptions.VEHICLESTATE)
    @ApiResponses({@ApiResponse(response = ResponseRepresentation.class, code = 200, message = ApiDescriptions.VEHICLESTATE_RESPONSE),
            @ApiResponse(response = ErrorResponse.class, code = 400, message = ApiDescriptions.BAD_REQUEST),
            @ApiResponse(code = 401, message = ApiDescriptions.UNAUTHORIZED),
            @ApiResponse(response = ErrorResponse.class, code = 500, message = ApiDescriptions.INTERNAL_SERVER_ERROR)})
    public Response vehicleState(ClientRequestRepresentation<VehicleState> clientRequestRepresentation) {

        return handleClientRemote(clientRequestRepresentation, Action.VEHICLE_STATE);
    }
}
