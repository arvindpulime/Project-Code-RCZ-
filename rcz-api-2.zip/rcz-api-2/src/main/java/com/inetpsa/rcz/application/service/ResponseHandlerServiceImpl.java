package com.inetpsa.rcz.application.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.inetpsa.rcz.application.exception.ApplicationException;
import com.inetpsa.rcz.application.exception.ErrorCode;
import com.inetpsa.rcz.application.representation.*;
import com.inetpsa.rcz.domain.model.api.request.Request;
import com.inetpsa.rcz.domain.model.api.request.RequestStatus;
import com.inetpsa.rcz.domain.model.payload.topic.Topic;
import com.inetpsa.rcz.domain.services.RequestService;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;
import com.inetpsa.rcz.infrastructure.kafka.KafkaConfig;
import org.seedstack.seed.Configuration;

import javax.inject.Inject;
import javax.inject.Named;

public class ResponseHandlerServiceImpl implements ResponseHandlerService {

    public static final String TOPIC_SEPARATOR = "/";
    public static final String PROCESS_MANAGEMENT = "ProcessManagement";
    public static final String CORRELATION_ID_NOT_FOUND = "Correlation id not found [%s], for RCZ response [%s]";
    @Inject
    private RequestService requestService;

    @Inject
    @Named("kafka")
    private PublisherService<NotifierData> publisherService;

    @Configuration
    private KafkaConfig kafkaConfig;

    @Override
    public void handle(String response, String topicValue) throws ApplicationException {
        String correlationId = getCorrelationId(response);
        Request request = requestService.get(correlationId).orElseThrow(() -> new ApplicationException(String.format(CORRELATION_ID_NOT_FOUND, correlationId, response), ErrorCode.CORRELATION_ID_NOT_FOUND));

        NotifierData notifierData = getNotifierData(topicValue.replace(TOPIC_SEPARATOR + PROCESS_MANAGEMENT, ""), request);
        if (isProcess(topicValue)) {
            publisherService.publish(JsonConverter.convert(new NotificationRepresentation(MessageType.Process, response)), notifierData.setMessageType(MessageType.Process));
        } else {
            publisherService.publish(JsonConverter.convert(new NotificationRepresentation(MessageType.Response, response)), notifierData.setMessageType(MessageType.Response));
            request.setStatus(RequestStatus.FINISH);
            requestService.save(request);
        }
    }

    private NotifierData getNotifierData(String topicValue, Request request) {
        Topic topic = new Topic(topicValue);
        return new NotifierData()
                .setActionService(topic.getActionService())
                .setActionType(topic.getActionType())
                .setCallerId(request.getCallerId())
                .setCallerType(topic.getTag().literal())
                .setVin(request.getVin())
                .setTopic(kafkaConfig.getResponseTopic());
    }

    private RequestPayload getRequestPayload(Request request) {
        return JsonConverter.convert(request.getRequest().getRawJson(), new TypeReference<RequestPayload>() {
        });
    }

    private String getCorrelationId(String response) {
        return JsonConverter.convert(response, new TypeReference<ResponseRepresentation>() {
        }).getCorrelationId();
    }

    private boolean isProcess(String topicValue) {
        String[] topicArray = topicValue.split(TOPIC_SEPARATOR);
        if (PROCESS_MANAGEMENT.equals(topicArray[topicArray.length - 1])) {
            return true;
        }
        return false;
    }
}
