package com.inetpsa.rcz.infrastructure.kafka;

import com.google.inject.Injector;
import com.inetpsa.rcz.application.representation.NotifierData;
import com.inetpsa.rcz.application.service.PublisherService;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.header.internals.RecordHeader;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;

@Named("kafka")
public class KafkaProducerService implements PublisherService<NotifierData> {


    @Inject
    private Injector injector;

    @Configuration
    private KafkaConfig kafkaConfig;

    @Logging
    private Logger logger;

    @Inject
    @Named("response")
    private Producer<String, String> producer;

    @Override
    public void publish(String message, NotifierData target) {
        ProducerRecord<String, String> producerRecord = new ProducerRecord<>(kafkaConfig.getResponseTopic(), target.getVin(), message);
        producerRecord.headers().add(new RecordHeader("CallerId", target.getCallerId().getBytes()));
        producerRecord.headers().add(new RecordHeader("CallerType", target.getCallerType().getBytes()));
        producerRecord.headers().add(new RecordHeader("ActionService", target.getActionService().toString().getBytes()));
        producerRecord.headers().add(new RecordHeader("ActionType", target.getActionType().toString().getBytes()));
        producerRecord.headers().add(new RecordHeader("VIN", target.getVin().getBytes()));
        producerRecord.headers().add(new RecordHeader("message_type", target.getMessageType().toString().getBytes()));
        producer.send(producerRecord, (metadata, exception) -> {
            if (exception != null) {
                logger.error("Kafka producer error for message : [{}]", message);
                logger.error(exception.getMessage(), exception);
            }
        });
    }
}
