package com.inetpsa.rcz.application.exception;

public enum ErrorCode {
    VALIDATION_ERROR,
    CORRELATION_ID_NOT_FOUND,
    NOTIFICATION_CLIENT_ERROR
}
