package com.inetpsa.rcz.infrastructure.rest;

public class RestClientConfiguration {

    private int maxRetry = 3;
    private int delay = 1;
    private int connectionTimeout = 3000;
    private int requestTimeout = 3000;

    public int getMaxRetry() {
        return maxRetry;
    }

    public RestClientConfiguration setMaxRetry(int maxRetry) {
        this.maxRetry = maxRetry;
        return this;
    }

    public int getDelay() {
        return delay;
    }

    public RestClientConfiguration setDelay(int delay) {
        this.delay = delay;
        return this;
    }

    public int getConnectionTimeout() {
        return connectionTimeout;
    }

    public RestClientConfiguration setConnectionTimeout(int connectionTimeout) {
        this.connectionTimeout = connectionTimeout;
        return this;
    }

    public int getRequestTimeout() {
        return requestTimeout;
    }

    public RestClientConfiguration setRequestTimeout(int requestTimeout) {
        this.requestTimeout = requestTimeout;
        return this;
    }
}
