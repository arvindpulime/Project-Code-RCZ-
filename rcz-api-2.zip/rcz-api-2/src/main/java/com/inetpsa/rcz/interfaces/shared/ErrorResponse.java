package com.inetpsa.rcz.interfaces.shared;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.inetpsa.rcz.application.exception.ErrorCode;
import io.swagger.annotations.ApiModelProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ErrorResponse {

    @ApiModelProperty(value = ApiDescriptions.RESPONSE_CODE)
    private ErrorCode code;

    @ApiModelProperty(value = ApiDescriptions.RESPONSE_MESSAGE)
    private String message;

    public ErrorCode getCode() {
        return code;
    }

    public ErrorResponse setCode(ErrorCode code) {
        this.code = code;
        return this;
    }

    public String getMessage() {
        return message;
    }

    public ErrorResponse setMessage(String message) {
        this.message = message;
        return this;
    }
}
