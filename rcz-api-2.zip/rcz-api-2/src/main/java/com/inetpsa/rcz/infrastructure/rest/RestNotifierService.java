package com.inetpsa.rcz.infrastructure.rest;

import com.inetpsa.rcz.application.exception.ApplicationException;
import com.inetpsa.rcz.application.exception.ErrorCode;
import com.inetpsa.rcz.application.representation.Callback;
import com.inetpsa.rcz.application.service.NotifierService;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.jodah.failsafe.function.CheckedRunnable;
import org.glassfish.jersey.client.ClientProperties;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import javax.ws.rs.ProcessingException;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import java.time.Duration;

public class RestNotifierService implements NotifierService {

    public static final String HTTP_ERROR_WHILE_SENDING_NOTIFICATION = "Error while sending notification, http error code [%s], reason [%s], data [%s]";
    public static final String ERROR_WHILE_SENDING_NOTIFICATION = "Error while sending notification, reason [%s]";
    @Logging
    private static Logger logger;

    @Configuration
    private RestClientConfiguration notifierRest;

    @Override
    public void notify(Callback callback, String message) {
        try {
            process(() -> send(callback, message), ApplicationException.class);
        } catch (ApplicationException e) {
            logger.error(e.getMessage(), e);
        }
    }

    private void send(Callback callback, String message) throws ApplicationException {
        Client client = ClientBuilder.newBuilder().build();
        WebTarget webTarget = client.target(callback.getUrl());
        MultivaluedMap<String, Object> headers = new MultivaluedHashMap();
        if (callback.getHttpHeaders() != null && callback.getHttpHeaders().size() > 0) {
            callback.getHttpHeaders().forEach((biconsumer, action) -> action.forEach(value -> headers.add(biconsumer, value)));
        }
        try {
            Response response = webTarget.request(MediaType.APPLICATION_JSON)
                    .headers(headers)
                    .property(ClientProperties.CONNECT_TIMEOUT, notifierRest.getConnectionTimeout())
                    .property(ClientProperties.READ_TIMEOUT, notifierRest.getRequestTimeout())
                    .post(Entity.entity(message, MediaType.APPLICATION_JSON));
            if (response.getStatus() != 200) {
                throw new ApplicationException(ErrorCode.NOTIFICATION_CLIENT_ERROR, String.format(HTTP_ERROR_WHILE_SENDING_NOTIFICATION, response.getStatus(), response.getStatusInfo().getReasonPhrase(), response.readEntity(String.class)));
            }
        } catch (ProcessingException e) {
            throw new ApplicationException(ErrorCode.NOTIFICATION_CLIENT_ERROR, String.format(ERROR_WHILE_SENDING_NOTIFICATION, e.getMessage()));
        }
    }

    public <E extends Throwable> void process(CheckedRunnable runnable, Class<E> failures) throws E {
        try {
            Failsafe.with(new RetryPolicy<>()
                    .handle(failures)
                    .withDelay(Duration.ofMillis(notifierRest.getDelay()))
                    .withMaxRetries(notifierRest.getMaxRetry())
                    .onSuccess(e -> logger.info("FAILSAFE SUCCESS EXECUTION : {}", e.getResult()))
                    .onFailure(e -> logger.error("FAILSAFE FAILURE EXECUTION", e.getFailure()))
            ).run(runnable);
        } catch (FailsafeException e) {
            try {
                throw (E) e.getCause();
            } catch (ClassCastException e1) {
                throw e;
            }
        }

    }

}
