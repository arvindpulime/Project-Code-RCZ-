package com.inetpsa.rcz.application.representation;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.Map;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Callback {

    @JsonProperty("url")
    @NotNull
    private String url;

    @JsonProperty("httpHeaders")
    private Map<String, List<String>> httpHeaders;

    public String getUrl() {
        return url;
    }

    public Callback setUrl(String url) {
        this.url = url;
        return this;
    }

    public Map<String, List<String>> getHttpHeaders() {
        return httpHeaders;
    }

    public Callback setHttpHeaders(Map<String, List<String>> httpHeaders) {
        this.httpHeaders = httpHeaders;
        return this;
    }
}
