package com.inetpsa.rcz.application.representation;

public enum MessageType {
    Process,
    Response;
}
