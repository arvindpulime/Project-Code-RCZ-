package com.inetpsa.rcz.application.representation;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.inetpsa.rcz.domain.model.payload.ValidationPattern;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ClientRequestRepresentation<R> extends RequestRepresentation<R> {
    @NotNull
    //@Pattern(regexp = ValidationPattern.PATTERN_ACCESS_TOKEN)
    @JsonProperty("access_token")
    private String accessToken;
    @NotNull
    @Pattern(regexp = ValidationPattern.PATTERN_CUSTOMER_ID)
    @JsonProperty("customer_id")
    private String customerId;

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getCustomerId() {
        return customerId;
    }

    public ClientRequestRepresentation<R> setCustomerId(String customerId) {
        this.customerId = customerId;
        return this;
    }
}
