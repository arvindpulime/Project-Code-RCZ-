package com.inetpsa.rcz.application.service;

import com.inetpsa.rcz.application.exception.ApplicationException;
import com.inetpsa.rcz.application.exception.ErrorCode;
import com.inetpsa.rcz.domain.services.PayloadValidationService;

import javax.inject.Inject;
import javax.validation.ValidationException;

public class ValidationServiceImpl implements ValidationService {

    @Inject
    private PayloadValidationService payloadValidationService;

    @Override
    public <T> void validateRequest(T payload) throws ApplicationException {
        try {

            payloadValidationService.validateRequest(payload);
        } catch (ValidationException e) {
            throw new ApplicationException(e.getMessage(), e, ErrorCode.VALIDATION_ERROR);
        }

    }
}
