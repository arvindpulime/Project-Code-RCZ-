package com.inetpsa.rcz.infrastructure.mqtt;

import com.google.common.base.Charsets;
import com.inetpsa.rcz.application.exception.ApplicationException;
import com.inetpsa.rcz.application.service.ResponseHandlerService;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.seedstack.mqtt.MqttListener;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import javax.inject.Inject;

@MqttListener(clients = "${mqtt.subscribe.clients}",
        topics = {"${mqtt.subscribe.topics}"},
        qos = {"${mqtt.subscribe.qos}"})
public class ResponseListener implements MqttCallback {

    @Inject
    private ResponseHandlerService responseHandlerService;

    @Logging
    private Logger logger;

    @Override
    public void connectionLost(Throwable throwable) {

    }

    @Override
    public void messageArrived(String topic, MqttMessage mqttMessage) throws Exception {
        try {
            responseHandlerService.handle(new String(mqttMessage.getPayload(), Charsets.UTF_8), topic);
        } catch (ApplicationException e) {
            logger.error(e.getMessage(), e);
        }
    }

    @Override
    public void deliveryComplete(IMqttDeliveryToken token) {

    }
}
