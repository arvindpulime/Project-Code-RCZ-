package com.inetpsa.rcz.application.representation;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.inetpsa.rcz.domain.model.payload.ValidationPattern;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RequestPayload {


    @NotNull
    @Pattern(regexp = ValidationPattern.PATTERN_VIN)
    @JsonProperty("vin")
    private String vin;


    public String getVin() {
        return vin;
    }

    public RequestPayload setVin(String vin) {
        this.vin = vin;
        return this;
    }
}
