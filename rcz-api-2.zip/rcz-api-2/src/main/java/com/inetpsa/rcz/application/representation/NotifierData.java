package com.inetpsa.rcz.application.representation;

import com.inetpsa.rcz.domain.model.action.ActionService;
import com.inetpsa.rcz.domain.model.action.ActionType;

public class NotifierData {

    private String topic;

    private String callerType;

    private String callerId;

    private ActionService actionService;

    private ActionType actionType;

    private String vin;

    private MessageType messageType;


    public NotifierData() {
    }


    public String getTopic() {
        return topic;
    }

    public NotifierData setTopic(String topic) {
        this.topic = topic;
        return this;
    }

    public String getCallerType() {
        return callerType;
    }

    public NotifierData setCallerType(String callerType) {
        this.callerType = callerType;
        return this;
    }

    public String getCallerId() {
        return callerId;
    }

    public NotifierData setCallerId(String callerId) {
        this.callerId = callerId;
        return this;
    }

    public ActionService getActionService() {
        return actionService;
    }

    public NotifierData setActionService(ActionService actionService) {
        this.actionService = actionService;
        return this;
    }

    public ActionType getActionType() {
        return actionType;
    }

    public NotifierData setActionType(ActionType actionType) {
        this.actionType = actionType;
        return this;
    }

    public String getVin() {
        return vin;
    }

    public NotifierData setVin(String vin) {
        this.vin = vin;
        return this;
    }

    public MessageType getMessageType() {
        return messageType;
    }

    public NotifierData setMessageType(MessageType messageType) {
        this.messageType = messageType;
        return this;
    }
}
