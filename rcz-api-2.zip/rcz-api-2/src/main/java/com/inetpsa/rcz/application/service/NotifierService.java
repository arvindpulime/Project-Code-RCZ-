package com.inetpsa.rcz.application.service;

import com.inetpsa.rcz.application.representation.Callback;
import org.seedstack.business.Service;

@Service
public interface NotifierService {
    void notify(Callback callback, String message);
}
