package com.inetpsa.carbide.serializer.infrastructure.coffig;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.seedstack.coffig.Config;

@Config("serializer.json")
public class SerializerConfig {

    private String dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
    private String timeZone = "UTC";

    private JsonInclude.Include include = JsonInclude.Include.NON_NULL;

    private boolean prettyPrint;

    public String getDateFormat() {
        return dateFormat;
    }

    public String getTimeZone() {
        return timeZone;
    }

    public JsonInclude.Include getInclude() {
        return include;
    }

    public boolean isPrettyPrint() {
        return prettyPrint;
    }
}
