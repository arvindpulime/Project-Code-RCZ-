package com.inetpsa.carbide.serializer.application.service;

import com.inetpsa.carbide.domain.interfaces.data.Message;
import com.inetpsa.carbide.serializer.application.exceptions.SerializationException;
import org.seedstack.business.Service;

@Service
public interface SerializerService {

    String serialize(Message message) throws SerializationException;
}
