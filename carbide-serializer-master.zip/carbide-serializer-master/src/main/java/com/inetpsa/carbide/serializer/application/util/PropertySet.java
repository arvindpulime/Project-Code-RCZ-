package com.inetpsa.carbide.serializer.application.util;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public final class PropertySet {

    private static final Set<String> RM_FROM_BEV;
    private static final Set<String> RM_FROM_PHEV;
    private static final Set<String> RM_FROM_ICE;

    static {
        RM_FROM_BEV = Stream.of(
                // Battery
                "fuelLevel", "autonomy",
                // Vehicle Status
                "fuelLevel", "residualAutonomy", "fuelTotalConsumption",
                // Vehicle Usage
                "torque", "gearboxRatio", "engineSpeed", "phevEngineSpeed", "currentPropulsion",
                // Trip
                "avgFuelConsumption",
                // CFM LEV
                "phevEngineSpeed",
                // CFM Extension
                "gearboxEffectiveRatio", "torque", "engineSpeed",
                "engineOilLevel", "engineAirTemperature", "engineWaterTemperature", "engineOilTemperature",
                "gearboxCalculatedRatio",
                // CFM Periodic
                "gmpStatus", "engineSpeeds", "oilTemperature", "fuelTotalConsumption", "fuelInstantConsumptions",
                "fuelLevel",
                // CFM Event
                "gmpStatus", "alertOfSCRLowLevel", "oilTemperature", "fuelTotalConsumption", "fuelInstantConsumption",
                "alertOfFuelLowLevel", "fuelLevel", "residualAutonomy")
                .collect(Collectors.toCollection(HashSet::new));

        RM_FROM_PHEV = Stream.of(
                // Battery Status Summary
                "remainingCapacity",
                // Vehicle Usage
                "bevEngineSpeed",
                // CFM LEV
                "bevEngineSpeed",
                // CFM Extension
                "gearboxCalculatedRatio",
                // CFM Periodic
                "gmpStatus",
                // CFM Event
                "gmpStatus")
                .collect(Collectors.toCollection(HashSet::new));

        RM_FROM_ICE = Stream.of(
                // Battery
                "chargeState", "chargeMode", "plugState", "rtabStartTime", "loadLevel",
                "zevAutonomy", "remainingChargeTime", "zevChargeGain",
                // Vehicle Status
                "chargeState", "zevAutonomy",
                // Vehicle Usage
                "phevEngineSpeed", "bevEngineSpeed", "currentPropulsion",
                //Trip
                "zevAvgPowerConsumption", "zevUtilization",
                // CFM LEV
                "phevEngineSpeed", "bevEngineSpeed", "residualEnergy", "totalEnergy", "batteryInternalResistanceHealth",
                "batteryLoadLevel", "batteryCapacityHealth", "zevAutonomy")
                .collect(Collectors.toCollection(HashSet::new));
    }

    private PropertySet() {
    }

    public static Set<String> notInBev() {
        return Collections.unmodifiableSet(RM_FROM_BEV);
    }

    public static Set<String> notInPhev() {
        return Collections.unmodifiableSet(RM_FROM_PHEV);
    }

    public static Set<String> notInThermal() {
        return Collections.unmodifiableSet(RM_FROM_ICE);
    }
}
