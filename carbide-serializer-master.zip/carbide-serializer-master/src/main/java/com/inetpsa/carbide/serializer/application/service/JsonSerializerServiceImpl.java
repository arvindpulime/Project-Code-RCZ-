package com.inetpsa.carbide.serializer.application.service;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.ser.FilterProvider;
import com.fasterxml.jackson.databind.ser.impl.SimpleBeanPropertyFilter;
import com.fasterxml.jackson.databind.ser.impl.SimpleFilterProvider;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.inetpsa.carbide.domain.interfaces.data.Message;
import com.inetpsa.carbide.domain.interfaces.enums.ServiceType;
import com.inetpsa.carbide.serializer.application.exceptions.SerializationException;
import com.inetpsa.carbide.serializer.application.util.PropertySet;
import com.inetpsa.carbide.serializer.infrastructure.coffig.SerializerConfig;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.TimeZone;

public class JsonSerializerServiceImpl implements SerializerService {

    @Logging
    private Logger logger;

    @Configuration
    private SerializerConfig config;

    @Override
    public String serialize(Message message) throws SerializationException {
        try {
            final FilterProvider filterProvider = filterProperties(message.getHeader().getServiceType());
            return getMapper().writer(filterProvider).writeValueAsString(message);
        } catch (JsonProcessingException e) {
            throw new SerializationException("Serialization failed", e);
        }
    }

    private ObjectMapper getMapper() {
        DateFormat dateFormat = new SimpleDateFormat(config.getDateFormat());
        dateFormat.setTimeZone(TimeZone.getTimeZone(config.getTimeZone()));
        ObjectMapper mapper = new ObjectMapper()
                .setSerializationInclusion(config.getInclude())
                .setDateFormat(dateFormat)
                .setVisibility(PropertyAccessor.FIELD, JsonAutoDetect.Visibility.ANY);
        mapper.registerModule(new JavaTimeModule());
        if (config.isPrettyPrint()) {
            mapper.enable(SerializationFeature.INDENT_OUTPUT);
        }
        return mapper;
    }

    private SimpleFilterProvider filterProperties(int serviceType) {
        SimpleBeanPropertyFilter propertyFilter = null;
        switch (serviceType) {
            case ServiceType.BEV:
                propertyFilter = SimpleBeanPropertyFilter.serializeAllExcept(PropertySet.notInBev());
                break;
            case ServiceType.PHEV:
                propertyFilter = SimpleBeanPropertyFilter.serializeAllExcept(PropertySet.notInPhev());
                break;
            case ServiceType.ICE:
                propertyFilter = SimpleBeanPropertyFilter.serializeAllExcept(PropertySet.notInThermal());
                break;
        }
        return new SimpleFilterProvider().addFilter("LevFilter", propertyFilter);
    }
}
