alter table RCZQTPARAMETER add headerVersion varchar(10);
alter table RCZQTPARAMETER add ecuType varchar(10);
alter table RCZQTPARAMETER add orangeServiceType varchar(10);
alter table RCZQTPARAMETER add objectType varchar(10);
alter table RCZQTPARAMETER add objectVersion varchar(10);
alter table RCZQTPARAMETER add objectId varchar(10);
update rczqtparameter set headerVersion = '01', ecuType = '00', orangeServiceType = '03', objectType = '00', objectVersion = '01', objectId = '00' where id = '1';
DELETE FROM rczqtsms WHERE sendingDate IS NULL;