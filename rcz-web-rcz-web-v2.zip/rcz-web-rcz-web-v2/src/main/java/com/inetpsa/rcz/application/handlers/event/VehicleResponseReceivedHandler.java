package com.inetpsa.rcz.application.handlers.event;

import com.fasterxml.jackson.core.type.TypeReference;
import com.inetpsa.rcz.application.exceptions.ApplicationException;
import com.inetpsa.rcz.application.handlers.payload.ResponseHandler;
import com.inetpsa.rcz.application.services.LocalizationService;
import com.inetpsa.rcz.application.services.PublisherService;
import com.inetpsa.rcz.application.services.PublisherService.Target.TargetBuilder;
import com.inetpsa.rcz.application.util.LocalizationKey;
import com.inetpsa.rcz.domain.model.action.Action;
import com.inetpsa.rcz.domain.model.action.ActionType;
import com.inetpsa.rcz.domain.model.enums.EventMessage;
import com.inetpsa.rcz.domain.model.enums.ExchangeStatus;
import com.inetpsa.rcz.domain.model.enums.ResponseStatus;
import com.inetpsa.rcz.domain.model.event.VehicleResponseReceived;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.log.LogMessage;
import com.inetpsa.rcz.domain.model.payload.data.VehicleStateResult;
import com.inetpsa.rcz.domain.model.payload.response.ResponsePayload;
import com.inetpsa.rcz.domain.model.payload.topic.Topic;
import com.inetpsa.rcz.domain.model.vehicle.Vehicle;
import com.inetpsa.rcz.domain.services.ExchangeService;
import com.inetpsa.rcz.domain.services.LogService;
import com.inetpsa.rcz.domain.services.VehicleService;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;
import org.apache.commons.lang3.StringUtils;
import org.seedstack.business.domain.BaseDomainEventHandler;
import org.seedstack.business.domain.DomainRegistry;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.Optional;

import static com.inetpsa.rcz.application.util.TypeResolver.RESPONSE_TYPES;

public class VehicleResponseReceivedHandler extends BaseDomainEventHandler<VehicleResponseReceived> {

    @Inject
    private ExchangeService exchangeService;

    @Inject
    private DomainRegistry domainRegistry;

    @Named("mqtt")
    @Inject
    private PublisherService publisherService;

    @Inject
    private LogService logService;

    @Inject
    private VehicleService vehicleService;

    @Inject
    private LocalizationService localizationService;

    @Override
    public void onEvent(VehicleResponseReceived event) {
        Exchange exchange = event.getExchange();
        try {
            checkError(event);
            updateStolenVehicle(exchange);
            ResponseHandler<?> responseHandler = domainRegistry.getService(RESPONSE_TYPES.get(exchange.getAction()));
            ResponsePayload<?> responsePayload = responseHandler.handle(exchange, event.getBtaResponsePayload());
            String responseRaw = JsonConverter.convert(responsePayload);
            Topic topic = new Topic(exchange.getTopic());
            String targetTopic = topic.toTarget(false);
            publisherService.publish(responseRaw, TargetBuilder.builder().withTopic(targetTopic).build());
            exchangeStatusUpdate(exchange, responsePayload);
            logService.info(LogMessage.create(EventMessage.RESPONSE_SENT).data(responseRaw).topic(targetTopic), exchange);
        } catch (ApplicationException e) {//NOSONAR
            exchangeErrorUpdate(exchange);
            logService.error(LogMessage.create(EventMessage.RESPONSE_ERROR).data(e.getMessage()), exchange);
        }
    }

    private void checkError(VehicleResponseReceived event) throws ApplicationException {
        if(ExchangeStatus.ERROR.equals(event.getExchange().getStatus())){
            throw new ApplicationException(localizationService.localize(LocalizationKey.VEHICLE_RESPONSE_ERROR_ALREADY_IN_TIMEOUT), ResponseStatus.VEHICLE_CONNECTION_TIMEOUT);
        }
    }

    /**
     * Update vehicleInfo raw Json with stolen true
     *
     * @param exchange Exchange
     * @throws ApplicationException thrown if the vehicle does not exist
     */
    private void updateStolenVehicle(Exchange exchange) throws ApplicationException {
        if (Action.STOLEN_VIN.equals(exchange.getAction())) {
            Optional<Vehicle> vehicle = vehicleService.find(exchange.getUin());
            if (!vehicle.isPresent()) {
                throw new ApplicationException(localizationService.localize(LocalizationKey.BAD_REQUEST_UNKNOWN_UIN_KEY, exchange.getUin()), ResponseStatus.BAD_REQUEST);
            }
            if (vehicle.get().getVehicleInfo() == null || StringUtils.isBlank(vehicle.get().getVehicleInfo().getRawJson())) {
                logService.warn(LogMessage.create(EventMessage.ALARM_WARNING).data("Stolen status was not updated, unknown VehicleInfo for UIN : " + exchange.getUin()), exchange);
            } else {
                VehicleStateResult result = JsonConverter.convert(vehicle.get().getVehicleInfo().getRawJson(), new TypeReference<VehicleStateResult>() {
                });
                result.setStolen(true);
                vehicle.get().getVehicleInfo().setRawJson(JsonConverter.convert(result));
        }
    }
    }

    private void exchangeStatusUpdate(Exchange exchange, ResponsePayload<?> responsePayload) {
        if (!ActionType.IMMOBILIZATION.equals(exchange.getAction().getActionType())
                || (ActionType.IMMOBILIZATION.equals(exchange.getAction().getActionType())
                && !ResponseStatus.STATUS_OK.equals(exchange.getResponseStatus()))) {
            exchange.setStatus(ExchangeStatus.FINISHED);
        }
        exchange.setResponseStatus(ResponseStatus.fromValue(responsePayload.getReturnCode()));
        exchangeService.update(exchange);
    }

    private void exchangeErrorUpdate(Exchange exchange) {
        exchange.setStatus(ExchangeStatus.ERROR);
        exchangeService.update(exchange);
    }
}
