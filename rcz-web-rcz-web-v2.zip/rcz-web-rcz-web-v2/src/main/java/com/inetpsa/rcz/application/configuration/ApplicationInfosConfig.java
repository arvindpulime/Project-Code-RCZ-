package com.inetpsa.rcz.application.configuration;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.UUID;

public class ApplicationInfosConfig {
    private String name;

    private String description;

    private String version;

    private String buildDate;

    private String instance = getHostName();

    private static String getHostName() {
        try {
            return InetAddress.getLocalHost().getHostName();
        } catch (UnknownHostException e) {
            return UUID.randomUUID().toString();
        }
    }


    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public String getVersion() {
        return version;
    }

    public String getBuildDate() {
        return buildDate;
    }

    public String getInstance() {
        return instance;
    }
}
