package com.inetpsa.rcz.application.handlers.payload.tracking;

import com.fasterxml.jackson.core.type.TypeReference;
import com.inetpsa.rcz.application.handlers.payload.AbstractResponseHandler;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.payload.data.Data;
import com.inetpsa.rcz.domain.model.payload.data.Tracking;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;
import org.apache.commons.lang3.StringUtils;

public class TrackingResponseHandler extends AbstractResponseHandler<Tracking> {
    @Override
    protected Tracking handleResponseData(Data data, Exchange exchange) {
        if (StringUtils.isNotBlank(data.getValue())) {
            return JsonConverter.convert(data.getValue(), new TypeReference<Tracking>() {
            });
        }
        return null;
    }
}
