package com.inetpsa.rcz.application.scheduler;

import com.inetpsa.rcz.application.configuration.RczConfig;
import com.inetpsa.rcz.domain.services.MonitoringService;
import org.quartz.*;
import org.seedstack.scheduler.ScheduledTasks;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.LifecycleListener;

import javax.inject.Inject;

public class SchedulerLifecycle implements LifecycleListener {


    public static final String EXCHANGE_TIMEOUT = "ExchangeTimeout";
    public static final String MQTT_MONITORING = "MqttMonitoring";
    public static final String APPLICATION_MONITORING = "ApplicationMonitoring";


    @Configuration
    private RczConfig rczConfig;

    @Inject
    private ScheduledTasks scheduledTasks;
    private Trigger trigger;


    @Inject
    private MonitoringService monitoringService;

    @Override
    public void started() {
        monitoringService.deleteAll();
        initExchangeTimeout();
        initMqttMonitoring();
        initAppMonitoring();
    }

    private void initAppMonitoring() {
        if (rczConfig.getApplicationMonitoring().getScheduler().isEnable()) {
            trigger = getBuild(rczConfig.getApplicationMonitoring().getScheduler().getDelay(), APPLICATION_MONITORING);
            scheduledTasks
                    .scheduledTask(ApplicationMonitoringTask.class).withTaskName(APPLICATION_MONITORING)
                    .withTrigger(trigger)
                    .schedule();
        }
    }

    private void initExchangeTimeout() {
        if (rczConfig.getExchange().getTimeout().isEnable()) {
            trigger = getBuild(rczConfig.getExchange().getTimeout().getDelay(), EXCHANGE_TIMEOUT);
            scheduledTasks
                    .scheduledTask(ExchangeTimeoutTask.class).withTaskName(EXCHANGE_TIMEOUT)
                    .withTrigger(trigger)
                    .schedule();
        }
    }

    private void initMqttMonitoring() {
        if (rczConfig.getMqttMonitoring().getScheduler().isEnable()) {
            trigger = getBuild(rczConfig.getMqttMonitoring().getScheduler().getDelay(), MQTT_MONITORING);
            scheduledTasks
                    .scheduledTask(MqttMonitoringTask.class).withTaskName(MQTT_MONITORING)
                    .withTrigger(trigger)
                    .schedule();
        }
    }

    private SimpleTrigger getBuild(int delay, String triggerName) {
        return TriggerBuilder.newTrigger()
                .withIdentity(TriggerKey.triggerKey(triggerName))
                .withSchedule(SimpleScheduleBuilder.simpleSchedule()
                        .withIntervalInMilliseconds(delay)
                        .repeatForever())
                .build();
    }


    @Override
    public void stopping() {
        stopTimeout();
        stopMqttMonitoring();
        stopApplicationMonitoring();

    }

    private void stopApplicationMonitoring() {
        if (rczConfig.getApplicationMonitoring().getScheduler().isEnable()) {
            scheduledTasks.scheduledTask(ApplicationMonitoringTask.class).withTaskName(APPLICATION_MONITORING).unschedule(APPLICATION_MONITORING);
        }
    }

    private void stopMqttMonitoring() {
        if (rczConfig.getMqttMonitoring().getScheduler().isEnable()) {
            scheduledTasks.scheduledTask(MqttMonitoringTask.class).withTaskName(MQTT_MONITORING).unschedule(MQTT_MONITORING);
        }
    }

    private void stopTimeout() {
        if (rczConfig.getExchange().getTimeout().isEnable()) {
            scheduledTasks.scheduledTask(ExchangeTimeoutTask.class).withTaskName(EXCHANGE_TIMEOUT).unschedule(EXCHANGE_TIMEOUT);
        }
    }


}