package com.inetpsa.rcz.application.handlers.payload;

import com.fasterxml.jackson.core.type.TypeReference;
import com.inetpsa.rcz.application.exceptions.ApplicationException;
import com.inetpsa.rcz.domain.model.enums.CallerType;
import com.inetpsa.rcz.domain.model.enums.ResponseStatus;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.payload.ResponseStatusResolver;
import com.inetpsa.rcz.domain.model.payload.data.Data;
import com.inetpsa.rcz.domain.model.payload.data.DataWrapper;
import com.inetpsa.rcz.domain.model.payload.request.RequestPayload;
import com.inetpsa.rcz.domain.model.payload.response.BTAResponsePayload;
import com.inetpsa.rcz.domain.model.payload.response.ResponsePayload;
import com.inetpsa.rcz.domain.services.ParameterService;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;
import org.apache.commons.lang3.StringUtils;

import javax.inject.Inject;
import java.util.Date;

public abstract class AbstractResponseHandler<R> implements ResponseHandler<R> {

    @Inject
    private ParameterService parameterService;

    @Override
    public ResponsePayload<R> handle(Exchange exchange, BTAResponsePayload btaResponsePayload) throws ApplicationException {
        try {
            ResponsePayload<R> responsePayload = new ResponsePayload<>();
            responsePayload.setResponseDate(new Date());
            RequestPayload requestPayload = getRequest(exchange);
            if (btaResponsePayload != null) {
                ResponseStatus responseStatus = ResponseStatusResolver.getBTAResponseStatus(btaResponsePayload.getStatus(), exchange.getAction().getActionService());
                if (CallerType.CLIENT.equals(exchange.getCallerType()) && !parameterService.get().getRcz().getClientResponseDebug()) {
                    responsePayload.setReturnCode(ResponseStatusResolver.getClientResponseStatus(responseStatus).code());
                } else {
                    responsePayload.setReturnCode(responseStatus.code());
                    responsePayload.setReason(btaResponsePayload.getReason());
                }
                if (btaResponsePayload.getData() != null && StringUtils.isNotBlank(btaResponsePayload.getData().getValue())) {
                    responsePayload.setResponseData(handleResponseData(btaResponsePayload.getData(), exchange));
                }
            }
            responsePayload.setLocation(getLocation(btaResponsePayload));
            responsePayload.setCorrelationId(requestPayload.getCorrelationId());
            responsePayload.setVin(exchange.getVin());
            return responsePayload;
        } catch (Exception e) {
            throw new ApplicationException(e.getMessage(), e, ResponseStatus.TECHNICAL_ERROR);
        }
    }

    private RequestPayload getRequest(Exchange exchange) {
        return JsonConverter.convert(exchange.getRequest().getRawJson(), new TypeReference<RequestPayload>() {
        });
    }

    private Data getLocation(BTAResponsePayload btaResponsePayload) {
        if (btaResponsePayload != null) {
            if (btaResponsePayload.getLocation() != null) {
                return btaResponsePayload.getLocation();
            }
            if (btaResponsePayload.getData() != null && StringUtils.isNotBlank(btaResponsePayload.getData().getValue())) {
                DataWrapper dataWrapper = JsonConverter.convert(btaResponsePayload.getData().getValue(), new TypeReference<DataWrapper>() {
                });
                if (dataWrapper != null) {
                    if (dataWrapper.getLocation() != null) {
                        return dataWrapper.getLocation();
                    } else if (dataWrapper.getSatellites() != null) {
                        return btaResponsePayload.getData();
                    }
                }
            }
        }
        return null;
    }

    protected abstract R handleResponseData(Data data, Exchange exchange);
}
