package com.inetpsa.rcz.application.handlers.payload.horn;

import com.inetpsa.rcz.application.handlers.payload.BTARequestHandler;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.payload.data.Horn;
import com.inetpsa.rcz.domain.model.payload.request.BTARequestPayload;
import com.inetpsa.rcz.domain.model.payload.request.RequestPayload;
import com.inetpsa.rcz.domain.model.vehicle.Vehicle;
import com.inetpsa.rcz.domain.services.VehicleService;

import javax.inject.Inject;
import java.util.Date;
import java.util.Optional;

public class HornBTARequestHandler implements BTARequestHandler<Horn, Horn> {

    @Inject
    private VehicleService vehicleService;

    @Override
    public BTARequestPayload<Horn> handle(Exchange exchange, RequestPayload<Horn> requestPayload) {
        Optional<Vehicle> vehicle = vehicleService.find(exchange.getUin());
        BTARequestPayload<Horn> btaRequest = new BTARequestPayload<>();
        btaRequest.setRequestDate(new Date());
        if (vehicle.isPresent() && Vehicle.BSRF.equals(vehicle.get().getBtaType())) {
            btaRequest.setData(new Horn(null, true));
        } else {
            btaRequest.setData(new Horn(2, true));
        }
        btaRequest.setRequestId(exchange.getId());
        return btaRequest;
    }
}

