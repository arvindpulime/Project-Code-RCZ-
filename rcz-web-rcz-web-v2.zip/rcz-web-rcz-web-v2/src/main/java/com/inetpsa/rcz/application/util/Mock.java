package com.inetpsa.rcz.application.util;

import com.fasterxml.jackson.core.type.TypeReference;
import com.google.common.base.Charsets;
import com.google.common.io.CharStreams;
import com.inetpsa.rcz.application.exceptions.JsonParseException;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;

import java.io.InputStream;
import java.io.InputStreamReader;

public final class Mock {

    public static <T> T get(String mock, TypeReference<T> typeReference) {
        try {
            InputStream is = Mock.class.getResourceAsStream(mock);
            String json = CharStreams.toString(new InputStreamReader(is, Charsets.UTF_8));
            return JsonConverter.convert(json, typeReference);
        } catch (Exception e) {//NOSONAR
            throw new JsonParseException("CVS Mock file not found : " + mock, e);
        }
    }
}
