package com.inetpsa.rcz.application.representation.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.validation.constraints.NotNull;
import javax.ws.rs.QueryParam;
import java.io.Serializable;
import java.util.Objects;

/**
 * @author tuan.docao@ext.mpsa.com
 */
public class PartnerRightsRequest implements Serializable {

    @JsonProperty("event_id")
    @QueryParam("event_id")
    private String eventId;

    @JsonProperty("partner_id")
    @QueryParam("partner_id")
    private String partnerId;

    @JsonProperty("brand")
    @QueryParam("brand")
    private String brand;

    @JsonProperty("contract_id")
    @QueryParam("contract_id")
    private String contractId;

    @NotNull
    @JsonProperty("service_code")
    @QueryParam("service_code")
    private String serviceCode;

    @NotNull
    @JsonProperty("vin")
    @QueryParam("vin")
    private String vin;

    public PartnerRightsRequest() {
    }

    public String getEventId() {
        return eventId;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }

    public String getPartnerId() {
        return partnerId;
    }

    public void setPartnerId(String partnerId) {
        this.partnerId = partnerId;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getContractId() {
        return contractId;
    }

    public void setContractId(String contractId) {
        this.contractId = contractId;
    }

    public String getServiceCode() {
        return serviceCode;
    }

    public void setServiceCode(String serviceCode) {
        this.serviceCode = serviceCode;
    }

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PartnerRightsRequest that = (PartnerRightsRequest) o;
        return Objects.equals(getPartnerId(), that.getPartnerId()) &&
                Objects.equals(getBrand(), that.getBrand()) &&
                Objects.equals(getContractId(), that.getContractId()) &&
                Objects.equals(getServiceCode(), that.getServiceCode()) &&
                Objects.equals(getVin(), that.getVin());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getPartnerId(), getBrand(), getContractId(), getServiceCode(), getVin());
    }
}
