package com.inetpsa.rcz.application.handlers.event;

import com.inetpsa.rcz.application.exceptions.JsonParseException;
import com.inetpsa.rcz.application.services.PublisherService;
import com.inetpsa.rcz.application.services.PublisherService.Target.TargetBuilder;
import com.inetpsa.rcz.domain.model.enums.EventMessage;
import com.inetpsa.rcz.domain.model.event.AlarmForwarded;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.log.LogMessage;
import com.inetpsa.rcz.domain.model.payload.data.BtaCrudData;
import com.inetpsa.rcz.domain.model.payload.request.BTARequestPayload;
import com.inetpsa.rcz.domain.model.payload.request.RemoteAlarmRequestPayload;
import com.inetpsa.rcz.domain.model.payload.topic.Topic;
import com.inetpsa.rcz.domain.services.ExchangeService;
import com.inetpsa.rcz.domain.services.LogService;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;
import org.seedstack.business.domain.BaseDomainEventHandler;
import org.seedstack.business.domain.DomainEventPublisher;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.Date;

public class AlarmForwardedHandler extends BaseDomainEventHandler<AlarmForwarded> {

    @Logging
    private Logger logger;

    @Inject
    private ExchangeService exchangeService;

    @Inject
    @Named("mqtt")
    private PublisherService publisherService;

    @Inject
    private LogService logService;

    @Inject
    private DomainEventPublisher eventPublisher;

    @Override
    public void onEvent(AlarmForwarded event) {
        try {
            Exchange exchange = event.getExchange();
            logService.info(LogMessage.create(EventMessage.ALARM_FORWARD_RESPONSE_RECEIVED), exchange);
            // build & save BTA request
            BTARequestPayload<BtaCrudData> btaRequestPayload = buildBtaRequest(exchange, event.getRemoteAlarmRequestPayload());
            String btaRequestJson = JsonConverter.convert(btaRequestPayload);
            // veh is awake ?
            // -- no VehicleWakeUpRequested
            // -- yes continue
            String btaTopic = new Topic(exchange.getTopic()).toBTA(exchange.getUin());

            publisherService.publish(btaRequestJson, TargetBuilder.builder().withTopic(btaTopic).build());
            // VehicleCommandSent --> log request BTA
            logService.info(LogMessage.create(EventMessage.ALARM_DELETE_SENT).data(btaRequestJson).topic(btaTopic), exchange);
        } catch (JsonParseException e) {
            logger.error(e.getMessage(), e);
        }
    }

    private BTARequestPayload<BtaCrudData> buildBtaRequest(Exchange exchange, RemoteAlarmRequestPayload remoteAlarmRequestPayload) {
        BTARequestPayload<BtaCrudData> btaRequestPayload = new BTARequestPayload();
        btaRequestPayload.setRequestDate(new Date());
        btaRequestPayload.setRequestId(exchange.getId());
        btaRequestPayload.setData(new BtaCrudData(remoteAlarmRequestPayload.getRequestId()));
        return btaRequestPayload;
    }
}
