package com.inetpsa.rcz.application.representation.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.inetpsa.rcz.application.representation.ServiceRepresentation;

import javax.validation.Valid;
import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * @author tuan.docao@ext.mpsa.com
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PartnerRights implements Serializable {

    @JsonProperty("event_id")
    private String eventId;

    @JsonProperty("partner_id")
    private String partnerId;

    /**
     * Map[VIN, Map[UIN, List[ServiceRepresentation]]]
     */
    @JsonProperty("services")
    private Map<String, Map<String, List<ServiceRepresentation>>> services;

    public PartnerRights() {
    }

    public String getEventId() {
        return eventId;
    }

    public PartnerRights setEventId(String eventId) {
        this.eventId = eventId;
        return this;
    }

    public String getPartnerId() {
        return partnerId;
    }

    public void setPartnerId(String partnerId) {
        this.partnerId = partnerId;
    }

    public Map<String, Map<String, List<ServiceRepresentation>>> getServices() {
        return services;
    }

    public PartnerRights setServices(Map<String, Map<String, List<ServiceRepresentation>>> services) {
        this.services = services;
        return this;
    }
}
