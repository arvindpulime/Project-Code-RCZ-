package com.inetpsa.rcz.application.representation.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @author tuan.docao@ext.mpsa.com
 */
public class BTARightsRequest implements Serializable {

    @JsonProperty("event_id")
    private String eventId;

    @NotNull
    @JsonProperty("service_code")
    private String serviceCode;

    @NotNull
    @JsonProperty("uin")
    private String uin;

    public BTARightsRequest() {
    }

    public String getEventId() {
        return eventId;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }

    public String getServiceCode() {
        return serviceCode;
    }

    public void setServiceCode(String serviceCode) {
        this.serviceCode = serviceCode;
    }

    public String getUin() {
        return uin;
    }

    public void setUin(String uin) {
        this.uin = uin;
    }
}
