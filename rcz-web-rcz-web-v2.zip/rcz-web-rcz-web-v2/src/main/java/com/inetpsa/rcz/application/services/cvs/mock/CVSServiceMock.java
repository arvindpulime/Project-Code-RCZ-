package com.inetpsa.rcz.application.services.cvs.mock;

import com.fasterxml.jackson.core.type.TypeReference;
import com.inetpsa.rcz.application.exceptions.AuthorizationException;
import com.inetpsa.rcz.application.exceptions.JsonParseException;
import com.inetpsa.rcz.application.representation.request.BTARightsRequest;
import com.inetpsa.rcz.application.representation.request.BTAServicesRequestLean;
import com.inetpsa.rcz.application.representation.request.ConsumerServicesRequestLean;
import com.inetpsa.rcz.application.representation.request.PartnerRightsRequest;
import com.inetpsa.rcz.application.representation.response.*;
import com.inetpsa.rcz.application.services.cvs.CVSService;
import com.inetpsa.rcz.application.util.Mock;

import javax.inject.Named;

/**
 * @author tuan.docao@ext.mpsa.com
 */
@Named("mock")
public class CVSServiceMock implements CVSService {

    private static final String PARTNER_RIGHTS = "/mocks/{}_partner-rights.json";

    private static final String CONSUMER_SERVICES_LEAN = "/mocks/{}_consumer-services-lean.json";

    private static final String OAUTH_CONSUMER_SERVICES_LEAN = "/mocks/{}_oauth-consumer-services-lean.json";

    private static final String BTA_RIGHTS = "/mocks/bta-rights.json";

    private static final String BTA_SERVICES_LEAN = "/mocks/{}_bta-services-lean.json";


    @Override
    public PartnerRights getPartnerServices(PartnerRightsRequest request) throws AuthorizationException {
        return get(PARTNER_RIGHTS.replace("{}", request.getPartnerId()), new TypeReference<PartnerRights>() {
        });
    }

    @Override
    public ConsumerServicesLean getConsumerServices(ConsumerServicesRequestLean request) throws AuthorizationException {
        return get(CONSUMER_SERVICES_LEAN.replace("{}", request.getVin()), new TypeReference<ConsumerServicesLean>() {
        });
    }

    @Override
    public OAuthConsumerServiceLean getOAuthConsumerServices(ConsumerServicesRequestLean request) throws AuthorizationException {
        return get(OAUTH_CONSUMER_SERVICES_LEAN.replace("{}", request.getToken()), new TypeReference<OAuthConsumerServiceLean>() {
        });
    }

    @Override
    public BTARights postBTARights(BTARightsRequest request) throws AuthorizationException {
        return get(BTA_RIGHTS, new TypeReference<BTARights>() {
        });
    }

    @Override
    public BTAServicesLean getBTAServices(BTAServicesRequestLean request) throws AuthorizationException {
        return get(BTA_SERVICES_LEAN.replace("{}", request.getUin()), new TypeReference<BTAServicesLean>() {
        });
    }

    private <T> T get(String request, TypeReference<T> typeReference) throws AuthorizationException {
        try {
            return Mock.get(request, typeReference);
        } catch (JsonParseException e) {
            throw new AuthorizationException(e.getMessage());
        }
    }
}
