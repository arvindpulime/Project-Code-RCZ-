package com.inetpsa.rcz.application.util;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.inetpsa.rcz.application.exceptions.JsonParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URL;

public final class JsonConverter {

    private static final Logger logger = LoggerFactory.getLogger(JsonConverter.class);

    private static final ObjectMapper objectMapper = getObjectMapper();

    private static ObjectMapper getObjectMapper() {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.findAndRegisterModules();
        objectMapper.setSerializationInclusion(JsonInclude.Include.NON_EMPTY);
        objectMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        return objectMapper;
    }

    public static String convert(Object obj) {
        try {
            return objectMapper.writeValueAsString(obj);
        } catch (JsonProcessingException e) {
            logger.error(e.getMessage(), e);
            throw new JsonParseException(e.getMessage(), e);
        }
    }

    public static String convertWithPrettyPrint(Object obj) {
        try {
            ObjectWriter prettyObjectWriter = objectMapper.writerWithDefaultPrettyPrinter();
            return prettyObjectWriter.writeValueAsString(obj);
        } catch (JsonProcessingException e) {
            logger.error(e.getMessage(), e);
            throw new JsonParseException(e.getMessage(), e);
        }
    }

    public static <T> T convert(String json, TypeReference<T> typeReference) {
        try {
            return objectMapper.readValue(json, typeReference);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            throw new JsonParseException(e.getMessage(), e);
        }
    }

    public static <T> T convert(URL json, TypeReference<T> typeReference) {
        try {
            return objectMapper.readValue(json, typeReference);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            throw new JsonParseException(e.getMessage(), e);
        }
    }

    public static <T> T convert(URL json, Class<T> valueType) {
        try {
            return objectMapper.readValue(json, valueType);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            throw new JsonParseException(e.getMessage(), e);
        }
    }

    public static <T> T convert(String json, Class<T> valueType) {
        try {
            return objectMapper.readValue(json, valueType);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            throw new JsonParseException(e.getMessage(), e);
        }
    }

}
