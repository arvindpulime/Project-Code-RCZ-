package com.inetpsa.rcz.application.services.impl;

import com.fasterxml.jackson.core.type.TypeReference;
import com.inetpsa.rcz.application.exceptions.ApplicationException;
import com.inetpsa.rcz.application.exceptions.AuthorizationException;
import com.inetpsa.rcz.application.representation.ServiceRepresentation;
import com.inetpsa.rcz.application.representation.request.BTAServicesRequestLean;
import com.inetpsa.rcz.application.representation.request.ConsumerServicesRequestLean;
import com.inetpsa.rcz.application.representation.request.PartnerRightsRequest;
import com.inetpsa.rcz.application.representation.response.*;
import com.inetpsa.rcz.application.services.AuthorizationService;
import com.inetpsa.rcz.application.services.LocalizationService;
import com.inetpsa.rcz.application.services.cvs.CVSService;
import com.inetpsa.rcz.application.util.LocalizationKey;
import com.inetpsa.rcz.domain.model.action.Action;
import com.inetpsa.rcz.domain.model.enums.CallerType;
import com.inetpsa.rcz.domain.model.enums.ResponseStatus;
import com.inetpsa.rcz.domain.model.event.AuthorizationReceivedEvent;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.payload.request.RequestPayload;
import com.inetpsa.rcz.domain.model.service.ServiceFeature;
import com.inetpsa.rcz.domain.services.ParameterService;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;
import org.apache.commons.lang3.StringUtils;
import org.seedstack.business.domain.DomainEventPublisher;
import org.seedstack.business.domain.DomainRegistry;
import org.seedstack.business.domain.Repository;
import org.seedstack.jpa.Jpa;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.Logging;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;

import javax.inject.Inject;
import java.util.*;

@JpaUnit("rcz")
public class AuthorizationServiceImpl implements AuthorizationService {

    @Inject
    private LocalizationService localizationService;

    private CVSService cvsService;

    @Logging
    private Logger logger;

    @Inject
    private DomainEventPublisher eventPublisher;

    @Inject
    @Jpa
    private Repository<ServiceFeature, String> serviceFeatureRepository;

    @Inject
    private ParameterService parameterService;

    @Inject
    public AuthorizationServiceImpl(DomainRegistry domainRegistry, ParameterService parameterService) {
        boolean cvsMock = parameterService.get().getCvs().getCvsMock();
        if (cvsMock) {
            cvsService = domainRegistry.getService(CVSService.class, CVSService.MOCK);
        } else {
            cvsService = domainRegistry.getService(CVSService.class, CVSService.REST);
        }
    }

    @Override
    @Transactional
    public String authorizeActionOnUIN(Exchange exchange) throws ApplicationException {
        if (parameterService.get().getCvs().getCvsAuthAccess() && CallerType.CLIENT.equals(exchange.getCallerType())) {
            ConsumerServicesLean consumerServiceLean = getOAuthConsumerServicesLean(exchange, buildConsumerServicesRequestLean(exchange));
            return filterServices(exchange, consumerServiceLean.getServices());
        } else if (CallerType.PARTNER.equals(exchange.getCallerType())) {
            return filterServices(exchange, getPartnerService(exchange));
        } else {
            ConsumerServicesLean consumerServiceLean = getConsumerServiceLean(exchange, buildConsumerServicesRequestLean(exchange));
            return filterServices(exchange, consumerServiceLean.getServices());
        }
    }


    private Map<String, List<ServiceRepresentation>> getPartnerService(Exchange exchange) throws ApplicationException {
        PartnerRights partnerService;
        try {
            partnerService = cvsService.getPartnerServices(buildPartnerServicesRequest(exchange));
            fireAuthorizationReceivedEvent(exchange, JsonConverter.convert(partnerService));
            if (partnerService == null || partnerService.getServices() == null || !partnerService.getServices().containsKey(exchange.getVin())) {
                throw new ApplicationException(localizationService.localize(LocalizationKey.AUTHORIZATION_DENIED_CVS_ON_UIN_RESPONSE_KO_KEY), ResponseStatus.AUTHORIZATION_DENIED);
            }
            return partnerService.getServices().get(exchange.getVin());
        } catch (AuthorizationException e) {
            fireAuthorizationReceivedEvent(exchange, e.getMessage());
            throw new ApplicationException(localizationService.localize(LocalizationKey.AUTHORIZATION_DENIED_CVS_FROM_UIN_RESPONSE_KO_KEY), ResponseStatus.AUTHORIZATION_DENIED);
        }
    }

    private ConsumerServicesLean getConsumerServiceLean(Exchange exchange, ConsumerServicesRequestLean requestLean) throws ApplicationException {
        ConsumerServicesLean consumerServices;
        try {
            consumerServices = cvsService.getConsumerServices(requestLean);
            fireAuthorizationReceivedEvent(exchange, JsonConverter.convert(consumerServices));
            if (consumerServices == null) {
                throw new ApplicationException(localizationService.localize(LocalizationKey.AUTHORIZATION_DENIED_CVS_ON_UIN_RESPONSE_KO_KEY), ResponseStatus.AUTHORIZATION_DENIED);
            }
            return consumerServices;
        } catch (AuthorizationException e) {
            fireAuthorizationReceivedEvent(exchange, e.getMessage());
            throw new ApplicationException(localizationService.localize(LocalizationKey.AUTHORIZATION_DENIED_CVS_FROM_UIN_RESPONSE_KO_KEY), ResponseStatus.AUTHORIZATION_DENIED);
        }
    }

    private OAuthConsumerServiceLean getoAuthConsumerServices(Exchange exchange, ConsumerServicesRequestLean requestLean) throws ApplicationException {
        try {
            if (StringUtils.isBlank(requestLean.getToken())) {
                throw new ApplicationException(localizationService.localize(LocalizationKey.AUTHORIZATION_DENIED_CVS_ACCESS_TOKEN_EMPTY), ResponseStatus.AUTHORIZATION_DENIED);
            }
            OAuthConsumerServiceLean oAuthConsumerServices = cvsService.getOAuthConsumerServices(requestLean);
            fireAuthorizationReceivedEvent(exchange, JsonConverter.convert(oAuthConsumerServices));
            return oAuthConsumerServices;
        } catch (AuthorizationException e) {
            fireAuthorizationReceivedEvent(exchange, e.getMessage());
            throw new ApplicationException(localizationService.localize(LocalizationKey.AUTHORIZATION_DENIED_CVS_FROM_UIN_RESPONSE_KO_KEY), ResponseStatus.AUTHORIZATION_DENIED);
        }
    }

    private void fireAuthorizationReceivedEvent(Exchange exchange, String message) {
        eventPublisher.publish(new AuthorizationReceivedEvent(exchange, message));
    }

    private BTAServicesLean getBtaServices(Exchange exchange, BTAServicesRequestLean btaServicesRequestLean) throws ApplicationException {
        try {
            BTAServicesLean btaServices = cvsService.getBTAServices(btaServicesRequestLean);
            fireAuthorizationReceivedEvent(exchange, JsonConverter.convert(btaServices));
            return btaServices;
        } catch (AuthorizationException e) {
            fireAuthorizationReceivedEvent(exchange, e.getMessage());
            throw new ApplicationException(localizationService.localize(LocalizationKey.AUTHORIZATION_DENIED_CVS_FROM_UIN_VIN_DOES_NOT_MATCH_TARGETED_VEHICLE_KEY), ResponseStatus.AUTHORIZATION_DENIED);
        }
    }

    private ConsumerServicesLean getOAuthConsumerServicesLean(Exchange exchange, ConsumerServicesRequestLean requestLean) throws ApplicationException {
        ConsumerServicesLean consumerServices = null;
        OAuthConsumerServiceLean oAuthConsumerServiceLean = getoAuthConsumerServices(exchange, requestLean);
        if (oAuthConsumerServiceLean != null && oAuthConsumerServiceLean.getServices() != null) {
            Map<String, List<ServiceRepresentation>> services = oAuthConsumerServiceLean.getServices().get(exchange.getVin());
            if (services != null) {
                consumerServices = new ConsumerServicesLean(exchange.getVin(), oAuthConsumerServiceLean.getServices().get(exchange.getVin()));
            }
        }
        if (consumerServices == null) {
            throw new ApplicationException(localizationService.localize(LocalizationKey.CVS_ERROR_INVALID_OR_EXPIRED_ACCES_TOKEN), ResponseStatus.RIGHTS_ERRORS);
        }
        return consumerServices;
    }


    @Override
    @Transactional
    public String authorizeActionFromUIN(Exchange exchange) throws ApplicationException {
        BTAServicesRequestLean btaServicesRequestLean = buildBTAServicesRequestLean(exchange);
        BTAServicesLean btaServices = getBtaServices(exchange, btaServicesRequestLean);
        if (btaServices == null) {
            throw new ApplicationException(localizationService.localize(LocalizationKey.AUTHORIZATION_DENIED_CVS_FROM_UIN_RESPONSE_KO_KEY), ResponseStatus.AUTHORIZATION_DENIED);
        }
        final String targetVin = exchange.getVin();
        final String responseVin = btaServices.getVin();
        if (targetVin == null || !targetVin.equals(responseVin)) {
            throw new ApplicationException(localizationService.localize(LocalizationKey.AUTHORIZATION_DENIED_CVS_FROM_UIN_VIN_DOES_NOT_MATCH_TARGETED_VEHICLE_KEY), ResponseStatus.AUTHORIZATION_DENIED);
        }
        return filterServices(exchange, btaServices.getServices());
    }


    private String filterServices(Exchange exchange, Map<String, List<ServiceRepresentation>> services) throws ApplicationException {
        for (Map.Entry<String, List<ServiceRepresentation>> entry : services.entrySet()) {
            for (ServiceRepresentation serviceRepresentation : entry.getValue()) {
                Optional<ServiceFeature> serviceFeature = serviceFeatureRepository.get(serviceRepresentation.getCode());
                if (serviceFeature.isPresent()) {
                    boolean dateOk = checkServiceValidity(exchange.getRequest().getReceivedDate(), serviceFeature.get().getStartDate(), serviceFeature.get().getEndDate());
                    if (!dateOk) {
                        logger.warn("Service expired : {}", serviceFeature.get().getId());
                        continue;
                    }

                    boolean actionOk = checkActionAuthorization(exchange, serviceFeature.get());
                    if (actionOk) {
                        return entry.getKey();
                    }
                }
            }
        }
        throw new ApplicationException(localizationService.localize(LocalizationKey.AUTHORIZATION_DENIED_CVS_RESPONSE_NO_MATCHING_SERVICE_KEY), ResponseStatus.AUTHORIZATION_DENIED);
    }

    private ConsumerServicesRequestLean buildConsumerServicesRequestLean(Exchange exchange) throws ApplicationException {
        ConsumerServicesRequestLean requestLean = new ConsumerServicesRequestLean();
        requestLean.setEventId(exchange.getId());
        requestLean.setVin(exchange.getVin());
        RequestPayload requestPayload = JsonConverter.convert(exchange.getRequest().getRawJson(), new TypeReference<RequestPayload>() {
        });
        requestLean.setAccountId(requestPayload.getCustomerId());
        if (requestPayload != null && CallerType.CLIENT.equals(exchange.getCallerType())) {
            if (requestPayload.getAccessToken() != null) {
                requestLean.setToken(requestPayload.getAccessToken());
            } else {
                throw new ApplicationException(localizationService.localize(LocalizationKey.AUTHORIZATION_DENIED_CVS_ACCESS_TOKEN_EMPTY), ResponseStatus.AUTHORIZATION_DENIED);
            }
        }
        return requestLean;
    }

    private PartnerRightsRequest buildPartnerServicesRequest(Exchange exchange) {
        RequestPayload requestPayload = JsonConverter.convert(exchange.getRequest().getRawJson(), new TypeReference<RequestPayload>() {
        });
        PartnerRightsRequest request = new PartnerRightsRequest();
        request.setEventId(exchange.getId());
        request.setVin(exchange.getVin());
        request.setPartnerId(requestPayload.getCustomerId());
        return request;
    }

    private BTAServicesRequestLean buildBTAServicesRequestLean(Exchange exchange) {
        BTAServicesRequestLean btaServicesRequestLean = new BTAServicesRequestLean();
        btaServicesRequestLean.setEventId(exchange.getId());
        btaServicesRequestLean.setUin(exchange.getUin());
        return btaServicesRequestLean;
    }

    private boolean checkServiceValidity(Date requestReceivedDate, Date startValidityDate, Date endValidityDate) {
        return (requestReceivedDate.compareTo(startValidityDate) >= 0 && requestReceivedDate.compareTo(endValidityDate) <= 0);
    }

    private boolean checkActionAuthorization(Exchange exchange, ServiceFeature serviceFeature) {
        Set<Action> actions;
        return (actions = serviceFeature.getActions()) != null && actions.contains(exchange.getAction());
    }

}
