package com.inetpsa.rcz.infrastructure.mqtt.publisher;

import org.seedstack.coffig.Config;

@Config("rcz.mqtt")
public class MqttConfig {

    PublisherConfig publish = new PublisherConfig();

    public PublisherConfig getPublish() {
        return publish;
    }

    public static class PublisherConfig {
        private String [] clients;
        private Integer qos = 1;
        private Boolean retained = false;
        public String[] getClients() {
            return clients;
        }

        public Integer getQos() {
            return qos;
        }

        public Boolean getRetained() {
            return retained;
        }
    }
}
