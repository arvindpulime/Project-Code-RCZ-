package com.inetpsa.rcz.application.util;

import com.google.common.collect.ImmutableMap;
import com.inetpsa.rcz.application.handlers.payload.BTARequestHandler;
import com.inetpsa.rcz.application.handlers.payload.RequestHandler;
import com.inetpsa.rcz.application.handlers.payload.ResponseHandler;
import com.inetpsa.rcz.domain.model.action.Action;
import com.inetpsa.rcz.domain.model.payload.data.*;
import com.inetpsa.rcz.domain.model.payload.data.Error;
import com.inetpsa.rcz.domain.model.payload.topic.BtaTopicsResolver;
import org.seedstack.shed.reflect.TypeOf;

import java.lang.reflect.Type;
import java.util.Map;

public final class TypeResolver {

    public static final Map<Action, Type> REQUEST_TYPES = initRequestTypes();

    public static final Map<Action, Type> BTA_REQUEST_TYPES = initBTARequestTypes();

    public static final Map<Action, Type> RESPONSE_TYPES = initResponseTypes();

    public static final Map<Action, Type> BTA_TOPICRESOLVER_TYPES = initTopicResolverTypes();

    private static Map<Action, Type> initTopicResolverTypes() {
        return ImmutableMap.<Action, Type>builder()
                .put(Action.HORN, new TypeOf<BtaTopicsResolver<Horn>>() {
                }.getType())
                .put(Action.DOORS, new TypeOf<BtaTopicsResolver<Doors>>() {
                }.getType())
                .put(Action.LIGHTS, new TypeOf<BtaTopicsResolver<Lights>>() {
                }.getType())
                .put(Action.VEHICLE_STATE, new TypeOf<BtaTopicsResolver<VehicleState>>() {
                }.getType())
                .put(Action.VEHICLE_STATE_STOLEN, new TypeOf<BtaTopicsResolver<VehicleState>>() {
                }.getType())
                .put(Action.REQUEST_STATE, new TypeOf<BtaTopicsResolver<RequestState>>() {
                }.getType())
                .put(Action.REQUEST_STATE_STOLEN, new TypeOf<BtaTopicsResolver<RequestState>>() {
                }.getType())
                .put(Action.STOLEN_VIN, new TypeOf<BtaTopicsResolver<StolenVin>>() {
                }.getType())
                .put(Action.TRACKING, new TypeOf<BtaTopicsResolver<Tracking>>() {
                }.getType())
                .put(Action.IMMOBILIZATION, new TypeOf<BtaTopicsResolver<Immobilization>>() {
                }.getType())
                .put(Action.IMMOBILIZATION_STOLEN, new TypeOf<BtaTopicsResolver<Immobilization>>() {
                }.getType())
                .put(Action.CHARGING, new TypeOf<BtaTopicsResolver<Charging>>() {
                }.getType())
                .put(Action.CHARGING_STATE, new TypeOf<BtaTopicsResolver<VehicleChargingState>>() {
                }.getType())
                .put(Action.THERMAL_PRECONDITIONING, new TypeOf<BtaTopicsResolver<Preconditioning>>() {
                }.getType())
                .put(Action.LOW_POWER_INFO, new TypeOf<BtaTopicsResolver<LowPowerInfo>>() {
                }.getType())
                .put(Action.LOW_POWER_INFO_STOLEN, new TypeOf<BtaTopicsResolver<LowPowerInfo>>() {
                }.getType())
                .build();

    }

    private static Map<Action, Type> initRequestTypes() {
        return ImmutableMap.<Action, Type>builder()
                .put(Action.HORN, new TypeOf<RequestHandler<Horn>>() {
                }.getType())
                .put(Action.DOORS, new TypeOf<RequestHandler<Doors>>() {
                }.getType())
                .put(Action.LIGHTS, new TypeOf<RequestHandler<Lights>>() {
                }.getType())
                .put(Action.VEHICLE_STATE, new TypeOf<RequestHandler<VehicleState>>() {
                }.getType())
                .put(Action.VEHICLE_STATE_STOLEN, new TypeOf<RequestHandler<VehicleState>>() {
                }.getType())
                .put(Action.REQUEST_STATE, new TypeOf<RequestHandler<RequestState>>() {
                }.getType())
                .put(Action.REQUEST_STATE_STOLEN, new TypeOf<RequestHandler<RequestState>>() {
                }.getType())
                .put(Action.STOLEN_VIN, new TypeOf<RequestHandler<StolenVin>>() {
                }.getType())
                .put(Action.TRACKING, new TypeOf<RequestHandler<Tracking>>() {
                }.getType())
                .put(Action.IMMOBILIZATION, new TypeOf<RequestHandler<Immobilization>>() {
                }.getType())
                .put(Action.IMMOBILIZATION_STOLEN, new TypeOf<RequestHandler<Immobilization>>() {
                }.getType())
                .put(Action.CHARGING, new TypeOf<RequestHandler<Charging>>() {
                }.getType())
                .put(Action.CHARGING_STATE, new TypeOf<RequestHandler<VehicleChargingState>>() {
                }.getType())
                .put(Action.THERMAL_PRECONDITIONING, new TypeOf<RequestHandler<Preconditioning>>() {
                }.getType())
                .put(Action.LOW_POWER_INFO, new TypeOf<RequestHandler<LowPowerInfoRequest>>() {
                }.getType())
                .put(Action.LOW_POWER_INFO_STOLEN, new TypeOf<RequestHandler<LowPowerInfoRequest>>() {
                }.getType())
                .build();

    }

    private static Map<Action, Type> initBTARequestTypes() {
        return ImmutableMap.<Action, Type>builder()
                .put(Action.HORN, new TypeOf<BTARequestHandler<Horn, Horn>>() {
                }.getType())
                .put(Action.DOORS, new TypeOf<BTARequestHandler<Doors, Doors>>() {
                }.getType())
                .put(Action.LIGHTS, new TypeOf<BTARequestHandler<Lights, Lights>>() {
                }.getType())
                .put(Action.VEHICLE_STATE, new TypeOf<BTARequestHandler<VehicleState, VehicleState>>() {
                }.getType())
                .put(Action.VEHICLE_STATE_STOLEN, new TypeOf<BTARequestHandler<VehicleState, VehicleState>>() {
                }.getType())
                .put(Action.REQUEST_STATE, new TypeOf<BTARequestHandler<Void, Void>>() {
                }.getType())
                .put(Action.REQUEST_STATE_STOLEN, new TypeOf<BTARequestHandler<Void, Void>>() {
                }.getType())
                .put(Action.STOLEN_VIN, new TypeOf<BTARequestHandler<StolenVin, StolenState>>() {
                }.getType())
                .put(Action.TRACKING, new TypeOf<BTARequestHandler<Tracking, Tracking>>() {
                }.getType())
                .put(Action.IMMOBILIZATION, new TypeOf<BTARequestHandler<Immobilization, Immobilization>>() {
                }.getType())
                .put(Action.IMMOBILIZATION_STOLEN, new TypeOf<BTARequestHandler<Immobilization, Immobilization>>() {
                }.getType())
                .put(Action.CHARGING, new TypeOf<BTARequestHandler<Charging, ChargingBTA>>() {
                }.getType())
                .put(Action.CHARGING_STATE, new TypeOf<BTARequestHandler<VehicleChargingState, Void>>() {
                }.getType())
                .put(Action.THERMAL_PRECONDITIONING, new TypeOf<BTARequestHandler<Preconditioning, PreconditioningBTA>>() {
                }.getType())
                .put(Action.LOW_POWER_INFO, new TypeOf<BTARequestHandler<LowPowerInfoRequest, Void>>() {
                }.getType())
                .put(Action.LOW_POWER_INFO_STOLEN, new TypeOf<BTARequestHandler<LowPowerInfoRequest, Void>>() {
                }.getType())
                .build();
    }

    private static Map<Action, Type> initResponseTypes() {
        return ImmutableMap.<Action, Type>builder()
                .put(Action.HORN, new TypeOf<ResponseHandler<Horn>>() {
                }.getType())
                .put(Action.DOORS, new TypeOf<ResponseHandler<Doors>>() {
                }.getType())
                .put(Action.LIGHTS, new TypeOf<ResponseHandler<Lights>>() {
                }.getType())
                .put(Action.VEHICLE_STATE, new TypeOf<ResponseHandler<VehicleStateClient>>() {
                }.getType())
                .put(Action.VEHICLE_STATE_STOLEN, new TypeOf<ResponseHandler<VehicleStateClient>>() {
                }.getType())
                .put(Action.REQUEST_STATE, new TypeOf<ResponseHandler<RequestStateResult>>() {
                }.getType())
                .put(Action.REQUEST_STATE_STOLEN, new TypeOf<ResponseHandler<RequestStateResult>>() {
                }.getType())
                .put(Action.STOLEN_VIN, new TypeOf<ResponseHandler<StolenState>>() {
                }.getType())
                .put(Action.TRACKING, new TypeOf<ResponseHandler<Tracking>>() {
                }.getType())
                .put(Action.IMMOBILIZATION, new TypeOf<ResponseHandler<Immobilization>>() {
                }.getType())
                .put(Action.IMMOBILIZATION_STOLEN, new TypeOf<ResponseHandler<Immobilization>>() {
                }.getType())
                .put(Action.CHARGING, new TypeOf<ResponseHandler<Error>>() {
                }.getType())
                .put(Action.CHARGING_STATE, new TypeOf<ResponseHandler<Error>>() {
                }.getType())
                .put(Action.THERMAL_PRECONDITIONING, new TypeOf<ResponseHandler<Error>>() {
                }.getType())
                .put(Action.LOW_POWER_INFO, new TypeOf<ResponseHandler<LowPowerInfo>>() {
                }.getType())
                .put(Action.LOW_POWER_INFO_STOLEN, new TypeOf<ResponseHandler<LowPowerInfo>>() {
                }.getType())
                .build();

    }

}
