package com.inetpsa.rcz.application.handlers.event;

import com.inetpsa.rcz.application.util.LocalizationKey;
import com.inetpsa.rcz.domain.model.enums.EventMessage;
import com.inetpsa.rcz.domain.model.enums.ProcessStatus;
import com.inetpsa.rcz.domain.model.event.RequestAccepted;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.log.LogMessage;
import com.inetpsa.rcz.domain.model.payload.response.ProcessPayload;
import com.inetpsa.rcz.domain.services.LogService;

import javax.inject.Inject;
import java.util.Date;

public class RequestAcceptedHandler extends AbstractProcessEventHandler<RequestAccepted> {

    @Inject
    protected LogService logService;

    @Override
    protected ProcessPayload buildProcessPayload(Exchange exchange) {
        logService.info(LogMessage.create(EventMessage.REQUEST_ACCEPTED), exchange);
        ProcessPayload processPayload = new ProcessPayload();
        processPayload.setVin(exchange.getVin());
        processPayload.setCode(ProcessStatus.REQUEST_ACCEPTED.code());
        processPayload.setCorrelationId(exchange.getCorrelationId());
        processPayload.setDate(new Date());
        processPayload.setMessage(localizationService.localize(LocalizationKey.PROCESS_900_REQUEST_ACCEPTED_KEY));
        return processPayload;
    }

}
