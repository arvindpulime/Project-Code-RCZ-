package com.inetpsa.rcz.infrastructure.kafka.producer;

import com.google.inject.Injector;
import com.google.inject.Key;
import com.google.inject.TypeLiteral;
import com.google.inject.name.Names;
import com.inetpsa.rcz.application.services.PublisherService;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.header.internals.RecordHeader;
import org.seedstack.kafka.KafkaConfig;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.Arrays;
import java.util.Map;

@Named("kafka")
public class KafkaProducerService implements PublisherService {


    @Inject
    private Injector injector;

    @Configuration
    private KafkaConfig kafkaConfig;

    @Logging
    private Logger logger;

    @Override
    public void publish(String message, Target target) {
        if (kafkaConfig != null && !kafkaConfig.getProducers().isEmpty()) {
            publish(message, target, kafkaConfig.getProducers().keySet().toArray(new String[kafkaConfig.getProducers().size()]));
        } else {
            if (logger.isDebugEnabled()) {
                logger.debug("No kafka producers found, message not sent ----> topic [{}], message [{}]", target.getTopic(), message);
            }
        }
    }

    @Override
    public void publish(String message, Target target, String... clients) {
        Arrays.asList(clients).forEach(client -> produce(message, target, client));
    }

    private void produce(String message, Target target, String client) {
        Producer<String, String> producer = getProducer(client);
        ProducerRecord<String, String> record = new ProducerRecord<>(target.getTopic(), target.getKey(), message);
        if (!target.getHeaders().isEmpty()) {
            for (Map.Entry<String, String> entry : target.getHeaders().entrySet()) {
                record.headers().add(new RecordHeader(entry.getKey(), entry.getValue().getBytes()));
            }
        }
        producer.send(record, (metadata, exception) -> {
            if (exception != null) {
                logger.error("Kafka producer error for message : [{}]", message);
                logger.error(exception.getMessage(), exception);
            }
        });
    }


    Producer<String, String> getProducer(String client) {
        return injector.getInstance(Key.get(new TypeLiteral<Producer<String, String>>() {
        }, Names.named(client)));
    }

}
