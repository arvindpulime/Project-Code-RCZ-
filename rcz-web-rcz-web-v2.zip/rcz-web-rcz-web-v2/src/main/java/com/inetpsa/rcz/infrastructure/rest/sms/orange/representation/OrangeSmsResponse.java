package com.inetpsa.rcz.infrastructure.rest.sms.orange.representation;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class OrangeSmsResponse {

    private OutboundSMSMessageRequest outboundSMSMessageRequest = new OutboundSMSMessageRequest();

}
