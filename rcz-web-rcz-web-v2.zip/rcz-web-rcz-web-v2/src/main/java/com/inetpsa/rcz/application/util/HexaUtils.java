package com.inetpsa.rcz.application.util;

import org.apache.commons.codec.binary.Hex;
import org.apache.commons.lang3.StringUtils;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public final class HexaUtils {

    public static final int BINARY_BASE = 2;
    public static final int FOUR_BYTES = 8;
    public static final int SIX_BYTES = 12;
    public static final int FIVE_BYTES = 10;
    public static final int TEN_BYTES = 20;
    public static final int TWO_BYTES = 4;
    public static final int SINGLE_BYTE = 2;
    public static final String PAD_STR = "0";
    public static final int SIX_BITS = 6;
    public static final int FOUR_BITS = 4;
    public static final int FIVE_BITS = 5;
    public static final int THREE_BYTES = 6;

    /**
     * encode string to hexa
     *
     * @param value to encode
     * @return
     */
    public static String stringToHex(String value, int nbBytes) {
        if (StringUtils.isNotBlank(value)) {
            return StringUtils.leftPad(Hex.encodeHexString(value.getBytes()), nbBytes, PAD_STR);
        }
        return StringUtils.leftPad("", nbBytes, PAD_STR);
    }

    public static String intToHex(String value, int nbBytes) {
        return StringUtils.leftPad(Integer.toHexString(Integer.parseInt(value)), nbBytes, PAD_STR);

    }

    public static String intToHex(int value, int nbBytes) {
        return StringUtils.leftPad(Integer.toHexString(value).substring(6, 8), nbBytes, PAD_STR);

    }

    public static String intToBinary(int value, int nbBytes) {
        return StringUtils.leftPad(Integer.toBinaryString(value), nbBytes, PAD_STR);

    }

    /**
     * encode date to hexa
     *
     * @param sendingDate to encode
     * @return encoded value
     */
    public static String dateToHex(Date sendingDate) {
        Calendar calendar = GregorianCalendar.getInstance();
        calendar.setTime(sendingDate);
        String dateStr = intToBinary(calendar.get(Calendar.YEAR) - 2000, SIX_BITS) +
                intToBinary(calendar.get(Calendar.MONTH) + 1, FOUR_BITS) +
                intToBinary(calendar.get(Calendar.DAY_OF_MONTH), FIVE_BITS) +
                intToBinary(calendar.get(Calendar.HOUR), FIVE_BITS) +
                intToBinary(calendar.get(Calendar.MINUTE), SIX_BITS) +
                intToBinary(calendar.get(Calendar.SECOND), SIX_BITS);
        return StringUtils.leftPad(Long.toHexString(Long.parseLong(dateStr, BINARY_BASE)), FOUR_BYTES, PAD_STR);
    }
}
