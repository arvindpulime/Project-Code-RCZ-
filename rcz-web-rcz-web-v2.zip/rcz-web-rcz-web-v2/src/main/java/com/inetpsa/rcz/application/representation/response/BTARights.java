package com.inetpsa.rcz.application.representation.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.inetpsa.rcz.application.representation.ServiceRepresentation;

import java.io.Serializable;

/**
 * @author tuan.docao@ext.mpsa.com
 */
public class BTARights implements Serializable {

    @JsonProperty("event_id")
    private String eventId;

    @JsonProperty("uin")
    private String uin;

    @JsonProperty("vin")
    private String vin;

    @JsonProperty("service")
    private ServiceRepresentation service;

    public BTARights() {
    }

    public String getEventId() {
        return eventId;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }

    public String getUin() {
        return uin;
    }

    public void setUin(String uin) {
        this.uin = uin;
    }

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    public ServiceRepresentation getService() {
        return service;
    }

    public void setService(ServiceRepresentation service) {
        this.service = service;
    }
}
