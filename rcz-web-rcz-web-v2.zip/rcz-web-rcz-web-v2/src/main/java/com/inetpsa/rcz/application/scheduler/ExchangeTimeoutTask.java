package com.inetpsa.rcz.application.scheduler;

import com.inetpsa.rcz.application.configuration.PoolConfig;
import com.inetpsa.rcz.domain.model.event.RequestTimeout;
import org.seedstack.business.domain.DomainEventPublisher;
import org.seedstack.scheduler.SchedulingContext;
import org.seedstack.scheduler.Task;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import javax.inject.Inject;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadPoolExecutor;

public class ExchangeTimeoutTask implements Task {

    @Inject
    private DomainEventPublisher eventPublisher;

    private final static ThreadPoolExecutor THREAD_POOL_EXECUTOR = new PoolConfig(PoolConfig.RejectedExecutionPolicy.DISCARD).getThreadPoolExecutor();

    @Logging
    private Logger logger;

    @Override
    public void execute(SchedulingContext sc) throws Exception {
        try {

            THREAD_POOL_EXECUTOR.execute(() -> eventPublisher.publish(new RequestTimeout()));
        } catch (RejectedExecutionException e) {
            logger.warn("ExchangeTimeout Batch threadpool is already full", e);
        }
    }
}
