package com.inetpsa.rcz.application.handlers.event;

import com.inetpsa.rcz.domain.model.enums.EventMessage;
import com.inetpsa.rcz.domain.model.enums.ResponseStatus;
import com.inetpsa.rcz.domain.model.event.ServiceStateDeleted;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.log.LogMessage;
import com.inetpsa.rcz.domain.services.ExchangeService;
import com.inetpsa.rcz.domain.services.LogService;
import org.seedstack.business.domain.BaseDomainEventHandler;

import javax.inject.Inject;

public class ServiceStateDeletedHandler extends BaseDomainEventHandler<ServiceStateDeleted> {
    @Inject
    private LogService logService;

    @Inject
    private ExchangeService exchangeService;

    @Override
    //TODO comment exchange status off, when all vehicles will supports the delete feature
    public void onEvent(ServiceStateDeleted serviceStateDeleted) {
        Exchange exchange = serviceStateDeleted.getExchange();
        exchange.setResponseStatus(serviceStateDeleted.getBtaResponsePayload().getResponseStatus());
        if (serviceStateDeleted.getBtaResponsePayload().getResponseStatus().equals(ResponseStatus.STATUS_OK)) {
            //exchange.setStatus(ExchangeStatus.FINISHED);
            logService.info(LogMessage.create(EventMessage.SERVICE_STATE_DELETED), exchange);
        }else {
            //exchange.setStatus(ExchangeStatus.ERROR);
            logService.error(LogMessage.create(EventMessage.SERVICE_STATE_DELETE_ERROR), exchange);
        }
        exchangeService.update(exchange);
    }
}
