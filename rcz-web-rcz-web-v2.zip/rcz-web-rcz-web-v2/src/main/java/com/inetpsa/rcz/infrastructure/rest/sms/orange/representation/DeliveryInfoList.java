package com.inetpsa.rcz.infrastructure.rest.sms.orange.representation;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DeliveryInfoList {

    private List<DeliveryInfo> deliveryInfo = new ArrayList<>();
    private String resourceURL;

    public List<DeliveryInfo> getDeliveryInfo() {
        return deliveryInfo;
    }

    public DeliveryInfoList setDeliveryInfo(List<DeliveryInfo> deliveryInfo) {
        this.deliveryInfo = deliveryInfo;
        return this;
    }

    public String getResourceURL() {
        return resourceURL;
    }

    public DeliveryInfoList setResourceURL(String resourceURL) {
        this.resourceURL = resourceURL;
        return this;
    }

    public void addDeliveryInfo(DeliveryInfo deliveryInfo){
        this.deliveryInfo.add(deliveryInfo);
    }
}
