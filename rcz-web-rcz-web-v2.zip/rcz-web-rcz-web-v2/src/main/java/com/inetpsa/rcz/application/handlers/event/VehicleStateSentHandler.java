package com.inetpsa.rcz.application.handlers.event;

import com.inetpsa.rcz.application.util.LocalizationKey;
import com.inetpsa.rcz.domain.model.enums.ProcessStatus;
import com.inetpsa.rcz.domain.model.event.VehicleStateSent;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.payload.response.ProcessPayload;

import java.util.Date;

public class VehicleStateSentHandler extends AbstractProcessEventHandler<VehicleStateSent> {

    @Override
    protected ProcessPayload buildProcessPayload(Exchange exchange) {
        ProcessPayload processPayload = new ProcessPayload();
        processPayload.setVin(exchange.getVin());
        processPayload.setCode(ProcessStatus.PSA_VEH_STATE_REQUEST.code());
        processPayload.setCorrelationId(exchange.getCorrelationId());
        processPayload.setDate(new Date());
        processPayload.setMessage(localizationService.localize(LocalizationKey.PROCESS_902_CHECKING_VEHICLE_STATE_KEY));
        return processPayload;
    }
}
