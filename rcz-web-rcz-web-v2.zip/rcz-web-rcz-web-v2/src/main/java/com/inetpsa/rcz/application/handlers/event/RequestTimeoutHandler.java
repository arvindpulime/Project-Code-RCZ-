package com.inetpsa.rcz.application.handlers.event;

import com.inetpsa.rcz.domain.model.action.Action;
import com.inetpsa.rcz.domain.model.action.ActionType;
import com.inetpsa.rcz.domain.model.enums.EventMessage;
import com.inetpsa.rcz.domain.model.enums.ExchangeStatus;
import com.inetpsa.rcz.domain.model.enums.ResponseStatus;
import com.inetpsa.rcz.domain.model.event.ErrorOccurred;
import com.inetpsa.rcz.domain.model.event.RequestTimeout;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.log.LogMessage;
import com.inetpsa.rcz.domain.services.ExchangeService;
import com.inetpsa.rcz.domain.services.LogService;
import com.inetpsa.rcz.domain.services.ParameterService;
import org.seedstack.business.domain.BaseDomainEventHandler;
import org.seedstack.business.domain.DomainEventPublisher;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import javax.inject.Inject;
import java.util.List;

@JpaUnit("rcz")
public class RequestTimeoutHandler extends BaseDomainEventHandler<RequestTimeout> {

    @Logging
    private Logger logger;

    @Inject
    private ExchangeService exchangeService;

    @Inject
    private LogService logService;

    @Inject
    private DomainEventPublisher eventPublisher;

    @Inject
    private ParameterService parameterService;

    @Override
    public void onEvent(RequestTimeout event) {
        try {
            logger.info("PURGE TASK FIRED");
            List<Exchange> exchanges = exchangeService.findAllInTimeout(parameterService.get().getRcz().getExchangeTimeoutMin());
            if (exchanges != null && !exchanges.isEmpty()) {
                exchanges.forEach(this::processTimeout);
                logger.info("NUMBER OF EXCHANGES HANDLED : {}", exchanges.size());
            } else {
                logger.info("NO TIMEOUT EXCHANGE FOUND FOR PURGE");
            }
        } catch (Exception e) {//NOSONAR
            logger.error("AN ERROR OCCURRED ON THE PURGING TASK", e);
        }
    }

    private void processTimeout(Exchange exchange) {
        if (!Action.REMOTE_ALARM.equals(exchange.getAction())
                && !Action.STOLEN_VIN.equals(exchange.getAction())
                && !Action.TRACKING.equals(exchange.getAction())
                && ((!ActionType.IMMOBILIZATION.equals(exchange.getAction().getActionType())
                || (ActionType.IMMOBILIZATION.equals(exchange.getAction().getActionType())
                && !ResponseStatus.STATUS_OK.equals(exchange.getResponseStatus()))))) {
            exchange.setStatus(ExchangeStatus.ERROR);
            exchange.setResponseStatus(ResponseStatus.VEHICLE_CONNECTION_TIMEOUT);
            exchangeService.update(exchange);
            logService.warn(LogMessage.create(EventMessage.REQUEST_TIMEOUT), exchange);
            eventPublisher.publish(new ErrorOccurred(exchange, ResponseStatus.VEHICLE_CONNECTION_TIMEOUT));
        }
    }

}
