package com.inetpsa.rcz.application.handlers.payload.charging.state;

import com.inetpsa.rcz.application.handlers.payload.BTARequestHandler;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.payload.data.VehicleChargingState;
import com.inetpsa.rcz.domain.model.payload.request.BTARequestPayload;
import com.inetpsa.rcz.domain.model.payload.request.RequestPayload;

import java.util.Date;

public class ChargingStateBTARequestHandler implements BTARequestHandler<VehicleChargingState, Void> {


    @Override
    public BTARequestPayload<Void> handle(Exchange exchange, RequestPayload<VehicleChargingState> requestPayload) {
        BTARequestPayload<Void> btaRequest = new BTARequestPayload<>();
        btaRequest.setRequestDate(new Date());
        btaRequest.setRequestId(exchange.getId());
        return btaRequest;
    }
}
