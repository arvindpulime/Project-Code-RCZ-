package com.inetpsa.rcz.application.handlers.event;

import com.inetpsa.rcz.application.exceptions.JsonParseException;
import com.inetpsa.rcz.application.services.PublisherService;
import com.inetpsa.rcz.application.services.PublisherService.Target.TargetBuilder;
import com.inetpsa.rcz.domain.model.enums.EventMessage;
import com.inetpsa.rcz.domain.model.event.ImmoStateForwarded;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.log.LogMessage;
import com.inetpsa.rcz.domain.model.payload.data.BtaCrudData;
import com.inetpsa.rcz.domain.model.payload.data.Immobilization;
import com.inetpsa.rcz.domain.model.payload.request.BTARequestPayload;
import com.inetpsa.rcz.domain.model.payload.request.ImmoStateRequestPayload;
import com.inetpsa.rcz.domain.model.payload.topic.BtaTopicsResolver;
import com.inetpsa.rcz.domain.model.payload.topic.Topic;
import com.inetpsa.rcz.domain.services.ExchangeService;
import com.inetpsa.rcz.domain.services.LogService;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;
import org.seedstack.business.domain.BaseDomainEventHandler;
import org.seedstack.business.domain.DomainEventPublisher;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.Date;

import static com.inetpsa.rcz.domain.model.payload.topic.Topic.*;

public class ImmoStateForwardedHandler extends BaseDomainEventHandler<ImmoStateForwarded> {

    @Logging
    private Logger logger;

    @Inject
    private ExchangeService exchangeService;

    @Named("mqtt")
    @Inject
    private PublisherService publisherService;

    @Inject
    private LogService logService;

    @Inject
    private DomainEventPublisher eventPublisher;

    @Inject
    private BtaTopicsResolver<Immobilization> immobilizationBtaTopicsResolver;

    @Override
    public void onEvent(ImmoStateForwarded event) {
        try {
            Exchange exchange = event.getExchange();
            // build & save BTA request
            BTARequestPayload<BtaCrudData> btaRequestPayload = buildBtaRequest(exchange, event.getImmoStateRequestPayload());
            String btaRequestJson = JsonConverter.convert(btaRequestPayload);
            // veh is awake ?
            // -- no VehicleWakeUpRequested
            // -- yes continue

            String btaTopic = getDeleteTopic(event.getTopic());
            publisherService.publish(btaRequestJson, TargetBuilder.builder().withTopic(btaTopic).build());
            // VehicleCommandSent --> log request BTA
            logService.info(LogMessage.create(EventMessage.IMMOBILIZATION_STATE_DELETED).data(btaRequestJson).topic(btaTopic), exchange);
        } catch (JsonParseException e) {
            logger.error(e.getMessage(), e);
        }
    }

    static String getDeleteTopic(Topic topic) {
        return new StringBuilder(ORGANIZATION).append(Topic.TOPIC_SEP)
                .append(topic.getActionService().literal()).append(TOPIC_SEP)
                .append(Topic.Direction.TO.literal()).append(TOPIC_SEP)
                .append(Topic.Tag.UIN.literal()).append(TOPIC_SEP)
                .append(topic.getId()).append(TOPIC_SEP)
                .append(topic.getActionType().literal()).append(TOPIC_SEP)
                .append(BTA_DELETE).toString();
    }

    private BTARequestPayload<BtaCrudData> buildBtaRequest(Exchange exchange, ImmoStateRequestPayload immoStateRequestPayload) {
        //TODO Req ID from immoData
        BTARequestPayload<BtaCrudData> btaRequestPayload = new BTARequestPayload();
        if (immoStateRequestPayload != null) {
        btaRequestPayload.setData(new BtaCrudData(immoStateRequestPayload.getRequestId()));
        }
        btaRequestPayload.setRequestDate(new Date());
        btaRequestPayload.setRequestId(exchange.getId());

        return btaRequestPayload;
    }
}
