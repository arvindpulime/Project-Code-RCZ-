package com.inetpsa.rcz.infrastructure.rest.sms.orange.representation;

import com.inetpsa.rcz.application.util.ClientConfig;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class OrangeRestClientConfig extends ClientConfig {

    private String senderAddress;
    private String headerHost;

}
