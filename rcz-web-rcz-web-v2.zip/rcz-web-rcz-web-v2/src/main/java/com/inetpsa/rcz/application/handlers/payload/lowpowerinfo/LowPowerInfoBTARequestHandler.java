package com.inetpsa.rcz.application.handlers.payload.lowpowerinfo;

import com.inetpsa.rcz.application.handlers.payload.BTARequestHandler;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.payload.data.LowPowerInfoRequest;
import com.inetpsa.rcz.domain.model.payload.data.VehicleState;
import com.inetpsa.rcz.domain.model.payload.request.BTARequestPayload;
import com.inetpsa.rcz.domain.model.payload.request.RequestPayload;

public class LowPowerInfoBTARequestHandler implements BTARequestHandler<LowPowerInfoRequest, Void> {

    @Override
    public BTARequestPayload<Void> handle(Exchange exchange, RequestPayload<LowPowerInfoRequest> requestPayload) {
        return null;
    }
}
