package com.inetpsa.rcz.application.handlers.event;

import com.fasterxml.jackson.core.type.TypeReference;
import com.inetpsa.rcz.application.configuration.RczConfig;
import com.inetpsa.rcz.application.exceptions.ApplicationException;
import com.inetpsa.rcz.application.exceptions.JsonParseException;
import com.inetpsa.rcz.application.services.AuthorizationService;
import com.inetpsa.rcz.application.services.PublisherService;
import com.inetpsa.rcz.application.services.PublisherService.Target.TargetBuilder;
import com.inetpsa.rcz.application.services.ValidationService;
import com.inetpsa.rcz.domain.model.action.Action;
import com.inetpsa.rcz.domain.model.action.ActionType;
import com.inetpsa.rcz.domain.model.enums.CallerType;
import com.inetpsa.rcz.domain.model.enums.EventMessage;
import com.inetpsa.rcz.domain.model.enums.ExchangeStatus;
import com.inetpsa.rcz.domain.model.enums.ResponseStatus;
import com.inetpsa.rcz.domain.model.event.AlarmForwarded;
import com.inetpsa.rcz.domain.model.event.AlarmReceived;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.log.LogMessage;
import com.inetpsa.rcz.domain.model.payload.request.RemoteAlarmRequestPayload;
import com.inetpsa.rcz.domain.model.payload.request.RequestPayload;
import com.inetpsa.rcz.domain.model.payload.topic.Topic;
import com.inetpsa.rcz.domain.model.shared.Payload;
import com.inetpsa.rcz.domain.services.ExchangeService;
import com.inetpsa.rcz.domain.services.LogService;
import com.inetpsa.rcz.domain.services.ParameterService;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;
import org.seedstack.business.domain.BaseDomainEventHandler;
import org.seedstack.business.domain.DomainEventPublisher;
import org.seedstack.business.domain.Factory;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.Date;

public class AlarmReceivedHandler extends BaseDomainEventHandler<AlarmReceived> {

    @Logging
    private Logger logger;

    @Inject
    private Factory<Exchange> exchangeFactory;

    @Inject
    private ExchangeService exchangeService;

    @Inject
    @Named("kafka")
    private PublisherService publisherService;

    @Inject
    private ValidationService validationService;

    @Inject
    private LogService logService;

    @Inject
    private ParameterService parameterService;

    @Inject
    private AuthorizationService authorizationService;

    @Inject
    private DomainEventPublisher eventPublisher;

    @Configuration
    private RczConfig rczConfig;

    @Override
    public void onEvent(AlarmReceived event) {
        Exchange exchange = initExchange(event.getTopic(), event.getMessage());
        logService.info(LogMessage.create(EventMessage.ALARM_RECEIVED).data(event.getMessage()).topic(event.getTopic().toString()), exchange);
        try {
            RemoteAlarmRequestPayload remoteAlarmRequestPayload = getRemoteAlarmRequestPayload(event);
            validationService.validateRequest(remoteAlarmRequestPayload);
            updateWithRemoteAlarmPayload(exchange, remoteAlarmRequestPayload);
            authorizationService.authorizeActionFromUIN(exchange);
            String response = buildResponse(exchange, remoteAlarmRequestPayload, event.getTopic());
            publisherService.publish(response, TargetBuilder.builder().withTopic(rczConfig.getExchange().getTopics().getAlarm()).withKey(exchange.getCallerId()).build());
            logService.info(LogMessage.create(EventMessage.ALARM_FORWARDED).data(response).topic(rczConfig.getExchange().getTopics().getAlarm()), exchange);
            eventPublisher.publish(new AlarmForwarded(exchange, remoteAlarmRequestPayload));
        } catch (ApplicationException e) {//NOSONAR
            updateWithError(exchange, e);
            logService.error(LogMessage.create(EventMessage.ALARM_ERROR_OCCURRED).data(e.getMessage()), exchange);
        }
    }

    private RemoteAlarmRequestPayload.AlarmType getAlarmType(Topic topic) {
        if (topic.getActionType().equals(ActionType.MOTION_ALERT)) {
            return RemoteAlarmRequestPayload.AlarmType.MOTION_ALERT;
        } else {
            return RemoteAlarmRequestPayload.AlarmType.VEHICLE_ALARM;
        }
    }

    private RemoteAlarmRequestPayload getRemoteAlarmRequestPayload(AlarmReceived event) throws ApplicationException {
        try {
            return JsonConverter.convert(event.getMessage(), new TypeReference<RemoteAlarmRequestPayload>() {
            });
        } catch (JsonParseException e) {
            throw new ApplicationException(e.getMessage(), e, ResponseStatus.BAD_REQUEST);
        }
    }

    private String buildResponse(Exchange exchange, RemoteAlarmRequestPayload remoteAlarmPayload, Topic topic) {
        RequestPayload<RemoteAlarmRequestPayload> requestPayload = new RequestPayload<>();
        requestPayload.setCorrelationId(exchange.getCorrelationId());
        requestPayload.setRequestDate(new Date());
        requestPayload.setVin(exchange.getVin());
        remoteAlarmPayload.setVin(null);
        remoteAlarmPayload.setAlarmType(getAlarmType(topic));
        requestPayload.setRequestParameters(remoteAlarmPayload);
        return JsonConverter.convert(requestPayload);
    }

    private void updateWithError(Exchange exchange, ApplicationException e) {
        exchange.setStatus(ExchangeStatus.ERROR);
        exchange.setResponseStatus(e.getResponseStatus());
        exchangeService.update(exchange);
    }

    private Exchange initExchange(Topic topic, String request) {
        Exchange exchange = exchangeFactory.create();
        if (Topic.Tag.UIN == topic.getTag()) {
            exchange.setCallerType(CallerType.VEHICLE);
            exchange.setCallerId(topic.getId());
            exchange.setUin(topic.getId());
        }
        exchange.setRequest(new Payload(new Date(), request));
        exchange.setAction(Action.create(topic.getActionService(), topic.getActionType()));
        exchange.setTopic(topic.toString());
        exchange.setStatus(ExchangeStatus.INITIAL);
        exchangeService.add(exchange);
        return exchange;
    }

    private void updateWithRemoteAlarmPayload(Exchange exchange, RemoteAlarmRequestPayload remoteAlarmPayload) {
        exchange.setCorrelationId(exchange.getId());
        exchange.setVin(remoteAlarmPayload.getVin());
        exchange.setStatus(ExchangeStatus.PENDING);
        exchange.setResponseStatus(ResponseStatus.STATUS_OK);
        exchangeService.update(exchange);
    }

}
