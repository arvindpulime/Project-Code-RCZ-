package com.inetpsa.rcz.application.services;

import com.inetpsa.rcz.application.exceptions.ApplicationException;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.payload.data.VehicleStateResult;
import com.inetpsa.rcz.domain.model.payload.response.BTAResponsePayload;
import org.seedstack.business.Service;

@Service
public interface AccessService {

    void checkAccess(BTAResponsePayload btaResponsePayload, Exchange exchange) throws ApplicationException;

    void checkAccess(VehicleStateResult vehicleStateResult, Exchange exchange) throws ApplicationException;
}
