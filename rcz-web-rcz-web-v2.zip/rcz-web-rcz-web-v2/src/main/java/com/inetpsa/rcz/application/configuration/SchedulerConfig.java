package com.inetpsa.rcz.application.configuration;

public class SchedulerConfig {
    private int delay = 60000;

    private boolean enable = false;

    public int getDelay() {
        return delay;
    }

    public boolean isEnable() {
        return enable;
    }
}