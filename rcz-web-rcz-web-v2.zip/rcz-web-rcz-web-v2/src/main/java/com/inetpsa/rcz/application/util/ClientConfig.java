package com.inetpsa.rcz.application.util;

import lombok.Data;
import lombok.experimental.Accessors;

import java.util.HashMap;
import java.util.Map;

@Data
@Accessors(chain = true)
public class ClientConfig {

    private String host;
    private String username;
    private String password;
    private int maxRetry = 3;
    private int delay = 1000;
    private int requestTimeout = 10000;
    private int connectionTimeout = 10000;
    private boolean mocked;
    private SSLConfig ssl = new SSLConfig();

    @Data
    @Accessors(chain = true)
    public static class SSLConfig {
        private SSLConfig.TrustStoreConfig truststore = new TrustStoreConfig();

        public SSLConfig.TrustStoreConfig getTruststore() {
            return truststore;
        }

        @Data
        @Accessors(chain = true)
        public static class TrustStoreConfig {
            private String file;
            private String password;

            public String getFile() {
                return file;
            }

            public String getPassword() {
                return password;
            }
        }
    }

    public int getRequestTimeout() {
        return requestTimeout;
    }
}
