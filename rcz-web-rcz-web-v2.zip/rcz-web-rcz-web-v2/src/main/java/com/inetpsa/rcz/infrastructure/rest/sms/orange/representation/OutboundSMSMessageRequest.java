package com.inetpsa.rcz.infrastructure.rest.sms.orange.representation;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OutboundSMSMessageRequest {

    private List<String> address;
    private DeliveryInfoList deliveryInfoList;
    private String senderAddress;
    private String resourceURL;
    private OutboundSMSTextMessage outboundSMSTextMessage;
    private OutboundSMSTextMessage outboundSMSBinaryMessage;
    private int validityPeriod;
    private String subAddress;

}