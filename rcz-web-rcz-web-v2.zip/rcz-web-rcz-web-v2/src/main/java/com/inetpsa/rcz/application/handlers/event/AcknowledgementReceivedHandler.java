package com.inetpsa.rcz.application.handlers.event;

import com.fasterxml.jackson.core.type.TypeReference;
import com.inetpsa.rcz.application.exceptions.TechnicalException;
import com.inetpsa.rcz.domain.model.enums.EventMessage;
import com.inetpsa.rcz.domain.model.event.AcknowledgmentReceived;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.log.LogMessage;
import com.inetpsa.rcz.domain.model.payload.data.Acknowledgement;
import com.inetpsa.rcz.domain.services.ExchangeService;
import com.inetpsa.rcz.domain.services.LogService;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;
import org.seedstack.business.domain.BaseDomainEventHandler;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import javax.inject.Inject;
import java.text.MessageFormat;

public class AcknowledgementReceivedHandler extends BaseDomainEventHandler<AcknowledgmentReceived> {
    public static final String EXCHANGE_UNKNOWN_FOR_ACK_0 = "Exchange Unknown for ACK : [{0}]";
    @Logging
    protected Logger logger;
    @Inject
    protected ExchangeService exchangeService;
    @Inject
    protected LogService logService;

    @Override
    public void onEvent(AcknowledgmentReceived event) {
        try {
            Acknowledgement acknowledgement = JsonConverter.convert(event.getMessage(), new TypeReference<Acknowledgement>() {
            });
            Exchange exchange = exchangeService.findById(acknowledgement.getRequestId()).orElseThrow(() -> new TechnicalException(MessageFormat.format(EXCHANGE_UNKNOWN_FOR_ACK_0, acknowledgement.getRequestId())));
            logService.info(LogMessage.create(EventMessage.ACKNOWLEGEMENT_RECEIVED).data(event.getMessage()).topic(event.getTopic()), exchange);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
    }
}
