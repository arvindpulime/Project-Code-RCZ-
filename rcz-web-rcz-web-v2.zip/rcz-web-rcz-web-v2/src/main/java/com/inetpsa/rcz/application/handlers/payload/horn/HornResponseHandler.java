package com.inetpsa.rcz.application.handlers.payload.horn;

import com.fasterxml.jackson.core.type.TypeReference;
import com.inetpsa.rcz.application.handlers.payload.AbstractResponseHandler;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.payload.data.Data;
import com.inetpsa.rcz.domain.model.payload.data.Horn;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;
import org.apache.commons.lang3.StringUtils;

public class HornResponseHandler extends AbstractResponseHandler<Horn> {

    @Override
    protected Horn handleResponseData(Data data, Exchange exchange) {
        if (StringUtils.isNotBlank(data.getValue())) {
            return JsonConverter.convert(data.getValue(), new TypeReference<Horn>() {
            });
        }
        return null;
    }
}
