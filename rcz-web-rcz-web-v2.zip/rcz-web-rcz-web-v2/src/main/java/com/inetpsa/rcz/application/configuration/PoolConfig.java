package com.inetpsa.rcz.application.configuration;

import org.seedstack.coffig.SingleValue;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class PoolConfig {
    @SingleValue
    private boolean enabled = true;
    private int coreSize = 1;
    private int maxSize = 1;
    private int queueSize = 100;
    private int keepAlive = 300;
    private PoolConfig.RejectedExecutionPolicy rejectedExecutionPolicy;

    public PoolConfig() {
        this.rejectedExecutionPolicy = PoolConfig.RejectedExecutionPolicy.CALLER_RUNS;
    }
    public PoolConfig(PoolConfig.RejectedExecutionPolicy rejectedExecutionPolicy) {
        this.rejectedExecutionPolicy = rejectedExecutionPolicy;
    }
    public boolean isEnabled() {
        return this.enabled;
    }

    public PoolConfig setEnabled(boolean enabled) {
        this.enabled = enabled;
        return this;
    }


    public ThreadPoolExecutor getThreadPoolExecutor() {
        ThreadPoolExecutor threadPoolExecutor = new ThreadPoolExecutor(
                this.getCoreSize(),
                this.getMaxSize(),
                this.getKeepAlive(), TimeUnit.SECONDS,
                new ArrayBlockingQueue<>(this.getQueueSize())
        );
        threadPoolExecutor.setRejectedExecutionHandler(this.getRejectedExecutionHandler());
        return threadPoolExecutor;
    }

    public int getCoreSize() {
        return this.coreSize;
    }

    public PoolConfig setCoreSize(int coreSize) {
        this.coreSize = coreSize;
        return this;
    }

    public int getMaxSize() {
        return this.maxSize;
    }

    public PoolConfig setMaxSize(int maxSize) {
        this.maxSize = maxSize;
        return this;
    }

    public int getQueueSize() {
        return this.queueSize;
    }

    public PoolConfig setQueueSize(int queueSize) {
        this.queueSize = queueSize;
        return this;
    }

    public int getKeepAlive() {
        return this.keepAlive;
    }

    public PoolConfig setKeepAlive(int keepAlive) {
        this.keepAlive = keepAlive;
        return this;
    }

    public PoolConfig.RejectedExecutionPolicy getRejectedExecutionPolicy() {
        return this.rejectedExecutionPolicy;
    }

    public PoolConfig setRejectedExecutionPolicy(PoolConfig.RejectedExecutionPolicy rejectedExecutionPolicy) {
        this.rejectedExecutionPolicy = rejectedExecutionPolicy;
        return this;
    }
    public RejectedExecutionHandler getRejectedExecutionHandler() {
        switch (this.rejectedExecutionPolicy) {
            case ABORT:
                return new ThreadPoolExecutor.AbortPolicy();
            case DISCARD:
                return new ThreadPoolExecutor.DiscardPolicy();
            case DISCARD_OLDEST:
                return new ThreadPoolExecutor.DiscardOldestPolicy();
            case CALLER_RUNS:
                return new ThreadPoolExecutor.CallerRunsPolicy();
            default:
                return new ThreadPoolExecutor.CallerRunsPolicy();
        }
    }
    public static enum RejectedExecutionPolicy {
        ABORT,
        DISCARD,
        CALLER_RUNS,
        DISCARD_OLDEST;

        private RejectedExecutionPolicy() {
        }
    }
}
