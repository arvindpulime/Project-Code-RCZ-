package com.inetpsa.rcz.infrastructure.rest.sms;

import com.inetpsa.rcz.application.services.WakeUpService;
import com.inetpsa.rcz.application.util.HexaUtils;
import com.inetpsa.rcz.domain.model.sms.Sms;
import com.inetpsa.rcz.domain.model.vehicle.Vehicle;
import com.inetpsa.rcz.domain.services.ParameterService;
import com.inetpsa.rcz.domain.services.SmsService;
import net.jodah.failsafe.RetryPolicy;

import javax.inject.Inject;
import java.time.Duration;

import static com.inetpsa.rcz.application.util.HexaUtils.dateToHex;
import static com.inetpsa.rcz.application.util.HexaUtils.intToHex;

public abstract class AbstractWakeUpService implements WakeUpService {

    public static final String VERSION = "1.0";

    public static final String SMS_TEXT_SEPARATOR = "7E";

    public static final String SMS_TEXT_CODE_01 = "01";

    public static final String SMS_TEXT_CODE_02 = "02";

    public static final String SMS_TEXT_CODE_03 = "03";

    public static final String SMS_TEXT_CODE_04 = "04";

    public static final String SMS_TEXT_CODE_05 = "05";

    public static final String SMS_TEXT_CODE_06 = "06";

    public static final String SMS_TEXT_CODE_07 = "07";

    public static final String SMS_TEXT_CODE_08 = "08";

    public static final String SMS_TEXT_CODE_09 = "09";

    public static final int SINGLE_BYTE = 2;
    public static final int BINARY_BASE = 2;
    public static final int TWO_BYTES = 4;
    public static final int FOUR_BYTES = 8;
    public static final int SIX_BYTES = 12;
    public static final int FIVE_BYTES = 10;
    public static final int TEN_BYTES = 20;
    public static final String PAD_STR = "0";
    public static final int SIX_BITS = 6;
    public static final int FOUR_BITS = 4;
    public static final int FIVE_BITS = 5;
    public static final int THREE_BYTES = 6;


    @Inject
    private ParameterService parameterService;

    @Inject
    private SmsService smsService;

    @Override
    public void wakeUp(Vehicle vehicle) {
        Sms sms = buildSms(vehicle);
        smsService.save(sms);
        sendSmsWithFailsafe(vehicle, sms);
    }

    public abstract void sendSmsWithFailsafe(Vehicle vehicle, Sms sms);

    public abstract Sms buildSms(Vehicle vehicle);


    protected Sms smsFail(Sms sms, Exception exception) {
        sms.setAnswerStatus(exception.getMessage());
        return smsService.update(sms);
    }

    protected RetryPolicy buildRetryPolicy() {
        RetryPolicy retryPolicy = new RetryPolicy();
        retryPolicy
                .withDelay(Duration.ofMillis(parameterService.get().getSms().getRetryDelay()))
                .withMaxRetries(parameterService.get().getSms().getNbRetry())
                .handle(WakeUpException.class);
        return retryPolicy;
    }

    protected String buildMessage(Vehicle vehicle, Sms sms) {
        StringBuilder builder = new StringBuilder(SMS_TEXT_CODE_01)
                .append(intToHex(String.valueOf(parameterService.get().getSms().getMessageVersion()), SINGLE_BYTE))
                .append(SMS_TEXT_SEPARATOR).append(SMS_TEXT_CODE_02).append(HexaUtils.stringToHex(vehicle.getShortVin(), TEN_BYTES))
                .append(SMS_TEXT_SEPARATOR).append(SMS_TEXT_CODE_03).append(intToHex(String.valueOf(parameterService.get().getSms().getDspt()), TWO_BYTES))
                .append(SMS_TEXT_SEPARATOR).append(SMS_TEXT_CODE_04).append(intToHex(String.valueOf(parameterService.get().getSms().getMessageId()), TWO_BYTES))
                .append(SMS_TEXT_SEPARATOR).append(SMS_TEXT_CODE_05).append(intToHex(String.valueOf(parameterService.get().getSms().getServiceType()), SINGLE_BYTE))
                .append(SMS_TEXT_SEPARATOR).append(SMS_TEXT_CODE_06).append(intToHex(String.valueOf(parameterService.get().getSms().getMessageType()), SINGLE_BYTE))
                .append(SMS_TEXT_SEPARATOR).append(SMS_TEXT_CODE_07).append(dateToHex(sms.getSendingDate()))
                .append(SMS_TEXT_SEPARATOR).append(SMS_TEXT_CODE_08).append(intToHex(String.valueOf(parameterService.get().getSms().getMessageVersion()), SINGLE_BYTE))
                .append(SMS_TEXT_SEPARATOR).append(SMS_TEXT_CODE_09).append(intToHex(String.valueOf(parameterService.get().getSms().getDataLength()), THREE_BYTES));
        return builder.toString().toUpperCase();
    }

}
