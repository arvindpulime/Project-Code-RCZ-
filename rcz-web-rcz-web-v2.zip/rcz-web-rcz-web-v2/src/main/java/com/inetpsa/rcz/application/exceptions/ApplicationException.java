package com.inetpsa.rcz.application.exceptions;


import com.inetpsa.rcz.domain.model.enums.ResponseStatus;

/**
 * @author tuan.docao@ext.mpsa.com
 */
public class ApplicationException extends Exception {

    private ResponseStatus responseStatus;

    public ApplicationException(ResponseStatus responseStatus) {
        this.responseStatus = responseStatus;
    }

    public ApplicationException(String message, ResponseStatus responseStatus) {
        super(message);
        this.responseStatus = responseStatus;
    }

    public ApplicationException(String message, Throwable cause, ResponseStatus responseStatus) {
        super(message, cause);
        this.responseStatus = responseStatus;
    }

    public ApplicationException(Throwable cause, ResponseStatus responseStatus) {
        super(cause);
        this.responseStatus = responseStatus;
    }

    public ResponseStatus getResponseStatus() {
        return responseStatus;
    }

}
