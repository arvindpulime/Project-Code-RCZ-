package com.inetpsa.rcz.application.handlers.payload.immobilization;

import com.inetpsa.rcz.application.handlers.payload.BTARequestHandler;
import com.inetpsa.rcz.application.util.HexaUtils;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.payload.ValidationPattern;
import com.inetpsa.rcz.domain.model.payload.data.Immobilization;
import com.inetpsa.rcz.domain.model.payload.request.BTARequestPayload;
import com.inetpsa.rcz.domain.model.payload.request.RequestPayload;

import java.util.Date;

public class ImmobilizationBTARequestHandler implements BTARequestHandler<Immobilization, Immobilization> {

    private static final String ACTIVATE = "activate";

    @Override
    public BTARequestPayload<Immobilization> handle(Exchange exchange, RequestPayload<Immobilization> requestPayload) {
        BTARequestPayload<Immobilization> btaRequest = new BTARequestPayload<>();
        btaRequest.setRequestDate(new Date());
        btaRequest.setRequestId(exchange.getId());
        boolean activate = ACTIVATE.equals(requestPayload.getRequestParameters().getAction());
        Immobilization immobilization = new Immobilization(activate);
        immobilization.setPassword(buildPassword(activate, exchange.getVin()));
        btaRequest.setData(immobilization);
        return btaRequest;
    }

    public static String buildPassword(boolean activate, String vin) {
        if (vin != null && vin.matches(ValidationPattern.PATTERN_VIN)) {
            if (activate) {
                return HexaUtils.stringToHex(vin.substring(10, 17), 7).toUpperCase();
            } else {
                return twoSComplementByChar(vin.substring(10, 17)).toUpperCase();
            }
        }
        return null;
    }

    private static String twoSComplementByChar(String value) {
        char[] chars = value.toCharArray();
        StringBuilder hex = new StringBuilder();
        for (char ch : chars) {
            int comp = -1 * Integer.parseInt(HexaUtils.stringToHex(String.valueOf(ch), 1), 16);
            hex.append(HexaUtils.intToHex(comp, 1));
        }
        return hex.toString();
    }
}
