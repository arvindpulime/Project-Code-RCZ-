package com.inetpsa.rcz.application.scheduler;

import com.google.common.collect.Lists;
import com.google.inject.Injector;
import com.google.inject.Key;
import com.google.inject.name.Names;
import com.inetpsa.rcz.application.configuration.RczConfig;
import com.inetpsa.rcz.domain.model.monitoring.MqttClient;
import com.inetpsa.rcz.domain.services.MonitoringService;
import org.eclipse.paho.client.mqttv3.IMqttClient;
import org.seedstack.mqtt.spi.MqttClientInfo;
import org.seedstack.mqtt.spi.MqttInfo;
import org.seedstack.mqtt.spi.MqttPoolInfo;
import org.seedstack.scheduler.SchedulingContext;
import org.seedstack.scheduler.Task;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import javax.inject.Inject;
import java.util.List;

public class MqttMonitoringTask implements Task {

    @Configuration("rcz")
    private RczConfig rczConfig;

    @Inject
    private MqttInfo mqttInfo;

    @Inject
    private Injector injector;

    @Logging
    private Logger logger;

    @Inject
    private MonitoringService monitoringService;

    @Override
    public void execute(SchedulingContext sc) throws Exception {
        MqttClientWrapper mqttClientWrapper = getMqttMonitoringData();
        monitoringService.updateMqttMonitoringData(mqttClientWrapper.getInstance(), mqttClientWrapper.getMqttClients());
    }


    private MqttClientWrapper getMqttMonitoringData() {
        List<MqttClient> clientList = Lists.newArrayList();
        for (String clientId : mqttInfo.getClientNames()) {
            MqttClient representation = buildClientRepresentation(clientId);
            clientList.add(representation);
        }
        return new MqttClientWrapper(rczConfig.getApplication().getInstance(), clientList);
    }

    private MqttClient buildClientRepresentation(String clientId) {
        final MqttClientInfo clientInfo = mqttInfo.getClientInfo(clientId);
        final IMqttClient client = injector.getInstance(Key.get(IMqttClient.class, Names.named(clientId)));

        MqttClient representation = new MqttClient().setConnected(client.isConnected());
        representation.serverURIs(clientInfo.getUri())
                .setCleanSession(clientInfo.isCleanSession())
                .setConnectionTimeout(clientInfo.getConnectionTimeout())
                .setKeepAliveInterval(clientInfo.getKeepAliveInterval())
                .setMqttVersion(clientInfo.getMqttVersion())
                .setReconnectionInterval(clientInfo.getReconnectionInterval())
                .setReconnectionMode(clientInfo.getMqttReconnectionMode());

        if (clientInfo.getTopicFilters() != null) {
            representation.topics(clientInfo.getTopicFilters());
        }

        MqttPoolInfo mqttPoolInfo;
        if ((mqttPoolInfo = clientInfo.getMqttPoolInfo()) != null) {
            representation.setPoolCoreSize(mqttPoolInfo.getCoreSize())
                    .setPoolKeepAlive(mqttPoolInfo.getKeepAlive())
                    .setPoolMaxSize(mqttPoolInfo.getMaxSize())
                    .setPoolQueueSize(mqttPoolInfo.getQueueSize());
        }
        return representation;
    }


    public class MqttClientWrapper {
        private String instance;
        private List<MqttClient> mqttClients;

        public MqttClientWrapper() {
        }

        public MqttClientWrapper(String instance, List<MqttClient> mqttClients) {
            this.instance = instance;
            this.mqttClients = mqttClients;
        }

        public String getInstance() {
            return instance;
        }

        public List<MqttClient> getMqttClients() {
            return mqttClients;
        }
    }
}
