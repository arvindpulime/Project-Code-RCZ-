package com.inetpsa.rcz.application.handlers.payload;

import com.inetpsa.rcz.application.exceptions.ApplicationException;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.payload.request.BTARequestPayload;
import com.inetpsa.rcz.domain.model.payload.request.RequestPayload;
import org.seedstack.business.Service;

@Service
public interface BTARequestHandler<R, B> {
    BTARequestPayload<B> handle(Exchange exchange, RequestPayload<R> requestPayload) throws ApplicationException;
}
