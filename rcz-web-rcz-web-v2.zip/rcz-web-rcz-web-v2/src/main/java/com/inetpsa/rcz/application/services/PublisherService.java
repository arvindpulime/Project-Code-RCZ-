package com.inetpsa.rcz.application.services;

import org.seedstack.business.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public interface PublisherService {

    /**
     * Publishes a message to a topic on multiple broker
     *
     * @param message - message to publisher
     * @param target  - to deliver the message to
     */
    void publish(String message, Target target);

    /**
     * Publishes a message to a topic on multiple broker
     *
     * @param message - message to publisher
     * @param target  - to deliver the message to
     * @param clients - destinations
     */
    void publish(String message, Target target, String... clients);

    class Target {
        private String topic;
        private String key;
        private Map<String, String> headers = new HashMap<>();

        public String getTopic() {
            return topic;
        }

        public Target setTopic(String topic) {
            this.topic = topic;
            return this;
        }

        public String getKey() {
            return key;
        }

        public Target setKey(String key) {
            this.key = key;
            return this;
        }

        public Map<String, String> getHeaders() {
            return headers;
        }

        public Target setHeaders(Map<String, String> headers) {
            this.headers = headers;
            return this;
        }

        public static final class TargetBuilder {
            private String topic;
            private String key;
            private Map<String, String> headers = new HashMap<>();
            private TargetBuilder() {
            }

            public static TargetBuilder builder() {
                return new TargetBuilder();
            }

            public TargetBuilder withTopic(String topic) {
                this.topic = topic;
                return this;
            }

            public TargetBuilder withKey(String key) {
                this.key = key;
                return this;
            }
            public TargetBuilder withHeader(String key, String value) {
                this.headers.put(key, value);
                return this;
            }


            public Target build() {
                Target target = new Target();
                target.key = this.key;
                target.topic = this.topic;
                target.headers = this.headers;
                return target;
            }
        }
    }

}
