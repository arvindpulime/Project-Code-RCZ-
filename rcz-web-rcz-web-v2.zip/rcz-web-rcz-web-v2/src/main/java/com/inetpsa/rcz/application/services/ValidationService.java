package com.inetpsa.rcz.application.services;

import com.inetpsa.rcz.application.exceptions.ApplicationException;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import org.seedstack.business.Service;
import org.seedstack.seed.transaction.Transactional;

@Service
public interface ValidationService {

    <T> void validateRequest(T requestPayload) throws ApplicationException;

    void checkQuota(Exchange exchange) throws ApplicationException;

    void checkDuplicate(Exchange exchange) throws ApplicationException;

    void checkTimeout(Exchange exchange) throws ApplicationException;

    void checkUserQuotaForWarning(Exchange exchange) throws ApplicationException;

    void checkActionRight(Exchange exchange) throws ApplicationException;
}
