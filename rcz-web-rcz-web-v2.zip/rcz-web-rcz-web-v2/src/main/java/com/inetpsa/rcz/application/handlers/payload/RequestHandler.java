package com.inetpsa.rcz.application.handlers.payload;

import com.inetpsa.rcz.application.exceptions.ApplicationException;
import com.inetpsa.rcz.domain.model.payload.request.RequestPayload;
import org.seedstack.business.Service;

@Service
public interface RequestHandler<R> {
    RequestPayload<R> handle(String request) throws ApplicationException;
}
