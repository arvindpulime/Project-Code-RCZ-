package com.inetpsa.rcz.application.representation.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.inetpsa.rcz.application.representation.ServiceRepresentation;

import java.io.Serializable;
import java.util.List;

/**
 * @author tuan.docao@ext.mpsa.com
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Grant implements Serializable {

    @JsonProperty("contract_id")
    private String contractId;

    @JsonProperty("uin")
    private String uin;

    @JsonProperty("services")
    private List<ServiceRepresentation> services;

    public Grant() {
    }

    public String getContractId() {
        return contractId;
    }

    public void setContractId(String contractId) {
        this.contractId = contractId;
    }

    public String getUin() {
        return uin;
    }

    public void setUin(String uin) {
        this.uin = uin;
    }

    public List<ServiceRepresentation> getServices() {
        return services;
    }

    public void setServices(List<ServiceRepresentation> services) {
        this.services = services;
    }
}
