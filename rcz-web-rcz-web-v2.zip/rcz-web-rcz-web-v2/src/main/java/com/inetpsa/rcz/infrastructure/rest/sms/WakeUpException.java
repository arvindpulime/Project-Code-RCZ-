package com.inetpsa.rcz.infrastructure.rest.sms;

/**
 * Internal Bytel exception
 */
public class WakeUpException extends RuntimeException {

    public WakeUpException(String message) {
        super(message);
    }

    public WakeUpException(String message, Throwable cause) {
        super(message, cause);
    }

}