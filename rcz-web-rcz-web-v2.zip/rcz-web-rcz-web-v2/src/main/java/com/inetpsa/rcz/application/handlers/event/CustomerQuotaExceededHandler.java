package com.inetpsa.rcz.application.handlers.event;

import com.inetpsa.rcz.application.util.LocalizationKey;
import com.inetpsa.rcz.domain.model.enums.ProcessStatus;
import com.inetpsa.rcz.domain.model.event.CustomerQuotaExceeded;
import com.inetpsa.rcz.domain.model.event.VehicleCommandSent;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.payload.response.ProcessPayload;

import java.util.Date;

public class CustomerQuotaExceededHandler extends AbstractProcessEventHandler<CustomerQuotaExceeded> {

    @Override
    protected ProcessPayload buildProcessPayload(Exchange exchange) {
        ProcessPayload processPayload = new ProcessPayload();
        processPayload.setVin(exchange.getVin());
        processPayload.setCode(ProcessStatus.QUOTA_EXCEEDED_WARNING.code());
        processPayload.setCorrelationId(exchange.getCorrelationId());
        processPayload.setDate(new Date());
        processPayload.setMessage(localizationService.localize(LocalizationKey.PROCESS_904_REQUEST_QUOTA_EXCEEDED_WARNING));
        return processPayload;
    }
}