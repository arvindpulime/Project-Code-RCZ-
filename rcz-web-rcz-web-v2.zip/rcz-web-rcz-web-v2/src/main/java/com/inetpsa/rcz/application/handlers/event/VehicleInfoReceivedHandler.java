package com.inetpsa.rcz.application.handlers.event;

import com.fasterxml.jackson.core.type.TypeReference;
import com.inetpsa.rcz.application.configuration.RczConfig;
import com.inetpsa.rcz.application.exceptions.ApplicationException;
import com.inetpsa.rcz.application.exceptions.JsonParseException;
import com.inetpsa.rcz.application.services.AuthorizationService;
import com.inetpsa.rcz.application.services.PublisherService;
import com.inetpsa.rcz.application.services.ValidationService;
import com.inetpsa.rcz.application.services.VehicleUpstreamService;
import com.inetpsa.rcz.domain.model.enums.EventMessage;
import com.inetpsa.rcz.domain.model.enums.ExchangeStatus;
import com.inetpsa.rcz.domain.model.enums.ResponseStatus;
import com.inetpsa.rcz.domain.model.event.VehicleInfoReceived;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.log.LogMessage;
import com.inetpsa.rcz.domain.model.payload.data.VehicleStateResult;
import com.inetpsa.rcz.domain.model.shared.Payload;
import com.inetpsa.rcz.domain.model.vehicle.VehicleVehicleInfo;
import com.inetpsa.rcz.domain.services.LogService;
import com.inetpsa.rcz.domain.services.VehicleService;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;
import org.apache.commons.lang3.StringUtils;
import org.modelmapper.ModelMapper;
import org.seedstack.business.domain.Factory;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import javax.inject.Provider;
import java.util.Date;
import java.util.Optional;

public class VehicleInfoReceivedHandler extends AbstractVehicleInfoReceivedHandler<VehicleInfoReceived> {

    public static final String VIN_UNREADABLE = "Was unable to read parameter VIN from VehicleInfo";

    public static final String VIN_NOT_MATCHED = "The VIN and UIN does not match";
    public static final String REASON = "reason";
    @Inject
    protected VehicleService vehicleService;

    @Inject
    protected Factory<VehicleVehicleInfo> vehicleFactory;

    @Inject
    private LogService logService;

    @Inject
    private AuthorizationService authorizationService;

    @Inject
    private Provider<ModelMapper> modelMapperProvider;

    @Inject
    @Named("kafka")
    private PublisherService publisherService;

    @Configuration
    private RczConfig rczConfig;

    @Inject
    private ValidationService validationService;

    @Inject
    private VehicleUpstreamService vehicleUpstreamService;

    @Logging
    private Logger logger;

    @Override
    public void onEvent(VehicleInfoReceived event) {
        Exchange exchange = initExchange(event);
        try {
            logService.info(LogMessage.create(EventMessage.VEHICLE_AUTO_STATE_RECEIVED).data(event.getMessage()), exchange);
            exchange.setVin(getVin(event));
            //authorizationService.authorizeActionFromUIN(exchange);
            vehicleUpstreamService.find(exchange);
            VehicleVehicleInfo vehicle = mergeAndUpdate(exchange, event);
            logService.info(LogMessage.create(EventMessage.VEHICLE_UPDATED).data(vehicle.getVehicleInfo().getRawJson()), exchange);
            exchangeService.update(exchange);
        } catch (Exception e) {//NOSONAR
            exchange.setStatus(ExchangeStatus.ERROR);
            logService.error(LogMessage.create(EventMessage.VEHICLE_AUTO_STATE_ERROR).data(e.getMessage()), exchange);
            exchangeService.update(exchange);
        }
    }


    private VehicleVehicleInfo mergeAndUpdate(Exchange exchange, VehicleInfoReceived vehicleInfoReceived) throws ApplicationException {
        Optional<VehicleVehicleInfo> vehicle = vehicleService.findVehicleVehicleInfo(vehicleInfoReceived.getUin());
        if(!vehicle.isPresent() || !vehicle.get().getVin().equals(exchange.getVin()) || !vehicle.get().getId().equals(exchange.getUin())){
            throw new ApplicationException(VIN_NOT_MATCHED, ResponseStatus.VEHICLE_VALIDATION_ERROR);
        }
        VehicleStateResult vehicleStateResultEvent = getVehicleState(vehicleInfoReceived.getMessage());
        VehicleStateResult vehicleStateResult = merge(vehicleStateResultEvent, vehicle.get().getVehicleInfo());
        validationService.validateRequest(vehicleStateResult);
        String payload = JsonConverter.convert(vehicleStateResult);
        vehicle.get().setVehicleInfo(new Payload(new Date(), vehicleStateResult.getDate(), payload));

        vehicle.get().setVin(vehicleStateResult.getVin());
        publisherService.publish(payload, PublisherService.Target.TargetBuilder.builder().withTopic(rczConfig.getExchange().getTopics().getVehicleInfo()).withKey(vehicle.get().getVin())
                .withHeader(REASON, String.valueOf(vehicleStateResult.getReason()))
                .build());
        vehicleService.saveVehicleVehicleInfo(vehicle.get());
        return vehicle.get();
    }

    public VehicleStateResult merge(VehicleStateResult vehicleStateResult, Payload vehicleInfo) throws ApplicationException {
        try {
            if (vehicleInfo != null && StringUtils.isNotBlank(vehicleInfo.getRawJson())) {
                VehicleStateResult vehicleStateResultLocal = JsonConverter.convert(vehicleInfo.getRawJson(), new TypeReference<VehicleStateResult>() {
                });
                modelMapperProvider.get().map(vehicleStateResult, vehicleStateResultLocal);
                vehicleStateResult = vehicleStateResultLocal;
            }
            return vehicleStateResult;
        } catch (JsonParseException e) {
            throw new ApplicationException(e.getMessage(), ResponseStatus.TECHNICAL_ERROR);
        }
    }

    private VehicleStateResult getVehicleState(String event) {
        return JsonConverter.convert(event, new TypeReference<VehicleStateResult>() {
        });
    }

    private String getVin(VehicleInfoReceived event) throws ApplicationException {
        if (StringUtils.isNotBlank(event.getMessage())) {
            VehicleStateResult vehicleStateResult = JsonConverter.convert(event.getMessage(), new TypeReference<VehicleStateResult>() {
            });
            if (vehicleStateResult != null && StringUtils.isNotBlank(vehicleStateResult.getVin())) {
                return vehicleStateResult.getVin();
            }
        }
        throw new ApplicationException(VIN_UNREADABLE, ResponseStatus.VEHICLE_VALIDATION_ERROR);
    }


}
