package com.inetpsa.rcz.infrastructure.rest.sms.orange.representation;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OutboundSMSTextMessage {

    private String message;

    public OutboundSMSTextMessage(String message) {
        this.message = message;
    }
}