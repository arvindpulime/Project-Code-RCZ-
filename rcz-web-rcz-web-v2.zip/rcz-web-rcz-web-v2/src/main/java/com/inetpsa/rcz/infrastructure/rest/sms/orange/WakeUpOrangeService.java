package com.inetpsa.rcz.infrastructure.rest.sms.orange;

import com.inetpsa.rcz.application.configuration.RczConfig;
import com.inetpsa.rcz.application.exceptions.ApplicationException;
import com.inetpsa.rcz.application.util.ClientConfig;
import com.inetpsa.rcz.application.util.HexaUtils;
import com.inetpsa.rcz.application.util.RestClientUtilities;
import com.inetpsa.rcz.domain.model.sms.Message;
import com.inetpsa.rcz.domain.model.sms.Sms;
import com.inetpsa.rcz.domain.model.sms.User;
import com.inetpsa.rcz.domain.model.vehicle.Vehicle;
import com.inetpsa.rcz.domain.services.ParameterService;
import com.inetpsa.rcz.domain.services.SmsService;
import com.inetpsa.rcz.domain.utils.Base64Utils;
import com.inetpsa.rcz.infrastructure.rest.RestHandler;
import com.inetpsa.rcz.infrastructure.rest.sms.AbstractWakeUpService;
import com.inetpsa.rcz.infrastructure.rest.sms.WakeUpException;
import com.inetpsa.rcz.infrastructure.rest.sms.orange.representation.*;
import com.inetpsa.rcz.infrastructure.rest.sms.orange.representation.Error;
import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.lang3.StringUtils;
import org.glassfish.jersey.client.ClientProperties;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import java.util.Collections;
import java.util.Date;
import java.util.Optional;

import static com.inetpsa.rcz.application.util.HexaUtils.stringToHex;
import static com.inetpsa.rcz.domain.model.sms.UserType.MSISDN;
import static com.inetpsa.rcz.domain.model.vehicle.Provider.OFR;
import static javax.ws.rs.core.MediaType.APPLICATION_JSON;
import static net.jodah.failsafe.Failsafe.with;

@Named("ORANGE")
public class WakeUpOrangeService extends AbstractWakeUpService {

    public static final int NB_BYTES_VIN = 17;
    @Inject
    private ParameterService parameterService;

    @Inject
    private SmsService smsService;

    @Logging
    private Logger logger;

    @Configuration
    private RczConfig rczConfig;


    public static final String ORANGE_PARSING_ERROR = "ORANGE_PARSING_ERROR";

    public static final String ORANGE_CLIENT_ERROR = "ORANGE_CLIENT_ERROR";

    @Override
    public void sendSmsWithFailsafe(Vehicle vehicle, Sms sms) {
        try {

            with(buildRetryPolicy()).
                    onFailure(event -> logger.debug("SMS FAILED")).
                    onSuccess(cnx -> logger.debug("SMS_SUCCESS"))
                    .run(() -> send(vehicle, sms));
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            if (e.getCause() != null) {
                smsFail(sms, new WakeUpException("ORANGE_CLIENT_ERROR : " + e.getCause().getMessage()));
            } else {

                smsFail(sms, new WakeUpException("ORANGE_CLIENT_ERROR : " + e.getMessage()));
            }
        }
    }

    private Sms send(Vehicle vehicle, Sms sms) {
        try {
            Response response = sendSms(vehicle, sms);
            return processResponse(sms, response);
        } catch (Exception e) {
            throw new WakeUpException(e.getMessage());
        }
    }

    @Override
    public Sms buildSms(Vehicle vehicle) {
        Sms sms = smsService.create();
        sms.setProvider(OFR);
        sms.setUin(vehicle.getId());
        sms.setSendingDate(new Date());
        sms.addMessage(new Message(new User(MSISDN, vehicle.getMsisdn()), buildMessage(vehicle, sms)));
        return sms;
    }

    private Response sendSms(Vehicle vehicle, Sms sms) throws ApplicationException {
        WebTarget webTarget = RestClientUtilities.prepareClient(getRestClientConfig()).register(new RestHandler("ORANGE_SMS"));
        Response response = webTarget
                .request(APPLICATION_JSON)
                .accept(APPLICATION_JSON)
                .property(ClientProperties.CONNECT_TIMEOUT, parameterService.get().getSms().getOrange().getConnectionTimeout())
                .property(ClientProperties.READ_TIMEOUT, parameterService.get().getSms().getOrange().getRequestTimeout())
                .header(HttpHeaders.CONTENT_TYPE, APPLICATION_JSON)
                .header(HttpHeaders.HOST, parameterService.get().getSms().getOrange().getHeaderHost())
                .post(Entity.entity(buildRequest(vehicle, sms), APPLICATION_JSON));
        return response;
    }

    private ClientConfig getRestClientConfig() {
        ClientConfig config = rczConfig.getOrange();
        config.setUsername(parameterService.get().getSms().getOrange().getUsername());
        config.setPassword(Base64Utils.decode(parameterService.get().getSms().getOrange().getPassword()));
        config.setHost(parameterService.get().getSms().getOrange().getHost());
        return config;
    }

    private Sms processResponse(Sms sms, Response response) {
        switch (response.getStatus()) {
            case 200:
                return updateSms(sms, getOrangeSmsResponse(response));
            case 201:
                return updateSms(sms, getOrangeSmsResponse(response));
            default:
                return smsFail(sms, new WakeUpException(getErrorResponse(response)));

        }
    }

    private String getErrorResponse(Response response) {
        String message = ORANGE_PARSING_ERROR;
        try {
            Error error = response.readEntity(Error.class);
            message = StringUtils.replace(error.getRequestError().getServiceException().getText(), "%1", error.getRequestError().getServiceException().getVariables()
            );
        } catch (Exception e) {
            message = getErrorResponseMessage(response);
        }
        return message;
    }

    private String getErrorResponseMessage(Response response) {
        String message;
        message = String.format("Orange SMS ERROR - HTTP Status : %s, Reason : %s", response.getStatusInfo().getStatusCode(), response.getStatusInfo().getReasonPhrase());
        return message;
    }

    private OrangeSmsResponse getOrangeSmsResponse(Response response) {
        try {

            return response.readEntity(OrangeSmsResponse.class);
        } catch (Exception e) {
            throw new WakeUpException(getErrorResponseMessage(response) + ORANGE_PARSING_ERROR + " : " + e.getMessage(), e);
        }
    }

    private OrangeSmsRequest buildRequest(Vehicle vehicle, Sms sms) {

        String address = String.format("tel:%s", vehicle.getMsisdn());
        OutboundSMSMessageRequest outboundSMSMessageRequest = new OutboundSMSMessageRequest();
        outboundSMSMessageRequest.setAddress(Collections.singletonList(address));
        if (parameterService.get().getSms().getOrange().getMessageBinary()) {
            outboundSMSMessageRequest.setOutboundSMSBinaryMessage(new OutboundSMSTextMessage(toHexBase64(buildMessage(vehicle, sms))));
        } else {
            outboundSMSMessageRequest.setOutboundSMSTextMessage(new OutboundSMSTextMessage(buildMessage(vehicle, sms)));
        }
        outboundSMSMessageRequest.setSenderAddress(parameterService.get().getSms().getOrange().getSenderAddress());
        return new OrangeSmsRequest(outboundSMSMessageRequest);
    }

    private String toHexBase64(String data) {
        try {
            return new String(Base64.encodeBase64(Hex.decodeHex(data.toCharArray())));
        } catch (DecoderException e) {
            logger.error(e.getMessage(), e);
            return data;
        }
    }

    @Override
    protected String buildMessage(Vehicle vehicle, Sms sms) {
        StringBuilder builder = new StringBuilder("FF1F");
        builder.append(parameterService.get().getSms().getOrange().getHeaderVersion())
                .append(parameterService.get().getSms().getOrange().getEcuType())
                .append(parameterService.get().getSms().getOrange().getServiceType())
                .append(parameterService.get().getSms().getOrange().getObjectType())
                .append(parameterService.get().getSms().getOrange().getObjectVersion())
                .append(parameterService.get().getSms().getOrange().getObjectId())
                .append(stringToHex(vehicle.getVin(), NB_BYTES_VIN))
                .append(HexaUtils.intToHex(String.valueOf(System.currentTimeMillis()/1000), 8).toUpperCase()) //Date
                .append("00000000");
        return builder.toString().toUpperCase();
    }

    private Sms updateSms(Sms sms, OrangeSmsResponse response) {
        Optional<String> responseStatus = response
                .getOutboundSMSMessageRequest()
                .getDeliveryInfoList()
                .getDeliveryInfo()
                .stream()
                .findFirst()
                .map(DeliveryInfo::getDeliveryStatus);
        if (responseStatus.isPresent()) {
            sms.setAnswerStatus(responseStatus.get());
        }
        String resourceUrl = response.getOutboundSMSMessageRequest().getResourceURL();
        sms.setMessageId(getMessageId(resourceUrl));
        smsService.update(sms);
        return sms;
    }

    private String getMessageId(String resourceUrl) {
        if (StringUtils.isNotBlank(resourceUrl)) {
            try {
                return resourceUrl.substring(resourceUrl.lastIndexOf("/") + 1, resourceUrl.length());
            } catch (Exception e) {
                return null;
            }
        }
        return null;
    }
}
