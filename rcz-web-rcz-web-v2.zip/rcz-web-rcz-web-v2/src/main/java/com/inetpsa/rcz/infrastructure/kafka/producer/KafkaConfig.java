package com.inetpsa.rcz.infrastructure.kafka.producer;


public class KafkaConfig {
    ProducerConfig producer = new ProducerConfig();

    public ProducerConfig getProducer() {
        return producer;
    }

    public static class ProducerConfig {
        private String [] clients;
        public String[] getClients() {
            return clients;
        }

    }
}
