package com.inetpsa.rcz.application.handlers.payload.shared;

import com.fasterxml.jackson.core.type.TypeReference;
import com.inetpsa.rcz.application.handlers.payload.AbstractResponseHandler;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.payload.data.Data;
import com.inetpsa.rcz.domain.model.payload.data.Error;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;
import org.apache.commons.lang3.StringUtils;

public class ErrorResponseHandler extends AbstractResponseHandler<Error> {

    @Override
    protected Error handleResponseData(Data data, Exchange exchange) {
        if (StringUtils.isNotBlank(data.getValue())) {
            return JsonConverter.convert(data.getValue(), new TypeReference<Error>() {
            });
        }
        return null;
    }
}
