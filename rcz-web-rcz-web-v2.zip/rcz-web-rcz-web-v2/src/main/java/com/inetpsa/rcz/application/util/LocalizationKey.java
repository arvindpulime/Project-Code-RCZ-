package com.inetpsa.rcz.application.util;

/**
 * @author tuan.docao@ext.mpsa.com
 */
public final class LocalizationKey {


    private LocalizationKey() {
    }

    public static final String AUTHORIZATION_DENIED_CHECK_ACTION_RIGHT_PERMISSION_DENIED_KEY = "authorization.denied.check.action.right.permission.denied.key";

    public static final String AUTHORIZATION_DENIED_CVS_FROM_UIN_RESPONSE_KO_KEY = "authorization.denied.cvs.from.uin.response.ko.key";

    public static final String AUTHORIZATION_DENIED_CVS_FROM_UIN_VIN_DOES_NOT_MATCH_TARGETED_VEHICLE_KEY = "authorization.denied.cvs.from.uin.vin.does.not.match.targeted.vehicle.key";

    public static final String AUTHORIZATION_DENIED_CVS_ACCESS_TOKEN_EMPTY = "authorization.denied.cvs.access.token.empty.key";

    public static final String AUTHORIZATION_DENIED_CVS_ON_UIN_RESPONSE_KO_KEY = "authorization.denied.cvs.on.uin.response.ko.key";

    public static final String AUTHORIZATION_DENIED_CVS_RESPONSE_NO_MATCHING_SERVICE_KEY = "authorization.denied.cvs.response.no.matching.service.key";

    public static final String AUTHORIZATION_DENIED_VEHICLE_IS_STOLEN_KEY = "authorization.denied.vehicle.is.stolen.key";

    public static final String BAD_REQUEST_UNKNOWN_UIN_KEY = "bad.request.unknown.uin.key";

    public static final String BAD_DOORS_REQUEST_VEHICLE_NOT_BLACKLISTED = "bad.doors.request.vehicle.not.blacklisted";

    public static final String DUPLICATE_MESSAGE_KEY = "duplicate.message.key";

    public static final String HORN_QUOTA_MESSAGE_KEY = "horn.quota.message.key";

    public static final String LIGHTS_QUOTA_MESSAGE_KEY = "lights.quota.message.key";

    public static final String PROCESS_900_REQUEST_ACCEPTED_KEY = "process.900.request.accepted.key";

    public static final String PROCESS_901_VEHCILE_ASLEEP_KEY = "process.901.vehicle.asleep.key";

    public static final String PROCESS_902_CHECKING_VEHICLE_STATE_KEY = "process.902.checking.vehicle.state.key";

    public static final String PROCESS_903_REQUEST_FORWARDED_TO_VEHICLE_KEY = "process.903.request.forwarded.to.vehicle.key";

    public static final String PROCESS_904_REQUEST_QUOTA_EXCEEDED_WARNING = "process.904.quota.exceeded.warning.key";

    public static final String PROCESS_905_BATTERY_AVAILABILITY = "process.905.battery.availability.warning.key";


    public static final String REQUEST_ERROR_CORRELATION_ID_ERROR_MESSAGE_KEY = "request.error.correlation.id.error.message.key";

    public static final String REQUEST_ERROR_IMMOSTATE_EXCHANGE_NOT_FOUND = "request.error.immostate.exchange.not.found";

    public static final String RIGHTS_ERROR_STOLEN_VEHICLE_NOT_DECLARED_STOLEN_KEY = "rights.error.stolen.vehicle.not.declared.stolen.key";

    public static final String RIGHTS_ERROR_VES_SEV_NOT_STOPPED_KEY = "rights.error.ves.sev.not.stopped.key";

    public static final String RIGHTS_ERROR_PRIVACY_ON = "rights.error.privacy.on";

    public static final String RIGHTS_ERROR_BATTERY = "rights.error.battery";

    public static final String TECHNICAL_ERROR_NO_VEHICLE_FOUND_FOR_UIN_KEY = "technical.error.no.vehicle.found.for.uin.key";

    public static final String TECHNICAL_ERROR_UNSUPPORTED_TELECOM_PROVIDER = "technical.error.unsupported.telecom.provider.key";

    public static final String USER_QUOTA_MESSAGE_KEY = "user.quota.message.key";

    public static final String USER_DAILY_QUOTA_MESSAGE_KEY = "user.daily.quota.message.key";

    public static final String USER_QUOTA_WARNING_MESSAGE_KEY =  "user.quota.warning.message.key";;

    public static final String CVS_ERROR_INVALID_OR_EXPIRED_ACCES_TOKEN = "Invalid or expired acces_token";

    public static final String COMMODORE_VEHICLE_REQUEST_ERROR = "commodore.vehicle.request.error";

    public static final String VEHICLE_RESPONSE_ERROR_ALREADY_IN_TIMEOUT = "vehicle.response.error.already.in.timeout";

}
