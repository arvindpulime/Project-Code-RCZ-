package com.inetpsa.rcz.application.configuration;

import com.inetpsa.rcz.application.util.ClientConfig;

public class MonitoringConfig {

    private SchedulerConfig scheduler = new SchedulerConfig();

    private ClientConfig client = new ClientConfig();

    public SchedulerConfig getScheduler() {
        return scheduler;
    }

    public ClientConfig getClient() {
        return client;
    }
}
