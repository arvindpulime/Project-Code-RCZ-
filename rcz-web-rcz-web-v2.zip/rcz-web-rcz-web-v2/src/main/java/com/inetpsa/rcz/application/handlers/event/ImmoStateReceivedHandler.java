package com.inetpsa.rcz.application.handlers.event;

import com.fasterxml.jackson.core.type.TypeReference;
import com.inetpsa.rcz.application.exceptions.ApplicationException;
import com.inetpsa.rcz.application.services.LocalizationService;
import com.inetpsa.rcz.application.services.PublisherService;
import com.inetpsa.rcz.application.services.PublisherService.Target.TargetBuilder;
import com.inetpsa.rcz.application.services.ValidationService;
import com.inetpsa.rcz.application.util.LocalizationKey;
import com.inetpsa.rcz.domain.model.enums.EventMessage;
import com.inetpsa.rcz.domain.model.enums.ExchangeStatus;
import com.inetpsa.rcz.domain.model.enums.ResponseStatus;
import com.inetpsa.rcz.domain.model.event.ImmoStateForwarded;
import com.inetpsa.rcz.domain.model.event.ImmoStateReceived;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.log.LogMessage;
import com.inetpsa.rcz.domain.model.payload.request.ImmoStateRequestPayload;
import com.inetpsa.rcz.domain.model.payload.response.ImmoStateResponsePayload;
import com.inetpsa.rcz.domain.model.payload.topic.Topic;
import com.inetpsa.rcz.domain.services.ExchangeService;
import com.inetpsa.rcz.domain.services.LogService;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;
import org.seedstack.business.domain.BaseDomainEventHandler;
import org.seedstack.business.domain.DomainEventPublisher;
import org.seedstack.business.domain.Factory;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.Optional;

/**
 * @author tuan.docao@ext.mpsa.com
 */
public class ImmoStateReceivedHandler extends BaseDomainEventHandler<ImmoStateReceived> {

    @Logging
    private Logger logger;

    @Inject
    private Factory<Exchange> exchangeFactory;

    @Inject
    private ExchangeService exchangeService;

    @Named("mqtt")
    @Inject
    private PublisherService publisherService;

    @Inject
    private ValidationService validationService;

    @Inject
    private LogService logService;

    @Inject
    private LocalizationService localizationService;


    @Inject
    private DomainEventPublisher eventPublisher;

    @Override
    public void onEvent(ImmoStateReceived event) {

        final String message = event.getMessage();
        ImmoStateRequestPayload immoStateRequestPayload = JsonConverter.convert(message, new TypeReference<ImmoStateRequestPayload>() {
        });

        Exchange exchange = null;
        try {
            exchange = getExchange(immoStateRequestPayload);
            logService.info(LogMessage.create(EventMessage.IMMOBILIZATION_STATE_RECEIVED).data(event.getMessage()).topic(event.getTopic().toString()), exchange);
            validationService.validateRequest(immoStateRequestPayload);

            exchange.setStatus(ExchangeStatus.FINISHED);
            exchangeService.update(exchange);
            final Topic topic = new Topic(exchange.getTopic());

            String response = buildResponse(exchange, immoStateRequestPayload);
            String topicPartner = topic.toPartner(false);
            publisherService.publish(response, TargetBuilder.builder().withTopic(topicPartner).build());
            logService.info(LogMessage.create(EventMessage.IMMOBILIZATION_STATE_FORWARDED).data(response).topic(topicPartner), exchange);
            eventPublisher.publish(new ImmoStateForwarded(exchange, immoStateRequestPayload, event.getTopic()));
        } catch (ApplicationException e) {//NOSONAR
            if (exchange != null) {
                updateWithError(exchange, e);
                logService.error(LogMessage.create(EventMessage.REQUEST_ERROR).data(e.getMessage()), exchange);
            } else {
                logger.error(e.getMessage(), e);
            }
        }
    }

    private Exchange getExchange(ImmoStateRequestPayload immoStateRequestPayload) throws ApplicationException {
        Optional<Exchange> exchange = exchangeService.findById(immoStateRequestPayload.getRequestId());
        if (!exchange.isPresent()) {
            throw new ApplicationException(localizationService.localize(LocalizationKey.REQUEST_ERROR_IMMOSTATE_EXCHANGE_NOT_FOUND, immoStateRequestPayload.getRequestId()), ResponseStatus.REQUEST_ERROR);
        }
        return exchange.get();
    }

    private String buildResponse(Exchange exchange, ImmoStateRequestPayload immoStateRequestPayload) {
        ImmoStateResponsePayload responsePayload = new ImmoStateResponsePayload();
        responsePayload.setVin(exchange.getVin());
        responsePayload.setCorrelationId(exchange.getCorrelationId());
        responsePayload.setDate(immoStateRequestPayload.getDate());
        responsePayload.setImmoState(immoStateRequestPayload.getImmoState());
        responsePayload.setLocation(immoStateRequestPayload.getLocation());
        responsePayload.setSevStateValue(immoStateRequestPayload.getSevState().ordinal());
        return JsonConverter.convert(responsePayload);
    }

    private void updateWithError(Exchange exchange, ApplicationException e) {
        exchange.setStatus(ExchangeStatus.ERROR);
        exchange.setResponseStatus(e.getResponseStatus());
        exchangeService.update(exchange);
    }

}
