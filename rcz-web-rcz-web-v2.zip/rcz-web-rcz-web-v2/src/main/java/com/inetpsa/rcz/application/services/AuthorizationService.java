package com.inetpsa.rcz.application.services;

import com.inetpsa.rcz.application.exceptions.ApplicationException;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import org.seedstack.business.Service;

@Service
public interface AuthorizationService {

    /**
     * Return a valid UIN for the exchange action when authorized.
     *
     * @param exchange the exchange
     * @return the UIN if action is authorized, an {@code ApplicationException} otherwise
     * @throws ApplicationException if the action is not authorized nor available
     */
    String authorizeActionOnUIN(Exchange exchange) throws ApplicationException;

    /**
     * Return a valid UIN for the exchange action when authorized.
     *
     * @param exchange the exchange
     * @return the UIN if action is authorized, an {@code ApplicationException} otherwise
     * @throws ApplicationException if the action is not authorized nor available
     */
    String authorizeActionFromUIN(Exchange exchange) throws ApplicationException;
}
