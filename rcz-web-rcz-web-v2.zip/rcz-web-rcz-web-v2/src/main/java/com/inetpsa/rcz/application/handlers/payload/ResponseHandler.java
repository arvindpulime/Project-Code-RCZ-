package com.inetpsa.rcz.application.handlers.payload;

import com.inetpsa.rcz.application.exceptions.ApplicationException;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.payload.response.BTAResponsePayload;
import com.inetpsa.rcz.domain.model.payload.response.ResponsePayload;
import org.seedstack.business.Service;

@Service
public interface ResponseHandler<R> {

    ResponsePayload<R> handle(Exchange exchange, BTAResponsePayload btaResponsePayload) throws ApplicationException;
}
