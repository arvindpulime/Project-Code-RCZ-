package com.inetpsa.rcz.application.representation.request;

import java.io.Serializable;
import java.util.Objects;

/**
 * @author tuan.docao@ext.mpsa.com
 */
public class BTAServicesRequestLean implements Serializable {

    private String eventId;

    private String uin;

    public BTAServicesRequestLean() {
    }

    public String getEventId() {
        return eventId;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }

    public String getUin() {
        return uin;
    }

    public void setUin(String uin) {
        this.uin = uin;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BTAServicesRequestLean that = (BTAServicesRequestLean) o;
        return Objects.equals(getUin(), that.getUin());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getUin());
    }
}
