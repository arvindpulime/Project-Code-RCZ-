/*
 * Creation : 18 juil. 2016
 */
package com.inetpsa.rcz.application.handlers.payload.lights;

import com.inetpsa.rcz.application.handlers.payload.BTARequestHandler;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.payload.data.Lights;
import com.inetpsa.rcz.domain.model.payload.request.BTARequestPayload;
import com.inetpsa.rcz.domain.model.payload.request.RequestPayload;
import com.inetpsa.rcz.domain.model.vehicle.Vehicle;
import com.inetpsa.rcz.domain.services.VehicleService;

import javax.inject.Inject;
import java.util.Date;
import java.util.Optional;

public class LightsBTARequestHandler implements BTARequestHandler<Lights, Lights> {

    @Inject
    private VehicleService vehicleService;

    @Override
    public BTARequestPayload<Lights> handle(Exchange exchange, RequestPayload<Lights> requestPayload) {
        Optional<Vehicle> vehicle = vehicleService.find(exchange.getUin());

        BTARequestPayload<Lights> btaRequest = new BTARequestPayload<>();
        btaRequest.setRequestDate(new Date());
        Integer duration = 10;
        if (vehicle.isPresent() && Vehicle.BSRF.equals(vehicle.get().getBtaType())) {
            duration = null;
        }
        Lights lights = new Lights(duration);
        lights.setActivated(true);
        btaRequest.setData(lights);
        btaRequest.setRequestId(exchange.getId());
        return btaRequest;
    }

}
