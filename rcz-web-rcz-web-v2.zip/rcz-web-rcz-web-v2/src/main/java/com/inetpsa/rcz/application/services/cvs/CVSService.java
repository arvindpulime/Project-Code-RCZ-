package com.inetpsa.rcz.application.services.cvs;

import com.inetpsa.rcz.application.exceptions.AuthorizationException;
import com.inetpsa.rcz.application.representation.request.BTARightsRequest;
import com.inetpsa.rcz.application.representation.request.BTAServicesRequestLean;
import com.inetpsa.rcz.application.representation.request.ConsumerServicesRequestLean;
import com.inetpsa.rcz.application.representation.request.PartnerRightsRequest;
import com.inetpsa.rcz.application.representation.response.*;
import org.seedstack.business.Service;

/**
 * @author tuan.docao@ext.mpsa.com
 */
@Service
public interface CVSService {

    String MOCK = "mock";

    String REST = "rest";

    PartnerRights getPartnerServices(PartnerRightsRequest request) throws AuthorizationException;

    ConsumerServicesLean getConsumerServices(ConsumerServicesRequestLean request) throws AuthorizationException;

    OAuthConsumerServiceLean getOAuthConsumerServices(ConsumerServicesRequestLean request) throws AuthorizationException;

    BTARights postBTARights(BTARightsRequest request) throws AuthorizationException;

    BTAServicesLean getBTAServices(BTAServicesRequestLean request) throws AuthorizationException;
}
