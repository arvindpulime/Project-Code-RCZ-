package com.inetpsa.rcz.application.configuration;

public class ExchangeConfig {

    private SchedulerConfig timeout = new SchedulerConfig();

    private Topics topics;

    public SchedulerConfig getTimeout() {
        return timeout;
    }

    public Topics getTopics() {
        return topics;
    }


    public static class Topics {
        String alarm;
        String vehicleInfo;

        public String getAlarm() {
            return alarm;
        }

        public String getVehicleInfo() {
            return vehicleInfo;
        }
    }
}
