package com.inetpsa.rcz.rest.sms;

import com.google.common.collect.Lists;
import com.inetpsa.rcz.bytel.acknowledgement.CONTROL;
import com.inetpsa.rcz.bytel.acknowledgement.REPLY;
import com.inetpsa.rcz.bytel.heartbeat.PINGHB;
import com.inetpsa.rcz.domain.model.sms.Acknowledgement;
import com.inetpsa.rcz.domain.model.sms.Sms;
import com.inetpsa.rcz.domain.services.SmsService;
import com.inetpsa.rcz.domain.utils.XMLUtils;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.xml.bind.JAXBException;
import java.util.List;
import java.util.Optional;

/**
 * @author tuan.docao@ext.mpsa.com
 */
@Path("/bytel")
public class AcknowledgementResource {

    @Logging
    private Logger logger;

    @Inject
    private SmsService smsService;

    private static final String PAYLOAD_KEY = "xmlMsg";

    @POST
    @Path("/ack")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public Response ack(MultivaluedMap<String, String> formData) throws JAXBException {
        String xmlMsg = formData.getFirst(PAYLOAD_KEY);
        try {
            REPLY reply = processPayload(xmlMsg, REPLY.class);
            if (reply == null) {
                return Response.status(Response.Status.BAD_REQUEST).build();
            }
        } catch (ClassCastException e) {
            // no-op
        }

        return Response.ok(xmlMsg).type(MediaType.APPLICATION_FORM_URLENCODED_TYPE).build();
    }

    private <R> R processPayload(String xmlMsg, Class<R> jaxbClass) {
        R obj = null;
        try {
            obj = XMLUtils.unmarshal(xmlMsg, jaxbClass);
            if (obj instanceof REPLY) {
                List<Sms> smsToUpdate = populateSmsToUpdate((REPLY) obj);
                smsService.updateAll(smsToUpdate);
            }
        } catch (JAXBException e) {
            logger.error("Error unmarshalling request payload", e);
        }
        return obj;
    }

    private List<Sms> populateSmsToUpdate(REPLY reply) {
        List<CONTROL> controls = reply.getCONTROL();
        List<Sms> smsToUpdate = Lists.newArrayList();
        for (CONTROL control : controls) {
            final String smsId = control.getIDREQUETE();
            Acknowledgement acknowledgement = new Acknowledgement(control.getCODE(), control.getREASON());
            Optional<Sms> sms = smsService.findById(smsId);
            if (sms.isPresent()) {
                sms.get().setAcknowledgement(acknowledgement);
                smsToUpdate.add(sms.get());
            }
        }
        return smsToUpdate;
    }
}