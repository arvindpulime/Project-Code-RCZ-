package com.inetpsa.rcz.infrastructure.rest.sms.bytel;

import com.inetpsa.rcz.application.configuration.RczConfig;
import com.inetpsa.rcz.application.services.VehicleUpstreamService;
import com.inetpsa.rcz.bytel.answer.PUSHREPLY;
import com.inetpsa.rcz.bytel.heartbeat.PINGHB;
import com.inetpsa.rcz.bytel.sms.*;
import com.inetpsa.rcz.domain.model.sms.Message;
import com.inetpsa.rcz.domain.model.sms.Sms;
import com.inetpsa.rcz.domain.model.sms.User;
import com.inetpsa.rcz.domain.model.sms.UserType;
import com.inetpsa.rcz.domain.model.vehicle.Vehicle;
import com.inetpsa.rcz.domain.services.ParameterService;
import com.inetpsa.rcz.domain.services.SmsService;
import com.inetpsa.rcz.infrastructure.rest.sms.AbstractWakeUpService;
import com.inetpsa.rcz.infrastructure.rest.sms.WakeUpException;
import org.glassfish.jersey.apache.connector.ApacheConnectorProvider;
import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.client.ClientProperties;
import org.glassfish.jersey.client.RequestEntityProcessing;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.*;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.Date;

import static com.inetpsa.rcz.domain.model.vehicle.Provider.BYT;
import static javax.ws.rs.client.ClientBuilder.newClient;
import static net.jodah.failsafe.Failsafe.with;

@Named("BYTEL")
public class WakeUpBytelService extends AbstractWakeUpService {

    public static final String HEART_BEAT = "Heart_Beat";

    public static final String VERSION = "1.0";

    public static final String ID_REQUETE = "IDREQUETE";

    public static final String BYTEL_UNMARSHALLING_ERROR = "BYTEL_UNMARSHALLING_ERROR";

    public static final String BYTEL_TIMEOUT_ERROR = "BYTEL_TIMEOUT_ERROR";

    public static final String BYTEL_MARSHALLING_ERROR = "BYTEL_MARSHALLING_ERROR";

    public static final String XML_MESSAGE_PROPERTY = "xmlMsg";

    @Logging
    private Logger logger;

    @Inject
    private VehicleUpstreamService vehicleService;

    @Inject
    private ParameterService parameterService;

    @Inject
    private SmsService smsService;

    @Configuration
    private RczConfig rczConfig;

    @Override
    public void sendSmsWithFailsafe(Vehicle vehicle, Sms sms) {
        with(buildRetryPolicy()).
                onSuccess(cxn -> sendSms(sms)).
                onFailure(cxn -> smsFail(sms, new WakeUpException(BYTEL_TIMEOUT_ERROR))).
                runAsync(() -> sendPing(buildPing()));
    }

    @Override
    public Sms buildSms(Vehicle vehicle) {
        Sms sms = smsService.create();
        sms.setProvider(BYT);
        sms.setUin(vehicle.getId());
        sms.setAdm(parameterService.get().getSms().getByTel().getAdm());
        sms.setIcp(parameterService.get().getSms().getByTel().getIcp());
        sms.setIdOffer(parameterService.get().getSms().getByTel().getIdOffer());
        sms.setVersion(parameterService.get().getSms().getByTel().getProtocolVersion());
        sms.setSendingDate(new Date());
        sms.addMessage(new Message(new User(UserType.MSISDN, vehicle.getMsisdn()), parameterService.get().getSms().getByTel().getMessageFormat(), buildMessage(vehicle, sms)));
        return sms;
    }

    private void sendPing(PINGHB pinghb) {
        try {

            Response response = send(xmlToString(pinghb));
            if (response.getStatus() != 200) {
                throw new Exception(BYTEL_TIMEOUT_ERROR);
            }
        } catch (Exception e) {
            throw new WakeUpException(e.getMessage());
        }
    }

    private void sendSms(Sms sms) {
        try {
            Response response = send(xmlToString(buildPush(sms)));
            String xml = response.readEntity(String.class);
            PUSHREPLY reply = xmlToObject(xml, PUSHREPLY.class);
            sms.setAnswerStatus(reply.getSTATUS());
            smsService.update(sms);
        } catch (Exception e) {
            logger.warn(e.getMessage(), e);
            smsFail(sms, e);
        }
    }

    private Response send(String request) {
        MultivaluedMap<String, String> map = new MultivaluedHashMap<>();
        map.putSingle(XML_MESSAGE_PROPERTY, request);
        return initClient().target(parameterService.get().getSms().getByTel().getUri())
                .path(parameterService.get().getSms().getByTel().getPath())
                .request(MediaType.APPLICATION_FORM_URLENCODED)
                .accept(MediaType.APPLICATION_FORM_URLENCODED, MediaType.TEXT_XML)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_FORM_URLENCODED)
                .property(ClientProperties.CONNECT_TIMEOUT, rczConfig.getBytel().getConnectionTimeout())
                .property(ClientProperties.READ_TIMEOUT, rczConfig.getBytel().getRequestTimeout())
                .post(Entity.form(map));
    }

    private Client initClient() {
        if (parameterService.get().getRcz().getProxy()) {
            ClientConfig clientConfig = new ClientConfig();
            clientConfig.connectorProvider(new ApacheConnectorProvider());
            clientConfig.property(ClientProperties.PROXY_URI, rczConfig.getProxy().getHost())
                    .property(ClientProperties.PROXY_USERNAME, rczConfig.getProxy().getUsername())
                    .property(ClientProperties.PROXY_PASSWORD, rczConfig.getProxy().getPassword());
            Client client = newClient(clientConfig);
            client.property(ClientProperties.REQUEST_ENTITY_PROCESSING, RequestEntityProcessing.BUFFERED);
            return client;
        }
        return newClient();
    }

    private PINGHB buildPing() {
        PINGHB pinghb = new PINGHB();
        pinghb.setTYPE(HEART_BEAT);
        pinghb.setVERSION(VERSION);
        return pinghb;
    }

    private PUSH buildPush(Sms sms) {

        Message message = sms.getMessages().iterator().next();
        TO to = new TO();
        to.setTYPE(message.getTo().getType().name());
        to.setVALUE(message.getTo().getValue());
        USER user = new USER();
        user.getTO().add(to);

        TEXT text = new TEXT();
        text.setLENGTH(String.valueOf(parameterService.get().getSms().getMessageLength()));
        text.setvalue(message.getText());

        CONTENT content = new CONTENT();
        content.setFORMAT(message.getFormat());
        content.getUSER().add(user);
        content.getTEXT().add(text);

        PARAMETER parameter = new PARAMETER();
        parameter.setNAME(ID_REQUETE);
        parameter.setVALUE(String.valueOf(sms.getId()));

        OFFER offer = new OFFER();
        offer.setIDOFFER(sms.getIdOffer());
        offer.getPARAMETER().add(parameter);
        offer.getCONTENT().add(content);

        PUSH push = new PUSH();
        push.setVERSION(VERSION);
        push.setADM(sms.getAdm());
        push.setICP(sms.getIcp());
        push.getOFFER().add(offer);

        return push;
    }

    private <T> T xmlToObject(String xmlMessage, Class<T> xmlClass) {
        try {
            return (T) JAXBContext.newInstance(xmlClass).createUnmarshaller().unmarshal(new StringReader(xmlMessage));
        } catch (JAXBException e) {
            throw new WakeUpException(BYTEL_UNMARSHALLING_ERROR, e);
        }
    }

    private <T> String xmlToString(T xmlObject) {
        try {
            final Marshaller m = JAXBContext.newInstance(xmlObject.getClass()).createMarshaller();
            m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            final StringWriter w = new StringWriter();
            m.marshal(xmlObject, w);
            return w.toString();
        } catch (JAXBException e) {
            throw new WakeUpException(BYTEL_MARSHALLING_ERROR, e);
        }
    }
}
