package com.inetpsa.rcz.application.handlers.event;

import com.fasterxml.jackson.core.type.TypeReference;
import com.inetpsa.rcz.application.exceptions.ApplicationException;
import com.inetpsa.rcz.application.services.AuthorizationService;
import com.inetpsa.rcz.domain.model.enums.EventMessage;
import com.inetpsa.rcz.domain.model.enums.ExchangeStatus;
import com.inetpsa.rcz.domain.model.event.ServiceInfoReceived;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.log.LogMessage;
import com.inetpsa.rcz.domain.model.payload.data.ServiceInfo;
import com.inetpsa.rcz.domain.model.shared.Payload;
import com.inetpsa.rcz.domain.model.vehicle.VehicleServiceInfo;
import com.inetpsa.rcz.domain.services.LogService;
import com.inetpsa.rcz.domain.services.VehicleService;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;
import org.seedstack.business.domain.Factory;

import javax.inject.Inject;
import java.util.Date;
import java.util.Optional;

public class ServiceInfoReceivedHandler extends AbstractVehicleInfoReceivedHandler<ServiceInfoReceived> {

    @Inject
    protected VehicleService vehicleService;

    @Inject
    protected Factory<VehicleServiceInfo> vehicleFactory;

    @Inject
    private LogService logService;

    @Inject
    private AuthorizationService authorizationService;

    @Override
    public void onEvent(ServiceInfoReceived event) {
        Exchange exchange = initExchange(event);
        try {
            ServiceInfo serviceInfo = JsonConverter.convert(event.getMessage(), new TypeReference<ServiceInfo>() {
            });
            //authorizationService.authorizeActionFromUIN(exchange);
            VehicleServiceInfo vehicle = mergeAndUpdate(event, serviceInfo);
            logService.info(LogMessage.create(EventMessage.VEHICLE_UPDATED).data(vehicle.getServiceInfo().getRawJson()).topic(event.getTopic().toString()), exchange);
        } catch (Exception e) {//NOSONAR
            exchange.setStatus(ExchangeStatus.ERROR);
            logService.error(LogMessage.create(EventMessage.VEHICLE_SERVICE_INFO_RECEPTION_ERROR).data(e.getMessage()).topic(event.getTopic().toString()), exchange);
            exchangeService.update(exchange);
        }
    }

    private VehicleServiceInfo mergeAndUpdate(ServiceInfoReceived serviceInfoReceived, ServiceInfo serviceInfo) throws ApplicationException {
        Optional<VehicleServiceInfo> vehicle = vehicleService.findVehicleServiceInfo(serviceInfoReceived.getUin());
        if (!vehicle.isPresent()) {
            vehicle = Optional.of(vehicleFactory.create(serviceInfoReceived.getUin()));
        }
        Date receivedDate = new Date();
        vehicle.get().setServiceInfo(new Payload(receivedDate, receivedDate, JsonConverter.convert(serviceInfo)));
        vehicleService.saveVehicleServiceInfo(vehicle.get());
        return vehicle.get();
    }

}
