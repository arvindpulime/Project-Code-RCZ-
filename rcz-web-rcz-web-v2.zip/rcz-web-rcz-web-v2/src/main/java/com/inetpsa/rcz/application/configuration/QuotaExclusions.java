package com.inetpsa.rcz.application.configuration;

import java.util.ArrayList;
import java.util.List;

public class QuotaExclusions {
    public List<String> partners = new ArrayList<>();
    public List<String> getPartners() {
        return partners;
    }
}
