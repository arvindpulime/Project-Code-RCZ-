/*
 * Creation : 16 août 2016
 */
package com.inetpsa.rcz.application.handlers.payload.stolen;

import com.fasterxml.jackson.core.type.TypeReference;
import com.inetpsa.rcz.application.exceptions.ApplicationException;
import com.inetpsa.rcz.application.exceptions.JsonParseException;
import com.inetpsa.rcz.application.handlers.payload.RequestHandler;
import com.inetpsa.rcz.domain.model.enums.ResponseStatus;
import com.inetpsa.rcz.domain.model.payload.data.StolenVin;
import com.inetpsa.rcz.domain.model.payload.request.RequestPayload;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;

public class StolenVinRequestHandler implements RequestHandler<StolenVin> {

    @Override
    public RequestPayload<StolenVin> handle(String request) throws ApplicationException {
        try {
            return JsonConverter.convert(request, new TypeReference<RequestPayload<StolenVin>>() {
            });
        } catch (JsonParseException e) {
            throw new ApplicationException(e.getMessage(), e, ResponseStatus.FORMAT_ERROR);
        }
    }
}
