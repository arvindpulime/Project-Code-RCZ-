package com.inetpsa.rcz.application.handlers.payload.doors;

import com.fasterxml.jackson.core.type.TypeReference;
import com.inetpsa.rcz.application.handlers.payload.AbstractResponseHandler;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.payload.data.Data;
import com.inetpsa.rcz.domain.model.payload.data.Doors;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;
import org.apache.commons.lang3.StringUtils;

public class DoorsResponseHandler extends AbstractResponseHandler<Doors> {

    @Override
    protected Doors handleResponseData(Data data, Exchange exchange) {
        if (StringUtils.isNotBlank(data.getValue())) {
            return JsonConverter.convert(data.getValue(), new TypeReference<Doors>() {
            });
        }
        return null;
    }
}
