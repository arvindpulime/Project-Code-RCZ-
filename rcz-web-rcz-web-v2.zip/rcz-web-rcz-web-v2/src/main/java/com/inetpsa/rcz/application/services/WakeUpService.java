package com.inetpsa.rcz.application.services;

import com.inetpsa.rcz.domain.model.vehicle.Vehicle;
import com.inetpsa.rcz.infrastructure.rest.sms.WakeUpException;
import org.seedstack.business.Service;

@Service
public interface WakeUpService {

    /**
     * wake up the vehicle
     *
     * @param vehicle to wake
     * @throws WakeUpException exception
     */
    void wakeUp(Vehicle vehicle) throws WakeUpException;
}
