package com.inetpsa.rcz.application.representation.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.inetpsa.rcz.application.representation.ServiceRepresentation;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OAuthConsumerServiceLean implements Serializable {

    @JsonProperty("scope")
    private List<String> scope;
    @JsonProperty("grant_type")
    private String grant;
    @JsonProperty("realm")
    private String realm;
    @JsonProperty("token_type")
    private String token;
    @JsonProperty("expires_in")
    private String expiresIn;
    @JsonProperty("access_token")
    private String accessToken;
    @JsonProperty("customer_id")
    private String customerId;

    /**
     * Map
     */
    @JsonProperty("services")
    private Map<String, Map<String, List<ServiceRepresentation>>> services;

    public List<String> getScope() {
        return scope;
    }

    public void setScope(List<String> scope) {
        this.scope = scope;
    }

    public String getGrant() {
        return grant;
    }

    public void setGrant(String grant) {
        this.grant = grant;
    }

    public String getRealm() {
        return realm;
    }

    public void setRealm(String realm) {
        this.realm = realm;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getExpiresIn() {
        return expiresIn;
    }

    public void setExpiresIn(String expiresIn) {
        this.expiresIn = expiresIn;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public Map<String, Map<String, List<ServiceRepresentation>>> getServices() {
        return services;
    }

    public void setServices(Map<String, Map<String, List<ServiceRepresentation>>> services) {
        this.services = services;
    }
}
