package com.inetpsa.rcz.application.handlers.event;

import com.inetpsa.rcz.application.exceptions.InvalidStateException;
import com.inetpsa.rcz.application.exceptions.InvalidVehicleException;
import com.inetpsa.rcz.domain.model.action.Action;
import com.inetpsa.rcz.domain.model.enums.CallerType;
import com.inetpsa.rcz.domain.model.enums.EventMessage;
import com.inetpsa.rcz.domain.model.enums.ExchangeStatus;
import com.inetpsa.rcz.domain.model.event.VehicleStateReceived;
import com.inetpsa.rcz.domain.model.event.VehicleWakeUpReceived;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.log.LogMessage;
import com.inetpsa.rcz.domain.model.payload.exception.InvalidTopicException;
import com.inetpsa.rcz.domain.model.payload.topic.Topic;
import com.inetpsa.rcz.domain.model.shared.Payload;
import com.inetpsa.rcz.domain.model.vehicle.State;
import com.inetpsa.rcz.domain.model.vehicle.Vehicle;
import com.inetpsa.rcz.domain.model.vehicle.VehicleConnect;
import com.inetpsa.rcz.domain.services.ExchangeService;
import com.inetpsa.rcz.domain.services.LogService;
import com.inetpsa.rcz.domain.services.VehicleService;
import org.apache.commons.lang3.StringUtils;
import org.seedstack.business.domain.BaseDomainEventHandler;
import org.seedstack.business.domain.DomainEventPublisher;
import org.seedstack.business.domain.Factory;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import javax.inject.Inject;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class VehicleStateReceivedHandler extends BaseDomainEventHandler<VehicleStateReceived> {

    public static final String INVALID_VEHICLE_STATE_FOR_MESSAGE = "Invalid vehicle state for message [%s]";
    public static final String INVALID_VEHICLE_STATE_FOR_REASON = "Invalid vehicle state for reason [%s]";
    public static final String INVALID_VEHICLE_SESSION_FOR_TOPIC = "Invalid vehicle session for topic [%s], last session [%s], last source [%s]";

    public static final String MQTT_VALIDATION_VEHICLE_CONNECTION_UIN = "validation.mqtt.connect.uin";
    public static final String RESET_SESSION_AWAIT_TIME_IN_MINUTES = "reset.session.await.time.in.minutes";
    public static final String REASON_FORCED_LOGOUT = "Forced Logout";
    @Inject
    private VehicleService vehicleService;

    @Inject
    private Factory<VehicleConnect> vehicleFactory;

    @Inject
    private Factory<Exchange> exchangeFactory;

    @Inject
    private ExchangeService exchangeService;

    @Configuration(RESET_SESSION_AWAIT_TIME_IN_MINUTES)
    private int resetSessionAwaitTimeInMinutes = 1440;

    private static Pattern REASON_EXTRACTION_PATTERN = Pattern.compile("(reason\\s*\\((.*?)\\)){1}");

    private static String CONNECT_TOPIC = "CLIENT_CLIENT_CONNECT_MQTT";

    private static String DISCONNECT_TOPIC = "CLIENT_CLIENT_DISCONNECT_MQTT";

    @Logging
    private Logger logger;

    @Inject
    private LogService logService;

    @Inject
    private DomainEventPublisher eventPublisher;

    private static final String TRUE = "1";
    private static final String FALSE = "0";
    @Configuration(MQTT_VALIDATION_VEHICLE_CONNECTION_UIN)
    private String patternUin = "^[a-zA-Z0-9]{20}$";

    @Override
    public void onEvent(VehicleStateReceived vehicleStateReceived) {
        try {
            String message = getMessage(vehicleStateReceived);
            VehicleData vehicleData = getVehicleData(vehicleStateReceived);
            Exchange exchange = initExchange(vehicleData.getUin(), vehicleStateReceived);
            Vehicle vehicle = null;
            boolean wasAlreadyConnected = false;
            try {
                Optional<VehicleConnect> oVehicle = vehicleService.findVehicleConnect(vehicleData.getUin());
                if (oVehicle.isPresent() && oVehicle.get().getVehicleState() != null) {
                    wasAlreadyConnected = oVehicle.get().getVehicleState().isConnected();
                }
                vehicle = saveVehicleState(oVehicle, vehicleStateReceived, message, vehicleData);
                exchangeStatusUpdate(exchange, ExchangeStatus.FINISHED);
                logService.info(LogMessage.create(EventMessage.VEHICLE_UPDATED).data(vehicleStateReceived.getMessage()).topic(vehicleStateReceived.getTopic()), exchange);
                if (vehicle.isConnected() && !wasAlreadyConnected) {
                    Collection<Exchange> exchanges = exchangeService.findPendingAsleep(vehicleData.getUin());
                    exchanges.forEach(ex -> eventPublisher.publish(new VehicleWakeUpReceived(ex)));
                }
            } catch (InvalidStateException e) {
                logService.error(LogMessage.create(EventMessage.VEHICLE_STATE_SESSION_ERROR).data(e.getMessage() + String.format(", PAYLOAD [%s]", vehicleStateReceived.getMessage())).topic(vehicleStateReceived.getTopic()), exchange);
                exchangeStatusUpdate(exchange, ExchangeStatus.ERROR);
            }
        } catch (InvalidVehicleException e) {
            logger.debug(e.getMessage(), e);
        }

    }

    private void exchangeStatusUpdate(Exchange exchange, ExchangeStatus error) {
        exchange.setStatus(error);
        exchangeService.update(exchange);
    }

    private String getMessage(VehicleStateReceived vehicleStateReceived) {
        if (vehicleStateReceived.getTopic().contains(CONNECT_TOPIC)) {
            return TRUE;
        } else if (vehicleStateReceived.getTopic().contains(DISCONNECT_TOPIC)) {
            return FALSE;
        }
        return vehicleStateReceived.getMessage();
    }

    private VehicleData getVehicleData(VehicleStateReceived vehicleStateReceived) throws InvalidVehicleException {
        try {
            Topic topic = new Topic(vehicleStateReceived.getTopic());
            return new VehicleData(topic.getId());
        } catch (InvalidTopicException e) {
            return getVehicleData(vehicleStateReceived.getTopic());
        }
    }

    private String extractReason(String message) {
        Matcher matcher = REASON_EXTRACTION_PATTERN.matcher(message);
        if (matcher.find()) {
            String reason = matcher.group(2);
            if (StringUtils.isNotBlank(reason)) {
                return reason.trim();
            } else {
                return null;
            }
        } else {
            return null;
        }
    }


    private VehicleData getVehicleData(String topic) throws InvalidVehicleException {
        String[] dataArray = topic.split("/");
        if (dataArray.length < 10 || !Pattern.matches(patternUin, dataArray[8])) {
            throw new InvalidVehicleException(String.format(INVALID_VEHICLE_STATE_FOR_MESSAGE, topic));
        }
        try {
            String uin = dataArray[8];
            Long sessionId = Long.parseLong(dataArray[9]);
            String source = dataArray[4];
            return new VehicleData(uin, sessionId, source);
        } catch (NumberFormatException e) {
            throw new InvalidVehicleException(String.format(INVALID_VEHICLE_STATE_FOR_MESSAGE, topic), e);
        }


    }

    private Vehicle saveVehicleState(Optional<VehicleConnect> oVehicle, VehicleStateReceived vehicleStateReceived, String message, VehicleData vehicleData) throws InvalidStateException {
        boolean vehicleState = false;
        if (vehicleStateReceived.getMessage() != null) {
            vehicleState = message.contentEquals(TRUE);
        }
        checkReason(vehicleStateReceived, vehicleState);
        if (!oVehicle.isPresent()) {
            oVehicle = Optional.of(vehicleFactory.create(vehicleData.getUin()));
        } else {
            checkSessionId(oVehicle.get(), vehicleData, vehicleStateReceived);
        }
        State state = new State(vehicleState, new Date());
        oVehicle.get().setLastSession(vehicleData.getSessionId());
        oVehicle.get().setLastSource(vehicleData.getSource());
        oVehicle.get().setVehicleState(state);
        oVehicle.get().setUpdateDate(new Date());
        vehicleService.saveConnect(oVehicle.get());
        return vehicleService.find(oVehicle.get().getId()).orElseThrow(() -> new InvalidStateException("Vehicle State save error"));
    }

    private void checkReason(VehicleStateReceived vehicleStateReceived, boolean vehicleState) throws InvalidStateException {
        if (!vehicleState) {
            String reason = extractReason(vehicleStateReceived.getMessage());
            if (reason != null && REASON_FORCED_LOGOUT.equals(reason)) {
                throw new InvalidStateException(String.format(INVALID_VEHICLE_STATE_FOR_REASON, reason));
            }
        }
    }

    public void checkSessionId(VehicleConnect vehicle, VehicleData vehicleData, VehicleStateReceived vehicleStateReceived) throws InvalidStateException {
        Calendar hoursBeforeResetSession = Calendar.getInstance();
        hoursBeforeResetSession.add(Calendar.MINUTE, -resetSessionAwaitTimeInMinutes);
        if (vehicle.getLastSession() != null
                && (vehicleStateReceived.getTopic().contains(DISCONNECT_TOPIC)
                && (!vehicleData.getSource().equals(vehicle.getLastSource())
                || (vehicleData.getSource().equals(vehicle.getLastSource())
                && vehicleData.getSessionId() < vehicle.getLastSession()
                && vehicle.getUpdateDate().before(hoursBeforeResetSession.getTime()))))) {
            throw new InvalidStateException(String.format(INVALID_VEHICLE_SESSION_FOR_TOPIC, vehicleStateReceived.getTopic(), vehicle.getLastSession(), vehicle.getLastSource()));
        }

    }

    private Exchange initExchange(String uin, VehicleStateReceived vehicleStateReceived) {
        Exchange exchange = exchangeFactory.create();
        exchange.setCallerType(CallerType.VEHICLE);
        exchange.setCallerId(uin);
        exchange.setRequest(new Payload(new Date(), vehicleStateReceived.getMessage()));
        exchange.setAction(Action.VEHICLE_STATE);
        exchange.setTopic(vehicleStateReceived.getTopic());
        exchange.setStatus(ExchangeStatus.PENDING);
        exchange.setUin(uin);
        exchangeService.add(exchange);
        return exchange;
    }

    public class VehicleData {
        private String uin;
        private Long sessionId;
        private String source;

        public VehicleData(String uin, Long sessionId, String source) {
            this.uin = uin;
            this.sessionId = sessionId;
            this.source = source;
        }

        public VehicleData(String uin) {
            this.uin = uin;
        }

        public String getUin() {
            return uin;
        }

        public Long getSessionId() {
            return sessionId;
        }

        public String getSource() {
            return source;
        }
    }


}
