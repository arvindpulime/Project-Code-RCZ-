package com.inetpsa.rcz.application.handlers.payload.doors;

import com.fasterxml.jackson.core.type.TypeReference;
import com.inetpsa.rcz.application.exceptions.ApplicationException;
import com.inetpsa.rcz.application.handlers.payload.BTARequestHandler;
import com.inetpsa.rcz.application.services.LocalizationService;
import com.inetpsa.rcz.application.util.JsonConverter;
import com.inetpsa.rcz.application.util.LocalizationKey;
import com.inetpsa.rcz.domain.model.enums.ResponseStatus;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.payload.data.Doors;
import com.inetpsa.rcz.domain.model.payload.data.ServiceInfo;
import com.inetpsa.rcz.domain.model.payload.request.BTARequestPayload;
import com.inetpsa.rcz.domain.model.payload.request.RequestPayload;
import com.inetpsa.rcz.domain.model.vehicle.Vehicle;
import com.inetpsa.rcz.domain.services.VehicleService;
import org.apache.commons.lang3.StringUtils;

import javax.inject.Inject;
import java.util.Date;
import java.util.Optional;

public class DoorsBTARequestHandler implements BTARequestHandler<Doors, Doors> {

    private static final String LOCK = "lock";

    @Inject
    private VehicleService vehicleService;

    @Inject
    private LocalizationService localizationService;

    @Override
    public BTARequestPayload<Doors> handle(Exchange exchange, RequestPayload<Doors> requestPayload) throws ApplicationException {
        Optional<Vehicle> vehicle = vehicleService.find(exchange.getUin());
        ServiceInfo serviceInfo = null;
        if (vehicle.isPresent() && vehicle.get().getServiceInfo() != null && StringUtils.isNotBlank(vehicle.get().getServiceInfo().getRawJson())) {
            serviceInfo = JsonConverter.convert(vehicle.get().getServiceInfo().getRawJson(), new TypeReference<ServiceInfo>() {
            });
        }

        BTARequestPayload<Doors> btaRequest = new BTARequestPayload<>();
        btaRequest.setRequestDate(new Date());
        if (LOCK.equals(requestPayload.getRequestParameters().getAction())) {
            if (requestPayload.getRequestParameters().getForced()!=null && requestPayload.getRequestParameters().getForced()) {
                if (serviceInfo != null && serviceInfo.isBlackListed()) {
                    btaRequest.setData(new Doors(2));
                } else {
                    throw new ApplicationException(localizationService.localize(LocalizationKey.BAD_DOORS_REQUEST_VEHICLE_NOT_BLACKLISTED), ResponseStatus.BAD_REQUEST);
                }
            } else {
                btaRequest.setData(new Doors(1));
            }
        } else {
            //TODO change state to action
            int state = 0;
            if (requestPayload.getRequestParameters().getState() != null) {
                state = requestPayload.getRequestParameters().getState();
            }
            btaRequest.setData(new Doors(state));
        }

        btaRequest.setRequestId(exchange.getId());
        return btaRequest;
    }
}

