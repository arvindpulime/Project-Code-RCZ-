package com.inetpsa.rcz.infrastructure.rest.sms.orange.representation;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class OrangeSmsRequest {

    private OutboundSMSMessageRequest outboundSMSMessageRequest;

    public OrangeSmsRequest(OutboundSMSMessageRequest outboundSMSMessageRequest) {
        this.outboundSMSMessageRequest = outboundSMSMessageRequest;
    }
}
