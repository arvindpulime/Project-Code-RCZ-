package com.inetpsa.rcz.application.handlers.event;

import com.inetpsa.rcz.application.exceptions.ApplicationException;
import com.inetpsa.rcz.application.handlers.payload.BTARequestHandler;
import com.inetpsa.rcz.application.handlers.payload.RequestHandler;
import com.inetpsa.rcz.application.services.LocalizationService;
import com.inetpsa.rcz.application.services.PublisherService;
import com.inetpsa.rcz.application.services.PublisherService.Target.TargetBuilder;
import com.inetpsa.rcz.domain.model.enums.EventMessage;
import com.inetpsa.rcz.domain.model.enums.ResponseStatus;
import com.inetpsa.rcz.domain.model.event.ErrorOccurred;
import com.inetpsa.rcz.domain.model.event.VehicleStateResponseReceived;
import com.inetpsa.rcz.domain.model.event.VehicleStateSent;
import com.inetpsa.rcz.domain.model.event.VehicleWakeUpReceived;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.log.LogMessage;
import com.inetpsa.rcz.domain.model.payload.data.Data;
import com.inetpsa.rcz.domain.model.payload.data.VehicleState;
import com.inetpsa.rcz.domain.model.payload.request.BTARequestPayload;
import com.inetpsa.rcz.domain.model.payload.request.RequestPayload;
import com.inetpsa.rcz.domain.model.payload.response.BTAResponsePayload;
import com.inetpsa.rcz.domain.model.payload.topic.Topic;
import com.inetpsa.rcz.domain.model.vehicle.Vehicle;
import com.inetpsa.rcz.domain.services.LogService;
import com.inetpsa.rcz.domain.services.ParameterService;
import com.inetpsa.rcz.domain.services.VehicleService;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.seedstack.business.domain.BaseDomainEventHandler;
import org.seedstack.business.domain.DomainEventPublisher;
import org.seedstack.business.domain.DomainRegistry;
import org.seedstack.shed.reflect.TypeOf;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.Optional;

import static com.inetpsa.rcz.application.util.TypeResolver.REQUEST_TYPES;

public class VehicleWakeUpReceivedHandler extends BaseDomainEventHandler<VehicleWakeUpReceived> {

    @Inject
    protected DomainRegistry domainRegistry;

    @Inject
    private VehicleService vehicleService;

    @Inject
    private DomainEventPublisher eventPublisher;

    @Inject
    private LogService logService;

    @Named("mqtt")
    @Inject
    private PublisherService publisherService;

    @Inject
    private ParameterService parameterService;

    @Inject
    private LocalizationService localizationService;

    @Override
    public void onEvent(VehicleWakeUpReceived event) {
        RequestHandler<?> requestHandler = domainRegistry.getService(REQUEST_TYPES.get(event.getExchange().getAction()));
        try {
            RequestPayload requestPayload = requestHandler.handle(event.getExchange().getRequest().getRawJson());
            if (parameterService.get().getRcz().getAutomaticVehicleState()) {
                autoVehicleState(event.getExchange(), requestPayload);
            } else {
                manualVehicleState(event.getExchange(), requestPayload);
            }
        } catch (ApplicationException e) {//NOSONAR
            logService.error(LogMessage.create(EventMessage.REQUEST_ERROR).data(ExceptionUtils.getRootCauseMessage(e)), event.getExchange(), LogService.AppLog.DATABASE);
            eventPublisher.publish(new ErrorOccurred(event.getExchange(), e.getResponseStatus(), e.getMessage()));
        }

    }

    private void autoVehicleState(Exchange exchange, RequestPayload requestPayload) throws ApplicationException {
        Optional<Vehicle> vehicle = vehicleService.find(exchange.getUin());
        if (!vehicle.isPresent() || vehicle.get().getVehicleInfo() == null || StringUtils.isBlank(vehicle.get().getVehicleInfo().getRawJson())) {
            manualVehicleState(exchange, requestPayload);
        } else {
            BTAResponsePayload btaResponsePayload = new BTAResponsePayload();
            btaResponsePayload.setData(new Data(vehicle.get().getVehicleInfo().getRawJson()));
            btaResponsePayload.setStatus(Integer.parseInt(ResponseStatus.STATUS_OK.code()));
            eventPublisher.publish(new VehicleStateResponseReceived(exchange, btaResponsePayload));
        }
    }

    private void manualVehicleState(Exchange exchange, RequestPayload requestPayload) throws ApplicationException {
        // build & save BTA request
        BTARequestHandler<VehicleState, VehicleState> btaRequestHandler = domainRegistry.getService(new TypeOf<BTARequestHandler<VehicleState, VehicleState>>() {
        }.getType());
        BTARequestPayload<VehicleState> btaRequestPayload = btaRequestHandler.handle(exchange, requestPayload);
        String btaRequestJson = JsonConverter.convert(btaRequestPayload);
        Topic topic = new Topic(exchange.getTopic());
        String btaTopic = topic.toBTAVehicleState(exchange.getUin());
        publisherService.publish(btaRequestJson, TargetBuilder.builder().withTopic(btaTopic).build());
        // VehicleCommandSent --> log request BTA
        logService.info(LogMessage.create(EventMessage.VEHICLE_STATE_SENT_TO_VEHICLE).data(btaRequestJson).topic(btaTopic), exchange);
        eventPublisher.publish(new VehicleStateSent(exchange));
    }


}
