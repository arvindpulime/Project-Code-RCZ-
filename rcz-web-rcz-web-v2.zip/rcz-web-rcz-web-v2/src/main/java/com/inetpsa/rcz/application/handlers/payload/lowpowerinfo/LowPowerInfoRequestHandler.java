package com.inetpsa.rcz.application.handlers.payload.lowpowerinfo;

import com.fasterxml.jackson.core.type.TypeReference;
import com.inetpsa.rcz.application.exceptions.ApplicationException;
import com.inetpsa.rcz.application.exceptions.JsonParseException;
import com.inetpsa.rcz.application.exceptions.RequestParseException;
import com.inetpsa.rcz.application.handlers.payload.RequestHandler;
import com.inetpsa.rcz.domain.model.enums.ResponseStatus;
import com.inetpsa.rcz.domain.model.payload.data.LowPowerInfo;
import com.inetpsa.rcz.domain.model.payload.data.LowPowerInfoRequest;
import com.inetpsa.rcz.domain.model.payload.request.RequestPayload;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;

public class LowPowerInfoRequestHandler implements RequestHandler<LowPowerInfoRequest> {

    @Override
    public RequestPayload<LowPowerInfoRequest> handle(String requestRawJson) throws ApplicationException {
        try {
            return JsonConverter.convert(requestRawJson, new TypeReference<RequestPayload<LowPowerInfoRequest>>() {
            });
        } catch (RequestParseException | JsonParseException e) {
            throw new ApplicationException(e.getMessage(), e, ResponseStatus.FORMAT_ERROR);
        }
    }
}
