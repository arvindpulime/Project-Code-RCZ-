package com.inetpsa.rcz.application.handlers.event;

import com.fasterxml.jackson.core.type.TypeReference;
import com.inetpsa.rcz.application.services.PublisherService;
import com.inetpsa.rcz.domain.model.action.Action;
import com.inetpsa.rcz.domain.model.enums.CallerType;
import com.inetpsa.rcz.domain.model.enums.EventMessage;
import com.inetpsa.rcz.domain.model.enums.ExchangeStatus;
import com.inetpsa.rcz.domain.model.event.ServiceStateReceived;
import com.inetpsa.rcz.domain.model.event.VehicleWakeUpReceived;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.log.LogMessage;
import com.inetpsa.rcz.domain.model.payload.data.ServiceState;
import com.inetpsa.rcz.domain.model.payload.request.BTARequestPayload;
import com.inetpsa.rcz.domain.model.payload.topic.Topic;
import com.inetpsa.rcz.domain.model.shared.Payload;
import com.inetpsa.rcz.domain.model.vehicle.State;
import com.inetpsa.rcz.domain.model.vehicle.Vehicle;
import com.inetpsa.rcz.domain.model.vehicle.VehicleServiceState;
import com.inetpsa.rcz.domain.services.ExchangeService;
import com.inetpsa.rcz.domain.services.LogService;
import com.inetpsa.rcz.domain.services.VehicleService;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;
import org.apache.commons.lang3.StringUtils;
import org.seedstack.business.domain.BaseDomainEventHandler;
import org.seedstack.business.domain.DomainEventPublisher;
import org.seedstack.business.domain.Factory;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.Collection;
import java.util.Date;
import java.util.Optional;

public class ServiceStateReceivedHandler extends BaseDomainEventHandler<ServiceStateReceived> {

    public static final String SERVICE_STATE_ERROR = "ServiceState error for topic [{}], payload [{}]";

    @Inject
    private Factory<VehicleServiceState> vehicleFactory;

    @Inject
    private ExchangeService exchangeService;

    @Inject
    private DomainEventPublisher eventPublisher;

    @Inject
    private LogService logService;

    @Inject
    private Factory<Exchange> exchangeFactory;

    @Logging
    private Logger logger;

    @Inject
    private VehicleService vehicleService;

    @Named("mqtt")
    @Inject
    private PublisherService publisherService;

    private static final int TRUE = 1;

    @Override
    public void onEvent(ServiceStateReceived serviceStateReceived) {
        Optional<Exception> exception = Optional.empty();
        Optional<Vehicle> vehicle = Optional.empty();
        ServiceState serviceState = null;
        boolean wasAlreadyConnected = false;
        try {
            boolean status = false;
            if (serviceStateReceived.getMessage() != null) {
                serviceState = JsonConverter.convert(serviceStateReceived.getMessage(), new TypeReference<ServiceState>() {
                });
                status = serviceState.getState() == TRUE;
            }
            Optional<VehicleServiceState> oVehicle = vehicleService.findVehicleServiceState(serviceStateReceived.getTopic().getId());
            if (oVehicle.isPresent() && oVehicle.get().getServiceState() != null) {
                wasAlreadyConnected = oVehicle.get().getServiceState().isConnected();
            }
            vehicle = getUpdateVehicle(oVehicle, serviceStateReceived, status);
        } catch (Exception e1) {//NOSONAR
            exception = Optional.of(e1);
        } finally {
            Exchange exchange = initExchange(serviceStateReceived);
            try {
                logService.info(LogMessage.create(EventMessage.SERVICE_STATE_RECEIVED).data(serviceStateReceived.getMessage()).topic(serviceStateReceived.getTopic().toString()), exchange);
                if (exception.isPresent()) {
                    throw exception.get();
                }
                logService.info(LogMessage.create(EventMessage.SERVICE_STATE_UPDATED), exchange);
                deleteServiceState(serviceStateReceived, serviceState, exchange);
                if (vehicle.isPresent() && vehicle.get().isConnected() && !wasAlreadyConnected) {
                    resumePendingExchange(vehicle.get().getId());
                }
            } catch (Exception e) {//NOSONAR
                exchangeError(serviceStateReceived, exchange, e);
            }
        }
    }

    private void deleteServiceState(ServiceStateReceived serviceStateReceived, ServiceState serviceState, Exchange exchange) {
        if (serviceState != null && StringUtils.isNotBlank(serviceState.getRequestId())) {
            Topic topic = serviceStateReceived.getTopic();
            BTARequestPayload<ServiceState> btaRequestPayload = new BTARequestPayload<>();
            btaRequestPayload.setRequestDate(new Date());
            btaRequestPayload.setRequestId(exchange.getId());
            btaRequestPayload.setData(new ServiceState(serviceState.getRequestId()));
            String target = topic.toBTA(exchange.getUin());
            String deleteData = JsonConverter.convert(btaRequestPayload);
            publisherService.publish(deleteData, PublisherService.Target.TargetBuilder.builder().withTopic(target).build());
            logService.info(LogMessage.create(EventMessage.SERVICE_STATE_DELETE_SENT).topic(target).data(deleteData), exchange);
        }
    }

    private void exchangeError(ServiceStateReceived serviceStateReceived, Exchange exchange, Exception e) {
        exchange.setStatus(ExchangeStatus.ERROR);
        logger.error(SERVICE_STATE_ERROR, serviceStateReceived.getTopic(), serviceStateReceived.getMessage(), e);
        logService.error(LogMessage.create(EventMessage.SERVICE_STATE_ERROR).data(e.getMessage()), exchange);
        exchangeService.update(exchange);
    }


    Optional<Vehicle> getUpdateVehicle(Optional<VehicleServiceState> vehicle, ServiceStateReceived serviceStateReceived, boolean serviceState) {
        if (!vehicle.isPresent()) {
            vehicle = Optional.of(vehicleFactory.create(serviceStateReceived.getTopic().getId()));
        }
        State state = new State(serviceState, new Date());
        vehicle.get().setServiceState(state);
        vehicleService.saveServiceState(vehicle.get());
        return vehicleService.find(vehicle.get().getId());
    }


    private Exchange initExchange(ServiceStateReceived event) {
        Exchange exchange = exchangeFactory.create();
        String request = event.getMessage();
        Topic topic = event.getTopic();
        exchange.setCallerType(CallerType.VEHICLE);
        exchange.setCallerId(topic.getId());
        exchange.setRequest(new Payload(new Date(), request));
        exchange.setAction(Action.SERVICE_STATE);
        exchange.setTopic(topic.toString());
        exchange.setStatus(ExchangeStatus.FINISHED);
        exchange.setUin(topic.getId());
        exchangeService.add(exchange);
        return exchange;
    }

    private void resumePendingExchange(String uin) {
        Collection<Exchange> exchanges = exchangeService.findPendingAsleep(uin);
        exchanges.forEach(exchange -> eventPublisher.publish(new VehicleWakeUpReceived(exchange)));
    }
}
