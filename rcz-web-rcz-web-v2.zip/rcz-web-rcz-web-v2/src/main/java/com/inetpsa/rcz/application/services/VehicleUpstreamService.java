package com.inetpsa.rcz.application.services;

import com.inetpsa.rcz.application.exceptions.ApplicationException;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.vehicle.Vehicle;
import org.seedstack.business.Service;

@Service
public interface VehicleUpstreamService {


    Vehicle find(Exchange exchange) throws ApplicationException;
}
