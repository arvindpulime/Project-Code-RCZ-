package com.inetpsa.rcz.application.handlers.payload.preconditioning;

import com.fasterxml.jackson.core.type.TypeReference;
import com.inetpsa.rcz.application.exceptions.ApplicationException;
import com.inetpsa.rcz.application.exceptions.JsonParseException;
import com.inetpsa.rcz.application.exceptions.RequestParseException;
import com.inetpsa.rcz.application.handlers.payload.RequestHandler;
import com.inetpsa.rcz.domain.model.enums.ResponseStatus;
import com.inetpsa.rcz.domain.model.payload.data.Preconditioning;
import com.inetpsa.rcz.domain.model.payload.request.RequestPayload;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;

public class PreconditioningRequestHandler implements RequestHandler<Preconditioning> {

    @Override
    public RequestPayload<Preconditioning> handle(String request) throws ApplicationException {
        try {
            return JsonConverter.convert(request, new TypeReference<RequestPayload<Preconditioning>>() {
            });
        } catch (RequestParseException | JsonParseException e) {
            throw new ApplicationException(e.getMessage(), e, ResponseStatus.FORMAT_ERROR);
        }
    }

}
