package com.inetpsa.rcz.application.handlers.event;

import com.inetpsa.rcz.application.services.PublisherService.Target.TargetBuilder;
import com.inetpsa.rcz.domain.model.enums.EventMessage;
import com.inetpsa.rcz.domain.model.enums.ExchangeStatus;
import com.inetpsa.rcz.domain.model.enums.ResponseStatus;
import com.inetpsa.rcz.domain.model.event.RequestStateReceived;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.log.LogMessage;
import com.inetpsa.rcz.domain.model.payload.data.RequestState;
import com.inetpsa.rcz.domain.model.payload.data.RequestStateResult;
import com.inetpsa.rcz.domain.model.payload.request.RequestPayload;
import com.inetpsa.rcz.domain.model.payload.response.ResponsePayload;
import com.inetpsa.rcz.domain.model.payload.topic.Topic;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;

import java.util.Date;

/**
 * @author tuan.docao@ext.mpsa.com
 */
public class RequestStateReceivedHandler extends AbstractRequestReceivedHandler<RequestStateReceived> {

    @Override
    void process(Exchange exchange, RequestPayload<?> requestPayload) {
        RequestState requestParameters = (RequestState) requestPayload.getRequestParameters();
        String requestStateStatus = exchangeService.getRequestStateStatus(requestParameters.getCorrelationId());
        ResponsePayload<RequestStateResult> responsePayload = buildResponse(exchange, requestStateStatus);
        String rawJson = JsonConverter.convert(responsePayload);
        Topic topic = new Topic(exchange.getTopic());
        String target = topic.toTarget(false);
        publisherService.publish(rawJson, TargetBuilder.builder().withTopic(target).build());
        exchange.setStatus(ExchangeStatus.FINISHED);
        exchange.setResponseStatus(ResponseStatus.STATUS_OK);
        exchangeService.update(exchange);
        logService.info(LogMessage.create(EventMessage.RESPONSE_SENT).data(rawJson).topic(target), exchange);
    }

    private ResponsePayload<RequestStateResult> buildResponse(Exchange exchange, String requestStateStatus) {
        RequestStateResult requestStateResult = new RequestStateResult(requestStateStatus);
        ResponsePayload<RequestStateResult> responsePayload = new ResponsePayload<>();
        responsePayload.setResponseData(requestStateResult);
        responsePayload.setResponseDate(new Date());
        responsePayload.setCorrelationId(exchange.getCorrelationId());
        responsePayload.setVin(exchange.getVin());
        responsePayload.setReturnMessage(ResponseStatus.STATUS_OK.name());
        responsePayload.setReturnCode(ResponseStatus.STATUS_OK.code());
        return responsePayload;
    }

}
