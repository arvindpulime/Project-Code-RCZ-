package com.inetpsa.rcz.application.scheduler;

import com.fasterxml.jackson.core.type.TypeReference;
import com.inetpsa.rcz.application.configuration.RczConfig;
import com.inetpsa.rcz.application.util.JsonConverter;
import com.inetpsa.rcz.domain.model.monitoring.AppInfo;
import com.inetpsa.rcz.domain.services.MonitoringService;
import org.seedstack.scheduler.SchedulingContext;
import org.seedstack.scheduler.Task;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import javax.inject.Inject;

public class ApplicationMonitoringTask implements Task {

    @Configuration("rcz")
    private RczConfig rczConfig;

    @Logging
    private Logger logger;

    @Inject
    private MonitoringService monitoringService;

    @Override
    public void execute(SchedulingContext sc) throws Exception {
        AppInfo appInfo = JsonConverter.convert(JsonConverter.convert(rczConfig.getApplication()), new TypeReference<AppInfo>() {
        });
        monitoringService.updateApplicationMonitoringData(appInfo.getInstance(), appInfo);
    }
}
