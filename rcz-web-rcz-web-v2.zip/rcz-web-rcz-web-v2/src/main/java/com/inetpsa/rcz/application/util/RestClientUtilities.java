package com.inetpsa.rcz.application.util;

import com.google.common.base.Charsets;
import com.inetpsa.rcz.application.exceptions.ApplicationException;
import com.inetpsa.rcz.domain.model.enums.ResponseStatus;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;
import org.glassfish.jersey.client.authentication.HttpAuthenticationFeature;
import org.glassfish.jersey.jackson.JacksonFeature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.text.MessageFormat;
import java.util.List;

import static org.glassfish.jersey.client.ClientProperties.SUPPRESS_HTTP_COMPLIANCE_VALIDATION;

public class RestClientUtilities {

    private static final Logger LOGGER = LoggerFactory.getLogger(RestClientUtilities.class);
    private static final String ERROR_LOADING_KEY_STORE = "Error while loading keyStore [{0}]";

    public static WebTarget prepareClient(ClientConfig restClientConfig) throws ApplicationException {

        try {
            org.glassfish.jersey.client.ClientConfig clientConfig = new org.glassfish.jersey.client.ClientConfig();
            clientConfig.property(SUPPRESS_HTTP_COMPLIANCE_VALIDATION, true);
            ClientBuilder clientBuilder = ClientBuilder.newBuilder().withConfig(clientConfig).register(JacksonFeature.class);

            if (StringUtils.isNotEmpty(restClientConfig.getUsername()) && StringUtils.isNotEmpty(restClientConfig.getPassword())) {
                HttpAuthenticationFeature authenticationFeature = HttpAuthenticationFeature.basic(restClientConfig.getUsername(), restClientConfig.getPassword());
                clientBuilder = clientBuilder.register(authenticationFeature);
            }

            if (isHttps(restClientConfig)) {
                clientBuilder = clientBuilder.trustStore(loadKeyStore(restClientConfig)).hostnameVerifier((s, sslSession) -> true);
            }

            URI uri = new URI(restClientConfig.getHost());
            WebTarget webTarget = clientBuilder.build().target(buildHost(uri));

            webTarget = buildQueryParam(uri, webTarget);
            return webTarget;
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            throw new ApplicationException(e.getMessage(), e, ResponseStatus.TECHNICAL_ERROR);
        }
    }

    public static boolean isHttps(ClientConfig wsConfig) {
        return wsConfig.getSsl() != null
                && wsConfig.getSsl().getTruststore() != null
                && StringUtils.isNotEmpty(wsConfig.getSsl().getTruststore().getFile())
                && StringUtils.isNotEmpty(wsConfig.getSsl().getTruststore().getPassword());
    }


    public static KeyStore loadKeyStore(ClientConfig wsConfig) throws IOException {
        KeyStore store = null;
        try (InputStream is = new FileInputStream((wsConfig.getSsl().getTruststore().getFile()))) {
            store = KeyStore.getInstance(KeyStore.getDefaultType());
            char[] password = wsConfig.getSsl().getTruststore().getPassword().toCharArray();
            store.load(is, password);
        } catch (Exception e) {//NOSONAR
            LOGGER.error(MessageFormat.format(ERROR_LOADING_KEY_STORE, wsConfig.getSsl().getTruststore().getFile()), e);
            throw new IOException(MessageFormat.format(ERROR_LOADING_KEY_STORE, wsConfig.getSsl().getTruststore().getFile()), e);
        }
        return store;
    }

    public static WebTarget buildQueryParam(URI uri, WebTarget target) {
        List<NameValuePair> params = URLEncodedUtils.parse(uri, Charsets.UTF_8);
        if (params != null) {
            for (NameValuePair nameValuePair : params) {
                target = target.queryParam(nameValuePair.getName(), nameValuePair.getValue());
            }
        }
        return target;
    }

    public static String buildHost(URI uri) {
        StringBuilder pathBuilder = new StringBuilder(uri.getScheme()).append("://").append(uri.getHost());
        if (uri.getPort() > -1) {
            pathBuilder.append(":").append(uri.getPort());
        }
        if (StringUtils.isNotBlank(uri.getPath())) {
            pathBuilder.append(uri.getPath());
        }
        return pathBuilder.toString();
    }
}
