package com.inetpsa.rcz.application.handlers.payload.state.request;

import com.inetpsa.rcz.application.handlers.payload.AbstractResponseHandler;
import com.inetpsa.rcz.application.handlers.payload.ResponseHandler;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.payload.data.Data;
import com.inetpsa.rcz.domain.model.payload.data.RequestStateResult;

public class RequestStateResponseHandler extends AbstractResponseHandler<RequestStateResult> implements ResponseHandler<RequestStateResult> {


    @Override
    protected RequestStateResult handleResponseData(Data data, Exchange exchange) {
        return null;
    }
}
