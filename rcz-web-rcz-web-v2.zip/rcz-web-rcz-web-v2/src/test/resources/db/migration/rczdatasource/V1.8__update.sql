drop table rczqtvehstatehistory;
drop table rczqtservicestatehistory;
