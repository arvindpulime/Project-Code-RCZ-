create table if not exists seed_i18n_key
(
    id          varchar(255) not null,
    description varchar(255),
    outdated    boolean,
    constraint seed_i18n_key_pkey
        primary key (id)
);

create table if not exists seed_i18n_locale
(
    code             varchar(255) not null,
    default_locale   boolean,
    english_language varchar(255),
    language         varchar(255),
    constraint seed_i18n_locale_pkey
        primary key (code)
);

create table if not exists seed_i18n_translation
(
    key_id      varchar(255) not null,
    locale      varchar(255) not null,
    approximate boolean,
    outdated    boolean,
    translation varchar(255),
    constraint seed_i18n_translation_pkey
        primary key (key_id, locale)
);

create table if not exists seed_i18n_key_trans
(
    key_id              varchar(255) not null,
    translations_key_id varchar(255) not null,
    translations_locale varchar(255) not null,
    constraint seed_i18n_key_trans_pkey
        primary key (key_id, translations_key_id, translations_locale),
    constraint seed_i18n_key_trans_unique
        unique (translations_key_id, translations_locale),
    constraint seed_i18n_translation_fk
        foreign key (translations_key_id, translations_locale) references seed_i18n_translation,
    constraint seed_i18n_key_fk
        foreign key (key_id) references seed_i18n_key
);

create table if not exists rczqtexchange
(
    id             varchar(255) not null,
    actionservice  varchar(255) not null,
    actiontype     varchar(255) not null,
    callerid       varchar(255) not null,
    callertype     varchar(255) not null,
    correlationid  varchar(255),
    processstatus  varchar(255),
    request        text,
    receiveddate   timestamp,
    sentdate       timestamp,
    responsestatus varchar(255),
    status         varchar(255),
    topic          varchar(255),
    uin            varchar(255),
    vin            varchar(255),
    constraint rczqtexchange_pkey
        primary key (id)
);

create table if not exists rczqthelper
(
    id         bigint not null,
    content    text,
    createdate timestamp,
    title      varchar(255),
    constraint rczqthelper_pkey
        primary key (id)
);

create table if not exists rczqtlog
(
    id         bigint       not null,
    exchangeid varchar(255),
    instanceid varchar(255),
    logdate    timestamp,
    loglevel   varchar(255),
    data       text,
    message    varchar(255) not null,
    topic      varchar(255),
    constraint rczqtlog_pkey
        primary key (id)
);

create table if not exists rczqtparameter
(
    id                              varchar(255) not null,
    bytelsmsdatalength              integer,
    bytelsmsadm                     varchar(255),
    bytelsmsdspt                    integer,
    bytelsmsicp                     varchar(255),
    bytelsmsidoffer                 varchar(255),
    bytelsmsmessageformat           varchar(255),
    bytelsmsmessageid               integer,
    bytelsmsmessagelength           integer,
    bytelsmsmessageversion          integer,
    bytelsmsmessagetype             integer,
    bytelsmsnbretry                 integer,
    bytelsmspath                    varchar(255),
    bytelsmsprotocolversion         varchar(255),
    bytelsmsretrydelay              integer,
    bytelsmsservicetype             integer,
    bytelsmstargettype              varchar(255),
    bytelsmsuri                     varchar(255),
    vehiclerequestmaxduration       integer,
    vehiclerequestmock              boolean,
    vehiclerequestnbretry           integer,
    vehiclerequestpath              varchar(255),
    vehiclerequestretrydelay        integer,
    vehiclerequesturi               varchar(255),
    cvsauthaccess                   boolean,
    cvsendpointurl                  varchar(255),
    cvsmock                         boolean,
    cvsoauthendpointurl             varchar(255),
    automaticvehiclestate           boolean,
    callerdailyquota                integer,
    callerdailyquotadurationmin     integer,
    callerdailyquotaenabled         boolean,
    callerquota                     integer,
    callerquotadurationmin          integer,
    callerquotawarning              integer,
    callerquotawarningdurationmin   integer,
    clientresponsedebug             boolean,
    exchangetimeoutmin              integer,
    hornquota                       integer,
    hornquotadurationmin            integer,
    lightsquota                     integer,
    lightsquotadurationmin          integer,
    openbar                         boolean,
    proxy                           boolean,
    remotealarmid                   varchar(255),
    constraint rczqtparameter_pkey
        primary key (id)
);

create table if not exists rczqtrequest
(
    id            varchar(255) not null,
    actionservice varchar(255),
    actiontype    varchar(255),
    callerid      varchar(255),
    callertype    varchar(255),
    customerid    varchar(255),
    request       text,
    receiveddate  timestamp,
    sentdate      timestamp,
    status        varchar(255),
    vin           varchar(255),
    constraint rczqtrequest_pkey
        primary key (id)
);

create table if not exists rczqtservicefeature
(
    code       varchar(255) not null,
    deleted    integer,
    enddate    timestamp,
    label      varchar(255),
    shortlabel varchar(255),
    startdate  timestamp,
    suspended  integer,
    constraint rczqtservicefeature_pkey
        primary key (code)
);

create table if not exists rczqtactions
(
    code          varchar(255) not null,
    actionservice varchar(255),
    actiontype    varchar(255),
    constraint rczqtservicefeature_fk
        foreign key (code) references rczqtservicefeature
);

create table if not exists rczqtsms
(
    id           bigint not null,
    ackcode      varchar(255),
    ackdate      timestamp,
    reason       varchar(255),
    adm          varchar(255),
    answerstatus varchar(255),
    icp          varchar(255),
    idoffer      varchar(255),
    sendingdate  timestamp,
    uin          varchar(255),
    version      varchar(255),
    constraint rczqtsms_pkey
        primary key (id)
);

create table if not exists rczqtsmsmessages
(
    id      bigint not null,
    format  varchar(255),
    text    varchar(255),
    totype  integer,
    tovalue varchar(255),
    constraint rczqtsms_id
        foreign key (id) references rczqtsms
);

create table if not exists rczqtuserlog
(
    id           bigint not null,
    email        varchar(255),
    entrydate    timestamp,
    log          varchar(4000),
    resourcetype varchar(255),
    userid       varchar(255),
    constraint rczqtuserlog_pkey
        primary key (id)
);

create table if not exists rczqtvehicle
(
    uin                  varchar(255) not null,
    btatype              varchar(255),
    lowpowerinfopayload  text,
    lowpowerinfodate     timestamp,
    lowpowerinfosentdate timestamp,
    msisdn               varchar(255),
    servicestate         boolean,
    servicestatedate     timestamp,
    updatedate           timestamp,
    vehicleinfospayload  text,
    vehicleinfosdate     timestamp,
    vehicleinfossentdate timestamp,
    vehiclestate         boolean,
    vehiclestatedate     timestamp,
    vin                  varchar(255),
    lastsession          bigint,
    lastsource           varchar(255),
    constraint rczqtvehicle_pkey
        primary key (uin)
);

create table if not exists rczqtservicestatehistory
(
    uin          varchar(255) not null,
    state        boolean,
    receiveddate timestamp,
    constraint rczqtvehicleservicestatehistory_fk
        foreign key (uin) references rczqtvehicle
);

create table if not exists rczqtvehstatehistory
(
    uin          varchar(255) not null,
    state        boolean,
    receiveddate timestamp,
    constraint rczqtvehiclevehstatehistory_fk
        foreign key (uin) references rczqtvehicle
);


--------------------------------------------------------
--  INDEX
--------------------------------------------------------
create index ndx_veh_vehsthys on rczqtvehstatehistory(uin);
create index ndx_smsmess_sms on rczqtsmsmessages(id);
create index ndx_veh_veserhys on rczqtservicestatehistory(uin);
create index ndx_action_servicefeature on rczqtactions(code);
create index ndx_log_exchange_id on rczqtlog(exchangeid);
create index ndx_sms_uin on rczqtsms(uin);
create index ndx_exchange_uin on rczqtexchange(uin);
create index ndx_exchange_vin on rczqtexchange(vin);
create index ndx_exchange_correlationid on rczqtexchange(correlationid);
create index ndx_exchange_corrid_status on rczqtexchange(correlationid, status);
create index ndx_exchange_quota on rczqtexchange(callerid, receiveddate);
create index ndx_exchange_duplicate on rczqtexchange(id, callerid, actionservice, actiontype, status);
create index ndx_exchange_callerid on rczqtexchange(callerid);
create index ndx_exchange_quota_action on rczqtexchange(vin,processstatus, callerid, actionservice, actiontype, receiveddate);
create index ndx_exchange_quota_wakeup on rczqtexchange(processstatus, callerid, receiveddate);
create index ndx_exchange_alert on rczqtexchange(responsestatus, receiveddate);
create index ndx_exchange_list on rczqtexchange(receiveddate desc, callertype);
create index ndx_exchange_alert2 on rczqtexchange(receiveddate desc, responsestatus, sentdate);
create index ndx_exchange_timeout on rczqtexchange(receiveddate desc, status);
create index ndx_log_criteria on rczqtlog( logdate, loglevel);
create index ndx_log_date on rczqtlog( logdate);
--------------------------------------------------------
--  DATA
--------------------------------------------------------

Insert into rczqtservicefeature (code,shortlabel,label,suspended,deleted,enddate,startdate) values ('BTA3221234','BTA3221234','BTA3221234','1', '1',to_timestamp('24/11/99 11:11:49,472000000','DD/MM/RR HH24:MI:SSXFF'),to_timestamp('24/11/00 11:11:57,191000000','DD/MM/RR HH24:MI:SSXFF'));

Insert into rczqtactions (code,actionservice,actiontype) values ('BTA3221234','STOLEN','VEHICLE_STATE');
Insert into rczqtactions (code,actionservice,actiontype) values ('BTA3221234','STOLEN','REQUEST_STATE');
Insert into rczqtactions (code,actionservice,actiontype) values ('BTA3221234','REMOTE','VEHICLE_INFO');
Insert into rczqtactions (code,actionservice,actiontype) values ('BTA3221234','STOLEN','STOLEN_VIN');
Insert into rczqtactions (code,actionservice,actiontype) values ('BTA3221234','STOLEN','TRACKING');
Insert into rczqtactions (code,actionservice,actiontype) values ('BTA3221234','STOLEN','IMMOBILIZATION');
Insert into rczqtactions (code,actionservice,actiontype) values ('BTA3221234','STOLEN','IMMO_DATA');
Insert into rczqtactions (code,actionservice,actiontype) values ('BTA3221234','REMOTE','ALARM');
Insert into rczqtactions (code,actionservice,actiontype) values ('BTA3221234','REMOTE','DOORS');
Insert into rczqtactions (code,actionservice,actiontype) values ('BTA3221234','REMOTE','HORN');
Insert into rczqtactions (code,actionservice,actiontype) values ('BTA3221234','REMOTE','LIGHTS');
Insert into rczqtactions (code,actionservice,actiontype) values ('BTA3221234','REMOTE','VEHICLE_STATE');

