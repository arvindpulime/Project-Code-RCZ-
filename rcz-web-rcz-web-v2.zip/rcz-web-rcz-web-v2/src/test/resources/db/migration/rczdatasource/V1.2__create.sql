BEGIN;

ALTER TABLE RCZQTVEHICLE ADD provider VARCHAR(20);
ALTER TABLE RCZQTSMS ADD provider VARCHAR(20);

DROP TABLE rczqtparameter;

create table if not exists rczqtparameter
(
    id                              varchar(255) not null,
    datalength                      integer,
    messagelength                   integer,
    nbretry                         integer,
    retrydelay                      integer,
    dspt                            integer,
    messageid                       integer,
    messageversion                  integer,
    messagetype                     integer,
    servicetype                     integer,
    bytelsmsadm                     varchar(255),
    bytelsmsicp                     varchar(255),
    bytelsmsidoffer                 varchar(255),
    bytelsmsmessageformat           varchar(255),
    bytelsmspath                    varchar(255),
    bytelsmsprotocolversion         varchar(255),
    bytelsmstargettype              varchar(255),
    bytelsmsuri                     varchar(255),
    orangeSmsHost                   varchar(255),
    orangeSmsPath                   varchar(255),
    orangeSmsUsername               varchar(255),
    orangeSmsPassword               varchar(255),
    orangeSmsSenderAddress          varchar(255),
    orangeSmsHeaderHost             varchar(255),
    orangeSmsRequestTimeout         integer,
    orangeSmsConnectionTimeout      integer,
    vehiclerequestmaxduration       integer,
    vehiclerequestmock              boolean,
    vehiclerequestnbretry           integer,
    vehiclerequestpath              varchar(255),
    vehiclerequestretrydelay        integer,
    vehiclerequesturi               varchar(255),
    cvsauthaccess                   boolean,
    cvsendpointurl                  varchar(255),
    cvsmock                         boolean,
    cvsoauthendpointurl             varchar(255),
    automaticvehiclestate           boolean,
    callerdailyquota                integer,
    callerdailyquotadurationmin     integer,
    callerdailyquotaenabled         boolean,
    callerquota                     integer,
    callerquotadurationmin          integer,
    callerquotawarning              integer,
    callerquotawarningdurationmin   integer,
    clientresponsedebug             boolean,
    exchangetimeoutmin              integer,
    hornquota                       integer,
    hornquotadurationmin            integer,
    lightsquota                     integer,
    lightsquotadurationmin          integer,
    openbar                         boolean,
    proxy                           boolean,
    remotealarmid                   varchar(255),
    constraint rczqtparameter_pkey
        primary key (id)
);

COMMIT;