package com.inetpsa.rcz.application.handlers.event;

import com.inetpsa.rcz.domain.model.enums.EventMessage;
import com.inetpsa.rcz.domain.model.enums.ExchangeStatus;
import com.inetpsa.rcz.domain.model.event.ImmoStateReceived;
import com.inetpsa.rcz.domain.model.event.RequestReceived;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.log.Log;
import com.inetpsa.rcz.domain.model.payload.topic.Topic;
import org.assertj.core.api.Assertions;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.List;
import java.util.stream.Collectors;

public class ImmoStateReceivedHandlerTest extends AbstractMqttRequestTest {

    @Before
    public void setUp() throws Exception {

    }

    protected Exchange sendPartnerImmoState(String id) {
        String correlationId = id;
        Topic topic = new Topic("psa/Stolen/from/uid/" + id + "/Immobilization");
        String request = getImmoStateRequest(correlationId, AUTHORIZED_VIN);
        RequestReceived event = new RequestReceived(topic, request);
        Exchange exchange = fireAndWaitForExchange(event, correlationId);
        Assertions.assertThat(exchange).isNotNull();
        return exchange;
    }

    @After
    public void tearDown() throws Exception {

    }


    @Test
    public void ImmoStateRequestWithValidationIssue() {
        Exchange immoExchange = sendPartnerImmoState("ImmoStateRequestWithValidationIssue");
        String correlationId = immoExchange.getCorrelationId();
        Topic topic = new Topic("psa/Stolen/from/uin/mdercz03/ImmoData");
        String btaResponse = getImmoStateVehicleResponse(immoExchange.getId(), "9");
        ImmoStateReceived event = new ImmoStateReceived(topic, btaResponse);
        Exchange exchange = fireAndWaitForExchange(event, correlationId);
        Assertions.assertThat(exchange).isNotNull();
        Assertions.assertThat(exchange.getStatus()).isEqualTo(ExchangeStatus.ERROR);
        List<Log> logs = getLogs(exchange);
        Assertions.assertThat(logs.stream().filter(log ->
                log.getMessage().getData() != null && EventMessage.REQUEST_ERROR.name().equals(log.getMessage().getMessage())).collect(Collectors.toList()))
                .hasSize(1);
    }

    @Test
    public void ImmoStateRequestForwarded() {
        Exchange immoExchange = sendPartnerImmoState("ImmoStateRequestForwarded");
        String correlationId = immoExchange.getCorrelationId();
        Topic topic = new Topic("psa/Stolen/from/uin/mdercz03/ImmoData");
        String btaResponse = getImmoStateVehicleResponse(immoExchange.getId(), "0");
        ImmoStateReceived event = new ImmoStateReceived(topic, btaResponse);
        Exchange exchange = fireAndWaitForExchange(event, correlationId);
        Assertions.assertThat(exchange).isNotNull();
        Assertions.assertThat(exchange.getStatus()).isEqualTo(ExchangeStatus.FINISHED);
        List<Log> logs = getLogs(exchange);
        Assertions.assertThat(logs.stream().filter(log ->
                log.getMessage().getMessage() != null && EventMessage.IMMOBILIZATION_STATE_FORWARDED.name().equals(log.getMessage().getMessage())).collect(Collectors.toList()))
                .hasSize(1);

    }

    protected String getImmoStateRequest(String correlationId, String vin) {
        return "{\n" +
                "\t\"req_date\": \"2016-10-03T11:05:02Z\",\n" +
                "\t\"vin\": \"" + vin + "\",\n" +
                "\t\"customer_id\": \"mdemym00\",\n" +
                "\t\"correlation_id\": \"" + correlationId + "\",\n" +
                "\t\"req_parameters\": {\n" +
                "\t\t\"action\": \"activate\"\n" +
                "\t}\n" +
                "}";
    }

    private String getImmoStateVehicleResponse(String exchangeId, String sevState) {
        return "{\n" +
                "\t\"req_id\": \"" + exchangeId + "\",\n" +
                "\t\"date\": \"2016-10-12T15:00:02Z\",\n" +
                "\t\"immo_state\": 1 ,\n" +
                "\t\"location\": {\n" +
                "\t\t\"dop\": {\n" +
                "\t\t\t\"valid_p\": \"false\",\n" +
                "\t\t\t\"valid_h\": \"false\",\n" +
                "\t\t\t\"valid_v\": \"false\",\n" +
                "\t\t\t\"p\": 99.99,\n" +
                "\t\t\t\"h\": 99.99,\n" +
                "\t\t\t\"v\": 99.99\n" +
                "\t\t},\n" +
                "\t\t\"satellites\": {\n" +
                "\t\t\t\"valid_usd\": \"false\",\n" +
                "\t\t\t\"valid_trk\": \"false\",\n" +
                "\t\t\t\"valid_vis\": \"false\",\n" +
                "\t\t\t\"used\": 0,\n" +
                "\t\t\t\"tracked\": 0,\n" +
                "\t\t\t\"visible\": 0\n" +
                "\t\t},\n" +
                "\t\t\"gnss\": {\n" +
                "\t\t\t\"fix_status\": 0,\n" +
                "\t\t\t\"valid_lat\": \"false\",\n" +
                "\t\t\t\"valid_lng\": \"false\",\n" +
                "\t\t\t\"valid_alt\": \"false\",\n" +
                "\t\t\t\"valid_hdg\": \"false\",\n" +
                "\t\t\t\"valid_spd\": \"false\",\n" +
                "\t\t\t\"valid_err_hps\": \"false\",\n" +
                "\t\t\t\"valid_err_alt\": \"false\",\n" +
                "\t\t\t\"valid_err_spd\": \"false\",\n" +
                "\t\t\t\"latitude\": 0,\n" +
                "\t\t\t\"longitude\": 0,\n" +
                "\t\t\t\"altitude\": 0,\n" +
                "\t\t\t\"heading\": 0,\n" +
                "\t\t\t\"speed\": 0,\n" +
                "\t\t\t\"error_h_position\": 0,\n" +
                "\t\t\t\"error_altitude\": -1,\n" +
                "\t\t\t\"error_v_speed\": -1\n" +
                "\t\t},\n" +
                "\t\t\"dr\": {\n" +
                "\t\t\t\"valid_lat\": \"false\",\n" +
                "\t\t\t\"valid_lng\": \"false\",\n" +
                "\t\t\t\"valid_hdg\": \"false\",\n" +
                "\t\t\t\"valid_spd\": \"false\",\n" +
                "\t\t\t\"latitude\": 0.8471959999999999,\n" +
                "\t\t\t\"longitude\": 0.0436,\n" +
                "\t\t\t\"heading\": 2997,\n" +
                "\t\t\t\"speed\": 0\n" +
                "\t\t}\n" +
                "\t},\n" +
                "\t\"sev_state\": " + sevState + "\n" +
                "}";
    }
}