package com.inetpsa.rcz.application.handlers.event;

import com.fasterxml.jackson.core.type.TypeReference;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.log.Log;
import com.inetpsa.rcz.domain.model.payload.response.ResponsePayload;
import com.inetpsa.rcz.domain.repository.ExchangeRepository;
import com.inetpsa.rcz.domain.repository.LogRepository;
import com.inetpsa.rcz.domain.services.ExchangeService;
import com.inetpsa.rcz.domain.services.ParameterService;
import com.inetpsa.rcz.fixtures.PublishedRczMessageListener;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.seedstack.business.domain.DomainEvent;
import org.seedstack.business.domain.DomainEventPublisher;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.testing.junit4.SeedITRunner;
import org.seedstack.seed.transaction.Transactional;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

@JpaUnit("rcz")
@RunWith(SeedITRunner.class)
public abstract class AbstractMqttRequestTest {

    @Inject
    protected DomainEventPublisher eventPublisher;

    @Inject
    protected ExchangeService exchangeService;

    @Inject
    protected ParameterService parameterService;

    @Before
    public void setUp() throws Exception {
    }

    @Inject
    protected ExchangeRepository exchangeRepository;

    @Inject
    protected LogRepository logRepository;

    protected static final String AUTHORIZED_VIN = "VF3CA5FV8CW100632";
    protected static final String VIN_NOT_VALID = "vinNotValid";


    protected <T> List<ResponsePayload<T>> getResponsePayloads(Exchange exchange, TypeReference<ResponsePayload<T>> typeReference) {
        List<Log> errorLogs = getLogs(exchange);
        Assertions.assertThat(errorLogs).isNotEmpty();
        return getResponsePayloads(errorLogs, typeReference);
    }

    private <T> List<ResponsePayload<T>> getResponsePayloads(List<Log> logs, TypeReference<ResponsePayload<T>> typeReference) {
        List<ResponsePayload<T>> responsePayloads = new ArrayList<>();
        logs.stream().forEach(log -> {
            if (log.getMessage() != null && StringUtils.isNotBlank(log.getMessage().getData())) {
                responsePayloads.add(JsonConverter.convert(log.getMessage().getData(), typeReference));
            }
        });
        return responsePayloads;
    }


    @Transactional
    protected List<Log> getLogs(Exchange exchange) {
        return logRepository.findByExchangeId(exchange.getId());
    }


    protected Exchange fireAndWaitForExchange(DomainEvent event, String correlationId) {
        eventPublisher.publish(event);
        waitForPublish();
        Optional<Exchange> exchange = getByCorrelationId(correlationId);
        Assertions.assertThat(exchange).isNotNull();
        return exchange.get();
    }

    @Transactional
    protected Optional<Exchange> getByCorrelationId(String correlationId) {
        return exchangeRepository.findByCorrelationId(correlationId);
    }

    protected void waitForPublish() {
        try {
            Assertions.assertThat(PublishedRczMessageListener.messageReceivedCount.await(10000, TimeUnit.MILLISECONDS)).isTrue();
        } catch (InterruptedException e) {//NOSONAR
            Assertions.fail(e.getMessage());
        }
    }


}
