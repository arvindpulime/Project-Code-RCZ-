package com.inetpsa.rcz.fixtures;

import com.google.common.collect.Lists;
import io.nuun.kernel.api.plugin.InitState;
import io.nuun.kernel.api.plugin.context.Context;
import io.nuun.kernel.api.plugin.context.InitContext;
import io.nuun.kernel.core.AbstractPlugin;
import org.seedstack.mqtt.internal.MqttPlugin;

import java.util.Collection;


public class BrokerITPlugin extends AbstractPlugin {

    @Override
    public InitState init(InitContext initContext) {
        return InitState.INITIALIZED;
    }

    @Override
    public void start(Context context) {
        BrokerFixture.startBroker();
        super.start(context);
    }

    @Override
    public void stop() {
        BrokerFixture.stopBroker();
        super.stop();
    }

    @Override
    public Collection<Class<?>> dependentPlugins() {
        return Lists.newArrayList(MqttPlugin.class);
    }

    @Override
    public String name() {
        return "BrokerITPlugin";
    }
}
