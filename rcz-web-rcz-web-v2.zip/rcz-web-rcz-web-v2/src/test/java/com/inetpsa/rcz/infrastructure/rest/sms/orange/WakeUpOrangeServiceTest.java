package com.inetpsa.rcz.infrastructure.rest.sms.orange;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.inetpsa.rcz.application.services.WakeUpService;
import com.inetpsa.rcz.application.util.JsonConverter;
import com.inetpsa.rcz.domain.model.sms.Sms;
import com.inetpsa.rcz.domain.model.vehicle.Vehicle;
import com.inetpsa.rcz.domain.services.SmsService;
import com.inetpsa.rcz.infrastructure.rest.sms.WakeUpException;
import org.apache.commons.io.FileUtils;
import org.hamcrest.CoreMatchers;
import org.junit.*;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.testing.junit4.SeedITRunner;
import org.seedstack.seed.transaction.Transactional;

import javax.inject.Inject;
import javax.inject.Named;
import java.io.File;
import java.io.IOException;
import java.util.Objects;
import java.util.Optional;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.wireMockConfig;
import static java.nio.charset.StandardCharsets.UTF_8;

@JpaUnit("rcz")
@RunWith(SeedITRunner.class)
public class WakeUpOrangeServiceTest {

    private static final WireMockServer wireMockServer = new WireMockServer(wireMockConfig().port(8888));
    private static final String RESPONSE_201_PATH = "mocks/sms/orange-response-201.json";
    private static final String RESPONSE_400_PATH = "mocks/sms/orange-response-400.json";
    private static final String REQUEST_PATH_UIN_MDERCZ03 = "mocks/sms/orange-request-uin-mdercz03.json";
    private static final String REQUEST_PATH_UIN_MDERCZ04 = "mocks/sms/orange-request-uin-mdercz04.json";

    @Inject
    @Named("ORANGE")
    private WakeUpService wakeUpService;

    @Inject
    private SmsService smsService;

    @Rule
    public ExpectedException exception = ExpectedException.none();

    @BeforeClass
    public static void beforeClass() {
        wireMockServer.start();
    }

    @AfterClass
    public static void afterClass() {
        wireMockServer.stop();
    }

    @Test
    @Transactional
    public void sendSmsWithSuccessStatus201() throws IOException {

        String mockResponse = file2String(RESPONSE_201_PATH);

        wireMockServer.stubFor(post(urlMatching("/dcpapi/smsmessaging/v1/outbound/.*"))
                .willReturn(
                        aResponse()
                                .withStatus(201)
                                .withHeader("Content-Type", "application/json")
                                .withBody(mockResponse)
                ));

        Vehicle vehicle = JsonConverter.convert(file2String(REQUEST_PATH_UIN_MDERCZ03), Vehicle.class);
        wakeUpService.wakeUp(vehicle);

        Optional<Sms> sms = smsService.findByUin("mdercz03");
        Assert.assertTrue(sms.isPresent());
        Assert.assertEquals(sms.get().getAnswerStatus(), "DeliveredToTerminal");
    }

    @Test
    @Transactional
    public void sendSmsWithFailStatus400() throws IOException, WakeUpException {

        String mockResponse = file2String(RESPONSE_400_PATH);

        wireMockServer.stubFor(post(urlMatching("/dcpapi/smsmessaging/v1/outbound/.*"))
                .willReturn(aResponse()
                        .withStatus(400)
                        .withHeader("Content-Type", "application/json")
                        .withBody(mockResponse)));

        Vehicle vehicle = JsonConverter.convert(file2String(REQUEST_PATH_UIN_MDERCZ04), Vehicle.class);
        wakeUpService.wakeUp(vehicle);

        Optional<Sms> sms = smsService.findByUin("mdercz04");
        Assert.assertTrue(sms.isPresent());
        Assert.assertThat(sms.get().getAnswerStatus(), CoreMatchers.containsString("Message too long"));
    }

    private String file2String(String path) throws IOException {
        return FileUtils.readFileToString(new File(Objects.requireNonNull(getClass().getClassLoader().getResource(path)).getFile()), UTF_8);
    }


}
