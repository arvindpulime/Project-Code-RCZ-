package com.inetpsa.rcz.application.handlers.event;

import com.fasterxml.jackson.core.type.TypeReference;
import com.inetpsa.rcz.application.util.LocalizationKey;
import com.inetpsa.rcz.domain.model.enums.ExchangeStatus;
import com.inetpsa.rcz.domain.model.enums.ProcessStatus;
import com.inetpsa.rcz.domain.model.enums.ResponseStatus;
import com.inetpsa.rcz.domain.model.event.RequestReceived;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.parameter.Parameter;
import com.inetpsa.rcz.domain.model.payload.ValidationPattern;
import com.inetpsa.rcz.domain.model.payload.data.Horn;
import com.inetpsa.rcz.domain.model.payload.response.ResponsePayload;
import com.inetpsa.rcz.domain.model.payload.topic.Topic;
import com.inetpsa.rcz.domain.services.ParameterService;
import org.assertj.core.api.Assertions;
import org.awaitility.Awaitility;
import org.awaitility.Duration;
import org.junit.Before;
import org.junit.Test;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import javax.inject.Inject;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;

@JpaUnit("rcz")
public class RequestEventTest extends AbstractMqttRequestTest {


    public static final String MDEMYM_00 = "mdemym00";
    
    @Inject
    private ParameterService parameterService;

    @Before
    public void before() {
        Parameter parameter = parameterService.get();
        parameterService.update(parameter.setRcz(parameter.getRcz().setClientResponseDebug(true)));
    }

    @Test
    public void hornRequestAcceptedWithAutomaticVehicleState() {
        Parameter parameter = parameterService.get();
        parameterService.update(parameter.setRcz(parameter.getRcz()
                .setAutomaticVehicleState(true)
                .setCallerQuotaWarning(1000)));
        String correlationId = "hornRequestAcceptedWithAutomaticVehicleState";
        String horn = buildHornRequest(correlationId, AUTHORIZED_VIN);
        String topic = "psa/RemoteServices/from/uid/" + correlationId + "/Horn";
        Exchange exchange = fireAndWaitForExchange(new RequestReceived(new Topic(topic), horn), correlationId);
        Assertions.assertThat(exchange.getProcessStatus()).isEqualTo(ProcessStatus.REQUEST_SENT_TO_BTA);
    }

    @Test
    public void VehicleStateRequestFinishedWithAutomaticVehicleState() {
        Parameter parameter = parameterService.get();
        parameterService.update(parameter.setRcz(parameter.getRcz().setAutomaticVehicleState(true)));
        String correlationId = "VehicleStateRequestFinished";
        String vehicleState = buildVehicleStateRequest(correlationId, AUTHORIZED_VIN);
        String topic = "psa/Stolen/from/uid/" + correlationId + "/VehicleState";
        Exchange exchange = fireAndWaitForExchange(new RequestReceived(new Topic(topic), vehicleState), correlationId);
        Assertions.assertThat(exchange.getStatus()).isEqualTo(ExchangeStatus.FINISHED);
    }

    @Test
    public void hornRequestNotValid() {
        Parameter parameter = parameterService.get();
        parameterService.update(parameter.setRcz(parameter.getRcz().setAutomaticVehicleState(true)));
        String correlationId = "hornRequestNotValid";
        String horn = buildHornRequest(correlationId, VIN_NOT_VALID);
        String topic = "psa/RemoteServices/from/uid/" + correlationId + "/Horn";
        Exchange exchange = fireAndWaitForExchange(new RequestReceived(new Topic(topic), horn), correlationId);
        Assertions.assertThat(exchange.getResponseStatus()).isEqualTo(ResponseStatus.BAD_REQUEST);
    }

    @Test
    public void hornRequestAcceptedWithoutAutomaticVehicleState() {
        Parameter parameter = parameterService.get();
        parameterService.update(parameter.setRcz(parameter.getRcz().setAutomaticVehicleState(false)));
        String correlationId = "hornRequestAcceptedWithoutAutomaticVehicleState";
        String horn = buildHornRequest(correlationId, AUTHORIZED_VIN);
        String topic = "psa/RemoteServices/from/uid/" + correlationId + "/Horn";
        Exchange exchange = fireAndWaitForExchange(new RequestReceived(new Topic(topic), horn), correlationId);
        Assertions.assertThat(exchange.getProcessStatus()).isEqualTo(ProcessStatus.PSA_VEH_STATE_REQUEST);
    }

    @Test
    public void hornRequestWithDuplicateCorrelationId() {
        String correlationId = "hornRequestWithDuplicateCorrelationId";
        String horn = buildHornRequest(correlationId, AUTHORIZED_VIN);
        String callerId = MDEMYM_00;
        String topic = "psa/RemoteServices/from/uid/" + callerId + "/Horn";
        fireAndWaitForExchange(new RequestReceived(new Topic(topic), horn), correlationId);
        Exchange exchange = fireAndWaitForExchange(new RequestReceived(new Topic(topic), horn), correlationId);
        Assertions.assertThat(exchange.getCorrelationId()).isEqualTo(correlationId);
        List<Exchange> exchanges = getByCallerId(callerId);
        Assertions.assertThat(exchanges).isNotEmpty();
        List<Exchange> collectedExchanges = exchanges.stream().filter(exchange1 -> exchange1.getCorrelationId() == null && ResponseStatus.REQUEST_ERROR.equals(exchange1.getResponseStatus())).collect(Collectors.toList());
        Assertions.assertThat(collectedExchanges).hasSize(1);
        Exchange exchangeWithDuplicateCorrelation = collectedExchanges.iterator().next();
        List<ResponsePayload<Horn>> responsePayloads = getResponsePayloads(exchangeWithDuplicateCorrelation, new TypeReference<ResponsePayload<Horn>>() {
        });
        Assertions.assertThat(responsePayloads.stream().filter(hornResponsePayload ->
                hornResponsePayload.getReason() != null &&
                        hornResponsePayload.getReason().contains(LocalizationKey.REQUEST_ERROR_CORRELATION_ID_ERROR_MESSAGE_KEY)
        ).collect(Collectors.toList())).hasSize(1);
    }

    @Test
    public void hornRequestWithDuplicate() {
        Parameter parameter = parameterService.get();
        parameterService.update(parameter.setRcz(parameter.getRcz()
                .setAutomaticVehicleState(true)
                .setHornQuota(3)
                .setCallerQuota(100)
                .setCallerDailyQuota(100)));
        String correlationId = "hornRequestOk";
        String callerId = MDEMYM_00;
        String correlationIdForDuplicate = "hornRequestWithDuplicate";
        String horn = buildHornRequest(correlationId, AUTHORIZED_VIN);
        String hornForDuplicate = buildHornRequest(correlationIdForDuplicate, AUTHORIZED_VIN);
        String topic = "psa/RemoteServices/from/uid/" + callerId + "/Horn";
        Exchange exchange = fireAndWaitForExchange(new RequestReceived(new Topic(topic), horn), correlationId);
        Exchange exchangeDuplicate = fireAndWaitForExchange(new RequestReceived(new Topic(topic), hornForDuplicate), correlationIdForDuplicate);
        Assertions.assertThat(exchangeDuplicate.getResponseStatus()).isEqualTo(ResponseStatus.DUPLICATE);
        Assertions.assertThat(exchangeDuplicate.getCorrelationId()).isEqualTo(correlationIdForDuplicate);
        List<ResponsePayload<Horn>> responsePayloads = getResponsePayloads(getByCorrelationId(correlationIdForDuplicate).get(), new TypeReference<ResponsePayload<Horn>>() {
        });
        Assertions.assertThat(responsePayloads.stream().filter(hornResponsePayload ->
                hornResponsePayload.getReason() != null &&
                        hornResponsePayload.getReason().contains(LocalizationKey.DUPLICATE_MESSAGE_KEY)
        ).collect(Collectors.toList())).hasSize(1);
    }

    @Test
    public void hornQuotaExceededTest() {
        Parameter parameter = parameterService.get();
        parameterService.update(parameter.setRcz(parameter.getRcz()
                .setAutomaticVehicleState(true)
                .setHornQuota(1)
                .setCallerQuota(100)
                .setCallerDailyQuota(100)));
        String correlationId = "hornQuotaExceededTest0";
        String callerId = MDEMYM_00;
        String correlationIdForQuota1 = "hornQuotaExceededTest1";
        String correlationIdForQuota2 = "hornQuotaExceededTest2";

        String horn = buildHornRequest(correlationId, AUTHORIZED_VIN);
        String hornForQuota1 = buildHornRequest(correlationIdForQuota1, AUTHORIZED_VIN);

        String hornForQuota2 = buildHornRequest(correlationIdForQuota2, AUTHORIZED_VIN);
        String topic = "psa/RemoteServices/from/uid/" + callerId + "/Horn";
        Exchange exchange = fireAndWaitForExchange(new RequestReceived(new Topic(topic), horn), correlationId);
        updateExchangeStatus(exchange, ExchangeStatus.ERROR);
        updateExchangeStatus(fireAndWaitForExchange(new RequestReceived(new Topic(topic), hornForQuota1), correlationIdForQuota1), ExchangeStatus.ERROR);
        Exchange exchangeDuplicate = fireAndWaitForExchange(new RequestReceived(new Topic(topic), hornForQuota2), correlationIdForQuota2);
        Assertions.assertThat(exchangeDuplicate.getResponseStatus()).isEqualTo(ResponseStatus.HORN_QUOTA_EXCEEDED);
        Assertions.assertThat(exchangeDuplicate.getCorrelationId()).isEqualTo(correlationIdForQuota2);
        List<ResponsePayload<Horn>> responsePayloads = getResponsePayloads(exchangeDuplicate, new TypeReference<ResponsePayload<Horn>>() {
        });
        Assertions.assertThat(responsePayloads.stream().filter(hornResponsePayload ->
                hornResponsePayload.getReason() != null &&
                        hornResponsePayload.getReason().contains(LocalizationKey.HORN_QUOTA_MESSAGE_KEY)
        ).collect(Collectors.toList())).hasSize(1);
    }

    private void waitForExchangeProcessStatus(String id, ProcessStatus processStatus) {
        Awaitility.await().atMost(Duration.TWO_SECONDS).untilTrue(new AtomicBoolean(processStatus.equals(exchangeRepository.get(id).get().getProcessStatus())));
    }

    private void waitForResponseStatus(String id, ResponseStatus responseStatus) {
        Awaitility.await().atMost(Duration.FIVE_SECONDS).untilTrue(new AtomicBoolean(responseStatus.equals(exchangeRepository.get(id).get().getResponseStatus())));
    }

    @Test
    public void lightsQuotaExceededTest() {
        Parameter parameter = parameterService.get();
        parameterService.update(parameter.setRcz(parameter.getRcz().setAutomaticVehicleState(true)
                .setLightsQuota(1)
                .setCallerQuota(100)
                .setLightsQuotaDurationMin(100)));

        String correlationId = "lightsQuotaExceededTest0";
        String callerId = MDEMYM_00;
        String correlationIdForQuota1 = "lightsQuotaExceededTest1";
        String correlationIdForQuota2 = "lightsQuotaExceededTest2";
        String lights = buildLightsRequest(correlationId, AUTHORIZED_VIN);
        String lightsForDuplicate1 = buildLightsRequest(correlationIdForQuota1, AUTHORIZED_VIN);
        String lightsForDuplicate2 = buildLightsRequest(correlationIdForQuota2, AUTHORIZED_VIN);
        String topic = "psa/RemoteServices/from/uid/" + callerId + "/Lights";
        Exchange exchange = fireAndWaitForExchange(new RequestReceived(new Topic(topic), lights), correlationId);
        updateExchangeStatus(exchange, ExchangeStatus.ERROR);
        updateExchangeStatus(fireAndWaitForExchange(new RequestReceived(new Topic(topic), lightsForDuplicate1), correlationIdForQuota1), ExchangeStatus.ERROR);
        Exchange exchangeDuplicate = fireAndWaitForExchange(new RequestReceived(new Topic(topic), lightsForDuplicate2), correlationIdForQuota2);
        Assertions.assertThat(exchangeDuplicate.getResponseStatus()).isEqualTo(ResponseStatus.LIGHTS_QUOTA_EXCEEDED);
        Assertions.assertThat(exchangeDuplicate.getCorrelationId()).isEqualTo(correlationIdForQuota2);
        List<ResponsePayload<Horn>> responsePayloads = getResponsePayloads(exchangeDuplicate, new TypeReference<ResponsePayload<Horn>>() {
        });
        Assertions.assertThat(responsePayloads.stream().filter(hornResponsePayload ->
                hornResponsePayload.getReason() != null &&
                        hornResponsePayload.getReason().contains(LocalizationKey.LIGHTS_QUOTA_MESSAGE_KEY)
        ).collect(Collectors.toList())).hasSize(1);
    }

    @Transactional
    protected void updateExchangeStatus(Exchange exchange, ExchangeStatus status) {
        exchange.setStatus(status);
        exchangeRepository.update(exchange);
    }

    @Transactional
    protected List<Exchange> getByCallerId(String callerId) {
        return exchangeRepository.findByCallerId(callerId);
    }

    protected String buildHornRequest(String correlationId, String vin) {
        return "{\n" +
                "\t\"req_date\": \"" + getDateUtc() + "\",\n" +
                "\t\"vin\": \"" + vin + "\",\n" +
                "\t\"customer_id\": \"" + MDEMYM_00 + "\",\n" +
                "\t\"req_parameters\": {\n" +
                "\t\t\"action\": \"activate\",\n" +
                "\t\t\"nb_horn\": 5\n" +
                "\t},\n" +
                "\t\"correlation_id\": \"" + correlationId + "\"\n" +
                "}";
    }

    private String getDateUtc() {
        String oldPattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(oldPattern);
        Date oldDate = null;
        try {
            oldDate = simpleDateFormat.parse(Instant.now().toString());
            simpleDateFormat.applyPattern(ValidationPattern.PATTERN_DATE);
            return simpleDateFormat.format(oldDate);
        } catch (ParseException e) {
            return null;
        }
    }


    protected String buildVehicleStateRequest(String correlationId, String vin) {

        return "{\n" +
                "\t\"req_date\": \"" + getDateUtc() + "\",\n" +
                "\t\"vin\": \"" + vin + "\",\n" +
                "\t\"customer_id\": \"" + MDEMYM_00 + "\",\n" +
                "\t\"req_parameters\": {\n" +
                "\t\t\"action\": \"state\"\n" +
                "\t},\n" +
                "\t\"correlation_id\": \"" + correlationId + "\"\n" +
                "}";
    }

    protected String buildLightsRequest(String correlationId, String vin) {
        return "{\n" +
                "\t\"req_date\": \"" + getDateUtc() + "\",\n" +
                "\t\"vin\": \"" + vin + "\",\n" +
                "\t\"customer_id\": \"" + MDEMYM_00 + "\",\n" +
                "\t\"req_parameters\": {\n" +
                "\t\t\"action\": \"activate\",\n" +
                "\t\t\"duration\": 45\n" +
                "\t},\n" +
                "\t\"correlation_id\": \"" + correlationId + "\"\n" +
                "}";
    }

}