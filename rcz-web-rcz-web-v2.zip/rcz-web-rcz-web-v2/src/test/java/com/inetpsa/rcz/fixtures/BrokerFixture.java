package com.inetpsa.rcz.fixtures;

import io.moquette.server.Server;
import org.assertj.core.api.Assertions;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;

public class BrokerFixture {


    private static final Server server1 = new Server();
    private static final Server server2 = new Server();


    public static void startBroker() {
        startServer(server1, "/configMqttServer1.props");
        startServer(server2, "/configMqttServer2.props");
    }

    private static void startServer(Server server, String configFile) {
        final File c;
        try {
            c = new File(BrokerFixture.class.getResource(configFile).toURI());
            server.startServer(c);
        } catch (URISyntaxException | IOException e) {//NOSONAR
            Assertions.fail(e.getMessage(), e);
        }
    }

    public static void stopBroker() {
        server1.stopServer();
        server2.stopServer();
    }
}
