package com.inetpsa.rcz.infrastructure.rest.cvs;

import com.inetpsa.rcz.application.configuration.RczConfig;
import com.inetpsa.rcz.application.exceptions.AuthorizationException;
import com.inetpsa.rcz.application.representation.request.BTARightsRequest;
import com.inetpsa.rcz.application.representation.request.BTAServicesRequestLean;
import com.inetpsa.rcz.application.representation.request.ConsumerServicesRequestLean;
import com.inetpsa.rcz.application.representation.request.PartnerRightsRequest;
import com.inetpsa.rcz.application.representation.response.*;
import com.inetpsa.rcz.application.services.cvs.CVSService;
import com.inetpsa.rcz.domain.model.parameter.Parameter;
import com.inetpsa.rcz.domain.services.ParameterService;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.testing.junit4.SeedITRunner;
import org.seedstack.seed.undertow.LaunchWithUndertow;

import javax.inject.Inject;
import javax.inject.Named;

/**
 * @author tuan.docao@ext.mpsa.com
 */
@LaunchWithUndertow
@RunWith(SeedITRunner.class)
public class CVSServiceTest {

    public static final String RUNTIME_WEB_BASE_URL = "runtime.web.baseUrl";
    @Configuration(RUNTIME_WEB_BASE_URL)
    private String baseURL;

    @Inject
    @Named("rest")
    private CVSService cvsService;

    @Inject
    private ParameterService parameterService;

    @Configuration
    private RczConfig rczConfig;


    @Before
    public void setUp() throws Exception {
        Parameter parameter = parameterService.get();
        parameter.getCvs().setCvsEndpointUrl(baseURL);
        parameter.getCvs().setCvsOauthEndpointUrl(baseURL);
        parameterService.update(parameter);
        rczConfig.getCvs().setUsername("demo");
        rczConfig.getCvs().setPassword("dev");
    }

    @Test
    public void testGetConsumerServices() throws NoSuchFieldException, IllegalAccessException, AuthorizationException {
        ConsumerServicesRequestLean consumerServicesRequestLean = new ConsumerServicesRequestLean();
        consumerServicesRequestLean.setVin("VF3CA5FV8CW100632");
        ConsumerServicesLean consumerServices = cvsService.getConsumerServices(consumerServicesRequestLean);
        Assertions.assertThat(consumerServices).isNotNull();
    }

    @Test
    public void testGetOAuthConsumerServices() throws NoSuchFieldException, IllegalAccessException, AuthorizationException {
        ConsumerServicesRequestLean consumerServicesRequestLean = new ConsumerServicesRequestLean();
        consumerServicesRequestLean.setToken("ef7a7628-06ab-47bb-a110-b058270b6c80");
        OAuthConsumerServiceLean consumerServices = cvsService.getOAuthConsumerServices(consumerServicesRequestLean);
        Assertions.assertThat(consumerServices).isNotNull();
    }

    @Test
    public void testGetBTAServices() throws NoSuchFieldException, IllegalAccessException, AuthorizationException {
        BTAServicesRequestLean btaServicesRequestLean = new BTAServicesRequestLean();
        btaServicesRequestLean.setUin("mdercz03");
        BTAServicesLean btaServices = cvsService.getBTAServices(btaServicesRequestLean);
        Assertions.assertThat(btaServices).isNotNull();
    }

    @Test
    public void testGetPartnerRights() throws NoSuchFieldException, IllegalAccessException, AuthorizationException {
        PartnerRightsRequest partnerRightsRequest = new PartnerRightsRequest();
        partnerRightsRequest.setEventId("90e527b4-8cd9-4d12-a9cf-1992db8b5e85");
        partnerRightsRequest.setVin("VF3CA5FV8CW100632");
        partnerRightsRequest.setPartnerId("mdemym00");
        PartnerRights partnerServices = cvsService.getPartnerServices(partnerRightsRequest);
        Assertions.assertThat(partnerServices).isNotNull();
    }

    @Test
    public void testPostBTARights() throws NoSuchFieldException, IllegalAccessException, AuthorizationException {
        BTARightsRequest btaRightsRequest = new BTARightsRequest();
        btaRightsRequest.setServiceCode("serviceCode");
        btaRightsRequest.setUin("mdercz00");
        BTARights btaRights = cvsService.postBTARights(btaRightsRequest);
        Assertions.assertThat(btaRights).isNotNull();
    }

}