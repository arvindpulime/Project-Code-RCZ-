/*
 * Creation : 25 juil. 2016
 */
package com.inetpsa.rcz.requests;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.inetpsa.rcz.domain.model.payload.data.Lights;
import com.inetpsa.rcz.domain.model.payload.request.RequestPayload;
import org.assertj.core.api.Assertions;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.testing.junit4.SeedITRunner;
import javax.inject.Inject;
import javax.validation.ConstraintViolation;
import javax.validation.ValidatorFactory;
import java.io.IOException;
import java.util.Set;

@RunWith(SeedITRunner.class)
public class LightsTest {

    private final ObjectMapper mapper = new ObjectMapper();

    private Set<ConstraintViolation<RequestPayload<Lights>>> violations = null;

    private static final String LIGHTS_VALID_REQUEST = "{\"req_date\": \"2016-07-07T10:30:00Z\",\n" + "\"vin\" : \"VF3CA5FV8CW100632\",\n"
            + "\"customer_id\" : \"987654\",\n" + "\"correlation_id\": \"ac8d1c2ccd8311e4341a1681e6b88ec1\",\n"
            + "\"req_parameters\":{\"duration\": 5, \"action\": \"activate\"}\n" + "}";

    private static final String LIGHTS_INVALID_NESTED_OBJECT = "{\"req_date\": \"2016-07-07T10:30:00Z\",\n" + "\"vin\" : \"VF3CA5FV8CW100632\",\n"
            + "\"customer_id\" : \"987654\",\n" + "\"correlation_id\": \"ac8d1c2ccd8311e4341a1681e6b88ec1\",\n"
            + "\"req_parameters\":{\"duration\": 123, \"action\": \"activate\"}\n" + "}";

    private static final String LIGHTS_MISSING_NESTED_OBJECT = "{\"req_date\": \"2016-07-07T10:30:00Z\",\n" + "\"vin\" : \"VF3CA5FV8CW100632\",\n"
            + "\"customer_id\" : \"987654\",\n" + "\"correlation_id\": \"ac8d1c2ccd8311e4341a1681e6b88ec1\"\n" + "}";

    @Inject
    private ValidatorFactory validatorFactory;

    @Test
    public void testMapperOk() throws IOException {
        RequestPayload<Lights> payload = mapper.readValue(LIGHTS_VALID_REQUEST, new TypeReference<RequestPayload<Lights>>() {
        });
        Set<ConstraintViolation<RequestPayload<Lights>>> violations = validatorFactory.getValidator().validate(payload);
        Assertions.assertThat(violations.isEmpty()).isTrue();
    }

    @Test
    public void testFailedValidation() {
        RequestPayload<Lights> request = new RequestPayload<>();
        Lights light = new Lights();
        light.setAction("activate");
        light.setDuration(122);
        request.setRequestParameters(light);
        violations = validatorFactory.getValidator().validate(request);
        Assertions.assertThat(violations).hasSize(5);
    }

    @Test
    public void testNestedObjectInvalid() throws IOException {
        RequestPayload<Lights> payload = mapper.readValue(LIGHTS_INVALID_NESTED_OBJECT, new TypeReference<RequestPayload<Lights>>() {
        });
        violations = validatorFactory.getValidator().validate(payload);
        Assertions.assertThat(violations).hasSize(1);
    }

    @Test
    @Ignore
    public void testMandatoryNestedObjectNull() throws IOException {
        RequestPayload<Lights> payload = mapper.readValue(LIGHTS_MISSING_NESTED_OBJECT, new TypeReference<RequestPayload<Lights>>() {
        });
        violations = validatorFactory.getValidator().validate(payload);
        Assertions.assertThat(violations).hasSize(1);
    }

}
