ALTER TABLE "RCZQTVEHICLE" ADD "SERVICESTATEDATE" TIMESTAMP (6) DEFAULT CURRENT_TIMESTAMP (6);
ALTER TABLE "RCZQTVEHICLE" ADD "SERVICESTATE" NUMBER(1,0) DEFAULT 0;
ALTER TABLE "RCZQTVEHSTATEHISTORY" RENAME COLUMN "VEHICLESTATE" TO "STATE";

CREATE TABLE "RCZQTSERVICESTATEHISTORY"
 (	"UIN" VARCHAR2(255 CHAR),
    "RECEIVEDDATE" TIMESTAMP (6),
    "STATE" NUMBER(1,0)
 ) TABLESPACE "RCZQDDA1";

--------------------------------------------------------
--  CONSTRAINTS FOR TABLE RCZQTVEHSTATEHISTORY
--------------------------------------------------------

ALTER TABLE "RCZQTSERVICESTATEHISTORY" MODIFY ("RECEIVEDDATE" NOT NULL ENABLE);
ALTER TABLE "RCZQTSERVICESTATEHISTORY" MODIFY ("UIN" NOT NULL ENABLE);
ALTER TABLE "RCZQTSERVICESTATEHISTORY" ADD CONSTRAINT "FK_VEH_VESERHYS" FOREIGN KEY ("UIN") REFERENCES "RCZQTVEHICLE" ("UIN") ENABLE;


--------------------------------------------------------
--  CONSTRAINTS FOR TABLE RCZQTVEHSTATEHISTORY
--------------------------------------------------------

Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('APP_CALLER_DAILY_QUOTA','parameters.app.caller.daily.quota.description.key','3','APPLICATION','parameters.app.caller.daily.quota.label.key');
Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('APP_CALLER_DAILY_QUOTA_DURATION_MIN','parameters.app.caller.daily.quota.duration.min.description.key','1','APPLICATION','parameters.app.caller.daily.quota.duration.min.label.key');
Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('APP_CLIENT_RESPONSE_DEBUG','parameters.app.client.response.debug.description.key','false','APPLICATION','parameters.app.client.response.debug.label.key');

