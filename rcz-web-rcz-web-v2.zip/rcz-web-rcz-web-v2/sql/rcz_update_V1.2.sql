Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('COMMODORE_VEHICLE_REQUEST_URI','parameters.commodore.vehicle.request.uri.description.key','http://localhost:8888','COMMODORE','parameters.commodore.vehicle.request.uri.label.key');
Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('COMMODORE_VEHICLE_REQUEST_PATH','parameters.commodore.vehicle.request.path.description.key','/api/rczref/vehicle','COMMODORE','parameters.commodore.vehicle.request.path.label.key');
Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('COMMODORE_VEHICLE_REQUEST_NB_RETRY','parameters.commodore.vehicle.request.nb.retry.description.key','3','COMMODORE','parameters.commodore.vehicle.request.nb.retry.label.key');
Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('COMMODORE_VEHICLE_REQUEST_RETRY_DELAY','parameters.commodore.vehicle.request.retry.delay.description.key','1000','COMMODORE','parameters.commodore.vehicle.request.retry.delay.label.key');
Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('COMMODORE_MOCK','parameters.commodore.vehicle.request.cvsMock.description.key','false','COMMODORE','parameters.commodore.vehicle.request.cvsMock.label.key');
Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('COMMODORE_VEHICLE_REQUEST_MAX_DURATION','parameters.commodore.vehicle.request.max.duration.description.key','1000','COMMODORE','parameters.commodore.vehicle.request.max.duration.label.key');

Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('commodore.vehicle.request.error','Commodore vehicle request error','0');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('commodore.vehicle.request.error','en','0','0','Vehicle Request failed, error [{0}] for uin [{1}]');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('commodore.vehicle.request.error','commodore.vehicle.request.error','en');

DELETE FROM RCZQTPARAMETER WHERE KEY='APP_PROXY_HOST';
DELETE FROM RCZQTPARAMETER WHERE KEY='APP_PROXY_USERNAME';
DELETE FROM RCZQTPARAMETER WHERE KEY='APP_PROXY_PASSWORD';
DELETE FROM RCZQTPARAMETER WHERE KEY='CVS_USERNAME';
DELETE FROM RCZQTPARAMETER WHERE KEY='CVS_PASSWORD';