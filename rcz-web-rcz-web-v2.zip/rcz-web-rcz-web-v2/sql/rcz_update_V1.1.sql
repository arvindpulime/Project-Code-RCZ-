Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('CVS_OAUTH_ACCESS','parameters.cvs.auth.access.description.key','true','CVS','parameters.cvs.auth.access.label.key');
Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('CVS_OAUTH_ENDPOINT_URL','parameters.cvs.oauth.endpoint.url.description.key','http://localhost:80/cvs','CVS','parameters.cvs.oauth.endpoint.url.label.key');
Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('BYTEL_SMS_MESSAGE_FORMAT','parameters.bytel.sms.message.format.description.key','B','CVS','parameters.bytel.sms.message.format.label.key');
Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('BYTEL_SMS_MESSAGE_LENGTH','parameters.bytel.sms.message.length.description.key','48','CVS','parameters.bytel.sms.message.length.label.key');

