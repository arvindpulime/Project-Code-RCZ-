Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('APP_OPEN_BAR','parameters.app.open.bar.description.key','false','APPLICATION','parameters.app.open.bar.label.key');

commit;