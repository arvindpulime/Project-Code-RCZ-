--------------------------------------------------------
----------------------- RCZ ----------------------------
--------------------------------------------------------
--------------------------------------------------------

   --------------------------------------------------------
--  DDL for Table RCZQTOPTIONALSERVICE
--------------------------------------------------------

  CREATE TABLE "RCZQTOPTIONALSERVICE"
   (	"CODE" VARCHAR2(255 CHAR),
	"LABEL" VARCHAR2(255 CHAR)
   ) TABLESPACE "RCZQDDA1" ;

--------------------------------------------------------
--  DDL for Table RCZQTLOG
--------------------------------------------------------

  CREATE TABLE "RCZQTLOG"
   (	"ID" NUMBER(19,0),
	"EXCHANGEID" VARCHAR2(255 CHAR),
	"INSTANCEID" VARCHAR2(255 CHAR),
	"LOGDATE" TIMESTAMP (6),
	"LOGLEVEL" VARCHAR2(255 CHAR),
	"DATA" VARCHAR2(4000 CHAR),
	"MESSAGE" VARCHAR2(255 CHAR),
	"TOPIC" VARCHAR2(255 CHAR)
   ) TABLESPACE "RCZQDDA1" ;
--------------------------------------------------------
--  DDL for Table RCZQTSMS
--------------------------------------------------------

  CREATE TABLE "RCZQTSMS"
   (	"ID" NUMBER(19,0),
	"ACKCODE" VARCHAR2(255 CHAR),
	"REASON" VARCHAR2(255 CHAR),
	"ADM" VARCHAR2(255 CHAR),
	"ANSWERSTATUS" VARCHAR2(255 CHAR),
	"ICP" VARCHAR2(255 CHAR),
	"IDOFFER" VARCHAR2(255 CHAR),
	"SENDINGDATE" TIMESTAMP (6),
	"UIN" VARCHAR2(255 CHAR),
	"VERSION" VARCHAR2(255 CHAR)
   ) TABLESPACE "RCZQDDA1" ;

--------------------------------------------------------
--  DDL for Table RCZQTVEHSTATEHISTORY
--------------------------------------------------------

  CREATE TABLE "RCZQTVEHSTATEHISTORY"
   (	"UIN" VARCHAR2(255 CHAR),
	"RECEIVEDDATE" TIMESTAMP (6),
	"VEHICLESTATE" NUMBER(1,0)
   ) TABLESPACE "RCZQDDA1" ;


--------------------------------------------------------
--  DDL for Table RCZQTSMSMESSAGES
--------------------------------------------------------

  CREATE TABLE "RCZQTSMSMESSAGES"
   (	"ID" NUMBER(19,0),
	"FORMAT" VARCHAR2(255 CHAR),
	"TEXT" VARCHAR2(255 CHAR),
	"TOTYPE" NUMBER(10,0),
	"TOVALUE" VARCHAR2(255 CHAR)
   ) TABLESPACE "RCZQDDA1" ;
--------------------------------------------------------
--  DDL for Table RCZQTVEHICLE
--------------------------------------------------------

  CREATE TABLE "RCZQTVEHICLE"
   (	"UIN" VARCHAR2(255 CHAR),
	"BTATYPE" VARCHAR2(255 CHAR),
	"VEHICLESTATEDATE" TIMESTAMP (6),
	"VEHICLESTATE" NUMBER(1,0),
	"MSISDN" VARCHAR2(255 CHAR),
	"VEHICLEINFOSPAYLOAD" VARCHAR2(4000 CHAR),
	"VEHICLEINFOSDATE" TIMESTAMP (6),
	"VIN" VARCHAR2(255 CHAR)
   ) TABLESPACE "RCZQDDA1" ;
--------------------------------------------------------
--  DDL for Table RCZQTPARAMETER
--------------------------------------------------------

  CREATE TABLE "RCZQTPARAMETER"
   (	"KEY" VARCHAR2(255 CHAR),
	"DESCRIPTION" VARCHAR2(1024 CHAR),
	"VALUE" VARCHAR2(255 CHAR),
	"CATEGORY" VARCHAR2(255 CHAR),
	"LABEL" VARCHAR2(255 CHAR)
   ) TABLESPACE "RCZQDDA1" ;
--------------------------------------------------------
--  DDL for Table RCZQTACTIONS
--------------------------------------------------------

  CREATE TABLE "RCZQTACTIONS"
   (	"CODE" VARCHAR2(255 CHAR),
	"ACTIONSERVICE" VARCHAR2(255 CHAR),
	"ACTIONTYPE" VARCHAR2(255 CHAR)
   ) TABLESPACE "RCZQDDA1" ;
--------------------------------------------------------
--  DDL for Table RCZQTELEMENTARYSERVICE
--------------------------------------------------------

  CREATE TABLE "RCZQTELEMENTARYSERVICE"
   (	"CODE" VARCHAR2(255 CHAR),
	"LABEL" VARCHAR2(255 CHAR),
	"VALID" NUMBER(1,0) DEFAULT 0,
	"ACTIVE" NUMBER(1,0),
	"ENDVALIDITYDATE" TIMESTAMP (6),
	"STARTVALIDITYDATE" TIMESTAMP (6)
   ) TABLESPACE "RCZQDDA1" ;
--------------------------------------------------------
--  DDL for Table RCZQTSELLABLESERVICE
--------------------------------------------------------

  CREATE TABLE "RCZQTSELLABLESERVICE"
   (	"CODE" VARCHAR2(255 CHAR),
	"LABEL" VARCHAR2(255 CHAR)
   ) TABLESPACE "RCZQDDA1" ;
--------------------------------------------------------
--  DDL for Table RCZQTUSERLOG
--------------------------------------------------------

  CREATE TABLE "RCZQTUSERLOG"
   (	"ID" NUMBER(19,0),
	"EMAIL" VARCHAR2(255 CHAR),
	"ENTRYDATE" TIMESTAMP (6),
	"LOG" VARCHAR2(4000 CHAR),
	"RESOURCETYPE" VARCHAR2(255 CHAR),
	"USERID" VARCHAR2(255 CHAR)
   ) TABLESPACE "RCZQDDA1" ;
--------------------------------------------------------
--  DDL for Table RCZQTEXCHANGE
--------------------------------------------------------

  CREATE TABLE "RCZQTEXCHANGE"
   (	"ID" VARCHAR2(255 CHAR),
	"ACTIONSERVICE" VARCHAR2(255 CHAR),
	"ACTIONTYPE" VARCHAR2(255 CHAR),
	"CALLERID" VARCHAR2(255 CHAR),
	"CALLERTYPE" VARCHAR2(255 CHAR),
	"CORRELATIONID" VARCHAR2(255 CHAR),
	"PROCESSSTATUS" VARCHAR2(255 CHAR),
	"REQUEST" VARCHAR2(4000 CHAR),
	"RECEIVEDDATE" TIMESTAMP (6),
	"RESPONSESTATUS" VARCHAR2(255 CHAR),
	"STATUS" VARCHAR2(255 CHAR),
	"TOPIC" VARCHAR2(255 CHAR),
	"UIN" VARCHAR2(255 CHAR),
	"VIN" VARCHAR2(255 CHAR)
   ) TABLESPACE "RCZQDDA1" ;

--------------------------------------------------------
--  DDL for Table RCZQTHELPER
--------------------------------------------------------

  CREATE TABLE "RCZQTHELPER"
   (	"ID" NUMBER(19,0),
	"CONTENT" CLOB,
	"CREATEDATE" TIMESTAMP (6),
	"TITLE" VARCHAR2(255 CHAR)
   ) TABLESPACE "RCZQDDA1";



--------------------------------------------------------
--  DDL for Index IDX_OPTIONALSERVICE_CODE
--------------------------------------------------------

  CREATE UNIQUE INDEX "IDX_OPTIONALSERVICE_CODE" ON "RCZQTOPTIONALSERVICE" ("CODE")
  TABLESPACE "RCZQDIX1" ;

--------------------------------------------------------
--  DDL for Index IDX_LOG_ID
--------------------------------------------------------

  CREATE UNIQUE INDEX "IDX_LOG_ID" ON "RCZQTLOG" ("ID")
  TABLESPACE "RCZQDIX1" ;
--------------------------------------------------------
--  DDL for Index IDX_SMS_ID
--------------------------------------------------------

  CREATE UNIQUE INDEX "IDX_SMS_ID" ON "RCZQTSMS" ("ID")
  TABLESPACE "RCZQDIX1" ;

--------------------------------------------------------
--  DDL for Index IDX_VEHICLE_UIN
--------------------------------------------------------

  CREATE UNIQUE INDEX "IDX_VEHICLE_UIN" ON "RCZQTVEHICLE" ("UIN")
  TABLESPACE "RCZQDIX1" ;
--------------------------------------------------------
--  DDL for Index IDX_PARAMETER_KEY
--------------------------------------------------------

  CREATE UNIQUE INDEX "IDX_PARAMETER_KEY" ON "RCZQTPARAMETER" ("KEY")
  TABLESPACE "RCZQDIX1" ;
--------------------------------------------------------
--  DDL for Index IDX_ELEMENTARYSERVICE_CODE
--------------------------------------------------------

  CREATE UNIQUE INDEX "IDX_ELEMENTARYSERVICE_CODE" ON "RCZQTELEMENTARYSERVICE" ("CODE")
  TABLESPACE "RCZQDIX1" ;
--------------------------------------------------------
--  DDL for Index IDX_SELLABLESERVICE_CODE
--------------------------------------------------------

  CREATE UNIQUE INDEX "IDX_SELLABLESERVICE_CODE" ON "RCZQTSELLABLESERVICE" ("CODE")
  TABLESPACE "RCZQDIX1" ;
--------------------------------------------------------
--  DDL for Index IDX_USERLOG_ID
--------------------------------------------------------

  CREATE UNIQUE INDEX "IDX_USERLOG_ID" ON "RCZQTUSERLOG" ("ID")
  TABLESPACE "RCZQDIX1" ;
--------------------------------------------------------
--  DDL for Index IDX_RCZQTEXCHANGE_ID
--------------------------------------------------------

  CREATE UNIQUE INDEX "IDX_RCZQTEXCHANGE_ID" ON "RCZQTEXCHANGE" ("ID")
  TABLESPACE "RCZQDIX1" ;


--------------------------------------------------------
--  DDL for Index IDX_RCZQTHELPER_ID
--------------------------------------------------------

  CREATE UNIQUE INDEX "IDX_RCZQTHELPER_ID" ON "RCZQTHELPER" ("ID")
  TABLESPACE "RCZQDIX1" ;


--------------------------------------------------------
--  Constraints for Table RCZQTOPTIONALSERVICE
--------------------------------------------------------

  ALTER TABLE "RCZQTOPTIONALSERVICE" ADD PRIMARY KEY ("CODE")
  USING INDEX TABLESPACE "RCZQDIX1"  ENABLE;
  ALTER TABLE "RCZQTOPTIONALSERVICE" MODIFY ("CODE" NOT NULL ENABLE);

--------------------------------------------------------
--  Constraints for Table RCZQTLOG
--------------------------------------------------------

  ALTER TABLE "RCZQTLOG" ADD PRIMARY KEY ("ID")
  USING INDEX TABLESPACE "RCZQDIX1"  ENABLE;
  ALTER TABLE "RCZQTLOG" MODIFY ("MESSAGE" NOT NULL ENABLE);
  ALTER TABLE "RCZQTLOG" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table RCZQTSMS
--------------------------------------------------------

  ALTER TABLE "RCZQTSMS" ADD PRIMARY KEY ("ID")
  USING INDEX TABLESPACE "RCZQDIX1"  ENABLE;
  ALTER TABLE "RCZQTSMS" MODIFY ("ID" NOT NULL ENABLE);

--------------------------------------------------------
--  Constraints for Table RCZQTVEHSTATEHISTORY
--------------------------------------------------------

  ALTER TABLE "RCZQTVEHSTATEHISTORY" MODIFY ("VEHICLESTATE" NOT NULL ENABLE);
  ALTER TABLE "RCZQTVEHSTATEHISTORY" MODIFY ("UIN" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table RCZQTSMSMESSAGES
--------------------------------------------------------

  ALTER TABLE "RCZQTSMSMESSAGES" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table RCZQTVEHICLE
--------------------------------------------------------

  ALTER TABLE "RCZQTVEHICLE" ADD PRIMARY KEY ("UIN")
  USING INDEX TABLESPACE "RCZQDIX1"  ENABLE;
  ALTER TABLE "RCZQTVEHICLE" MODIFY ("VEHICLESTATE" NOT NULL ENABLE);
  ALTER TABLE "RCZQTVEHICLE" MODIFY ("UIN" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table RCZQTPARAMETER
--------------------------------------------------------

  ALTER TABLE "RCZQTPARAMETER" ADD PRIMARY KEY ("KEY")
  USING INDEX TABLESPACE "RCZQDIX1"  ENABLE;
  ALTER TABLE "RCZQTPARAMETER" MODIFY ("KEY" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table RCZQTACTIONS
--------------------------------------------------------

  ALTER TABLE "RCZQTACTIONS" MODIFY ("CODE" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table RCZQTELEMENTARYSERVICE
--------------------------------------------------------

  ALTER TABLE "RCZQTELEMENTARYSERVICE" ADD PRIMARY KEY ("CODE")
  USING INDEX TABLESPACE "RCZQDIX1"  ENABLE;
  ALTER TABLE "RCZQTELEMENTARYSERVICE" MODIFY ("VALID" NOT NULL ENABLE);
  ALTER TABLE "RCZQTELEMENTARYSERVICE" MODIFY ("CODE" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table RCZQTSELLABLESERVICE
--------------------------------------------------------

  ALTER TABLE "RCZQTSELLABLESERVICE" ADD PRIMARY KEY ("CODE")
  USING INDEX  TABLESPACE "RCZQDIX1"  ENABLE;
  ALTER TABLE "RCZQTSELLABLESERVICE" MODIFY ("CODE" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table RCZQTUSERLOG
--------------------------------------------------------

  ALTER TABLE "RCZQTUSERLOG" ADD PRIMARY KEY ("ID")
  USING INDEX TABLESPACE "RCZQDIX1"  ENABLE;
  ALTER TABLE "RCZQTUSERLOG" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table RCZQTEXCHANGE
--------------------------------------------------------

  ALTER TABLE "RCZQTEXCHANGE" ADD PRIMARY KEY ("ID")
  USING INDEX TABLESPACE "RCZQDIX1"  ENABLE;
  ALTER TABLE "RCZQTEXCHANGE" MODIFY ("CALLERTYPE" NOT NULL ENABLE);
  ALTER TABLE "RCZQTEXCHANGE" MODIFY ("CALLERID" NOT NULL ENABLE);
  ALTER TABLE "RCZQTEXCHANGE" MODIFY ("ACTIONTYPE" NOT NULL ENABLE);
  ALTER TABLE "RCZQTEXCHANGE" MODIFY ("ACTIONSERVICE" NOT NULL ENABLE);
  ALTER TABLE "RCZQTEXCHANGE" MODIFY ("ID" NOT NULL ENABLE);

--------------------------------------------------------
--  Ref Constraints for Table RCZQTVEHSTATEHISTORY
--------------------------------------------------------

  ALTER TABLE "RCZQTVEHSTATEHISTORY" ADD CONSTRAINT "FK_VEH_VEHSTHYS" FOREIGN KEY ("UIN")
	  REFERENCES "RCZQTVEHICLE" ("UIN") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table RCZQTSMSMESSAGES
--------------------------------------------------------

  ALTER TABLE "RCZQTSMSMESSAGES" ADD CONSTRAINT "FK_SMSMESS_SMS" FOREIGN KEY ("ID")
	  REFERENCES "RCZQTSMS" ("ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table RCZQTACTIONS
--------------------------------------------------------

  ALTER TABLE "RCZQTACTIONS" ADD CONSTRAINT "FK_ACTION_ELMACTION" FOREIGN KEY ("CODE")
	  REFERENCES "RCZQTELEMENTARYSERVICE" ("CODE") ENABLE;

--------------------------------------------------------
--  Constraints for Table RCZQTHELPER
--------------------------------------------------------

  ALTER TABLE "RCZQTHELPER" ADD PRIMARY KEY ("ID")
  USING INDEX TABLESPACE "RCZQDIX1"  ENABLE;
  ALTER TABLE "RCZQTHELPER" MODIFY ("ID" NOT NULL ENABLE);

CREATE SEQUENCE  "RCZQNSMS"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE  NOPARTITION ;
CREATE SEQUENCE  "RCZQNLOG"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE  NOPARTITION ;
CREATE SEQUENCE  "RCZQNUSERLOG"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE  NOPARTITION ;
CREATE SEQUENCE  "RCZQNHELPER"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE  NOPARTITION ;

REM INSERTING into RCZQTELEMENTARYSERVICE
SET DEFINE OFF;
Insert into RCZQTELEMENTARYSERVICE (CODE,LABEL,ACTIVE,ENDVALIDITYDATE,STARTVALIDITYDATE) values ('BTA3221230','BTA3221230','1',to_timestamp('24/11/18 11:11:49,472000000','DD/MM/RR HH24:MI:SS,FF'),to_timestamp('24/11/16 11:11:57,191000000','DD/MM/RR HH24:MI:SS,FF'));
Insert into RCZQTELEMENTARYSERVICE (CODE,LABEL,ACTIVE,ENDVALIDITYDATE,STARTVALIDITYDATE) values ('BTA3221231','BTA3221231','1',to_timestamp('24/11/18 11:11:49,472000000','DD/MM/RR HH24:MI:SS,FF'),to_timestamp('24/11/16 11:11:57,191000000','DD/MM/RR HH24:MI:SS,FF'));
Insert into RCZQTELEMENTARYSERVICE (CODE,LABEL,ACTIVE,ENDVALIDITYDATE,STARTVALIDITYDATE) values ('BTA3221232','BTA3221232','1',to_timestamp('24/11/18 11:11:49,472000000','DD/MM/RR HH24:MI:SS,FF'),to_timestamp('24/11/16 11:11:57,191000000','DD/MM/RR HH24:MI:SS,FF'));
Insert into RCZQTELEMENTARYSERVICE (CODE,LABEL,ACTIVE,ENDVALIDITYDATE,STARTVALIDITYDATE) values ('BTA3221233','BTA3221233','1',to_timestamp('24/11/18 11:11:49,472000000','DD/MM/RR HH24:MI:SS,FF'),to_timestamp('24/11/16 11:11:57,191000000','DD/MM/RR HH24:MI:SS,FF'));
Insert into RCZQTELEMENTARYSERVICE (CODE,LABEL,ACTIVE,ENDVALIDITYDATE,STARTVALIDITYDATE) values ('BTA3221234','BTA3221234','1',to_timestamp('24/11/18 11:11:49,472000000','DD/MM/RR HH24:MI:SS,FF'),to_timestamp('24/11/16 11:11:57,191000000','DD/MM/RR HH24:MI:SS,FF'));
Insert into RCZQTELEMENTARYSERVICE (CODE,LABEL,ACTIVE,ENDVALIDITYDATE,STARTVALIDITYDATE) values ('BTA3221235','BTA3221235','1',to_timestamp('24/11/18 11:11:49,472000000','DD/MM/RR HH24:MI:SS,FF'),to_timestamp('24/11/16 11:11:57,191000000','DD/MM/RR HH24:MI:SS,FF'));
Insert into RCZQTELEMENTARYSERVICE (CODE,LABEL,ACTIVE,ENDVALIDITYDATE,STARTVALIDITYDATE) values ('BTA3221236','BTA3221236','1',to_timestamp('24/11/18 11:11:49,472000000','DD/MM/RR HH24:MI:SS,FF'),to_timestamp('24/11/16 11:11:57,191000000','DD/MM/RR HH24:MI:SS,FF'));
Insert into RCZQTELEMENTARYSERVICE (CODE,LABEL,ACTIVE,ENDVALIDITYDATE,STARTVALIDITYDATE) values ('BTA3221237','BTA3221237','1',to_timestamp('24/11/18 11:11:49,472000000','DD/MM/RR HH24:MI:SS,FF'),to_timestamp('24/11/16 11:11:57,191000000','DD/MM/RR HH24:MI:SS,FF'));
Insert into RCZQTELEMENTARYSERVICE (CODE,LABEL,ACTIVE,ENDVALIDITYDATE,STARTVALIDITYDATE) values ('BTA3221238','BTA3221238','1',to_timestamp('24/11/18 11:11:49,472000000','DD/MM/RR HH24:MI:SS,FF'),to_timestamp('24/11/16 11:11:57,191000000','DD/MM/RR HH24:MI:SS,FF'));
Insert into RCZQTELEMENTARYSERVICE (CODE,LABEL,ACTIVE,ENDVALIDITYDATE,STARTVALIDITYDATE) values ('BTA3221239','BTA3221239','1',to_timestamp('24/11/18 11:11:49,472000000','DD/MM/RR HH24:MI:SS,FF'),to_timestamp('24/11/16 11:11:57,191000000','DD/MM/RR HH24:MI:SS,FF'));

REM INSERTING into RCZQTPARAMETER
SET DEFINE OFF;
Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('APP_PROXY','parameters.app.proxy.description.key','false','APPLICATION','parameters.app.proxy.label.key');
Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('APP_PROXY_HOST','parameters.app.proxy.host.description.key','http://http.internetpsa.inetpsa.com:80','APPLICATION','parameters.app.proxy.host.label.key');
Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('APP_PROXY_USERNAME','parameters.app.proxy.username.description.key','mdercz00','APPLICATION','parameters.app.proxy.username.label.key');
Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('APP_PROXY_PASSWORD','parameters.app.proxy.password.description.key','cddrcz00','APPLICATION','parameters.app.proxy.password.label.key');
Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('CVS_MOCK','parameters.cvs.cvsMock.description.key','true','CVS','parameters.cvs.cvsMock.label.key');
Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('CVS_ENDPOINT_URL','parameters.cvs.endpoint.url.description.key','http://localhost:80/cvs','CVS','parameters.cvs.endpoint.url.label.key');
Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('CVS_USERNAME','parameters.cvs.username.description.key','mdercz00','CVS','parameters.cvs.username.label.key');
Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('CVS_PASSWORD','parameters.cvs.password.description.key','cddrcz00','CVS','parameters.cvs.password.label.key');
Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('APP_EXCHANGE_TIMEOUT_MIN','parameters.app.exchange.timeout.min.description.key','15','APPLICATION','parameters.app.exchange.timeout.min.label.key');
Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('APP_CALLER_QUOTA','parameters.app.caller.quota.description.key','3','APPLICATION','parameters.app.caller.quota.label.key');
Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('APP_CALLER_QUOTA_DURATION_MIN','parameters.app.caller.quota.duration.min.description.key','1','APPLICATION','parameters.app.caller.quota.duration.min.label.key');
Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('APP_HORN_QUOTA','parameters.app.horn.quota.description.key','3','APPLICATION','parameters.app.horn.quota.label.key');
Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('APP_HORN_QUOTA_DURATION_MIN','parameters.app.horn.quota.duration.min.description.key','60','APPLICATION','parameters.app.horn.quota.duration.min.label.key');
Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('APP_LIGHTS_QUOTA','parameters.app.lights.quota.description.key','1','APPLICATION','parameters.app.lights.quota.label.key');
Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('APP_LIGHTS_QUOTA_DURATION_MIN','parameters.app.lights.quota.duration.min.description.key','10','APPLICATION','parameters.app.lights.quota.duration.min.label.key');
Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('APP_REMOTE_ALARM_RCZ_ID','parameters.app.remote.alarm.id.description.key','mdercz00','APPLICATION','parameters.app.remote.alarm.id.label.key');
Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('APP_AUTOMATICAL_VEHICLE_STATE','parameters.app.automatical.vehicle.state.description.key','true','APPLICATION','parameters.app.automatical.vehicle.state.label.key');
Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('BYTEL_DATA_LENGTH','parameters.bytel.data.length.description.key','0','BYTEL','parameters.bytel.data.length.label.key');
Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('BYTEL_SMS_PROTOCOL_VERSION','parameters.bytel.sms.protocol.version.description.key','1.00','BYTEL','parameters.bytel.sms.protocol.version.label.key');
Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('BYTEL_SMS_DSPT','parameters.bytel.sms.dspt.description.key','0','BYTEL','parameters.bytel.sms.dspt.label.key');
Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('BYTEL_SMS_MESSAGE_ID','parameters.bytel.sms.message.id.description.key','1','BYTEL','parameters.bytel.sms.message.id.label.key');
Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('BYTEL_SMS_SERVICE_TYPE','parameters.bytel.sms.service.type.description.key','5','BYTEL','parameters.bytel.sms.service.type.label.key');
Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('BYTEL_SMS_MESSAGE_TYPE','parameters.bytel.sms.message.type.description.key','63','BYTEL','parameters.bytel.sms.message.type.label.key');
Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('BYTEL_SMS_MESSAGE_PROTOCOL_VERSION','parameters.bytel.sms.message.protocol.version.description.key','1','BYTEL','parameters.bytel.sms.message.protocol.version.label.key');
Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('BYTEL_SMS_ICP','parameters.bytel.sms.icp.description.key','PSA-PP3','BYTEL','parameters.bytel.sms.icp.label.key');
Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('BYTEL_SMS_ID_OFFER','parameters.bytel.sms.id.offer.description.key','EVSKCELSC22860','BYTEL','parameters.bytel.sms.id.offer.label.key');
Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('BYTEL_SMS_TO_TYPE','parameters.bytel.sms.to.type.description.key','MSISDN','BYTEL','parameters.bytel.sms.to.type.label.key');
Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('BYTEL_SMS_ADM','parameters.bytel.sms.adm.description.key','PSA-PP3_ADM','BYTEL','parameters.bytel.sms.adm.label.key');
Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('BYTEL_SMS_NB_RETRY','parameters.bytel.sms.nb.retry.description.key','3','BYTEL','parameters.bytel.sms.nb.retry.label.key');
Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('BYTEL_SMS_RETRY_DELAY','parameters.bytel.sms.retry.delay.description.key','1000','BYTEL','parameters.bytel.sms.retry.delay.label.key');
Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('BYTEL_SMS_URI','parameters.bytel.sms.uri.description.key','http://10.255.0.254:28000','BYTEL','parameters.bytel.sms.uri.label.key');
Insert into RCZQTPARAMETER (KEY,DESCRIPTION,VALUE,CATEGORY,LABEL) values ('BYTEL_SMS_PATH','parameters.bytel.sms.path.description.key','/','BYTEL','parameters.bytel.sms.path.label.key');


REM INSERTING into RCZQTACTIONS
SET DEFINE OFF;
Insert into RCZQTACTIONS (CODE,ACTIONSERVICE,ACTIONTYPE) values ('BTA3221234','STOLEN','VEHICLE_STATE');
Insert into RCZQTACTIONS (CODE,ACTIONSERVICE,ACTIONTYPE) values ('BTA3221234','STOLEN','REQUEST_STATE');
Insert into RCZQTACTIONS (CODE,ACTIONSERVICE,ACTIONTYPE) values ('BTA3221235','STOLEN','REQUEST_STATE');
Insert into RCZQTACTIONS (CODE,ACTIONSERVICE,ACTIONTYPE) values ('BTA3221235','REMOTE','VEHICLE_INFO');
Insert into RCZQTACTIONS (CODE,ACTIONSERVICE,ACTIONTYPE) values ('BTA3221234','REMOTE','VEHICLE_INFO');
Insert into RCZQTACTIONS (CODE,ACTIONSERVICE,ACTIONTYPE) values ('BTA3221234','STOLEN','STOLEN_VIN');
Insert into RCZQTACTIONS (CODE,ACTIONSERVICE,ACTIONTYPE) values ('BTA3221234','STOLEN','TRACKING');
Insert into RCZQTACTIONS (CODE,ACTIONSERVICE,ACTIONTYPE) values ('BTA3221235','STOLEN','VEHICLE_STATE');
Insert into RCZQTACTIONS (CODE,ACTIONSERVICE,ACTIONTYPE) values ('BTA3221235','STOLEN','IMMOBILIZATION');
Insert into RCZQTACTIONS (CODE,ACTIONSERVICE,ACTIONTYPE) values ('BTA3221235','STOLEN','IMMO_DATA');
Insert into RCZQTACTIONS (CODE,ACTIONSERVICE,ACTIONTYPE) values ('BTA3221235','STOLEN','STOLEN_VIN');
Insert into RCZQTACTIONS (CODE,ACTIONSERVICE,ACTIONTYPE) values ('BTA3221236','REMOTE','VEHICLE_INFO');
Insert into RCZQTACTIONS (CODE,ACTIONSERVICE,ACTIONTYPE) values ('BTA3221236','REMOTE','REQUEST_STATE');
Insert into RCZQTACTIONS (CODE,ACTIONSERVICE,ACTIONTYPE) values ('BTA3221236','REMOTE','ALARM');
Insert into RCZQTACTIONS (CODE,ACTIONSERVICE,ACTIONTYPE) values ('BTA3221236','REMOTE','VEHICLE_STATE');
Insert into RCZQTACTIONS (CODE,ACTIONSERVICE,ACTIONTYPE) values ('BTA3221237','REMOTE','DOORS');
Insert into RCZQTACTIONS (CODE,ACTIONSERVICE,ACTIONTYPE) values ('BTA3221237','REMOTE','VEHICLE_INFO');
Insert into RCZQTACTIONS (CODE,ACTIONSERVICE,ACTIONTYPE) values ('BTA3221237','REMOTE','REQUEST_STATE');
Insert into RCZQTACTIONS (CODE,ACTIONSERVICE,ACTIONTYPE) values ('BTA3221237','REMOTE','VEHICLE_STATE');
Insert into RCZQTACTIONS (CODE,ACTIONSERVICE,ACTIONTYPE) values ('BTA3221238','REMOTE','HORN');
Insert into RCZQTACTIONS (CODE,ACTIONSERVICE,ACTIONTYPE) values ('BTA3221238','REMOTE','VEHICLE_INFO');
Insert into RCZQTACTIONS (CODE,ACTIONSERVICE,ACTIONTYPE) values ('BTA3221238','REMOTE','REQUEST_STATE');
Insert into RCZQTACTIONS (CODE,ACTIONSERVICE,ACTIONTYPE) values ('BTA3221238','REMOTE','VEHICLE_STATE');
Insert into RCZQTACTIONS (CODE,ACTIONSERVICE,ACTIONTYPE) values ('BTA3221239','REMOTE','VEHICLE_INFO');
Insert into RCZQTACTIONS (CODE,ACTIONSERVICE,ACTIONTYPE) values ('BTA3221239','REMOTE','REQUEST_STATE');
Insert into RCZQTACTIONS (CODE,ACTIONSERVICE,ACTIONTYPE) values ('BTA3221239','REMOTE','LIGHTS');
Insert into RCZQTACTIONS (CODE,ACTIONSERVICE,ACTIONTYPE) values ('BTA3221239','REMOTE','VEHICLE_STATE');

Insert into RCZQTHELPER (ID,CREATEDATE,TITLE) values ('1',to_timestamp('05/12/16 10:12:58,401000000','DD/MM/RR HH24:MI:SS,FF'),'FAQ');


commit;

--------------------------------------------------------
---------------------  I18N ----------------------------
--------------------------------------------------------
--------------------------------------------------------


--------------------------------------------------------
--  DDL for Table SEED_I18N_KEY
--------------------------------------------------------

  CREATE TABLE "SEED_I18N_KEY"
   (	"ID" VARCHAR2(255 CHAR),
	"DESCRIPTION" VARCHAR2(255 CHAR),
	"OUTDATED" NUMBER(1,0)
   )
  TABLESPACE "RCZQDDA1" ;
--------------------------------------------------------
--  DDL for Table SEED_I18N_KEY_TRANS
--------------------------------------------------------

  CREATE TABLE "SEED_I18N_KEY_TRANS"
   (	"SEED_I18N_KEY_ID" VARCHAR2(255 CHAR),
	"TRANSLATIONS_KEY_ID" VARCHAR2(255 CHAR),
	"TRANSLATIONS_LOCALE" VARCHAR2(255 CHAR)
   )
  TABLESPACE "RCZQDDA1" ;
--------------------------------------------------------
--  DDL for Table SEED_I18N_LOCALE
--------------------------------------------------------

  CREATE TABLE "SEED_I18N_LOCALE"
   (	"CODE" VARCHAR2(255 CHAR),
	"DEFAULT_LOCALE" NUMBER(1,0),
	"ENGLISH_LANGUAGE" VARCHAR2(255 CHAR),
	"LANGUAGE" VARCHAR2(255 CHAR)
   )
  TABLESPACE "RCZQDDA1" ;
--------------------------------------------------------
--  DDL for Table SEED_I18N_TRANSLATION
--------------------------------------------------------

  CREATE TABLE "SEED_I18N_TRANSLATION"
   (	"KEY_ID" VARCHAR2(255 CHAR),
	"LOCALE" VARCHAR2(255 CHAR),
	"APPROXIMATE" NUMBER(1,0),
	"OUTDATED" NUMBER(1,0),
	"TRANSLATION" VARCHAR2(255 CHAR)
   )
  TABLESPACE "RCZQDDA1" ;

--------------------------------------------------------
--  Constraints for Table SEED_I18N_KEY
--------------------------------------------------------

  ALTER TABLE "SEED_I18N_KEY" ADD PRIMARY KEY ("ID")
  USING INDEX TABLESPACE "RCZQDDA1"  ENABLE;
  ALTER TABLE "SEED_I18N_KEY" MODIFY ("ID" NOT NULL ENABLE);

--------------------------------------------------------
--  Constraints for Table SEED_I18N_KEY_TRANS
--------------------------------------------------------

  ALTER TABLE "SEED_I18N_KEY_TRANS" ADD CONSTRAINT "IDX_I18N_KL" UNIQUE ("TRANSLATIONS_KEY_ID", "TRANSLATIONS_LOCALE")
  USING INDEX TABLESPACE "RCZQDIX1"  ENABLE;
  ALTER TABLE "SEED_I18N_KEY_TRANS" ADD PRIMARY KEY ("SEED_I18N_KEY_ID", "TRANSLATIONS_KEY_ID", "TRANSLATIONS_LOCALE")
  USING INDEX TABLESPACE "RCZQDIX1"  ENABLE;
  ALTER TABLE "SEED_I18N_KEY_TRANS" MODIFY ("TRANSLATIONS_LOCALE" NOT NULL ENABLE);
  ALTER TABLE "SEED_I18N_KEY_TRANS" MODIFY ("TRANSLATIONS_KEY_ID" NOT NULL ENABLE);
  ALTER TABLE "SEED_I18N_KEY_TRANS" MODIFY ("SEED_I18N_KEY_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table SEED_I18N_LOCALE
--------------------------------------------------------

  ALTER TABLE "SEED_I18N_LOCALE" ADD PRIMARY KEY ("CODE")
  USING INDEX TABLESPACE "RCZQDIX1" ENABLE;
  ALTER TABLE "SEED_I18N_LOCALE" MODIFY ("CODE" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table SEED_I18N_TRANSLATION
--------------------------------------------------------

  ALTER TABLE "SEED_I18N_TRANSLATION" ADD PRIMARY KEY ("KEY_ID", "LOCALE")
  USING INDEX TABLESPACE "RCZQDIX1" ENABLE;
  ALTER TABLE "SEED_I18N_TRANSLATION" MODIFY ("LOCALE" NOT NULL ENABLE);
  ALTER TABLE "SEED_I18N_TRANSLATION" MODIFY ("KEY_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Ref Constraints for Table SEED_I18N_KEY_TRANS
--------------------------------------------------------

  ALTER TABLE "SEED_I18N_KEY_TRANS" ADD CONSTRAINT "FK_I18N_KEY_TRANS" FOREIGN KEY ("SEED_I18N_KEY_ID")
	  REFERENCES "SEED_I18N_KEY" ("ID") ENABLE;
  ALTER TABLE "SEED_I18N_KEY_TRANS" ADD CONSTRAINT "FK_I18N_KEY_LOC" FOREIGN KEY ("TRANSLATIONS_KEY_ID", "TRANSLATIONS_LOCALE")
	  REFERENCES "SEED_I18N_TRANSLATION" ("KEY_ID", "LOCALE") ENABLE;




--------------------------------------------------------
--  DATA
--------------------------------------------------------

REM INSERTING into SEED_I18N_LOCALE
SET DEFINE OFF;
Insert into SEED_I18N_LOCALE (CODE,DEFAULT_LOCALE,ENGLISH_LANGUAGE,LANGUAGE) values ('en','1','English','English');
Insert into SEED_I18N_LOCALE (CODE,DEFAULT_LOCALE,ENGLISH_LANGUAGE,LANGUAGE) values ('fr','0','French','français');

REM INSERTING into SEED_I18N_KEY
SET DEFINE OFF;
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('process.900.request.accepted.key','Process 900 message (request accepted)','0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('process.903.request.forwarded.to.vehicle.key','Process 903 message (request forwarded to vehicle)','0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('process.902.checking.vehicle.state.key','Process 902 message (checking vehicle state)','0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('process.901.vehicle.asleep.key','Process 901 message (vehcile asleep)','0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.app.proxy.description.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.app.proxy.host.description.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.app.proxy.username.description.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.app.proxy.password.description.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.cvs.cvsMock.description.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.cvs.endpoint.url.description.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.cvs.username.description.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.cvs.password.description.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.app.exchange.timeout.min.description.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.app.caller.quota.description.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.app.caller.quota.duration.min.description.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.app.horn.quota.description.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.app.horn.quota.duration.min.description.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.app.lights.quota.description.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.app.lights.quota.duration.min.description.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.app.remote.alarm.id.description.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.app.automatical.vehicle.state.description.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.bytel.data.length.description.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.bytel.sms.protocol.version.description.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.bytel.sms.dspt.description.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.bytel.sms.message.id.description.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.bytel.sms.service.type.description.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.bytel.sms.message.type.description.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.bytel.sms.message.protocol.version.description.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.bytel.sms.icp.description.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.bytel.sms.id.offer.description.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.bytel.sms.to.type.description.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.bytel.sms.adm.description.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.bytel.sms.nb.retry.description.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.bytel.sms.retry.delay.description.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.bytel.sms.uri.description.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.bytel.sms.path.description.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('user.quota.message.key','Message for user quota. N
Need duration value for the first parameter and quota value the for second parameter','0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('horn.quota.message.key','Message for horn quota.
Need duration value for the first parameter and quota value the for second parameter','0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('lights.quota.message.key','Message for lights quota.
Need duration value for the first parameter and quota value the for second parameter','0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('duplicate.message.key','Message when a duplicate is detected from a client or a partner','0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('authorization.denied.cvs.on.uin.response.ko.key','Authorization denied message when the response is KO for the cvs on uin response','0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('authorization.denied.cvs.from.uin.response.ko.key','Authorization denied message when the response is KO for the cvs from uin response','0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('authorization.denied.cvs.from.uin.vin.does.not.match.targeted.vehicle.key','Authorization denied message when the VIN does not match the targeted vehicle for cvs from UIN responses.','0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('authorization.denied.cvs.response.no.matching.service.key','Authorization denied message when there is no matching elementary service for cvs responses','0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('rights.error.ves.sev.not.stopped.key','Rights error ves message when the sev i not stopped','0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('rights.error.stolen.vehicle.not.declared.stolen.key','Rights error stolen message when is not declared stolen.','0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.app.proxy.label.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('request.error.correlation.id.error.message.key','Request error message when the correlation id already exist','0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('technical.error.no.vehicle.found.for.uin.key','Technical error message when there is no vehicle found for the given uin.
Need UIN parameter value.','0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('bad.request.unknown.uin.key','Bad request message when the uin is unknown.
Need UIN parameter value.','0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('authorization.denied.check.action.right.permission.denied.key','Authorization denied message when the permission is denied for the given action.','0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('authorization.denied.vehicle.is.stolen.key','Authorization denied message the vehicle is stolen.','0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.app.proxy.host.label.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.app.proxy.username.label.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.app.proxy.password.label.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.cvs.cvsMock.label.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.cvs.endpoint.url.label.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.cvs.username.label.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.cvs.password.label.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.app.exchange.timeout.min.label.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.app.caller.quota.label.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.app.caller.quota.duration.min.label.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.app.horn.quota.label.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.app.horn.quota.duration.min.label.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.app.lights.quota.label.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.app.lights.quota.duration.min.label.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.app.remote.alarm.id.label.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.app.automatical.vehicle.state.label.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.bytel.data.length.label.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.bytel.sms.protocol.version.label.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.bytel.sms.dspt.label.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.bytel.sms.message.id.label.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.bytel.sms.service.type.label.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.bytel.sms.message.type.label.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.bytel.sms.message.protocol.version.label.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.bytel.sms.icp.label.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.bytel.sms.id.offer.label.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.bytel.sms.to.type.label.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.bytel.sms.adm.label.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.bytel.sms.nb.retry.label.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.bytel.sms.retry.delay.label.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.bytel.sms.uri.label.key',null,'0');
Insert into SEED_I18N_KEY (ID,DESCRIPTION,OUTDATED) values ('parameters.bytel.sms.path.label.key',null,'0');


REM INSERTING into SEED_I18N_TRANSLATION
SET DEFINE OFF;
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('process.900.request.accepted.key','en','0','0','Your request has been accepted and is being processed');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('process.903.request.forwarded.to.vehicle.key','en','0','0','Your request has been successfully forwarded to the vehicle');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('process.902.checking.vehicle.state.key','en','0','0','PSA is checking for the vehicle state');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('process.901.vehicle.asleep.key','en','0','0','The BTA is not connected, a request was sent to wake it up');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.app.proxy.description.key','en','0','0','Enable proxy');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.app.proxy.host.description.key','en','0','0','Proxy URL');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.app.proxy.username.description.key','en','0','0','Proxy username');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.app.proxy.password.description.key','en','0','0','Proxy password');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.cvs.cvsMock.description.key','en','0','0','Enable mocked response');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.cvs.endpoint.url.description.key','en','0','0','Host');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.cvs.username.description.key','en','0','0','Username');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.cvs.password.description.key','en','0','0','Password');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.app.exchange.timeout.min.description.key','en','0','0','Exchange timeout (min)');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.app.caller.quota.description.key','en','0','0','User quota');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.app.caller.quota.duration.min.description.key','en','0','0','User quota duration');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.app.horn.quota.description.key','en','0','0','Horn quota');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.app.horn.quota.duration.min.description.key','en','0','0','Horn quota duration (min)');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.app.lights.quota.description.key','en','0','0','Light quota');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.app.lights.quota.duration.min.description.key','en','0','0','Light quota duration (min)');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.app.remote.alarm.id.description.key','en','0','0','RCZ identifier');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.app.automatical.vehicle.state.description.key','en','0','0','Enable automatical vehicle state support');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.bytel.data.length.description.key','en','0','0','Data length');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.bytel.sms.protocol.version.description.key','en','0','0','Protocol Version');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.bytel.sms.dspt.description.key','en','0','0','DSPT');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.bytel.sms.message.id.description.key','en','0','0','Message ID');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.bytel.sms.service.type.description.key','en','0','0','Service Type');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.bytel.sms.message.type.description.key','en','0','0','Message Type');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.bytel.sms.message.protocol.version.description.key','en','0','0','Message Protocol Version');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.bytel.sms.icp.description.key','en','0','0','ICP');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.bytel.sms.id.offer.description.key','en','0','0','Offer ID');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.bytel.sms.to.type.description.key','en','0','0','Target Type');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.bytel.sms.adm.description.key','en','0','0','ADM');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.bytel.sms.nb.retry.description.key','en','0','0','Attempts');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.bytel.sms.retry.delay.description.key','en','0','0','Delay Between Attempts (ms)');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.bytel.sms.uri.description.key','en','0','0','URI');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.bytel.sms.path.description.key','en','0','0','Path');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('user.quota.message.key','en','0','0','The maximum number of requests allowed per {0} minutes for a customer / partner ({1}) is exceeded, the request will not be processed');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('horn.quota.message.key','en','0','0','The maximum number of Horn requests allowed per {0} minutes for a customer / partner ({1}) is exceeded, the request will not be processed');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('lights.quota.message.key','en','0','0','The maximum number of Light requests allowed per {0} minutes for a customer / partner ({1}) is exceeded, the request will not be processed');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('duplicate.message.key','en','0','0','Duplicate detected');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('authorization.denied.cvs.on.uin.response.ko.key','en','0','0','No valid response from CVS');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('authorization.denied.cvs.from.uin.response.ko.key','en','0','0','No valid response from CVS');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('authorization.denied.cvs.from.uin.vin.does.not.match.targeted.vehicle.key','en','0','0','VIN does not match the target vehicle');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('authorization.denied.cvs.response.no.matching.service.key','en','0','0','No matching service');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('rights.error.ves.sev.not.stopped.key','en','0','0','Action denied, SEV on');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('rights.error.stolen.vehicle.not.declared.stolen.key','en','0','0','Action denied, vehicle not stolen');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.app.proxy.label.key','en','0','0','Enable proxy');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('request.error.correlation.id.error.message.key','en','0','0','Correlation identifier should be unique. The given correlation identifier is already known in our system');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('technical.error.no.vehicle.found.for.uin.key','en','0','0','No vehicle found for UIN : {0}');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('bad.request.unknown.uin.key','en','0','0','Unknown vehicle with UIN : {0}');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('authorization.denied.check.action.right.permission.denied.key','en','0','0','You do not have the rights to do the requested action');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('authorization.denied.vehicle.is.stolen.key','en','0','0','Action denied, stolen vehicle');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.app.proxy.host.label.key','en','0','0','Proxy URL');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.app.proxy.username.label.key','en','0','0','Proxy username');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.app.proxy.password.label.key','en','0','0','Proxy password');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.cvs.cvsMock.label.key','en','0','0','Enable mocked response');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.cvs.endpoint.url.label.key','en','0','0','Host');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.cvs.username.label.key','en','0','0','Username');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.cvs.password.label.key','en','0','0','Password');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.app.exchange.timeout.min.label.key','en','0','0','Exchange timeout (min)');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.app.caller.quota.label.key','en','0','0','User quota');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.app.caller.quota.duration.min.label.key','en','0','0','User quota duration');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.app.horn.quota.label.key','en','0','0','Horn quota');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.app.horn.quota.duration.min.label.key','en','0','0','Horn quota duration (min)');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.app.lights.quota.label.key','en','0','0','Light quota');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.app.lights.quota.duration.min.label.key','en','0','0','Light quota duration (min)');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.app.remote.alarm.id.label.key','en','0','0','RCZ identifier');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.app.automatical.vehicle.state.label.key','en','0','0','Enable automatical vehicle state support');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.bytel.data.length.label.key','en','0','0','Data length');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.bytel.sms.protocol.version.label.key','en','0','0','Protocol Version');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.bytel.sms.dspt.label.key','en','0','0','DSPT');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.bytel.sms.message.id.label.key','en','0','0','Message ID');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.bytel.sms.service.type.label.key','en','0','0','Service Type');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.bytel.sms.message.type.label.key','en','0','0','Message Type');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.bytel.sms.message.protocol.version.label.key','en','0','0','Message Protocol Version');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.bytel.sms.icp.label.key','en','0','0','ICP');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.bytel.sms.id.offer.label.key','en','0','0','Offer ID');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.bytel.sms.to.type.label.key','en','0','0','Target Type');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.bytel.sms.adm.label.key','en','0','0','ADM');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.bytel.sms.nb.retry.label.key','en','0','0','Attempts');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.bytel.sms.retry.delay.label.key','en','0','0','Delay Between Attempts (ms)');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.bytel.sms.uri.label.key','en','0','0','URI');
Insert into SEED_I18N_TRANSLATION (KEY_ID,LOCALE,APPROXIMATE,OUTDATED,TRANSLATION) values ('parameters.bytel.sms.path.label.key','en','0','0','Path');

REM INSERTING into SEED_I18N_KEY_TRANS
SET DEFINE OFF;
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('authorization.denied.check.action.right.permission.denied.key','authorization.denied.check.action.right.permission.denied.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('authorization.denied.cvs.from.uin.response.ko.key','authorization.denied.cvs.from.uin.response.ko.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('authorization.denied.cvs.from.uin.vin.does.not.match.targeted.vehicle.key','authorization.denied.cvs.from.uin.vin.does.not.match.targeted.vehicle.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('authorization.denied.cvs.on.uin.response.ko.key','authorization.denied.cvs.on.uin.response.ko.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('authorization.denied.cvs.response.no.matching.service.key','authorization.denied.cvs.response.no.matching.service.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('authorization.denied.vehicle.is.stolen.key','authorization.denied.vehicle.is.stolen.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('bad.request.unknown.uin.key','bad.request.unknown.uin.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('duplicate.message.key','duplicate.message.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('horn.quota.message.key','horn.quota.message.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('lights.quota.message.key','lights.quota.message.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.app.automatical.vehicle.state.description.key','parameters.app.automatical.vehicle.state.description.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.app.automatical.vehicle.state.label.key','parameters.app.automatical.vehicle.state.label.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.app.caller.quota.description.key','parameters.app.caller.quota.description.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.app.caller.quota.duration.min.description.key','parameters.app.caller.quota.duration.min.description.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.app.caller.quota.duration.min.label.key','parameters.app.caller.quota.duration.min.label.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.app.caller.quota.label.key','parameters.app.caller.quota.label.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.app.exchange.timeout.min.description.key','parameters.app.exchange.timeout.min.description.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.app.exchange.timeout.min.label.key','parameters.app.exchange.timeout.min.label.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.app.horn.quota.description.key','parameters.app.horn.quota.description.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.app.horn.quota.duration.min.description.key','parameters.app.horn.quota.duration.min.description.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.app.horn.quota.duration.min.label.key','parameters.app.horn.quota.duration.min.label.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.app.horn.quota.label.key','parameters.app.horn.quota.label.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.app.lights.quota.description.key','parameters.app.lights.quota.description.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.app.lights.quota.duration.min.description.key','parameters.app.lights.quota.duration.min.description.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.app.lights.quota.duration.min.label.key','parameters.app.lights.quota.duration.min.label.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.app.lights.quota.label.key','parameters.app.lights.quota.label.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.app.proxy.description.key','parameters.app.proxy.description.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.app.proxy.host.description.key','parameters.app.proxy.host.description.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.app.proxy.host.label.key','parameters.app.proxy.host.label.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.app.proxy.label.key','parameters.app.proxy.label.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.app.proxy.password.description.key','parameters.app.proxy.password.description.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.app.proxy.password.label.key','parameters.app.proxy.password.label.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.app.proxy.username.description.key','parameters.app.proxy.username.description.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.app.proxy.username.label.key','parameters.app.proxy.username.label.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.app.remote.alarm.id.description.key','parameters.app.remote.alarm.id.description.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.app.remote.alarm.id.label.key','parameters.app.remote.alarm.id.label.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.bytel.data.length.description.key','parameters.bytel.data.length.description.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.bytel.data.length.label.key','parameters.bytel.data.length.label.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.bytel.sms.adm.description.key','parameters.bytel.sms.adm.description.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.bytel.sms.adm.label.key','parameters.bytel.sms.adm.label.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.bytel.sms.dspt.description.key','parameters.bytel.sms.dspt.description.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.bytel.sms.dspt.label.key','parameters.bytel.sms.dspt.label.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.bytel.sms.icp.description.key','parameters.bytel.sms.icp.description.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.bytel.sms.icp.label.key','parameters.bytel.sms.icp.label.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.bytel.sms.id.offer.description.key','parameters.bytel.sms.id.offer.description.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.bytel.sms.id.offer.label.key','parameters.bytel.sms.id.offer.label.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.bytel.sms.message.id.description.key','parameters.bytel.sms.message.id.description.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.bytel.sms.message.id.label.key','parameters.bytel.sms.message.id.label.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.bytel.sms.message.protocol.version.description.key','parameters.bytel.sms.message.protocol.version.description.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.bytel.sms.message.protocol.version.label.key','parameters.bytel.sms.message.protocol.version.label.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.bytel.sms.message.type.description.key','parameters.bytel.sms.message.type.description.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.bytel.sms.message.type.label.key','parameters.bytel.sms.message.type.label.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.bytel.sms.nb.retry.description.key','parameters.bytel.sms.nb.retry.description.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.bytel.sms.nb.retry.label.key','parameters.bytel.sms.nb.retry.label.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.bytel.sms.path.description.key','parameters.bytel.sms.path.description.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.bytel.sms.path.label.key','parameters.bytel.sms.path.label.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.bytel.sms.protocol.version.description.key','parameters.bytel.sms.protocol.version.description.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.bytel.sms.protocol.version.label.key','parameters.bytel.sms.protocol.version.label.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.bytel.sms.retry.delay.description.key','parameters.bytel.sms.retry.delay.description.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.bytel.sms.retry.delay.label.key','parameters.bytel.sms.retry.delay.label.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.bytel.sms.service.type.description.key','parameters.bytel.sms.service.type.description.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.bytel.sms.service.type.label.key','parameters.bytel.sms.service.type.label.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.bytel.sms.to.type.description.key','parameters.bytel.sms.to.type.description.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.bytel.sms.to.type.label.key','parameters.bytel.sms.to.type.label.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.bytel.sms.uri.description.key','parameters.bytel.sms.uri.description.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.bytel.sms.uri.label.key','parameters.bytel.sms.uri.label.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.cvs.endpoint.url.description.key','parameters.cvs.endpoint.url.description.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.cvs.endpoint.url.label.key','parameters.cvs.endpoint.url.label.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.cvs.cvsMock.description.key','parameters.cvs.cvsMock.description.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.cvs.cvsMock.label.key','parameters.cvs.cvsMock.label.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.cvs.password.description.key','parameters.cvs.password.description.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.cvs.password.label.key','parameters.cvs.password.label.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.cvs.username.description.key','parameters.cvs.username.description.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('parameters.cvs.username.label.key','parameters.cvs.username.label.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('process.900.request.accepted.key','process.900.request.accepted.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('process.901.vehicle.asleep.key','process.901.vehicle.asleep.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('process.902.checking.vehicle.state.key','process.902.checking.vehicle.state.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('process.903.request.forwarded.to.vehicle.key','process.903.request.forwarded.to.vehicle.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('request.error.correlation.id.error.message.key','request.error.correlation.id.error.message.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('rights.error.stolen.vehicle.not.declared.stolen.key','rights.error.stolen.vehicle.not.declared.stolen.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('rights.error.ves.sev.not.stopped.key','rights.error.ves.sev.not.stopped.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('technical.error.no.vehicle.found.for.uin.key','technical.error.no.vehicle.found.for.uin.key','en');
Insert into SEED_I18N_KEY_TRANS (SEED_I18N_KEY_ID,TRANSLATIONS_KEY_ID,TRANSLATIONS_LOCALE) values ('user.quota.message.key','user.quota.message.key','en');


commit;