package com.inetpsa.rcz.application.handlers.event;

import com.inetpsa.rcz.application.util.LocalizationKey;
import com.inetpsa.rcz.domain.model.enums.ProcessStatus;
import com.inetpsa.rcz.domain.model.event.VehicleCommandSent;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.payload.response.ProcessPayload;

import java.util.Date;

public class VehicleCommandSentHandler extends AbstractProcessEventHandler<VehicleCommandSent> {

    @Override
    protected ProcessPayload buildProcessPayload(Exchange exchange) {
        ProcessPayload processPayload = new ProcessPayload();
        processPayload.setVin(exchange.getVin());
        processPayload.setCode(ProcessStatus.REQUEST_SENT_TO_BTA.code());
        processPayload.setCorrelationId(exchange.getCorrelationId());
        processPayload.setDate(new Date());
        processPayload.setMessage(localizationService.localize(LocalizationKey.PROCESS_903_REQUEST_FORWARDED_TO_VEHICLE_KEY));
        return processPayload;
    }
}
