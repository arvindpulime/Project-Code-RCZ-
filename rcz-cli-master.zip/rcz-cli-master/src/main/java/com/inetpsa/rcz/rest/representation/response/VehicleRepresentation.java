package com.inetpsa.rcz.rest.representation.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.inetpsa.rcz.domain.model.vehicle.Vehicle;
import org.seedstack.business.assembler.DtoOf;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.util.Objects;

import static com.inetpsa.rcz.domain.model.payload.ValidationPattern.PATTERN_VIN;

@DtoOf(Vehicle.class)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class VehicleRepresentation {

    @NotNull
    @JsonProperty("uin")
    private String uin;

    @NotNull
    @JsonProperty("msisdn")
    private String msisdn;

    @NotNull
    @JsonProperty("typ_box")
    private String btaType;

    @NotNull
    @Pattern(regexp = PATTERN_VIN)
    @JsonProperty("vin")
    private String vin;

    public VehicleRepresentation() {
    }

    public String getUin() {
        return uin;
    }

    public VehicleRepresentation setUin(String uin) {
        this.uin = uin;
        return this;
    }

    public String getMsisdn() {
        return msisdn;
    }

    public VehicleRepresentation setMsisdn(String msisdn) {
        this.msisdn = msisdn;
        return this;
    }

    public String getBtaType() {
        return btaType;
    }

    public VehicleRepresentation setBtaType(String btaType) {
        this.btaType = btaType;
        return this;
    }

    public String getVin() {
        return vin;
    }

    public VehicleRepresentation setVin(String vin) {
        this.vin = vin;
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        VehicleRepresentation that = (VehicleRepresentation) o;
        return Objects.equals(uin, that.uin);
    }

    @Override
    public int hashCode() {
        return Objects.hash(uin);
    }
}
