package com.inetpsa.rcz.application.handlers.payload.preconditioning;

import com.inetpsa.rcz.application.handlers.payload.BTARequestHandler;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.payload.data.Preconditioning;
import com.inetpsa.rcz.domain.model.payload.data.PreconditioningBTA;
import com.inetpsa.rcz.domain.model.payload.request.BTARequestPayload;
import com.inetpsa.rcz.domain.model.payload.request.RequestPayload;

import java.util.Date;

public class PreconditioningBTARequestHandler implements BTARequestHandler<Preconditioning, PreconditioningBTA> {

    public static final String ACTIVATE = "activate";

    @Override
    public BTARequestPayload<PreconditioningBTA> handle(Exchange exchange, RequestPayload<Preconditioning> requestPayload) {
        BTARequestPayload<PreconditioningBTA> btaRequest = new BTARequestPayload<>();
        btaRequest.setRequestDate(new Date());
        btaRequest.setData(new PreconditioningBTA(requestPayload.getRequestParameters().getPrograms(), getAsap(requestPayload.getRequestParameters().getAsap())));
        btaRequest.setRequestId(exchange.getId());
        return btaRequest;
    }

    private Integer getAsap(String asap) {
        if (ACTIVATE.contentEquals(asap)) {
            return PreconditioningBTA.ACTIVATE;
        }
        return PreconditioningBTA.DEACTIVATE;
    }
}