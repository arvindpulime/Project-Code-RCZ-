package com.inetpsa.rcz.application.handlers.event;

import com.inetpsa.rcz.application.exceptions.ApplicationException;
import com.inetpsa.rcz.application.handlers.payload.BTARequestHandler;
import com.inetpsa.rcz.application.handlers.payload.RequestHandler;
import com.inetpsa.rcz.application.services.AccessService;
import com.inetpsa.rcz.application.services.PublisherService;
import com.inetpsa.rcz.application.services.PublisherService.Target.TargetBuilder;
import com.inetpsa.rcz.domain.model.action.ActionType;
import com.inetpsa.rcz.domain.model.enums.EventMessage;
import com.inetpsa.rcz.domain.model.enums.ResponseStatus;
import com.inetpsa.rcz.domain.model.event.ErrorOccurred;
import com.inetpsa.rcz.domain.model.event.VehicleCommandSent;
import com.inetpsa.rcz.domain.model.event.VehicleResponseReceived;
import com.inetpsa.rcz.domain.model.event.VehicleStateResponseReceived;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.log.LogMessage;
import com.inetpsa.rcz.domain.model.payload.request.BTARequestPayload;
import com.inetpsa.rcz.domain.model.payload.request.RequestPayload;
import com.inetpsa.rcz.domain.model.payload.topic.BtaTopicsResolver;
import com.inetpsa.rcz.domain.model.payload.topic.Topic;
import com.inetpsa.rcz.domain.services.ExchangeService;
import com.inetpsa.rcz.domain.services.LogService;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;
import org.seedstack.business.domain.BaseDomainEventHandler;
import org.seedstack.business.domain.DomainEventPublisher;
import org.seedstack.business.domain.DomainRegistry;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;

import static com.inetpsa.rcz.application.util.TypeResolver.*;

public class VehicleStateResponseReceivedHandler extends BaseDomainEventHandler<VehicleStateResponseReceived> {
    @Logging
    protected Logger logger;

    @Inject
    private ExchangeService exchangeService;

    @Inject
    private DomainRegistry domainRegistry;

    @Named("mqtt")
    @Inject
    private PublisherService publisherService;

    @Inject
    private DomainEventPublisher eventPublisher;

    @Inject
    private LogService logService;

    @Inject
    private AccessService accessService;

    @Override
    public void onEvent(VehicleStateResponseReceived event) {
        Exchange exchange = event.getExchange();
        try {
            accessService.checkAccess(event.getBtaResponsePayload(), exchange);
            if (ActionType.VEHICLE_STATE.equals(exchange.getAction().getActionType())) {
                exchange.setResponseStatus(ResponseStatus.STATUS_OK);
                eventPublisher.publish(new VehicleResponseReceived(exchange, event.getBtaResponsePayload()));
            } else {
                // build & save BTA request
                BTARequestHandler<?, ?> btaRequestHandler = domainRegistry.getService(BTA_REQUEST_TYPES.get(exchange.getAction()));
                RequestHandler requestHandler = domainRegistry.getService(REQUEST_TYPES.get(exchange.getAction()));
                RequestPayload requestPayload = requestHandler.handle(exchange.getRequest().getRawJson());
                BTARequestPayload<?> btaRequestPayload = btaRequestHandler.handle(exchange, requestPayload);
                String btaRequestJson = JsonConverter.convert(btaRequestPayload);
                // veh is awake ?
                // -- no VehicleWakeUpRequested
                // -- yes continue
                Topic topic = new Topic(exchange.getTopic());
                BtaTopicsResolver btaTopicsResolver = domainRegistry.getService(BTA_TOPICRESOLVER_TYPES.get(exchange.getAction()));
                String btaTopic = btaTopicsResolver.resolve(exchange.getUin(), topic, requestPayload);

                publisherService.publish(btaRequestJson, TargetBuilder.builder().withTopic(btaTopic).build());
                // VehicleCommandSent --> log request BTA
                //TODO UPDATE NEW STATUS SENT TO ATB
                logService.info(LogMessage.create(EventMessage.REQUEST_SENT_TO_VEHICLE).data(btaRequestJson).topic(btaTopic), exchange);
                eventPublisher.publish(new VehicleCommandSent(exchange));
            }

        } catch (ApplicationException e) {//NOSONAR
            logger.error(e.getMessage(), e);
            eventPublisher.publish(new ErrorOccurred(exchange, e.getResponseStatus(), e.getMessage()));
        }
    }

}
