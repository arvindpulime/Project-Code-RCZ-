package com.inetpsa.rcz.application.configuration;

import org.seedstack.coffig.Config;

@Config("rcz")
public class RczConfig {

    private LoggerConfig appLogger = new LoggerConfig();
    private ExchangeConfig exchange = new ExchangeConfig();
    private ClientConfig cvs = new ClientConfig();
    private ClientConfig refser = new ClientConfig();
    private ClientConfig proxy = new ClientConfig();
    private ClientConfig commodore = new ClientConfig();
    private Validation validation = new Validation();
    private QuotaExclusions quotaExclusions = new QuotaExclusions();

    public LoggerConfig getAppLogger() {
        return appLogger;
    }

    public ExchangeConfig getExchange() {
        return exchange;
    }

    public ClientConfig getCvs() {
        return cvs;
    }

    public ClientConfig getProxy() {
        return proxy;
    }

    public Validation getValidation() {
        return validation;
    }

    public ClientConfig getCommodore() {
        return commodore;
    }

    public static class Validation {
        private String language = "en";

        public String getLanguage() {
            return language;
        }
    }

    public ClientConfig getRefser() {
        return refser;
    }

    public QuotaExclusions getQuotaExclusions() {
        return quotaExclusions;
    }
}
