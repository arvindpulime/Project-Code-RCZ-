package com.inetpsa.rcz.application.services;

import org.seedstack.business.Service;

@Service
public interface LocalizationService {

    /**
     * Return a localized string based on the configured default locale and key. The
     * pattern is formatted according to the given arguments
     *
     * @param key  The i18n key to translate.
     * @param args The arguments used for message formatting.
     * @return The translation result.
     */
    String localize(String key, Object... args);
}
