package com.inetpsa.rcz.application.exceptions;

public class InvalidVehicleException extends Exception {

    public InvalidVehicleException(String message) {
        super(message);
    }
}
