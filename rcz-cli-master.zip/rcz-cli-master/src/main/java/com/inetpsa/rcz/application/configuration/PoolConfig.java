package com.inetpsa.rcz.application.configuration;

import org.seedstack.coffig.SingleValue;

public class PoolConfig {
    @SingleValue
    private boolean enabled = true;
    private int coreSize = 1;
    private int maxSize = 2;
    private int queueSize = 500;
    private int keepAlive = 60;
    private PoolConfig.RejectedExecutionPolicy rejectedExecutionPolicy;

    public PoolConfig() {
        this.rejectedExecutionPolicy = PoolConfig.RejectedExecutionPolicy.CALLER_RUNS;
    }

    public boolean isEnabled() {
        return this.enabled;
    }

    public PoolConfig setEnabled(boolean enabled) {
        this.enabled = enabled;
        return this;
    }

    public int getCoreSize() {
        return this.coreSize;
    }

    public PoolConfig setCoreSize(int coreSize) {
        this.coreSize = coreSize;
        return this;
    }

    public int getMaxSize() {
        return this.maxSize;
    }

    public PoolConfig setMaxSize(int maxSize) {
        this.maxSize = maxSize;
        return this;
    }

    public int getQueueSize() {
        return this.queueSize;
    }

    public PoolConfig setQueueSize(int queueSize) {
        this.queueSize = queueSize;
        return this;
    }

    public int getKeepAlive() {
        return this.keepAlive;
    }

    public PoolConfig setKeepAlive(int keepAlive) {
        this.keepAlive = keepAlive;
        return this;
    }

    public PoolConfig.RejectedExecutionPolicy getRejectedExecutionPolicy() {
        return this.rejectedExecutionPolicy;
    }

    public PoolConfig setRejectedExecutionPolicy(PoolConfig.RejectedExecutionPolicy rejectedExecutionPolicy) {
        this.rejectedExecutionPolicy = rejectedExecutionPolicy;
        return this;
    }

    public static enum RejectedExecutionPolicy {
        ABORT,
        DISCARD,
        CALLER_RUNS,
        DISCARD_OLDEST;

        private RejectedExecutionPolicy() {
        }
    }
}
