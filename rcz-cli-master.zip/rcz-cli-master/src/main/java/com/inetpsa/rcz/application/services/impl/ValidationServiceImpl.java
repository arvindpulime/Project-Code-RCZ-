package com.inetpsa.rcz.application.services.impl;

import com.inetpsa.rcz.application.configuration.RczConfig;
import com.inetpsa.rcz.application.exceptions.ApplicationException;
import com.inetpsa.rcz.application.services.LocalizationService;
import com.inetpsa.rcz.application.services.ValidationService;
import com.inetpsa.rcz.application.util.LocalizationKey;
import com.inetpsa.rcz.domain.model.action.Action;
import com.inetpsa.rcz.domain.model.enums.CallerType;
import com.inetpsa.rcz.domain.model.enums.ResponseStatus;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.parameter.ParameterKey;
import com.inetpsa.rcz.domain.repository.ExchangeRepository;
import com.inetpsa.rcz.domain.services.ParameterService;
import com.inetpsa.rcz.domain.services.PayloadValidationService;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.transaction.Transactional;

import javax.inject.Inject;
import javax.validation.ValidationException;
import java.util.Calendar;
import java.util.Date;

@JpaUnit("rcz")
public class ValidationServiceImpl implements ValidationService {

    @Inject
    private ExchangeRepository exchangeRepository;

    @Configuration
    private RczConfig rczConfig;

    @Inject
    private LocalizationService localizationService;

    @Inject
    private ParameterService parameterService;

    @Inject
    private PayloadValidationService payloadValidationService;


    @Override
    public <T> void validateRequest(T requestPayload) throws ApplicationException {
        try {
            payloadValidationService.validateRequest(requestPayload, rczConfig.getValidation().getLanguage());
        } catch (ValidationException e) {
            throw new ApplicationException(e.getMessage(), ResponseStatus.BAD_REQUEST);

        }
    }

    @Override
    @Transactional(readOnly = true)
    public void checkQuota(Exchange exchange) throws ApplicationException {
        if (checkForNoQuotaExclusion(exchange)) {
            checkUserQuota(exchange);
            checkDailyUserQuota(exchange);
            if (Action.HORN.equals(exchange.getAction())) {
                checkQuotaForHorn(exchange);
            }
            if (Action.LIGHTS.equals(exchange.getAction())) {
                checkQuotaForLight(exchange);
            }
        }
    }

    @Override
    @Transactional(readOnly = true)
    public void checkTimeout(Exchange exchange) throws ApplicationException {
        Integer timeout = Integer.parseInt(parameterService.getParameterValue(ParameterKey.APP_EXCHANGE_TIMEOUT_MIN));
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        calendar.add(Calendar.MINUTE, -timeout);
        Date timeoutDate = calendar.getTime();
        if( exchange.getRequest()!=null && timeoutDate.getTime() > exchange.getRequest().getSentDate().getTime()){
            throw new ApplicationException(localizationService.localize(LocalizationKey.VEHICLE_RESPONSE_ERROR_ALREADY_IN_TIMEOUT), ResponseStatus.VEHICLE_CONNECTION_TIMEOUT);
        }
    }

    private boolean checkForNoQuotaExclusion(Exchange exchange) {
        if (CallerType.PARTNER.equals(exchange.getCallerType())) {
            return !rczConfig.getQuotaExclusions().getPartners().stream().anyMatch(caller -> caller.equals(exchange.getCallerId()));
        }
        return true;
    }

    public void checkUserQuota(Exchange exchange) throws ApplicationException {
        int duration = Integer.parseInt(parameterService.getParameterValue(ParameterKey.APP_CALLER_QUOTA_DURATION_MIN));
        int quota = Integer.parseInt(parameterService.getParameterValue(ParameterKey.APP_CALLER_QUOTA));
        if (!exchangeRepository.checkQuotaByCaller(exchange.getCallerId(), exchange.getRequest().getReceivedDate(), duration, quota)) {
            throw new ApplicationException(localizationService.localize(LocalizationKey.USER_QUOTA_MESSAGE_KEY, duration, quota), ResponseStatus.REQUESTS_QUOTA_EXCEEDED);
        }
    }

    public void checkDailyUserQuota(Exchange exchange) throws ApplicationException {
        int duration = Integer.parseInt(parameterService.getParameterValue(ParameterKey.APP_CALLER_DAILY_QUOTA_DURATION_MIN));
        int quota = Integer.parseInt(parameterService.getParameterValue(ParameterKey.APP_CALLER_DAILY_QUOTA));
        boolean enabled = Boolean.valueOf(parameterService.getParameterValue(ParameterKey.APP_CALLER_DAILY_QUOTA_ENABLED));
        if (enabled
                && !exchangeRepository.checkQuotaByCallerAndSentToBta(exchange.getCallerId(), exchange.getRequest().getReceivedDate(), duration, quota)) {
            throw new ApplicationException(localizationService.localize(LocalizationKey.USER_DAILY_QUOTA_MESSAGE_KEY, duration, quota), ResponseStatus.REQUESTS_QUOTA_EXCEEDED);
        }
    }

    @Override
    @Transactional
    public void checkUserQuotaForWarning(Exchange exchange) throws ApplicationException {
        int duration = Integer.parseInt(parameterService.getParameterValue(ParameterKey.APP_CALLER_QUOTA_WARNING_DURATION_MIN));
        int quota = Integer.parseInt(parameterService.getParameterValue(ParameterKey.APP_CALLER_QUOTA_WARNING));
        if (!exchangeRepository.checkQuotaByCallerAndWakeUpCall(exchange.getCallerId(), exchange.getRequest().getReceivedDate(), duration, quota)) {
            throw new ApplicationException(localizationService.localize(LocalizationKey.USER_QUOTA_WARNING_MESSAGE_KEY, duration, quota), ResponseStatus.REQUESTS_QUOTA_WARNING);
        }
    }

    private void checkQuotaForHorn(Exchange exchange) throws ApplicationException {
        int duration = Integer.parseInt(parameterService.getParameterValue(ParameterKey.APP_HORN_QUOTA_DURATION_MIN));
        int quota = Integer.parseInt(parameterService.getParameterValue(ParameterKey.APP_HORN_QUOTA));
        if (!exchangeRepository.checkQuotaForAction(Action.HORN, exchange.getCallerId(), exchange.getVin(), duration, quota)) {
            throw new ApplicationException(localizationService.localize(LocalizationKey.HORN_QUOTA_MESSAGE_KEY, duration, quota), ResponseStatus.HORN_QUOTA_EXCEEDED);
        }
    }

    private void checkQuotaForLight(Exchange exchange) throws ApplicationException {
        int duration = Integer.parseInt(parameterService.getParameterValue(ParameterKey.APP_LIGHTS_QUOTA_DURATION_MIN));
        int quota = Integer.parseInt(parameterService.getParameterValue(ParameterKey.APP_LIGHTS_QUOTA));
        if (!exchangeRepository.checkQuotaForAction(Action.LIGHTS, exchange.getCallerId(), exchange.getVin(), duration, quota)) {
            throw new ApplicationException(localizationService.localize(LocalizationKey.LIGHTS_QUOTA_MESSAGE_KEY, duration, quota), ResponseStatus.LIGHTS_QUOTA_EXCEEDED);
        }
    }

    public void checkActionRight(Exchange exchange) throws ApplicationException {
        // check if immo, tracking and stolenvin are sent by partners only
        if ((Action.IMMOBILIZATION.equals(exchange.getAction())
                || Action.TRACKING.equals(exchange.getAction())
                || Action.VEHICLE_STATE_STOLEN.equals(exchange.getAction())
                || Action.STOLEN_VIN.equals(exchange.getAction()))
                && exchange.getCallerType() != CallerType.PARTNER) {
            throw new ApplicationException(localizationService.localize(LocalizationKey.AUTHORIZATION_DENIED_CHECK_ACTION_RIGHT_PERMISSION_DENIED_KEY), ResponseStatus.AUTHORIZATION_DENIED);
        }
    }

    @Override
    @Transactional(readOnly = true)
    public void checkDuplicate(Exchange exchange) throws ApplicationException {
        if (exchangeRepository.callerHasDuplicate(exchange)) {
            throw new ApplicationException(localizationService.localize(LocalizationKey.DUPLICATE_MESSAGE_KEY), ResponseStatus.DUPLICATE);
        }
    }

}
