package com.inetpsa.rcz.application.configuration;

public class LoggerConfig {
    private String [] implementations = {"database-logger", "slf4j-logger"};

    public String[] getImplementations() {
        return implementations;
    }
}
