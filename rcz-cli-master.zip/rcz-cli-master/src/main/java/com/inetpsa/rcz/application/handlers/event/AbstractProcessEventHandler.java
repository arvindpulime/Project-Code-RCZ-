package com.inetpsa.rcz.application.handlers.event;

import com.inetpsa.rcz.application.services.LocalizationService;
import com.inetpsa.rcz.application.services.PublisherService;
import com.inetpsa.rcz.application.services.PublisherService.Target.TargetBuilder;
import com.inetpsa.rcz.domain.model.enums.EventMessage;
import com.inetpsa.rcz.domain.model.enums.ProcessStatus;
import com.inetpsa.rcz.domain.model.event.AbstractExchangeEvent;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.log.LogMessage;
import com.inetpsa.rcz.domain.model.payload.response.ProcessPayload;
import com.inetpsa.rcz.domain.model.payload.topic.Topic;
import com.inetpsa.rcz.domain.services.ExchangeService;
import com.inetpsa.rcz.domain.services.LogService;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;
import org.seedstack.business.domain.BaseDomainEventHandler;

import javax.inject.Inject;
import javax.inject.Named;

public abstract class AbstractProcessEventHandler<E extends AbstractExchangeEvent> extends BaseDomainEventHandler<E> {

    @Inject
    protected LogService logService;

    @Named("mqtt")
    @Inject
    private PublisherService publisherService;

    @Inject
    private ExchangeService exchangeService;

    @Inject
    protected LocalizationService localizationService;

    public void onEvent(E event) {
        Exchange exchange = event.getExchange();
        ProcessPayload processPayload = buildProcessPayload(exchange);
        Topic topic = new Topic(event.getExchange().getTopic());
        String processRequest = JsonConverter.convert(processPayload);
        final String targetTopic = topic.toTarget(true);
        publisherService.publish(processRequest, TargetBuilder.builder().withTopic(targetTopic).build());
        logService.info(LogMessage.create(EventMessage.PROCESS_REQUEST_SENT).data(processRequest).topic(targetTopic), exchange);
        updateExchangeProcess(exchange, processPayload.getProcessCode());
    }

    protected void updateExchangeProcess(Exchange exchange, ProcessStatus processStatus) {
        exchange.setProcessStatus(processStatus);
        exchangeService.update(exchange);
    }

    protected abstract ProcessPayload buildProcessPayload(Exchange exchange);

}
