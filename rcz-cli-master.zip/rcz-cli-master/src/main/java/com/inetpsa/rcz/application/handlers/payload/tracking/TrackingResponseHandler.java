package com.inetpsa.rcz.application.handlers.payload.tracking;

import com.inetpsa.rcz.application.handlers.payload.AbstractResponseHandler;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.payload.data.Data;
import com.inetpsa.rcz.domain.model.payload.data.Tracking;

public class TrackingResponseHandler extends AbstractResponseHandler<Tracking> {
    @Override
    protected Tracking handleResponseData(Data data, Exchange exchange) {
        return null;
    }
}
