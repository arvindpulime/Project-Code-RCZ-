package com.inetpsa.rcz.rest.representation;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ServiceRepresentation implements Serializable {

    @JsonProperty("name")
    private String name;

    @JsonProperty("code")
    private String code;

    @JsonProperty("operators")
    @JsonDeserialize(as = ArrayList.class, contentAs = String.class)
    private List<String> operators;

    @JsonProperty("mqtt_service")
    private String mqttService;

    /**
     * Specific to rights
     */
    @JsonProperty("mqtt_organisation")
    private String mqttOrganization;

    /**
     * Specific to rights
     */
    @JsonProperty("authentication_type")
    private String authenticationType;

    public ServiceRepresentation() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public List<String> getOperators() {
        return operators;
    }

    public void setOperators(List<String> operators) {
        this.operators = operators;
    }

    public String getMqttService() {
        return mqttService;
    }

    public void setMqttService(String mqttService) {
        this.mqttService = mqttService;
    }

    public String getMqttOrganization() {
        return mqttOrganization;
    }

    public void setMqttOrganization(String mqttOrganization) {
        this.mqttOrganization = mqttOrganization;
    }

    public String getAuthenticationType() {
        return authenticationType;
    }

    public void setAuthenticationType(String authenticationType) {
        this.authenticationType = authenticationType;
    }
}