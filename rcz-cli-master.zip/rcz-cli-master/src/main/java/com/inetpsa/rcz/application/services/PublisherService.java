package com.inetpsa.rcz.application.services;

import org.seedstack.business.Service;

@Service
public interface PublisherService {

    /**
     * Publishes a message to a topic on multiple broker
     *
     * @param message - message to publisher
     * @param target  - to deliver the message to
     */
    void publish(String message, Target target);

    /**
     * Publishes a message to a topic on multiple broker
     *
     * @param message - message to publisher
     * @param target  - to deliver the message to
     * @param clients - destinations
     */
    void publish(String message, Target target, String... clients);

    class Target {
        private String topic;
        private String key;

        public String getTopic() {
            return topic;
        }

        public Target setTopic(String topic) {
            this.topic = topic;
            return this;
        }

        public String getKey() {
            return key;
        }

        public Target setKey(String key) {
            this.key = key;
            return this;
        }

        public static final class TargetBuilder {
            private String topic;
            private String key;

            private TargetBuilder() {
            }

            public static TargetBuilder builder() {
                return new TargetBuilder();
            }

            public TargetBuilder withTopic(String topic) {
                this.topic = topic;
                return this;
            }

            public TargetBuilder withKey(String key) {
                this.key = key;
                return this;
            }

            public Target build() {
                Target target = new Target();
                target.key = this.key;
                target.topic = this.topic;
                return target;
            }
        }
    }

}
