package com.inetpsa.rcz.application.handlers.event;

import com.fasterxml.jackson.core.type.TypeReference;
import com.inetpsa.rcz.domain.model.action.Action;
import com.inetpsa.rcz.domain.model.enums.CallerType;
import com.inetpsa.rcz.domain.model.enums.EventMessage;
import com.inetpsa.rcz.domain.model.enums.ExchangeStatus;
import com.inetpsa.rcz.domain.model.event.ServiceStateReceived;
import com.inetpsa.rcz.domain.model.event.VehicleWakeUpReceived;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.log.LogMessage;
import com.inetpsa.rcz.domain.model.payload.data.ServiceState;
import com.inetpsa.rcz.domain.model.payload.topic.Topic;
import com.inetpsa.rcz.domain.model.shared.Payload;
import com.inetpsa.rcz.domain.model.vehicle.State;
import com.inetpsa.rcz.domain.model.vehicle.Vehicle;
import com.inetpsa.rcz.domain.services.ExchangeService;
import com.inetpsa.rcz.domain.services.LogService;
import com.inetpsa.rcz.domain.services.VehicleService;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;
import org.seedstack.business.domain.BaseDomainEventHandler;
import org.seedstack.business.domain.DomainEventPublisher;
import org.seedstack.business.domain.Factory;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import javax.inject.Inject;
import java.util.Collection;
import java.util.Date;
import java.util.Optional;

public class ServiceStateReceivedHandler extends BaseDomainEventHandler<ServiceStateReceived> {

    public static final String SERVICE_STATE_ERROR = "ServiceState error for topic [{}], payload [{}]";

    @Inject
    private Factory<Vehicle> vehicleFactory;

    @Inject
    private ExchangeService exchangeService;

    @Inject
    private DomainEventPublisher eventPublisher;

    @Inject
    private LogService logService;

    @Inject
    private Factory<Exchange> exchangeFactory;

    @Logging
    private Logger logger;

    @Inject
    private VehicleService vehicleService;

    private static final int TRUE = 1;

    @Override
    public void onEvent(ServiceStateReceived serviceStateReceived) {
        Optional<Exception> exception = Optional.empty();
        Optional<Vehicle> vehicle = Optional.empty();
        try {
            vehicle = updateVehicle(serviceStateReceived);
        } catch (Exception e1) {//NOSONAR
            exception = Optional.of(e1);
        } finally {
            Exchange exchange = initExchange(serviceStateReceived);
            try {
                logService.info(LogMessage.create(EventMessage.SERVICE_STATE_RECEIVED).data(serviceStateReceived.getMessage()), exchange);
                if (exception.isPresent()) {
                    throw exception.get();
                }
                logService.info(LogMessage.create(EventMessage.SERVICE_STATE_UPDATED), exchange);
                if (vehicle.isPresent() && vehicle.get().isConnected()) {
                    resumePendingExchange(vehicle.get().getId());
                }
            } catch (Exception e) {//NOSONAR
                exchange.setStatus(ExchangeStatus.ERROR);
                logger.debug(SERVICE_STATE_ERROR, serviceStateReceived.getTopic(), serviceStateReceived.getMessage(), e);
                logService.error(LogMessage.create(EventMessage.SERVICE_STATE_ERROR).data(e.getMessage()), exchange);
                exchangeService.update(exchange);
            }
        }
    }

    private Optional<Vehicle> updateVehicle(ServiceStateReceived serviceStateReceived) {
        boolean serviceState = false;
        if (serviceStateReceived.getMessage() != null) {
            ServiceState status = JsonConverter.convert(serviceStateReceived.getMessage(), new TypeReference<ServiceState>() {
            });
            serviceState = status.getState() == TRUE;
        }
        return getUpdateVehicle(serviceStateReceived, serviceState);
    }

    Optional<Vehicle> getUpdateVehicle(ServiceStateReceived serviceStateReceived, boolean serviceState) {
        Optional<Vehicle> vehicle = vehicleService.find(serviceStateReceived.getTopic().getId());
        if (!vehicle.isPresent()) {
            vehicle = Optional.of(vehicleFactory.create(serviceStateReceived.getTopic().getId()));
        }
        State state = new State(serviceState, new Date());
        vehicle.get().setServiceState(state);
        vehicleService.save(vehicle.get());
        return vehicle;
    }

    private Exchange initExchange(ServiceStateReceived event) {
        Exchange exchange = exchangeFactory.create();
        String request = event.getMessage();
        Topic topic = event.getTopic();
        exchange.setCallerType(CallerType.VEHICLE);
        exchange.setCallerId(topic.getId());
        exchange.setRequest(new Payload(new Date(), request));
        exchange.setAction(Action.SERVICE_STATE);
        exchange.setTopic(topic.toString());
        exchange.setStatus(ExchangeStatus.FINISHED);
        exchange.setUin(topic.getId());
        exchangeService.update(exchange);
        return exchange;
    }

    private void resumePendingExchange(String uin) {
        Collection<Exchange> exchanges = exchangeService.findPendingAsleep(uin);
        exchanges.forEach(exchange -> eventPublisher.publish(new VehicleWakeUpReceived(exchange)));
    }
}
