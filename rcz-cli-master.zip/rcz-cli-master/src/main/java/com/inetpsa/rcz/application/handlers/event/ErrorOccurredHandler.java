package com.inetpsa.rcz.application.handlers.event;

import com.fasterxml.jackson.core.type.TypeReference;
import com.inetpsa.rcz.application.handlers.payload.ResponseHandler;
import com.inetpsa.rcz.application.services.PublisherService;
import com.inetpsa.rcz.application.services.PublisherService.Target.TargetBuilder;
import com.inetpsa.rcz.domain.model.enums.EventMessage;
import com.inetpsa.rcz.domain.model.enums.ExchangeStatus;
import com.inetpsa.rcz.domain.model.enums.ResponseStatus;
import com.inetpsa.rcz.domain.model.event.ErrorOccurred;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.log.LogMessage;
import com.inetpsa.rcz.domain.model.payload.request.RequestPayload;
import com.inetpsa.rcz.domain.model.payload.response.BTAResponsePayload;
import com.inetpsa.rcz.domain.model.payload.topic.Topic;
import com.inetpsa.rcz.domain.services.ExchangeService;
import com.inetpsa.rcz.domain.services.LogService;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;
import org.apache.commons.lang.StringUtils;
import org.seedstack.business.domain.BaseDomainEventHandler;
import org.seedstack.business.domain.DomainRegistry;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;

import static com.inetpsa.rcz.application.util.TypeResolver.RESPONSE_TYPES;

public class ErrorOccurredHandler extends BaseDomainEventHandler<ErrorOccurred> {

    @Logging
    private Logger logger;

    @Inject
    private ExchangeService exchangeService;

    @Inject
    private DomainRegistry domainRegistry;

    @Named("mqtt")
    @Inject
    private PublisherService publisherService;

    @Inject
    private LogService logService;


    @Override
    public void onEvent(ErrorOccurred errorOccurred) {
        try {
            updateWithError(errorOccurred.getExchange(), errorOccurred);
            if (ResponseStatus.FORMAT_ERROR.equals(errorOccurred.getResponseStatus())) {
                logService.error(LogMessage.create(EventMessage.REQUEST_ERROR).data(errorOccurred.getMessage()), errorOccurred.getExchange());
            } else {
                ResponseHandler<?> responseHandler = domainRegistry.getService(RESPONSE_TYPES.get(errorOccurred.getExchange().getAction()));
                logService.error(LogMessage.create(EventMessage.REQUEST_ERROR).data(errorOccurred.getMessage()), errorOccurred.getExchange(), LogService.AppLog.DATABASE);
                Topic topic = new Topic(errorOccurred.getExchange().getTopic());
                String responseJson = JsonConverter.convert(responseHandler.handle(errorOccurred.getExchange(), getBtaResponsePayload(errorOccurred)));
                String target = topic.toTarget(false);
                RequestPayload requestPayload = JsonConverter.convert(errorOccurred.getExchange().getRequest().getRawJson(), new TypeReference<RequestPayload>() {
                });
                if (requestPayload != null && StringUtils.isNotBlank(requestPayload.getCorrelationId())) {
                    publisherService.publish(responseJson, TargetBuilder.builder().withTopic(target).build());
                    // Event RequestSent
                    logService.info(LogMessage.create(EventMessage.RESPONSE_SENT).data(responseJson).topic(target), errorOccurred.getExchange());
                } else {
                    logService.info(LogMessage.create(EventMessage.RESPONSE_ERROR_NO_CORRELATION_ID).data(responseJson).topic(target), errorOccurred.getExchange());
                }
            }
        } catch (Exception e) {//NOSONAR
            logService.error(LogMessage.create(EventMessage.REQUEST_ERROR).data(errorOccurred.getMessage()), errorOccurred.getExchange());
        }
    }

    private BTAResponsePayload getBtaResponsePayload(ErrorOccurred errorOccurred) {
        BTAResponsePayload btaResponsePayload = new BTAResponsePayload();
        btaResponsePayload.setStatus(Integer.valueOf(errorOccurred.getResponseStatus().code()));
        btaResponsePayload.setReason(errorOccurred.getMessage());
        return btaResponsePayload;
    }

    private void updateWithError(Exchange exchange, ErrorOccurred errorOccurred) {
        exchange.setStatus(ExchangeStatus.ERROR);
        exchange.setResponseStatus(errorOccurred.getResponseStatus());
        exchangeService.update(exchange);
    }
}
