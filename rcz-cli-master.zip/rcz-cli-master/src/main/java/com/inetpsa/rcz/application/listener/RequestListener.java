package com.inetpsa.rcz.application.listener;

import com.fasterxml.jackson.core.type.TypeReference;
import com.google.common.base.Charsets;
import com.inetpsa.rcz.application.exceptions.JsonParseException;
import com.inetpsa.rcz.domain.model.action.Action;
import com.inetpsa.rcz.domain.model.action.ActionService;
import com.inetpsa.rcz.domain.model.action.ActionType;
import com.inetpsa.rcz.domain.model.enums.EventMessage;
import com.inetpsa.rcz.domain.model.enums.ExchangeStatus;
import com.inetpsa.rcz.domain.model.enums.ProcessStatus;
import com.inetpsa.rcz.domain.model.event.*;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.log.LogMessage;
import com.inetpsa.rcz.domain.model.payload.exception.InvalidTopicException;
import com.inetpsa.rcz.domain.model.payload.response.BTAResponsePayload;
import com.inetpsa.rcz.domain.model.payload.topic.Topic;
import com.inetpsa.rcz.domain.model.payload.topic.Topic.Tag;
import com.inetpsa.rcz.domain.services.ExchangeService;
import com.inetpsa.rcz.domain.services.LogService;
import com.inetpsa.rcz.domain.services.ParameterService;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.seedstack.business.domain.DomainEventPublisher;
import org.seedstack.mqtt.MqttListener;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import javax.inject.Inject;
import java.util.Optional;

@MqttListener(clients = "${rcz.mqtt.subscribe.clients}",
        topics = {"${rcz.mqtt.subscribe.horn.topics}", "${rcz.mqtt.subscribe.doors.topics}",
                "${rcz.mqtt.subscribe.lights.topics}", "${rcz.mqtt.subscribe.vehiclestate.topics}",
                "${rcz.mqtt.subscribe.requeststate.topics}", "${rcz.mqtt.subscribe.remotealarm.topics}",
                "${rcz.mqtt.subscribe.motionalert.topics}", "${rcz.mqtt.subscribe.stolenvin.topics}",
                "${rcz.mqtt.subscribe.tracking.topics}", "${rcz.mqtt.subscribe.immobilization.topics}",
                "${rcz.mqtt.subscribe.charging.topics}", "${rcz.mqtt.subscribe.chargingstate.topics}",
                "${rcz.mqtt.subscribe.preconditioning.topics}", "${rcz.mqtt.subscribe.servicestate.topics}",
                "${rcz.mqtt.subscribe.lowpowerinfo.topics}",
                "${rcz.mqtt.subscribe.response.topics}", "${rcz.mqtt.subscribe.devicemanagement.topics}"},
        qos = {"${rcz.mqtt.subscribe.horn.qos}", "${rcz.mqtt.subscribe.doors.qos}",
                "${rcz.mqtt.subscribe.lights.qos}", "${rcz.mqtt.subscribe.vehiclestate.qos}",
                "${rcz.mqtt.subscribe.requeststate.qos}", "${rcz.mqtt.subscribe.remotealarm.qos}",
                "${rcz.mqtt.subscribe.motionalert.qos}", "${rcz.mqtt.subscribe.stolenvin.qos}",
                "${rcz.mqtt.subscribe.tracking.qos}", "${rcz.mqtt.subscribe.immobilization.qos}",
                "${rcz.mqtt.subscribe.charging.qos}", "${rcz.mqtt.subscribe.chargingstate.qos}",
                "${rcz.mqtt.subscribe.preconditioning.qos}", "${rcz.mqtt.subscribe.servicestate.qos}",
                "${rcz.mqtt.subscribe.lowpowerinfo.qos}",
                "${rcz.mqtt.subscribe.response.qos}", "${rcz.mqtt.subscribe.devicemanagement.qos}"})
public class RequestListener implements MqttCallback {

    @Logging
    private Logger logger;

    @Inject
    private DomainEventPublisher eventPublisher;

    @Inject
    private ExchangeService exchangeService;

    @Inject
    protected LogService logService;

    @Inject
    private ParameterService parameterService;

    @Override
    public void connectionLost(Throwable cause) {

    }

    @Override
    public void messageArrived(String topic, MqttMessage message) throws Exception {
        try {
            String messageReceived = new String(message.getPayload(), Charsets.UTF_8);
            logger.debug("Request received from : [{}]", topic);
            logger.debug("Request content : [{}]", messageReceived);
            logger.debug("Event Request Received FIRE");
            fireEvent(topic, messageReceived);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
    }

    private void fireEvent(String topic, String message) {
        try{
            Topic t = new Topic(topic);
            final ActionType actionType = t.getActionType();

            if (ActionType.SERVICE_STATE == actionType) {
                eventPublisher.publish(new ServiceStateReceived(t, message));
            } else if (ActionType.REQUEST_STATE == actionType) {
                eventPublisher.publish(new RequestStateReceived(t, message));
            } else if (ActionType.IMMO_DATA == actionType && Tag.UIN == t.getTag()) {
                eventPublisher.publish(new ImmoStateReceived(t, message));
            } else if (ActionType.ALARM == actionType || ActionType.MOTION_ALERT == actionType) {
                eventPublisher.publish(new AlarmReceived(t, message));
            } else if (ActionType.VEHICLE_INFO.equals(actionType) && Tag.UIN == t.getTag()) {
                eventPublisher.publish(new VehicleInfoReceived(t, message, t.getId()));
            } else if (ActionType.LOW_POWER_INFO.equals(actionType) && Tag.UIN == t.getTag()) {
                eventPublisher.publish(new LowPowerInfoReceived(t, message, t.getId()));
            } else if (ActionService.DEVICE_MANAGEMENT.equals(t.getActionService()) && ActionType.STATE.equals(t.getActionType())) {
                eventPublisher.publish(new VehicleStateReceived(topic, message));
            } else if (ActionType.RESPONSE == actionType) {
                handleResponse(t, message);
            } else {
                eventPublisher.publish(new RequestReceived(t, message));
            }
        }catch (InvalidTopicException e){
            eventPublisher.publish(new VehicleStateReceived(topic, message));
        }
    }

    private void handleResponse(Topic topic, String message) {
        try {
            BTAResponsePayload btaResponsePayload = JsonConverter.convert(message, new TypeReference<BTAResponsePayload>() {
            });
            Optional<Exchange> exchange = exchangeService.findById(btaResponsePayload.getRequestId());
            if (!exchange.isPresent()) {
                logger.error("Technical error, Exchange not found for req_id : " + btaResponsePayload.getRequestId());
            } else if (Action.REMOTE_ALARM.equals(exchange.get().getAction())) {
                logService.info(LogMessage.create(EventMessage.ALARM_DELETE_RESPONSE_RECEIVED).data(message).topic(topic.toString()), exchange.get());
                eventPublisher.publish(new AlarmDeleted(exchange.get(), btaResponsePayload));
            } else if (ProcessStatus.PSA_VEH_STATE_REQUEST.equals(exchange.get().getProcessStatus())) {
                logService.info(LogMessage.create(EventMessage.VEHICLE_STATE_RESPONSE_RECEIVED_FROM_VEHICLE).data(message).topic(topic.toString()), exchange.get());
                eventPublisher.publish(new VehicleStateResponseReceived(exchange.get(), btaResponsePayload));
                eventPublisher.publish(new VehicleInfoReceived(topic, btaResponsePayload.getData().getValue(), exchange.get().getUin()));
            } else {
                if (ExchangeStatus.ERROR.equals(exchange.get().getStatus()) || ExchangeStatus.FINISHED.equals(exchange.get().getStatus())) {
                    logService.error(LogMessage.create(EventMessage.EXCHANGE_ALREADY_FINISHED).data(message).topic(topic.toString()), exchange.get());
                } else {
                    logService.info(LogMessage.create(EventMessage.RESPONSE_RECEIVED_FROM_VEHICLE).data(message).topic(topic.toString()), exchange.get());
                    eventPublisher.publish(new VehicleResponseReceived(exchange.get(), btaResponsePayload));
                    if (ActionType.LOW_POWER_INFO.equals(topic.getActionType())) {
                        eventPublisher.publish(new LowPowerInfoReceived(topic, btaResponsePayload.getData().getValue(), topic.getId()));
                    }
                }
            }
        } catch (JsonParseException e) {
            logger.error(e.getMessage(), e);
        }
    }

    @Override
    public void deliveryComplete(IMqttDeliveryToken token) {

    }

}
