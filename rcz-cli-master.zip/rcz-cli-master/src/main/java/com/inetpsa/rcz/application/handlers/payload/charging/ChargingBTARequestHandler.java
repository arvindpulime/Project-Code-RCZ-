package com.inetpsa.rcz.application.handlers.payload.charging;

import com.inetpsa.rcz.application.handlers.payload.BTARequestHandler;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.payload.data.Charging;
import com.inetpsa.rcz.domain.model.payload.data.ChargingBTA;
import com.inetpsa.rcz.domain.model.payload.request.BTARequestPayload;
import com.inetpsa.rcz.domain.model.payload.request.RequestPayload;

import java.util.Date;

public class ChargingBTARequestHandler implements BTARequestHandler<Charging, ChargingBTA> {

    @Override
    public BTARequestPayload<ChargingBTA> handle(Exchange exchange, RequestPayload<Charging> requestPayload) {
        BTARequestPayload<ChargingBTA> btaRequest = new BTARequestPayload<>();
        btaRequest.setRequestDate(new Date());
        btaRequest.setData(new ChargingBTA(requestPayload.getRequestParameters().getProgram(), getAsap(requestPayload.getRequestParameters().getType())));
        btaRequest.setRequestId(exchange.getId());
        return btaRequest;
    }


    private Integer getAsap(String type) {
        if (Charging.IMMEDIATE.contentEquals(type)) {
            return ChargingBTA.IMMEDIATE;
        }
        return ChargingBTA.DELAYED;
    }
}

