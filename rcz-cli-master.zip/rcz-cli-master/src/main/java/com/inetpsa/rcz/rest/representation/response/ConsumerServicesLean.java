package com.inetpsa.rcz.rest.representation.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.inetpsa.rcz.rest.representation.ServiceRepresentation;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author tuan.docao@ext.mpsa.com
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class ConsumerServicesLean implements Serializable {

    @JsonProperty("vin")
    private String vin;

    @JsonProperty("services")
    private Map<String, List<ServiceRepresentation>> services;

    public ConsumerServicesLean() {
    }

    public String getVin() {
        return vin;
    }

    public ConsumerServicesLean(String vin, Map<String, List<ServiceRepresentation>> services) {
        this.vin = vin;
        this.services = services;
    }


    public void setVin(String vin) {
        this.vin = vin;
    }

    public Map<String, List<ServiceRepresentation>> getServices() {
        return services;
    }

    public void setServices(HashMap<String, List<ServiceRepresentation>> services) {
        this.services = services;
    }
}
