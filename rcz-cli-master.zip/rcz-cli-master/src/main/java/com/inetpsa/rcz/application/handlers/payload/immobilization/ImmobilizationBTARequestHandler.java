package com.inetpsa.rcz.application.handlers.payload.immobilization;

import com.inetpsa.rcz.application.handlers.payload.BTARequestHandler;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.payload.ValidationPattern;
import com.inetpsa.rcz.domain.model.payload.data.Immobilization;
import com.inetpsa.rcz.domain.model.payload.request.BTARequestPayload;
import com.inetpsa.rcz.domain.model.payload.request.RequestPayload;

import java.util.Date;

public class ImmobilizationBTARequestHandler implements BTARequestHandler<Immobilization, Immobilization> {

    private static final String ACTIVATE = "activate";

    @Override
    public BTARequestPayload<Immobilization> handle(Exchange exchange, RequestPayload<Immobilization> requestPayload) {
        BTARequestPayload<Immobilization> btaRequest = new BTARequestPayload<>();
        btaRequest.setRequestDate(new Date());
        btaRequest.setRequestId(exchange.getId());
        boolean activate = ACTIVATE.equals(requestPayload.getRequestParameters().getAction());
        Immobilization immobilization = new Immobilization(activate);
        immobilization.setPassword(buildPassword(activate, exchange.getVin()));
        btaRequest.setData(immobilization);
        return btaRequest;
    }

    private String buildPassword(boolean activate, String vin) {
        if (vin != null && vin.matches(ValidationPattern.PATTERN_VIN)) {
            if (activate) {
                return vin.substring(10, 17);
            }else{
                return twoSComplementByChar(vin.substring(10, 17));
            }
        }
        return null;
    }

    private String twoSComplementByChar(String value){
        char[] chars = value.toCharArray();
        StringBuilder hex = new StringBuilder();
        for (char ch : chars) {
            hex.append(~(int)ch+1);
        }
        return hex.toString();
    }
}
