package com.inetpsa.rcz.rest.representation.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.validation.Valid;

/**
 * @author tuan.docao@ext.mpsa.com
 */
public class ConsumerRights {

    @JsonProperty("event_id")
    private String eventId;

    @JsonProperty("customer_id")
    private String customerId;

    @JsonProperty("vin")
    private String vin;

    @Valid
    @JsonProperty("grant")
    private Grant grant;

    public ConsumerRights() {
    }

    public String getEventId() {
        return eventId;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    public Grant getGrant() {
        return grant;
    }

    public void setGrant(Grant grant) {
        this.grant = grant;
    }
}
