package com.inetpsa.rcz.application.handlers.event;

import com.fasterxml.jackson.core.type.TypeReference;
import com.inetpsa.rcz.application.exceptions.ApplicationException;
import com.inetpsa.rcz.application.services.AuthorizationService;
import com.inetpsa.rcz.domain.model.enums.EventMessage;
import com.inetpsa.rcz.domain.model.enums.ExchangeStatus;
import com.inetpsa.rcz.domain.model.enums.ResponseStatus;
import com.inetpsa.rcz.domain.model.event.LowPowerInfoReceived;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.log.LogMessage;
import com.inetpsa.rcz.domain.model.payload.data.LowPowerInfo;
import com.inetpsa.rcz.domain.model.shared.Payload;
import com.inetpsa.rcz.domain.model.vehicle.Vehicle;
import com.inetpsa.rcz.domain.services.LogService;
import com.inetpsa.rcz.domain.services.VehicleService;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;
import org.apache.commons.lang.StringUtils;
import org.seedstack.business.domain.Factory;

import javax.inject.Inject;
import java.util.Date;
import java.util.Optional;

public class LowPowerInfoReceivedHandler extends AbstractVehicleInfoReceivedHandler<LowPowerInfoReceived> {

    public static final String VIN_UNREADABLE = "Was unable to read parameter VIN from LowPowerInfo";

    @Inject
    protected VehicleService vehicleService;

    @Inject
    protected Factory<Vehicle> vehicleFactory;

    @Inject
    private LogService logService;

    @Inject
    private AuthorizationService authorizationService;

    @Override
    public void onEvent(LowPowerInfoReceived event) {
        Exchange exchange = initExchange(event);
        try {
            LowPowerInfo lowPowerInfo = getLowPowerInfo(event);
            exchange.setVin(lowPowerInfo.getVin());
            authorizationService.authorizeActionFromUIN(exchange);
            Vehicle vehicle = mergeAndUpdate(event, lowPowerInfo);
            logService.info(LogMessage.create(EventMessage.VEHICLE_UPDATED).data(vehicle.getLowPowerInfo().getRawJson()), exchange);

        } catch (Exception e) {//NOSONAR
            exchange.setStatus(ExchangeStatus.ERROR);
            logService.error(LogMessage.create(EventMessage.VEHICLE_LOW_POWER_INFO_RECEPTION_ERROR).data(e.getMessage()), exchange);
            exchangeService.update(exchange);
        }
    }

    private Vehicle mergeAndUpdate(LowPowerInfoReceived vehicleInfoReceived, LowPowerInfo lowPowerInfo) throws ApplicationException {
        Optional<Vehicle> vehicle = vehicleService.find(vehicleInfoReceived.getUin());
        if (!vehicle.isPresent()) {
            vehicle = Optional.of(vehicleFactory.create(vehicleInfoReceived.getUin()));
        }
        vehicle.get().setLowPowerInfo(new Payload(new Date(), lowPowerInfo.getDate(), vehicleInfoReceived.getMessage()));
        vehicleService.save(vehicle.get());
        return vehicle.get();
    }

    private LowPowerInfo getLowPowerInfo(LowPowerInfoReceived event) throws ApplicationException {
        if (StringUtils.isNotBlank(event.getMessage())) {
            LowPowerInfo lowPowerInfo = JsonConverter.convert(event.getMessage(), new TypeReference<LowPowerInfo>() {
            });
            if (lowPowerInfo != null && StringUtils.isNotBlank(lowPowerInfo.getVin())) {
                return lowPowerInfo;
            }
        }
        throw new ApplicationException(VIN_UNREADABLE, ResponseStatus.VEHICLE_VALIDATION_ERROR);
    }


}
