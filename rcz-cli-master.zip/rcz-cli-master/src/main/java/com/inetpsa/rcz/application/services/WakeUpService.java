package com.inetpsa.rcz.application.services;

import com.inetpsa.rcz.application.exceptions.ApplicationException;
import com.inetpsa.rcz.domain.model.vehicle.Vehicle;
import org.seedstack.business.Service;

@Service
public interface WakeUpService {

    /**
     * wake up the vehicle
     * @param vehicle to wake
     */
    void wakeUp(Vehicle vehicle) throws ApplicationException;
}
