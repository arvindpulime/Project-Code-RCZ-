package com.inetpsa.rcz.application.handlers.payload.horn;

import com.inetpsa.rcz.application.handlers.payload.BTARequestHandler;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.payload.data.Horn;
import com.inetpsa.rcz.domain.model.payload.request.BTARequestPayload;
import com.inetpsa.rcz.domain.model.payload.request.RequestPayload;

import java.util.Date;

public class HornBTARequestHandler implements BTARequestHandler<Horn, Horn> {

    @Override
    public BTARequestPayload<Horn> handle(Exchange exchange, RequestPayload<Horn> requestPayload) {
        BTARequestPayload<Horn> btaRequest = new BTARequestPayload<>();
        btaRequest.setRequestDate(new Date());
        btaRequest.setData(new Horn(2, true));
        btaRequest.setRequestId(exchange.getId());
        return btaRequest;
    }
}

