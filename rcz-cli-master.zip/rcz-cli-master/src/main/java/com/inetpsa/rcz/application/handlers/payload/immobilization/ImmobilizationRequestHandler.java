package com.inetpsa.rcz.application.handlers.payload.immobilization;

import com.fasterxml.jackson.core.type.TypeReference;
import com.inetpsa.rcz.application.exceptions.ApplicationException;
import com.inetpsa.rcz.application.exceptions.JsonParseException;
import com.inetpsa.rcz.application.handlers.payload.RequestHandler;
import com.inetpsa.rcz.domain.model.enums.ResponseStatus;
import com.inetpsa.rcz.domain.model.payload.data.Immobilization;
import com.inetpsa.rcz.domain.model.payload.request.RequestPayload;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;

public class ImmobilizationRequestHandler implements RequestHandler<Immobilization> {
    @Override
    public RequestPayload<Immobilization> handle(String request) throws ApplicationException {
        try {
            return JsonConverter.convert(request, new TypeReference<RequestPayload<Immobilization>>() {
            });
        } catch (JsonParseException e) {
            throw new ApplicationException(e.getMessage(), e, ResponseStatus.FORMAT_ERROR);
        }
    }
}
