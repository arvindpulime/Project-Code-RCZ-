package com.inetpsa.rcz.application.util;

import com.inetpsa.rcz.domain.model.payload.topic.Topic;

public final class ConfigurationKeyBuilder {

    private static final String RCZ_MQTT_PUBLISH_PARAMETERS_KEY_PREFIX = "rcz.mqtt.publish.";

    public static String buildKey(Topic topic) {
        String key = RCZ_MQTT_PUBLISH_PARAMETERS_KEY_PREFIX + topic.getActionService().literal() + "." + topic.getActionType().literal();
        return key.toLowerCase();
    }
}
