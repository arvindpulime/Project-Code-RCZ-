package com.inetpsa.rcz.application.handlers.payload.tracking;

import com.fasterxml.jackson.core.type.TypeReference;
import com.inetpsa.rcz.application.exceptions.ApplicationException;
import com.inetpsa.rcz.application.exceptions.JsonParseException;
import com.inetpsa.rcz.application.handlers.payload.RequestHandler;
import com.inetpsa.rcz.domain.model.enums.ResponseStatus;
import com.inetpsa.rcz.domain.model.payload.data.Tracking;
import com.inetpsa.rcz.domain.model.payload.request.RequestPayload;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;

public class TrackingRequestHandler implements RequestHandler<Tracking> {
    @Override
    public RequestPayload<Tracking> handle(String request) throws ApplicationException {
        try {
            return JsonConverter.convert(request, new TypeReference<RequestPayload<Tracking>>() {
            });
        } catch (JsonParseException e) {
            throw new ApplicationException(e.getMessage(), e, ResponseStatus.FORMAT_ERROR);
        }
    }
}
