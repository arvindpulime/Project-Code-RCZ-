package com.inetpsa.rcz.application.handlers.event;

import com.inetpsa.rcz.application.util.LocalizationKey;
import com.inetpsa.rcz.domain.model.enums.ProcessStatus;
import com.inetpsa.rcz.domain.model.event.VehicleWakeUpRequested;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.payload.response.ProcessPayload;

import java.util.Date;

public class VehicleWakeUpRequestedHandler extends AbstractProcessEventHandler<VehicleWakeUpRequested> {

    @Override
    protected ProcessPayload buildProcessPayload(Exchange exchange) {
        ProcessPayload processPayload = new ProcessPayload();
        processPayload.setVin(exchange.getVin());
        processPayload.setCode(ProcessStatus.BTA_ASLEEP.code());
        processPayload.setCorrelationId(exchange.getCorrelationId());
        processPayload.setDate(new Date());
        processPayload.setMessage(localizationService.localize(LocalizationKey.PROCESS_901_VEHCILE_ASLEEP_KEY));
        return processPayload;
    }
}
