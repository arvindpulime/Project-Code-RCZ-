/*
 * Creation : 16 août 2016
 */
package com.inetpsa.rcz.application.handlers.payload.stolen;

import com.inetpsa.rcz.application.handlers.payload.BTARequestHandler;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.payload.data.StolenState;
import com.inetpsa.rcz.domain.model.payload.data.StolenVin;
import com.inetpsa.rcz.domain.model.payload.request.BTARequestPayload;
import com.inetpsa.rcz.domain.model.payload.request.RequestPayload;

import java.util.Date;

public class StolenVinBTARequestHandler implements BTARequestHandler<StolenVin, StolenState> {

    @Override
    public BTARequestPayload<StolenState> handle(Exchange exchange, RequestPayload<StolenVin> requestPayload) {
        BTARequestPayload<StolenState> btaRequest = new BTARequestPayload<>();
        btaRequest.setRequestDate(new Date());
        StolenState stolenState = new StolenState();
        stolenState.setStolenStateValue(requestPayload.getRequestParameters().getStolen());
        btaRequest.setData(stolenState);
        btaRequest.setRequestId(exchange.getId());
        return btaRequest;
    }

}
