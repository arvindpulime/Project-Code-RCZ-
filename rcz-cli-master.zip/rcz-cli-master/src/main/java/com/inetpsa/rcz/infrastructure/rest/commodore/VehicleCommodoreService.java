package com.inetpsa.rcz.infrastructure.rest.commodore;

import com.fasterxml.jackson.core.type.TypeReference;
import com.inetpsa.rcz.application.configuration.RczConfig;
import com.inetpsa.rcz.application.exceptions.ApplicationException;
import com.inetpsa.rcz.application.services.LocalizationService;
import com.inetpsa.rcz.application.services.ValidationService;
import com.inetpsa.rcz.application.services.VehicleUpstreamService;
import com.inetpsa.rcz.domain.model.enums.EventMessage;
import com.inetpsa.rcz.domain.model.enums.ResponseStatus;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.log.LogMessage;
import com.inetpsa.rcz.domain.model.parameter.ParameterKey;
import com.inetpsa.rcz.domain.model.vehicle.Vehicle;
import com.inetpsa.rcz.domain.services.LogService;
import com.inetpsa.rcz.domain.services.ParameterService;
import com.inetpsa.rcz.domain.services.VehicleService;
import com.inetpsa.rcz.rest.representation.response.VehicleRepresentation;
import net.jodah.failsafe.Failsafe;
import net.jodah.failsafe.FailsafeException;
import net.jodah.failsafe.RetryPolicy;
import net.jodah.failsafe.function.CheckedSupplier;
import org.apache.commons.lang.StringUtils;
import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;
import org.glassfish.jersey.client.ClientProperties;
import org.glassfish.jersey.client.authentication.HttpAuthenticationFeature;
import org.seedstack.business.assembler.Assembler;
import org.seedstack.business.domain.Factory;
import org.seedstack.business.modelmapper.ModelMapper;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.LifecycleListener;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.net.URI;
import java.text.MessageFormat;
import java.time.Duration;
import java.util.List;
import java.util.Optional;

import static com.inetpsa.rcz.application.util.LocalizationKey.COMMODORE_VEHICLE_REQUEST_ERROR;
import static com.inetpsa.rcz.application.util.Mock.get;

public class VehicleCommodoreService implements VehicleUpstreamService, LifecycleListener {

    private static final String VEHICLE_REQUEST = "/mocks/{}_vehicle_request.json";
    public static final String VEHICLE_REQUEST_SUCCESSFUL_FOR_UIN_WITH_VIN = "Vehicle request successful for UIN {} with VIN {}";

    @Inject
    private VehicleService vehicleService;

    @Inject
    private Factory<Vehicle> vehicleFactory;

    @Inject
    @ModelMapper
    private Assembler<Vehicle, VehicleRepresentation> vehicleAssembler;

    @Inject
    private ValidationService validationService;

    @Inject
    private ParameterService parameterService;

    @Inject
    private LocalizationService localizationService;

    @Logging
    private Logger logger;

    @Inject
    private LogService logService;

    @Configuration
    private RczConfig rczConfig;

    public Vehicle find(Exchange exchange) throws ApplicationException {
        Optional<Vehicle> vehicle = vehicleService.find(exchange.getUin());
        if (!vehicle.isPresent() || StringUtils.isBlank(vehicle.get().getVin())) {
            throw new ApplicationException(MessageFormat.format(localizationService.localize(COMMODORE_VEHICLE_REQUEST_ERROR), Response.Status.BAD_REQUEST.getStatusCode(), exchange.getUin()), ResponseStatus.VEHICLE_NOT_FOUND);
        }
        if (StringUtils.isBlank(vehicle.get().getBtaType()) || StringUtils.isBlank(vehicle.get().getMsisdn())) {
            logService.info(LogMessage.create(EventMessage.VEHICLE_UPDATE_REQUEST_SENT).data(vehicle.get().toString()), exchange);
            update(vehicle.get());
            logService.info(LogMessage.create(EventMessage.VEHICLE_UPDATED).data(vehicle.get().toString()), exchange);
        }

        return vehicle.get();
    }

    private void update(Vehicle vehicle) throws ApplicationException {
        VehicleRepresentation vehicleRepresentation = null;
        if (Boolean.parseBoolean(parameterService.getParameterValue(ParameterKey.COMMODORE_MOCK))) {
            vehicleRepresentation = getFromMock(vehicle);
        } else {
            vehicleRepresentation = getFromCommodoreWithFailsafe(vehicle);
        }
        vehicleAssembler.mergeAggregateIntoDto(vehicle, vehicleRepresentation);
        vehicleService.save(vehicle);
    }

    private VehicleRepresentation getFromMock(Vehicle vehicle) {
        return get(VEHICLE_REQUEST.replace("{}", vehicle.getId()), new TypeReference<VehicleRepresentation>() {
        });
    }


    private Response getFromCommodore(Vehicle vehicle) throws ApplicationException {
        try {
            logger.debug("Vehicle request attempt for UIN {}", vehicle.getId(), vehicle.getVin());
            HttpAuthenticationFeature authenticationFeature = HttpAuthenticationFeature.basic(rczConfig.getCommodore().getUsername(), rczConfig.getCommodore().getPassword());
            String configuredUri = parameterService.getParameterValue(ParameterKey.COMMODORE_VEHICLE_REQUEST_URI);
            URI uri = new URI(configuredUri);
            WebTarget target = ClientBuilder.newClient()
                    .register(authenticationFeature)
                    .target(buildHost(uri));
            target = target.path(buildPath(vehicle, uri));
            target = buildQueryParam(uri, target);
            return target
                    .request(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                    .property(ClientProperties.CONNECT_TIMEOUT, Integer.parseInt(parameterService.getParameterValue(ParameterKey.COMMODORE_VEHICLE_REQUEST_MAX_DURATION)))
                    .property(ClientProperties.READ_TIMEOUT, Integer.parseInt(parameterService.getParameterValue(ParameterKey.COMMODORE_VEHICLE_REQUEST_MAX_DURATION)))
                    .get(Response.class);
        } catch (Exception e) {//NOSONAR
            logger.error(e.getMessage(), e);
            throw new ApplicationException(e, ResponseStatus.TECHNICAL_ERROR);
        }

    }

    private String buildPath(Vehicle vehicle, URI uri) {
        String configuredPath = parameterService.getParameterValue(ParameterKey.COMMODORE_VEHICLE_REQUEST_PATH);
        StringBuilder pathBuilder = new StringBuilder(uri.getPath());
        if (StringUtils.isNotBlank(configuredPath)) {
            pathBuilder.append(configuredPath);
        }
        pathBuilder.append("/").append(vehicle.getVin());
        return pathBuilder.toString();
    }

    private String buildHost(URI uri) {
        StringBuilder pathBuilder = new StringBuilder(uri.getScheme()).append("//").append(uri.getHost());
        if (uri.getPort() > -1) {
            pathBuilder.append(":").append(uri.getPort());
        }
        return pathBuilder.toString();
    }

    private WebTarget buildQueryParam(URI uri, WebTarget target) {
        List<NameValuePair> params = URLEncodedUtils.parse(uri, "UTF-8");
        if (params != null) {
            for (NameValuePair nameValuePair : params) {
                target = target.queryParam(nameValuePair.getName(), nameValuePair.getValue());
            }
        }
        return target;
    }


    private String getPath(Vehicle vehicle) {
        String configuredPath = parameterService.getParameterValue(ParameterKey.COMMODORE_VEHICLE_REQUEST_PATH);
        String path = new StringBuilder("/").append(vehicle.getVin()).toString();
        if (StringUtils.isNotBlank(configuredPath)) {
            path = new StringBuilder(configuredPath).append(path).toString();
        }
        return path;
    }

    private VehicleRepresentation getFromCommodoreWithFailsafe(Vehicle vehicle) throws ApplicationException {
        Response response = null;
        try {
            response = runWithRetry(() -> getFromCommodore(vehicle), vehicle);

            if (response.getStatus() == Response.Status.INTERNAL_SERVER_ERROR.getStatusCode()) {
                throw new ApplicationException(MessageFormat.format(localizationService.localize(COMMODORE_VEHICLE_REQUEST_ERROR), Response.Status.INTERNAL_SERVER_ERROR.getStatusCode(), vehicle.getId()), ResponseStatus.VEHICLE_REQUEST_ERROR);
            }
            if (response.getStatus() == Response.Status.BAD_REQUEST.getStatusCode()) {
                throw new ApplicationException(MessageFormat.format(localizationService.localize(COMMODORE_VEHICLE_REQUEST_ERROR), Response.Status.BAD_REQUEST.getStatusCode(), vehicle.getId()), ResponseStatus.VEHICLE_NOT_FOUND);
            }
            VehicleRepresentation vehicleRepresentation = response.readEntity(VehicleRepresentation.class);
            validate(vehicleRepresentation);
            return vehicleRepresentation;
        } catch (Exception e) {
            logger.error(MessageFormat.format(localizationService.localize(COMMODORE_VEHICLE_REQUEST_ERROR), "Internal", vehicle.getId()), e);
            throw new ApplicationException(MessageFormat.format(localizationService.localize(COMMODORE_VEHICLE_REQUEST_ERROR), "Internal", vehicle.getId()), ResponseStatus.VEHICLE_REQUEST_ERROR);
        }
    }

    private void validate(VehicleRepresentation vehicleRepresentation) throws ApplicationException {
        try {
            validationService.validateRequest(vehicleRepresentation);
        } catch (ApplicationException e) {
            throw new ApplicationException(e.getMessage(), ResponseStatus.VEHICLE_VALIDATION_ERROR);
        }
    }

    public <T, E extends Throwable> T runWithRetry(CheckedSupplier<T> supplier, Vehicle vehicle) throws E {
        try {
            return Failsafe.with(new RetryPolicy<>()
                    .handle(Exception.class)
                    .withDelay(Duration.ofMillis(Integer.parseInt(parameterService.getParameterValue(ParameterKey.COMMODORE_VEHICLE_REQUEST_RETRY_DELAY))))
                    .withMaxDuration(Duration.ofMillis(Integer.parseInt(parameterService.getParameterValue(ParameterKey.COMMODORE_VEHICLE_REQUEST_MAX_DURATION))))
                    .withMaxRetries(Integer.parseInt(parameterService.getParameterValue(ParameterKey.COMMODORE_VEHICLE_REQUEST_NB_RETRY)))
                    .onSuccess(event -> logger.debug(VEHICLE_REQUEST_SUCCESSFUL_FOR_UIN_WITH_VIN, vehicle.getId(), vehicle.getVin()))
                    .onFailure(event -> logger.warn(MessageFormat.format(localizationService.localize(COMMODORE_VEHICLE_REQUEST_ERROR), event.getFailure().getMessage(), vehicle.getId())))
            ).get(supplier);
        } catch (FailsafeException e) {
            try {
                throw (E) e.getCause();
            } catch (ClassCastException e1) {
                throw e;
            }
        }
    }

}
