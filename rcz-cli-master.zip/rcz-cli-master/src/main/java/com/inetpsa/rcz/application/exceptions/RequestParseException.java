package com.inetpsa.rcz.application.exceptions;

public class RequestParseException extends RuntimeException {
    public RequestParseException() {
    }

    public RequestParseException(String message) {
        super(message);
    }

    public RequestParseException(String message, Throwable cause) {
        super(message, cause);
    }

    public RequestParseException(Throwable cause) {
        super(cause);
    }

    public RequestParseException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
