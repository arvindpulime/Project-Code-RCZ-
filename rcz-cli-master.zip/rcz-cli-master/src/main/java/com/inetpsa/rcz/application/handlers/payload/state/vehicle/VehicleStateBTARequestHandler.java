package com.inetpsa.rcz.application.handlers.payload.state.vehicle;

import com.inetpsa.rcz.application.handlers.payload.BTARequestHandler;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.payload.data.VehicleState;
import com.inetpsa.rcz.domain.model.payload.request.BTARequestPayload;
import com.inetpsa.rcz.domain.model.payload.request.RequestPayload;

import java.util.Date;

public class VehicleStateBTARequestHandler implements BTARequestHandler<VehicleState, VehicleState> {

    @Override
    public BTARequestPayload<VehicleState> handle(Exchange exchange, RequestPayload<VehicleState> requestPayload) {
        BTARequestPayload<VehicleState> btaRequest = new BTARequestPayload<>();
        btaRequest.setRequestDate(new Date());
        btaRequest.setRequestId(exchange.getId());
        return btaRequest;
    }
}
