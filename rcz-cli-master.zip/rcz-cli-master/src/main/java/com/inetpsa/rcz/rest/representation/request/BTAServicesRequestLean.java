package com.inetpsa.rcz.rest.representation.request;

import java.io.Serializable;

/**
 * @author tuan.docao@ext.mpsa.com
 */
public class BTAServicesRequestLean implements Serializable {

    private String eventId;

    private String uin;

    public BTAServicesRequestLean() {
    }

    public String getEventId() {
        return eventId;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }

    public String getUin() {
        return uin;
    }

    public void setUin(String uin) {
        this.uin = uin;
    }
}
