package com.inetpsa.rcz.application.handlers.event;

import com.fasterxml.jackson.core.type.TypeReference;
import com.inetpsa.rcz.application.exceptions.ApplicationException;
import com.inetpsa.rcz.application.services.AccessService;
import com.inetpsa.rcz.application.services.LocalizationService;
import com.inetpsa.rcz.application.services.VehicleUpstreamService;
import com.inetpsa.rcz.application.services.WakeUpService;
import com.inetpsa.rcz.application.util.LocalizationKey;
import com.inetpsa.rcz.domain.model.action.ActionType;
import com.inetpsa.rcz.domain.model.enums.EventMessage;
import com.inetpsa.rcz.domain.model.enums.ResponseStatus;
import com.inetpsa.rcz.domain.model.event.RequestReceived;
import com.inetpsa.rcz.domain.model.event.VehicleWakeUpReceived;
import com.inetpsa.rcz.domain.model.event.VehicleWakeUpRequested;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.log.LogMessage;
import com.inetpsa.rcz.domain.model.parameter.ParameterKey;
import com.inetpsa.rcz.domain.model.payload.data.VehicleStateResult;
import com.inetpsa.rcz.domain.model.payload.request.RequestPayload;
import com.inetpsa.rcz.domain.model.vehicle.Vehicle;
import com.inetpsa.rcz.domain.services.LogService;
import com.inetpsa.rcz.domain.services.ParameterService;
import com.inetpsa.rcz.domain.services.VehicleService;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;
import org.apache.commons.lang.StringUtils;

import javax.inject.Inject;
import java.util.Optional;

public class RequestReceivedHandler extends AbstractRequestReceivedHandler<RequestReceived> {

    @Inject
    private LocalizationService localizationService;

    @Inject
    private VehicleService vehicleService;

    @Inject
    private VehicleUpstreamService vehicleUpstreamService;

    @Inject
    private WakeUpService wakeUpService;

    @Inject
    private LogService logService;

    @Inject
    private ParameterService parameterService;

    @Inject
    private AccessService accessService;


    @Override
    void process(Exchange exchange, RequestPayload requestPayload) throws ApplicationException {
        Optional<Vehicle> vehicle = vehicleService.find(exchange.getUin());
        Boolean isConnected = null;
        if (vehicle.isPresent() ) {
            isConnected = vehicle.get().isConnected();
            checkAccess(vehicle.get(), exchange);
        }
        if (isConnected == null) {
            throw new ApplicationException(localizationService.localize(LocalizationKey.TECHNICAL_ERROR_NO_VEHICLE_FOUND_FOR_UIN_KEY, exchange.getUin()), ResponseStatus.TECHNICAL_ERROR);
        }
        if (isConnected || (ActionType.VEHICLE_STATE.equals(exchange.getAction().getActionType()) && Boolean.parseBoolean(parameterService.getParameterValue(ParameterKey.APP_AUTOMATICAL_VEHICLE_STATE)))) {
            domainEventPublisher.publish(new VehicleWakeUpReceived(exchange));
        } else {
            logService.info(LogMessage.create(EventMessage.VEHICLE_ASLEEP), exchange);
            wakeUpService.wakeUp(vehicleUpstreamService.find(exchange));
            domainEventPublisher.publish(new VehicleWakeUpRequested(exchange));
        }
    }

    private void checkAccess(Vehicle vehicle, Exchange exchange) throws ApplicationException {
        if (vehicle.getVehicleInfo() != null && StringUtils.isNotBlank(vehicle.getVehicleInfo().getRawJson())) {
            VehicleStateResult vehicleStateResult = JsonConverter.convert(vehicle.getVehicleInfo().getRawJson(), new TypeReference<VehicleStateResult>() {
            });
            accessService.checkAccess(vehicleStateResult, exchange);
        }
    }


}
