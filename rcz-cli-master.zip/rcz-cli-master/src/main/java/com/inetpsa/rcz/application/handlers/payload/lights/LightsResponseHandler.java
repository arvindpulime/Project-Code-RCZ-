/*
 * Creation : 18 juil. 2016
 */
package com.inetpsa.rcz.application.handlers.payload.lights;

import com.inetpsa.rcz.application.handlers.payload.AbstractResponseHandler;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.payload.data.Data;
import com.inetpsa.rcz.domain.model.payload.data.Lights;

public class LightsResponseHandler extends AbstractResponseHandler<Lights> {

    @Override
    protected Lights handleResponseData(Data data, Exchange exchange) {
        return null;
    }
}
