package com.inetpsa.rcz.application.scheduler;

import com.inetpsa.rcz.domain.model.event.RequestTimeout;
import org.seedstack.business.domain.DomainEventPublisher;
import org.seedstack.scheduler.Scheduled;
import org.seedstack.scheduler.SchedulingContext;
import org.seedstack.scheduler.Task;

import javax.inject.Inject;

@Scheduled("${rcz.exchange.timeout.scheduler.cron}")
public class ExchangeTimeoutTask implements Task {

    @Inject
    private DomainEventPublisher eventPublisher;

    @Override
    public void execute(SchedulingContext sc) throws Exception {
        eventPublisher.publish(new RequestTimeout());
    }
}
