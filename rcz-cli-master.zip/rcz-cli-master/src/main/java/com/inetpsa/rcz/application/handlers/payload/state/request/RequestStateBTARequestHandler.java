package com.inetpsa.rcz.application.handlers.payload.state.request;

import com.inetpsa.rcz.application.handlers.payload.BTARequestHandler;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.payload.request.BTARequestPayload;
import com.inetpsa.rcz.domain.model.payload.request.RequestPayload;

public class RequestStateBTARequestHandler implements BTARequestHandler<Void, Void> {

    @Override
    public BTARequestPayload<Void> handle(Exchange exchange, RequestPayload<Void> requestPayload) {
        return null;
    }
}
