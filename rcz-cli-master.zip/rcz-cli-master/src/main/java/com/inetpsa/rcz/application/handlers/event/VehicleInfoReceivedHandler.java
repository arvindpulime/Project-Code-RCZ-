package com.inetpsa.rcz.application.handlers.event;

import com.fasterxml.jackson.core.type.TypeReference;
import com.inetpsa.rcz.application.configuration.RczConfig;
import com.inetpsa.rcz.application.exceptions.ApplicationException;
import com.inetpsa.rcz.application.exceptions.JsonParseException;
import com.inetpsa.rcz.application.services.AuthorizationService;
import com.inetpsa.rcz.application.services.PublisherService;
import com.inetpsa.rcz.application.services.ValidationService;
import com.inetpsa.rcz.domain.model.enums.EventMessage;
import com.inetpsa.rcz.domain.model.enums.ExchangeStatus;
import com.inetpsa.rcz.domain.model.enums.ResponseStatus;
import com.inetpsa.rcz.domain.model.event.VehicleInfoReceived;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.log.LogMessage;
import com.inetpsa.rcz.domain.model.payload.data.VehicleStateResult;
import com.inetpsa.rcz.domain.model.shared.Payload;
import com.inetpsa.rcz.domain.model.vehicle.Vehicle;
import com.inetpsa.rcz.domain.services.LogService;
import com.inetpsa.rcz.domain.services.VehicleService;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;
import org.apache.commons.lang.StringUtils;
import org.modelmapper.ModelMapper;
import org.seedstack.business.domain.Factory;
import org.seedstack.seed.Configuration;

import javax.inject.Inject;
import javax.inject.Named;
import javax.inject.Provider;
import java.util.Date;
import java.util.Optional;

public class VehicleInfoReceivedHandler extends AbstractVehicleInfoReceivedHandler<VehicleInfoReceived> {

    public static final String VIN_UNREADABLE = "Was unable to read parameter VIN from VehicleInfo";
    @Inject
    protected VehicleService vehicleService;

    @Inject
    protected Factory<Vehicle> vehicleFactory;

    @Inject
    private LogService logService;

    @Inject
    private AuthorizationService authorizationService;

    @Inject
    private Provider<ModelMapper> modelMapperProvider;

    @Inject
    @Named("kafka")
    private PublisherService publisherService;

    @Configuration
    private RczConfig rczConfig;

    @Inject
    private ValidationService validationService;

    @Override
    public void onEvent(VehicleInfoReceived event) {
        Exchange exchange = initExchange(event);
        try {
            logService.info(LogMessage.create(EventMessage.VEHICLE_AUTO_STATE_RECEIVED).data(event.getMessage()), exchange);
            exchange.setVin(getVin(event));
            authorizationService.authorizeActionFromUIN(exchange);
            Vehicle vehicle = mergeAndUpdate(event);
            logService.info(LogMessage.create(EventMessage.VEHICLE_UPDATED).data(vehicle.getVehicleInfo().getRawJson()), exchange);

        } catch (Exception e) {//NOSONAR
            exchange.setStatus(ExchangeStatus.ERROR);
            logService.error(LogMessage.create(EventMessage.VEHICLE_AUTO_STATE_ERROR).data(e.getMessage()), exchange);
            exchangeService.update(exchange);
        }
    }

    private Vehicle mergeAndUpdate(VehicleInfoReceived vehicleInfoReceived) throws ApplicationException {
        Optional<Vehicle> vehicle = vehicleService.find(vehicleInfoReceived.getUin());
        if (!vehicle.isPresent()) {
            vehicle = Optional.of(vehicleFactory.create(vehicleInfoReceived.getUin()));
        }
        VehicleStateResult vehicleStateResult = merge(vehicleInfoReceived.getMessage(), vehicle.get());
        validationService.validateRequest(vehicleStateResult);
        String payload = JsonConverter.convert(vehicleStateResult);
        vehicle.get().setVehicleInfo(new Payload(new Date(), vehicleStateResult.getDate(), payload));

        vehicle.get().setVin(vehicleStateResult.getVin());
        publisherService.publish(payload, PublisherService.Target.TargetBuilder.builder().withTopic(rczConfig.getExchange().getTopics().getVehicleInfo()).withKey(vehicle.get().getVin()).build());
        vehicleService.save(vehicle.get());
        return vehicle.get();
    }

    public VehicleStateResult merge(String upstream, Vehicle vehicle) throws ApplicationException {
        try {
            VehicleStateResult vehicleStateResult = JsonConverter.convert(upstream, new TypeReference<VehicleStateResult>() {
            });
            if (vehicle.getVehicleInfo() != null && StringUtils.isNotBlank(vehicle.getVehicleInfo().getRawJson())) {
                VehicleStateResult vehicleStateResultLocal = JsonConverter.convert(vehicle.getVehicleInfo().getRawJson(), new TypeReference<VehicleStateResult>() {
                });
                modelMapperProvider.get().map(vehicleStateResult, vehicleStateResultLocal);
                vehicleStateResult = vehicleStateResultLocal;
            }
            return vehicleStateResult;
        } catch (JsonParseException e) {
            throw new ApplicationException(e.getMessage(), ResponseStatus.TECHNICAL_ERROR);
        }
    }

    private String getVin(VehicleInfoReceived event) throws ApplicationException {
        if (StringUtils.isNotBlank(event.getMessage())) {
            VehicleStateResult vehicleStateResult = JsonConverter.convert(event.getMessage(), new TypeReference<VehicleStateResult>() {
            });
            if (vehicleStateResult != null && StringUtils.isNotBlank(vehicleStateResult.getVin())) {
                return vehicleStateResult.getVin();
            }
        }
        throw new ApplicationException(VIN_UNREADABLE, ResponseStatus.VEHICLE_VALIDATION_ERROR);
    }


}
