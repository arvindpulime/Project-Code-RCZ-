package com.inetpsa.rcz.application.handlers.event;

import com.inetpsa.rcz.domain.model.action.Action;
import com.inetpsa.rcz.domain.model.enums.CallerType;
import com.inetpsa.rcz.domain.model.enums.ExchangeStatus;
import com.inetpsa.rcz.domain.model.event.AbstractVehicleInfoReceived;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.payload.topic.Topic;
import com.inetpsa.rcz.domain.model.shared.Payload;
import com.inetpsa.rcz.domain.services.ExchangeService;
import org.seedstack.business.domain.BaseDomainEventHandler;
import org.seedstack.business.domain.Factory;

import javax.inject.Inject;
import java.util.Date;

public abstract class AbstractVehicleInfoReceivedHandler<E extends AbstractVehicleInfoReceived> extends BaseDomainEventHandler<E> {

    public static final String VIN_UNREADABLE = "Was unable to read parameter VIN from VehicleInfo";

    @Inject
    protected Factory<Exchange> exchangeFactory;

    @Inject
    protected ExchangeService exchangeService;


    protected Exchange initExchange(E event) {
        Exchange exchange = exchangeFactory.create();
        String request = event.getMessage();
        Topic topic = event.getTopic();
        exchange.setUin(event.getUin());
        exchange.setCallerType(CallerType.VEHICLE);
        exchange.setCallerId(topic.getId());
        exchange.setRequest(new Payload(new Date(), request));
        exchange.setAction(Action.create(topic.getActionService(), topic.getActionType()));
        exchange.setTopic(topic.toString());
        exchange.setStatus(ExchangeStatus.FINISHED);
        exchangeService.update(exchange);
        return exchange;
    }


}
