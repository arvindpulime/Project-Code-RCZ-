package com.inetpsa.rcz.application.handlers.payload.state.vehicle;

import com.fasterxml.jackson.core.type.TypeReference;
import com.inetpsa.rcz.application.handlers.payload.AbstractResponseHandler;
import com.inetpsa.rcz.domain.model.enums.CallerType;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.payload.data.Data;
import com.inetpsa.rcz.domain.model.payload.data.VehicleStateClient;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;

public class VehicleStateResponseHandler extends AbstractResponseHandler<VehicleStateClient> {

    @Override
    protected VehicleStateClient handleResponseData(Data data, Exchange exchange) {
        VehicleStateClient result = JsonConverter.convert(data.getValue(), new TypeReference<VehicleStateClient>() {
        });
        result.setLocation(null);
        if (CallerType.CLIENT == exchange.getCallerType()) {
            result.setImmobilized(null);
            result.setStolen(null);
        }
        return result;
    }
}
