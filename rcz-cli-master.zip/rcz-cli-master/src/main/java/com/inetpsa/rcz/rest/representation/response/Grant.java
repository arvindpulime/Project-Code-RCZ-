package com.inetpsa.rcz.rest.representation.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.inetpsa.rcz.rest.representation.ServiceRepresentation;

import java.util.List;

/**
 * @author tuan.docao@ext.mpsa.com
 */
public class Grant {

    @JsonProperty("contract_id")
    private String contractId;

    @JsonProperty("uin")
    private String uin;

    @JsonProperty("services")
    private List<ServiceRepresentation> services;

    public Grant() {
    }

    public String getContractId() {
        return contractId;
    }

    public void setContractId(String contractId) {
        this.contractId = contractId;
    }

    public String getUin() {
        return uin;
    }

    public void setUin(String uin) {
        this.uin = uin;
    }

    public List<ServiceRepresentation> getServices() {
        return services;
    }

    public void setServices(List<ServiceRepresentation> services) {
        this.services = services;
    }
}
