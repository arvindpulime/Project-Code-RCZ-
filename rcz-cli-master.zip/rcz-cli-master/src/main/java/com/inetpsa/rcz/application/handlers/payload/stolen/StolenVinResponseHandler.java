/*
 * Creation : 16 août 2016
 */
package com.inetpsa.rcz.application.handlers.payload.stolen;

import com.inetpsa.rcz.application.handlers.payload.AbstractResponseHandler;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.payload.data.Data;
import com.inetpsa.rcz.domain.model.payload.data.StolenState;

public class StolenVinResponseHandler extends AbstractResponseHandler<StolenState> {

    @Override
    protected StolenState handleResponseData(Data data, Exchange exchange) {
        return null;
    }

}
