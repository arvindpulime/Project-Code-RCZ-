package com.inetpsa.rcz.application.handlers.payload.tracking;

import com.inetpsa.rcz.application.handlers.payload.BTARequestHandler;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.payload.data.Tracking;
import com.inetpsa.rcz.domain.model.payload.request.BTARequestPayload;
import com.inetpsa.rcz.domain.model.payload.request.RequestPayload;

import java.util.Date;

public class TrackingBTARequestHandler implements BTARequestHandler<Tracking, Tracking> {

    public static final String ACTIVATE = "activate";

    @Override
    public BTARequestPayload<Tracking> handle(Exchange exchange, RequestPayload<Tracking> requestPayload) {
        BTARequestPayload<Tracking> btaRequest = new BTARequestPayload<>();
        btaRequest.setRequestDate(new Date());
        btaRequest.setRequestId(exchange.getId());
        boolean activate = ACTIVATE.equals(requestPayload.getRequestParameters().getAction());
        Tracking tracking = new Tracking(requestPayload.getRequestParameters().getPeriodRun(), requestPayload.getRequestParameters().getPeriodShutdown(), activate);
        btaRequest.setData(tracking);
        return btaRequest;
    }
}
