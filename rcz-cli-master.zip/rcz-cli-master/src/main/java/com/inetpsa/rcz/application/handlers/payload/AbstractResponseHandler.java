package com.inetpsa.rcz.application.handlers.payload;

import com.fasterxml.jackson.core.type.TypeReference;
import com.inetpsa.rcz.application.exceptions.ApplicationException;
import com.inetpsa.rcz.domain.model.enums.CallerType;
import com.inetpsa.rcz.domain.model.enums.ResponseStatus;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.parameter.ParameterKey;
import com.inetpsa.rcz.domain.model.payload.ResponseStatusResolver;
import com.inetpsa.rcz.domain.model.payload.data.Data;
import com.inetpsa.rcz.domain.model.payload.data.DataWrapper;
import com.inetpsa.rcz.domain.model.payload.request.RequestPayload;
import com.inetpsa.rcz.domain.model.payload.response.BTAResponsePayload;
import com.inetpsa.rcz.domain.model.payload.response.ResponsePayload;
import com.inetpsa.rcz.domain.services.ParameterService;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;
import org.apache.commons.lang.StringUtils;

import javax.inject.Inject;
import java.util.Date;

public abstract class AbstractResponseHandler<R> implements ResponseHandler<R> {

    @Inject
    private ParameterService parameterService;

    @Override
    public ResponsePayload<R> handle(Exchange exchange, BTAResponsePayload btaResponsePayload) throws ApplicationException {
        try {
            ResponsePayload<R> responsePayload = new ResponsePayload<>();
            responsePayload.setResponseDate(new Date());
            ResponseStatus responseStatus = exchange.getResponseStatus();
            RequestPayload requestPayload = getRequest(exchange);

            if (btaResponsePayload != null) {
                responsePayload.setReturnCode(String.valueOf(btaResponsePayload.getStatus()));
                if (CallerType.CLIENT.equals(exchange.getCallerType())) {
                    responseStatus = ResponseStatusResolver.CLIENT_RESPONSE_STATUS_RESOLVER.get(responseStatus);
                }

                if (CallerType.PARTNER.equals(exchange.getCallerType()) || Boolean.parseBoolean(parameterService.getParameterValue(ParameterKey.APP_CLIENT_RESPONSE_DEBUG))) {
                    responseStatus = ResponseStatusResolver.BTA_RESPONSE_STATUS_RESOLVER.get(btaResponsePayload.getStatus());
                    responsePayload.setReason(btaResponsePayload.getReason());
                }

                if (btaResponsePayload.getData() != null && StringUtils.isNotBlank(btaResponsePayload.getData().getValue())) {
                    responsePayload.setResponseData(handleResponseData(btaResponsePayload.getData(), exchange));
                }
            }
            responsePayload.setLocation(getLocation(btaResponsePayload));
            if (responseStatus != null) {
                responsePayload.setReturnCode(responseStatus.code());
            }
            responsePayload.setCorrelationId(requestPayload.getCorrelationId());
            responsePayload.setVin(exchange.getVin());
            return responsePayload;
        } catch (Exception e) {
            throw new ApplicationException(e.getMessage(), e, ResponseStatus.TECHNICAL_ERROR);
        }
    }

    private RequestPayload getRequest(Exchange exchange) {
        return JsonConverter.convert(exchange.getRequest().getRawJson(), new TypeReference<RequestPayload>() {
        });
    }

    private Data getLocation(BTAResponsePayload btaResponsePayload) {
        if (btaResponsePayload != null) {
            if (btaResponsePayload.getLocation() != null) {
                return btaResponsePayload.getLocation();
            }
            if (btaResponsePayload.getData() != null && StringUtils.isNotBlank(btaResponsePayload.getData().getValue())) {
                DataWrapper dataWrapper = JsonConverter.convert(btaResponsePayload.getData().getValue(), new TypeReference<DataWrapper>() {
                });
                if (dataWrapper != null) {
                    if (dataWrapper.getLocation() != null) {
                        return dataWrapper.getLocation();
                    } else if (dataWrapper.getSatellites() != null) {
                        return btaResponsePayload.getData();
                    }
                }
            }
        }
        return null;
    }

    protected abstract R handleResponseData(Data data, Exchange exchange);
}
