package com.inetpsa.rcz.application.configuration;

import javax.validation.constraints.NotNull;

public class ExchangeConfig {

    private TimeoutConfig timeout = new TimeoutConfig();

    private Topics topics;

    public TimeoutConfig getTimeout() {
        return timeout;
    }

    public Topics getTopics() {
        return topics;
    }

    public static class TimeoutConfig {
        private Scheduler scheduler = new Scheduler();

        public static class Scheduler {
            @NotNull
            private String cron;

            public String getCron() {
                return cron;
            }
        }
    }

    public static class Topics {
        String alarm;
        String vehicleInfo;

        public String getAlarm() {
            return alarm;
        }

        public String getVehicleInfo() {
            return vehicleInfo;
        }
    }
}
