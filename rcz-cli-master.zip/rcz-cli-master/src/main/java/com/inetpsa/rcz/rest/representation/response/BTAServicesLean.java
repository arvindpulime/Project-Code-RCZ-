package com.inetpsa.rcz.rest.representation.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.inetpsa.rcz.rest.representation.ServiceRepresentation;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;

/**
 * @author tuan.docao@ext.mpsa.com
 */
public class BTAServicesLean implements Serializable {

    @JsonProperty("vin")
    private String vin;

    @JsonProperty("services")
    private HashMap<String, List<ServiceRepresentation>> services;

    public BTAServicesLean() {
    }

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    public HashMap<String, List<ServiceRepresentation>> getServices() {
        return services;
    }

    public void setServices(HashMap<String, List<ServiceRepresentation>> services) {
        this.services = services;
    }
}
