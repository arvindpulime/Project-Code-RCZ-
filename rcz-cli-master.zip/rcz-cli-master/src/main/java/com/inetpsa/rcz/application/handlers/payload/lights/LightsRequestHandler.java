/*
 * Creation : 18 juil. 2016
 */
package com.inetpsa.rcz.application.handlers.payload.lights;

import com.fasterxml.jackson.core.type.TypeReference;
import com.inetpsa.rcz.application.exceptions.ApplicationException;
import com.inetpsa.rcz.application.exceptions.JsonParseException;
import com.inetpsa.rcz.application.handlers.payload.RequestHandler;
import com.inetpsa.rcz.domain.model.enums.ResponseStatus;
import com.inetpsa.rcz.domain.model.payload.data.Lights;
import com.inetpsa.rcz.domain.model.payload.request.RequestPayload;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;

public class LightsRequestHandler implements RequestHandler<Lights> {

    @Override
    public RequestPayload<Lights> handle(String request) throws ApplicationException {
        try {
            return JsonConverter.convert(request, new TypeReference<RequestPayload<Lights>>() {
            });
        } catch (JsonParseException e) {
            throw new ApplicationException(e.getMessage(), e, ResponseStatus.FORMAT_ERROR);
        }
    }

}
