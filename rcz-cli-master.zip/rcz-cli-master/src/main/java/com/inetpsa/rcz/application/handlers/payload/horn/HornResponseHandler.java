package com.inetpsa.rcz.application.handlers.payload.horn;

import com.inetpsa.rcz.application.handlers.payload.AbstractResponseHandler;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.payload.data.Data;
import com.inetpsa.rcz.domain.model.payload.data.Horn;

public class HornResponseHandler extends AbstractResponseHandler<Horn> {

    @Override
    protected Horn handleResponseData(Data data, Exchange exchange) {
        return null;
    }
}
