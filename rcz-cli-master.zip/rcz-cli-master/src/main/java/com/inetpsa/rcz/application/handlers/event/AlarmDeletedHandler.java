package com.inetpsa.rcz.application.handlers.event;

import com.inetpsa.rcz.domain.model.enums.EventMessage;
import com.inetpsa.rcz.domain.model.enums.ExchangeStatus;
import com.inetpsa.rcz.domain.model.enums.ResponseStatus;
import com.inetpsa.rcz.domain.model.event.AlarmDeleted;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.log.LogMessage;
import com.inetpsa.rcz.domain.services.ExchangeService;
import com.inetpsa.rcz.domain.services.LogService;
import org.seedstack.business.domain.BaseDomainEventHandler;

import javax.inject.Inject;

public class AlarmDeletedHandler extends BaseDomainEventHandler<AlarmDeleted> {

    @Inject
    private LogService logService;

    @Inject
    private ExchangeService exchangeService;

    @Override
    public void onEvent(AlarmDeleted alarmDeleted) {
        Exchange exchange = alarmDeleted.getExchange();
        ExchangeStatus status = ExchangeStatus.ERROR;
        if (alarmDeleted.getBtaResponsePayload().getResponseStatus().equals(ResponseStatus.STATUS_OK)) {
            status = ExchangeStatus.FINISHED;
            logService.info(LogMessage.create(EventMessage.ALARM_DELETED).data(null), exchange);
        }
        exchange.setResponseStatus(alarmDeleted.getBtaResponsePayload().getResponseStatus());
        exchange.setStatus(status);
        exchangeService.update(exchange);
    }
}
