package com.inetpsa.rcz.application.services.impl;

import com.inetpsa.rcz.application.configuration.RczConfig;
import com.inetpsa.rcz.application.services.LocalizationService;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.seedstack.seed.transaction.Propagation;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;

import javax.inject.Inject;
import java.text.MessageFormat;

public class LocalizationServiceImpl implements LocalizationService {

    @Inject
    private org.seedstack.i18n.LocalizationService localizationService;

    @Logging
    private Logger logger;

    @Configuration
    private RczConfig rczConfig;

    @Override
    @JpaUnit("seed-i18n-domain")
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public String localize(String key, Object... args) {
        try {
            return localizationService.localize(rczConfig.getValidation().getLanguage(), key, args);
        } catch (IllegalArgumentException e) {
            logger.warn(MessageFormat.format("Error for translation locale : {0}, key : {1} ", rczConfig.getValidation().getLanguage(), key), e);
            return '[' + key + ']';
        }
    }
}
