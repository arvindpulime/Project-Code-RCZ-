package com.inetpsa.rcz.application.services.impl;

import com.fasterxml.jackson.core.type.TypeReference;
import com.inetpsa.rcz.application.exceptions.ApplicationException;
import com.inetpsa.rcz.application.services.AccessService;
import com.inetpsa.rcz.application.services.LocalizationService;
import com.inetpsa.rcz.application.util.LocalizationKey;
import com.inetpsa.rcz.domain.model.action.Action;
import com.inetpsa.rcz.domain.model.action.ActionType;
import com.inetpsa.rcz.domain.model.enums.*;
import com.inetpsa.rcz.domain.model.event.BatteryAvailability;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.parameter.ParameterKey;
import com.inetpsa.rcz.domain.model.payload.data.Charging;
import com.inetpsa.rcz.domain.model.payload.data.Preconditioning;
import com.inetpsa.rcz.domain.model.payload.data.VehicleStateResult;
import com.inetpsa.rcz.domain.model.payload.request.RequestPayload;
import com.inetpsa.rcz.domain.model.payload.response.BTAResponsePayload;
import com.inetpsa.rcz.domain.model.payload.topic.PreconditioningBtaTopicsResolver;
import com.inetpsa.rcz.domain.services.ParameterService;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;
import org.seedstack.business.domain.DomainEventPublisher;

import javax.inject.Inject;

public class AccessServiceImpl implements AccessService {

    @Inject
    private LocalizationService localizationService;

    @Inject
    private ParameterService parameterService;

    @Inject
    protected DomainEventPublisher domainEventPublisher;

    @Override
    public void checkAccess(BTAResponsePayload btaResponsePayload, Exchange exchange) throws ApplicationException {
        VehicleStateResult vehicleStateResult = JsonConverter.convert(btaResponsePayload.getData().getValue(), new TypeReference<VehicleStateResult>() {
        });
        checkAccess(vehicleStateResult, exchange);
    }

    @Override
    public void checkAccess(VehicleStateResult vehicleStateResult, Exchange exchange) throws ApplicationException {
        checkSevState(vehicleStateResult, exchange);
        if (!Boolean.parseBoolean(parameterService.getParameterValue(ParameterKey.APP_OPEN_BAR))) {
            checkStolen(vehicleStateResult, exchange);
        }
        checkPrivacy(vehicleStateResult, exchange);
        checkBattery(vehicleStateResult, exchange);
    }

    private void checkBattery(VehicleStateResult vehicleStateResult, Exchange exchange) throws ApplicationException {
        if (!((vehicleStateResult.getElectricalNetworkState() != null
                && !ElectricalNetworkStatus.INACTIVE_TRACTION_ONLY_START_AVAILABLE.equals(vehicleStateResult.getElectricalNetworkStatus())
        ) || (Action.VEHICLE_STATE.getActionType().equals(exchange.getAction().getActionType())
                || Action.DOORS.getActionType().equals(exchange.getAction().getActionType())
                || Action.IMMOBILIZATION.getActionType().equals(exchange.getAction().getActionType())
                || Action.CHARGING.getActionType().equals(exchange.getAction().getActionType()))
        )) {
            throw new ApplicationException(localizationService.localize(LocalizationKey.RIGHTS_ERROR_BATTERY), ResponseStatus.RIGHTS_ERROR_BATTERY);
        }
        if ((vehicleStateResult.getElectricalNetworkState() != null
                && ElectricalNetworkStatus.INACTIVE_TRACTION_ONLY_START_AVAILABLE.equals(vehicleStateResult.getElectricalNetworkStatus())
        ) && (Action.VEHICLE_STATE.getActionType().equals(exchange.getAction().getActionType())
                || Action.DOORS.getActionType().equals(exchange.getAction().getActionType())
                || Action.IMMOBILIZATION.getActionType().equals(exchange.getAction().getActionType())
                || Action.CHARGING.getActionType().equals(exchange.getAction().getActionType()))
        ) {
            domainEventPublisher.publish(new BatteryAvailability(exchange));
        }
    }

    private void checkPrivacy(VehicleStateResult vehicleStateResult, Exchange exchange) throws ApplicationException {
        if (CallerType.CLIENT == exchange.getCallerType() && PrivacyState.FULL_PRIVATE.equals(vehicleStateResult.getPrivacyState())) {
            throw new ApplicationException(localizationService.localize(LocalizationKey.RIGHTS_ERROR_PRIVACY_ON), ResponseStatus.RIGHTS_ERROR_PRIVACY);
        }
    }

    private void checkSevState(VehicleStateResult vehicleStateResult, Exchange exchange) throws ApplicationException {
        if (!(SevState.STOP.equals(vehicleStateResult.getSevState()) ||
                ((ActionType.VEHICLE_STATE.equals(exchange.getAction().getActionType())
                        || Action.CHARGING.equals(exchange.getAction())
                        || Action.THERMAL_PRECONDITIONING.equals(exchange.getAction()))
                        && !SevState.STOP.equals(vehicleStateResult.getSevState())))) {
            throw new ApplicationException(localizationService.localize(LocalizationKey.RIGHTS_ERROR_VES_SEV_NOT_STOPPED_KEY), ResponseStatus.RIGHTS_ERROR_VES);
        }
    }

    private boolean isChargeDelayed(VehicleStateResult vehicleStateResult, Exchange exchange) {
        if (Action.CHARGING.equals(exchange.getAction())) {
            RequestPayload<Charging> chargingRequestPayload = JsonConverter.convert(exchange.getRequest().getRawJson(), new TypeReference<RequestPayload<Charging>>() {
            });
            if (chargingRequestPayload != null
                    && chargingRequestPayload.getRequestParameters() != null
                    && Charging.DELAYED.contentEquals(chargingRequestPayload.getRequestParameters().getType())) {
                return true;
            }
        }
        return false;
    }

    private boolean isPrecondDeactivate(VehicleStateResult vehicleStateResult, Exchange exchange) {
        if (Action.THERMAL_PRECONDITIONING.equals(exchange.getAction())) {
            RequestPayload<Preconditioning> preconditioningRequestPayload = JsonConverter.convert(exchange.getRequest().getRawJson(), new TypeReference<RequestPayload<Preconditioning>>() {
            });
            if (PreconditioningBtaTopicsResolver.IsPrecondProgramed(preconditioningRequestPayload)) {
                return true;
            }
        }
        return false;
    }

    private void checkStolen(VehicleStateResult vehicleStateResult, Exchange exchange) throws ApplicationException {
        final boolean vehicleStolen = (vehicleStateResult.getStolen() == null) ? false : vehicleStateResult.getStolen();
        if (CallerType.CLIENT == exchange.getCallerType() && vehicleStolen) {
            throw new ApplicationException(localizationService.localize(LocalizationKey.AUTHORIZATION_DENIED_VEHICLE_IS_STOLEN_KEY), ResponseStatus.AUTHORIZATION_DENIED);
        }
        if (!Action.STOLEN_VIN.equals(exchange.getAction()) && CallerType.PARTNER == exchange.getCallerType() && !vehicleStolen) {
            throw new ApplicationException(localizationService.localize(LocalizationKey.RIGHTS_ERROR_STOLEN_VEHICLE_NOT_DECLARED_STOLEN_KEY), ResponseStatus.RIGHTS_ERROR_STOLEN);
        }
    }


}
