package com.inetpsa.rcz.application.handlers.event;

import com.inetpsa.rcz.application.exceptions.InvalidVehicleException;
import com.inetpsa.rcz.domain.model.action.Action;
import com.inetpsa.rcz.domain.model.enums.CallerType;
import com.inetpsa.rcz.domain.model.enums.EventMessage;
import com.inetpsa.rcz.domain.model.enums.ExchangeStatus;
import com.inetpsa.rcz.domain.model.event.VehicleStateReceived;
import com.inetpsa.rcz.domain.model.event.VehicleWakeUpReceived;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.log.LogMessage;
import com.inetpsa.rcz.domain.model.payload.exception.InvalidTopicException;
import com.inetpsa.rcz.domain.model.payload.topic.Topic;
import com.inetpsa.rcz.domain.model.shared.Payload;
import com.inetpsa.rcz.domain.model.vehicle.State;
import com.inetpsa.rcz.domain.model.vehicle.Vehicle;
import com.inetpsa.rcz.domain.services.ExchangeService;
import com.inetpsa.rcz.domain.services.LogService;
import com.inetpsa.rcz.domain.services.VehicleService;
import org.seedstack.business.domain.BaseDomainEventHandler;
import org.seedstack.business.domain.DomainEventPublisher;
import org.seedstack.business.domain.Factory;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import javax.inject.Inject;
import java.util.Collection;
import java.util.Date;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class VehicleStateReceivedHandler extends BaseDomainEventHandler<VehicleStateReceived> {

    public static final String INVALID_VEHICLE_STATE_FOR_MESSAGE = "Invalid vehicle state for message [%s]";
    public static final String MQTT_VALIDATION_VEHICLE_CONNECTION_UIN = "validation.mqtt.connect.uin";
    @Inject
    private VehicleService vehicleService;

    @Inject
    private Factory<Vehicle> vehicleFactory;

    @Inject
    private Factory<Exchange> exchangeFactory;

    @Inject
    private ExchangeService exchangeService;

    private static Pattern CLIENT_ID_EXTRACTION_PATTERN = Pattern.compile("(ClientId\\s*\\((.*?)\\)){1}");

    private static String CONNECT_TOPIC = "CLIENT_CLIENT_CONNECT_MQTT";

    private static String DISCONNECT_TOPIC = "CLIENT_CLIENT_DISCONNECT_MQTT";

    @Logging
    private Logger logger;

    @Inject
    private LogService logService;

    @Inject
    private DomainEventPublisher eventPublisher;

    private static final String TRUE = "1";
    private static final String FALSE = "0";
    @Configuration(MQTT_VALIDATION_VEHICLE_CONNECTION_UIN)
    private String patternUin = "^[a-zA-Z0-9]{20}$";

    @Override
    public void onEvent(VehicleStateReceived vehicleStateReceived) {
        try {
            String message = getMessage(vehicleStateReceived);
            String uin = getUin(vehicleStateReceived);
            Vehicle vehicle = saveVehicleState(vehicleStateReceived, message, uin);
            Exchange exchange = initExchange(uin, vehicleStateReceived);
            logService.info(LogMessage.create(EventMessage.VEHICLE_UPDATED).data(vehicleStateReceived.getMessage()).topic(vehicleStateReceived.getTopic()), exchange);
            if (vehicle.isConnected()) {
                Collection<Exchange> exchanges = exchangeService.findPendingAsleep(uin);
                exchanges.forEach(ex -> eventPublisher.publish(new VehicleWakeUpReceived(ex)));
            }
        } catch (InvalidVehicleException e) {
            logger.debug(e.getMessage(), e);
        }

    }

    private String getMessage(VehicleStateReceived vehicleStateReceived) {
        if (vehicleStateReceived.getTopic().contains(CONNECT_TOPIC)) {
            return TRUE;
        } else if (vehicleStateReceived.getTopic().contains(DISCONNECT_TOPIC)) {
            return FALSE;
        }
        return vehicleStateReceived.getMessage();
    }

    private String getUin(VehicleStateReceived vehicleStateReceived) throws InvalidVehicleException {
        try {
            Topic topic = new Topic(vehicleStateReceived.getTopic());
            return topic.getId();
        } catch (InvalidTopicException e) {
            return extractUin(vehicleStateReceived.getMessage());
        }
    }

    private String extractUin(String message) throws InvalidVehicleException {
        Matcher matcher = CLIENT_ID_EXTRACTION_PATTERN.matcher(message);
        if (matcher.find()) {
            String uin = matcher.group(2);
            if (Pattern.matches(patternUin, uin)) {
                return uin;
            } else {
                throw new InvalidVehicleException(String.format(INVALID_VEHICLE_STATE_FOR_MESSAGE, message));
            }
        } else {
            throw new InvalidVehicleException(String.format(INVALID_VEHICLE_STATE_FOR_MESSAGE, message));
        }
    }

    private Vehicle saveVehicleState(VehicleStateReceived vehicleStateReceived, String message, String uin) {
        boolean vehicleState = false;
        if (vehicleStateReceived.getMessage() != null) {
            vehicleState = message.contentEquals(TRUE);
        }
        Optional<Vehicle> vehicle = vehicleService.find(uin);

        if (!vehicle.isPresent()) {
            vehicle = Optional.of(vehicleFactory.create(uin));
        }
        State state = new State(vehicleState, new Date());
        vehicle.get().setVehicleState(state);
        vehicleService.save(vehicle.get());
        return vehicle.get();
    }

    private Exchange initExchange(String uin, VehicleStateReceived vehicleStateReceived) {
        Exchange exchange = exchangeFactory.create();
        exchange.setCallerType(CallerType.VEHICLE);
        exchange.setCallerId(uin);
        exchange.setRequest(new Payload(new Date(), vehicleStateReceived.getMessage()));
        exchange.setAction(Action.VEHICLE_STATE);
        exchange.setTopic(vehicleStateReceived.getTopic());
        exchange.setStatus(ExchangeStatus.FINISHED);
        exchange.setUin(uin);
        exchangeService.update(exchange);
        return exchange;
    }
}
