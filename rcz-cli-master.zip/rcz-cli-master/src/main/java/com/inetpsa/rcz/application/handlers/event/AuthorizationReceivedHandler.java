package com.inetpsa.rcz.application.handlers.event;

import com.inetpsa.rcz.domain.model.enums.EventMessage;
import com.inetpsa.rcz.domain.model.event.AuthorizationReceivedEvent;
import com.inetpsa.rcz.domain.model.log.LogMessage;
import com.inetpsa.rcz.domain.services.LogService;
import org.seedstack.business.domain.BaseDomainEventHandler;

import javax.inject.Inject;

public class AuthorizationReceivedHandler extends BaseDomainEventHandler<AuthorizationReceivedEvent> {


    @Inject
    protected LogService logService;

    @Override
    public void onEvent(AuthorizationReceivedEvent event) {
        logService.info(LogMessage.create(EventMessage.AUTHORIZATIONS_RECEIVED).data(event.getAuthorizations()), event.getExchange());
    }
}
