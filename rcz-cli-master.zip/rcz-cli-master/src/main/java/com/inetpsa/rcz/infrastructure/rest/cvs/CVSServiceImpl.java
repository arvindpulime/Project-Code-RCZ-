package com.inetpsa.rcz.infrastructure.rest.cvs;

import com.inetpsa.rcz.application.configuration.RczConfig;
import com.inetpsa.rcz.application.exceptions.AuthorizationException;
import com.inetpsa.rcz.application.services.cvs.CVSService;
import com.inetpsa.rcz.domain.model.parameter.ParameterKey;
import com.inetpsa.rcz.domain.services.ParameterService;
import com.inetpsa.rcz.rest.representation.request.BTARightsRequest;
import com.inetpsa.rcz.rest.representation.request.BTAServicesRequestLean;
import com.inetpsa.rcz.rest.representation.request.ConsumerRightsRequest;
import com.inetpsa.rcz.rest.representation.request.ConsumerServicesRequestLean;
import com.inetpsa.rcz.rest.representation.response.*;
import org.glassfish.jersey.client.authentication.HttpAuthenticationFeature;
import org.glassfish.jersey.jackson.JacksonFeature;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import javax.cache.annotation.CacheResult;
import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.FileInputStream;
import java.io.InputStream;
import java.security.KeyStore;
import java.text.MessageFormat;

/**
 * @author tuan.docao@ext.mpsa.com
 */
@Named("cvs-rest")
public class CVSServiceImpl implements CVSService {

    public static final String ERROR_LOADING_KEY_STORE = "Error while loading keyStore [{0}]";
    @Logging
    private Logger logger;

    private static final String ERR_CONSUMER_RIGHTS = "CVS error on consumer rights: HTTP{0} {1}";

    private static final String ERR_CONSUMER_SERVICES = "CVS error on consumer services: HTTP{0} {1}";

    private static final String ERR_BTA_RIGHTS = "CVS error on BTA rights: HTTP{0} {1}";

    private static final String ERR_BTA_SERVICES = "CVS error on BTA services: HTTP{0} {1}";

    private static final String POST_CONSUMER_RIGHTS = "/api-consumer/consumer-rights-control";

    private static final String GET_CONSUMER_SERVICES_LEAN = "/api-consumer/consumer-rights/lean";

    private static final String POST_BTA_RIGHTS = "/api-vehicle/v2/box-rights-control";

    private static final String GET_BTA_SERVICES_LEAN = "/api-vehicle/v2/box-services/lean";

    private static final String GET_OAUTH_CONSUMER_SERVICES_LEAN = "/am/oauth2/tokeninfo";

    @Configuration
    private RczConfig rczConfig;

    @Inject
    private ParameterService parameterService;

    @Override
    public ConsumerRights postConsumerRights(ConsumerRightsRequest request) throws AuthorizationException {
        Response response = buildClient().target(parameterService.getParameterValue(ParameterKey.CVS_ENDPOINT_URL))
                .path(POST_CONSUMER_RIGHTS)
                .request(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .post(Entity.entity(request, MediaType.APPLICATION_JSON_TYPE));

        if (response.getStatus() == 200) {
            return response.readEntity(ConsumerRights.class);
        } else if (response.getStatus() == 400) {
            throw new AuthorizationException(response.readEntity(String.class));
        } else {
            throw new AuthorizationException(processResponseError(response, ERR_CONSUMER_RIGHTS));
        }
    }

    @Override
    @CacheResult(cacheName = "consumerRightsCache")
    public ConsumerServicesLean getConsumerServices(ConsumerServicesRequestLean request) throws AuthorizationException {
        Response response = buildClient().target(parameterService.getParameterValue(ParameterKey.CVS_ENDPOINT_URL))
                .path(GET_CONSUMER_SERVICES_LEAN)
                .queryParam("event_id", request.getEventId())
                .queryParam("customer_id", request.getAccountId())
                .queryParam("vin", request.getVin())
                .request(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .get();

        if (response.getStatus() == 200) {
            return response.readEntity(ConsumerServicesLean.class);
        } else if (response.getStatus() == 400) {
            throw new AuthorizationException(response.readEntity(String.class));
        } else {
            throw new AuthorizationException(processResponseError(response, ERR_CONSUMER_SERVICES));
        }
    }

    @Override
    public OAuthConsumerServiceLean getOAuthConsumerServices(ConsumerServicesRequestLean request) throws AuthorizationException {
        if (request != null && request.getToken() != null) {
            Response response = buildClient().target(parameterService.getParameterValue(ParameterKey.CVS_OAUTH_ENDPOINT_URL))
                    .path(GET_OAUTH_CONSUMER_SERVICES_LEAN)
                    .request(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                    .header("Authorization", "Bearer " + request.getToken().trim())
                    .get();

            if (response.getStatus() == 200) {
                return response.readEntity(OAuthConsumerServiceLean.class);
            } else if (response.getStatus() == 400) {
                throw new AuthorizationException(response.readEntity(String.class));
            } else {
                throw new AuthorizationException(processResponseError(response, ERR_CONSUMER_SERVICES));
            }
        }
        return null;
    }

    @Override
    public BTARights postBTARights(BTARightsRequest request) throws AuthorizationException {
        Response response = buildClient().target(parameterService.getParameterValue(ParameterKey.CVS_ENDPOINT_URL))
                .path(POST_BTA_RIGHTS)
                .request(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .post(Entity.entity(request, MediaType.APPLICATION_JSON_TYPE));

        if (response.getStatus() == 200) {
            return response.readEntity(BTARights.class);
        } else if (response.getStatus() == 400) {
            throw new AuthorizationException(response.readEntity(String.class));
        } else {
            throw new AuthorizationException(processResponseError(response, ERR_BTA_RIGHTS));
        }
    }

    @Override
    @CacheResult(cacheName = "btaRightsCache")
    public BTAServicesLean getBTAServices(BTAServicesRequestLean request) throws AuthorizationException {
        Response response = buildClient().target(parameterService.getParameterValue(ParameterKey.CVS_ENDPOINT_URL))
                .path(GET_BTA_SERVICES_LEAN)
                .queryParam("event_id", request.getEventId())
                .queryParam("uin", request.getUin())
                .request(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON)
                .get();

        if (response.getStatus() == 200) {
            return response.readEntity(BTAServicesLean.class);
        } else if (response.getStatus() == 400) {
            throw new AuthorizationException(response.readEntity(String.class));
        } else {
            throw new AuthorizationException(processResponseError(response, ERR_BTA_SERVICES));
        }
    }

    private String processResponseError(Response response, String customMessage) {
        return MessageFormat.format(customMessage, response.getStatusInfo().getStatusCode(), response.getStatusInfo().getReasonPhrase());
    }

    private Client buildClient() throws AuthorizationException {
        KeyStore store = loadKeyStore();
        HttpAuthenticationFeature authenticationFeature = HttpAuthenticationFeature.basic(rczConfig.getCvs().getUsername(), rczConfig.getCvs().getPassword());
        return ClientBuilder.newBuilder().trustStore(store).hostnameVerifier((s, sslSession) -> true).register(authenticationFeature).register(JacksonFeature.class).build();
    }

    private KeyStore loadKeyStore() throws AuthorizationException {
        KeyStore store = null;
        try (InputStream is = new FileInputStream(rczConfig.getCvs().getSsl().getTruststore().getFile())) {
            store = KeyStore.getInstance(KeyStore.getDefaultType());
            char[] password = rczConfig.getCvs().getSsl().getTruststore().getPassword().toCharArray();
            store.load(is, password);
        } catch (Exception e) {//NOSONAR
            logger.error(MessageFormat.format(ERROR_LOADING_KEY_STORE, rczConfig.getCvs().getSsl().getTruststore().getFile()), e);
            throw new AuthorizationException(MessageFormat.format(ERROR_LOADING_KEY_STORE, rczConfig.getCvs().getSsl().getTruststore().getFile()));
        }
        return store;
    }


}
