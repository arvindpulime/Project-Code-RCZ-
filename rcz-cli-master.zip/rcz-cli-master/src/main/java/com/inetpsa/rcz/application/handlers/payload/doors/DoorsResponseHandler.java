package com.inetpsa.rcz.application.handlers.payload.doors;

import com.fasterxml.jackson.core.type.TypeReference;
import com.inetpsa.rcz.application.handlers.payload.AbstractResponseHandler;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.payload.data.Data;
import com.inetpsa.rcz.domain.model.payload.data.Doors;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;

public class DoorsResponseHandler extends AbstractResponseHandler<Doors> {

    @Override
    protected Doors handleResponseData(Data data, Exchange exchange) {
        return JsonConverter.convert(data.getValue(), new TypeReference<Doors>() {
        });
    }
}
