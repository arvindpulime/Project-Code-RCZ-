package com.inetpsa.rcz.infrastructure.rest.sms.bytel;

import com.inetpsa.rcz.application.configuration.RczConfig;
import com.inetpsa.rcz.application.exceptions.ApplicationException;
import com.inetpsa.rcz.application.services.VehicleUpstreamService;
import com.inetpsa.rcz.application.services.WakeUpService;
import com.inetpsa.rcz.bytel.answer.PUSHREPLY;
import com.inetpsa.rcz.bytel.heartbeat.PINGHB;
import com.inetpsa.rcz.bytel.sms.*;
import com.inetpsa.rcz.domain.model.parameter.ParameterKey;
import com.inetpsa.rcz.domain.model.sms.Message;
import com.inetpsa.rcz.domain.model.sms.Sms;
import com.inetpsa.rcz.domain.model.sms.User;
import com.inetpsa.rcz.domain.model.sms.UserType;
import com.inetpsa.rcz.domain.model.vehicle.Vehicle;
import com.inetpsa.rcz.domain.services.ParameterService;
import com.inetpsa.rcz.domain.services.SmsService;
import net.jodah.failsafe.RetryPolicy;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.lang.StringUtils;
import org.glassfish.jersey.apache.connector.ApacheConnectorProvider;
import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.client.ClientProperties;
import org.glassfish.jersey.client.RequestEntityProcessing;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.*;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import java.io.StringReader;
import java.io.StringWriter;
import java.time.Duration;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import static javax.ws.rs.client.ClientBuilder.newClient;
import static net.jodah.failsafe.Failsafe.with;

public class WakeUpBytelService implements WakeUpService {

    public static final String HEART_BEAT = "Heart_Beat";

    public static final String VERSION = "1.0";

    public static final String ID_REQUETE = "IDREQUETE";

    public static final String SMS_TEXT_SEPARATOR = "7E";

    public static final String SMS_TEXT_CODE_01 = "01";

    public static final String SMS_TEXT_CODE_02 = "02";

    public static final String SMS_TEXT_CODE_03 = "03";

    public static final String SMS_TEXT_CODE_04 = "04";

    public static final String SMS_TEXT_CODE_05 = "05";

    public static final String SMS_TEXT_CODE_06 = "06";

    public static final String SMS_TEXT_CODE_07 = "07";

    public static final String SMS_TEXT_CODE_08 = "08";

    public static final String SMS_TEXT_CODE_09 = "09";

    public static final String BYTEL_UNMARSHALLING_ERROR = "BYTEL_UNMARSHALLING_ERROR";

    public static final String BYTEL_TIMEOUT_ERROR = "BYTEL_TIMEOUT_ERROR";

    public static final String BYTEL_MARSHALLING_ERROR = "BYTEL_MARSHALLING_ERROR";

    public static final String XML_MESSAGE_PROPERTY = "xmlMsg";
    public static final int BINARY_BASE = 2;
    public static final int FOUR_BYTES = 8;
    public static final int SIX_BYTES = 12;
    public static final int FIVE_BYTES = 10;
    public static final int TEN_BYTES = 20;
    public static final int TWO_BYTES = 4;
    public static final int SINGLE_BYTE = 2;
    public static final String PAD_STR = "0";
    public static final int SIX_BITS = 6;
    public static final int FOUR_BITS = 4;
    public static final int FIVE_BITS = 5;
    public static final int THREE_BYTES = 6;

    @Logging
    private Logger logger;

    @Inject
    private VehicleUpstreamService vehicleService;

    @Inject
    private ParameterService parameterService;

    @Inject
    private SmsService smsService;

    @Configuration
    private RczConfig rczConfig;

    @Override
    public void wakeUp(Vehicle vehicle) throws ApplicationException {
        Sms sms = buildSms(vehicle);
        smsService.update(sms);
        with(buildRetryPolicy()).
                onSuccess(cxn -> sendSms(sms)).
                onFailure(cxn -> smsFail(sms, new BytelException(BYTEL_TIMEOUT_ERROR))).
                runAsync(() -> sendPing(buildPing()));
    }

    /**
     * send a Ping to bytel
     *
     * @param pinghb
     * @throws BytelException
     */
    private void sendPing(PINGHB pinghb) {
        Response response = send(xmlToString(pinghb));
        if (response.getStatus() != 200) {
            throw new BytelException(BYTEL_TIMEOUT_ERROR);
        }
    }

    /**
     * Send an SMS to Bytel
     *
     * @param sms
     */
    private void sendSms(Sms sms) {
        try {
            Response response = send(xmlToString(buildPush(sms)));
            String xml = response.readEntity(String.class);
            PUSHREPLY reply = xmlToObject(xml, PUSHREPLY.class);
            sms.setAnswerStatus(reply.getSTATUS());
            smsService.update(sms);
        } catch (BytelException e) {
            logger.warn(e.getMessage(), e);
            smsFail(sms, e);
        }
    }

    /**
     * Send the request to Bytel
     *
     * @param request value
     * @return Response
     */
    private Response send(String request) {
        MultivaluedMap<String, String> map = new MultivaluedHashMap<>();
        map.putSingle(XML_MESSAGE_PROPERTY, request);


        return initClient().target(parameterService.getParameterValue(ParameterKey.BYTEL_SMS_URI))
                .path(parameterService.getParameterValue(ParameterKey.BYTEL_SMS_PATH))
                .request(MediaType.APPLICATION_FORM_URLENCODED)
                .accept(MediaType.APPLICATION_FORM_URLENCODED, MediaType.TEXT_XML)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_FORM_URLENCODED)
                .post(Entity.form(map));
    }

    private Client initClient() {
        if (Boolean.parseBoolean(parameterService.getParameterValue(ParameterKey.APP_PROXY))) {
            ClientConfig clientConfig = new ClientConfig();
            clientConfig.connectorProvider(new ApacheConnectorProvider());
            clientConfig.property(ClientProperties.PROXY_URI, rczConfig.getProxy().getHost())
                    .property(ClientProperties.PROXY_USERNAME, rczConfig.getProxy().getUsername())
                    .property(ClientProperties.PROXY_PASSWORD, rczConfig.getProxy().getPassword());
            Client client = newClient(clientConfig);
            client.property(ClientProperties.REQUEST_ENTITY_PROCESSING, RequestEntityProcessing.BUFFERED);
            return client;
        }
        return newClient();
    }

    /**
     * Build the Sms
     *
     * @param vehicle to wake
     * @return Sms
     */
    private Sms buildSms(Vehicle vehicle) throws ApplicationException {
        Sms sms = smsService.create();
        sms.setUin(vehicle.getId());
        sms.setAdm(parameterService.getParameterValue(ParameterKey.BYTEL_SMS_ADM));
        sms.setIcp(parameterService.getParameterValue(ParameterKey.BYTEL_SMS_ICP));
        sms.setIdOffer(parameterService.getParameterValue(ParameterKey.BYTEL_SMS_ID_OFFER));
        sms.setVersion(parameterService.getParameterValue(ParameterKey.BYTEL_SMS_PROTOCOL_VERSION));
        sms.setSendingDate(new Date());
        sms.addMessage(new Message(new User(UserType.MSISDN, vehicle.getMsisdn()), parameterService.getParameterValue(ParameterKey.BYTEL_SMS_MESSAGE_FORMAT), buildMessage(vehicle, sms)));
        return sms;
    }

    /**
     * encode string to hexa
     *
     * @param value to encode
     * @return
     */
    private String stringToHex(String value, int nbBytes) {
        if (StringUtils.isNotBlank(value)) {
            return StringUtils.leftPad(Hex.encodeHexString(value.getBytes()), nbBytes, PAD_STR);
        }
        return StringUtils.leftPad("", nbBytes, PAD_STR);
    }

    private String intToHex(String value, int nbBytes) {
        return StringUtils.leftPad(Integer.toHexString(Integer.parseInt(value)), nbBytes, PAD_STR);

    }

    private String intToBinary(int value, int nbBytes) {
        return StringUtils.leftPad(Integer.toBinaryString(value), nbBytes, PAD_STR);

    }

    /**
     * encode date to hexa
     *
     * @param sendingDate to encode
     * @return encoded value
     */
    private String dateToHex(Date sendingDate) {
        Calendar calendar = GregorianCalendar.getInstance();
        calendar.setTime(sendingDate);
        String dateStr = intToBinary(calendar.get(Calendar.YEAR) - 2000, SIX_BITS) +
                intToBinary(calendar.get(Calendar.MONTH) + 1, FOUR_BITS) +
                intToBinary(calendar.get(Calendar.DAY_OF_MONTH), FIVE_BITS) +
                intToBinary(calendar.get(Calendar.HOUR), FIVE_BITS) +
                intToBinary(calendar.get(Calendar.MINUTE), SIX_BITS) +
                intToBinary(calendar.get(Calendar.SECOND), SIX_BITS);
        return StringUtils.leftPad(Long.toHexString(Long.parseLong(dateStr, BINARY_BASE)), FOUR_BYTES, PAD_STR);
    }

    /**
     * Sms update for failed sms
     *
     * @param sms
     * @param bytelException
     */
    private void smsFail(Sms sms, BytelException bytelException) {
        sms.setAnswerStatus(bytelException.getMessage());
        smsService.update(sms);
    }

    /**
     * Internal Retry policy
     *
     * @return Retry policy
     */
    private RetryPolicy buildRetryPolicy() {
        RetryPolicy retryPolicy = new RetryPolicy();
        retryPolicy.
                withDelay(Duration.ofMillis(Integer.parseInt(parameterService.getParameterValue(ParameterKey.BYTEL_SMS_RETRY_DELAY))))
                .withMaxRetries(Integer.parseInt(parameterService.getParameterValue(ParameterKey.BYTEL_SMS_NB_RETRY)))
                .handle(BytelException.class);
        return retryPolicy;
    }

    /**
     * Build Bytel ping
     *
     * @return
     */
    private PINGHB buildPing() {
        PINGHB pinghb = new PINGHB();
        pinghb.setTYPE(HEART_BEAT);
        pinghb.setVERSION(VERSION);
        return pinghb;
    }

    /**
     * Build PUSH from SMS
     *
     * @param sms Sms
     * @return PUSH
     */
    private PUSH buildPush(Sms sms) {

        Message message = sms.getMessages().iterator().next();
        TO to = new TO();
        to.setTYPE(message.getTo().getType().name());
        to.setVALUE(message.getTo().getValue());
        USER user = new USER();
        user.getTO().add(to);

        TEXT text = new TEXT();
        text.setLENGTH(parameterService.getParameterValue(ParameterKey.BYTEL_SMS_MESSAGE_LENGTH));
        text.setvalue(message.getText());

        CONTENT content = new CONTENT();
        content.setFORMAT(message.getFormat());
        content.getUSER().add(user);
        content.getTEXT().add(text);

        PARAMETER parameter = new PARAMETER();
        parameter.setNAME(ID_REQUETE);
        parameter.setVALUE(String.valueOf(sms.getId()));

        OFFER offer = new OFFER();
        offer.setIDOFFER(sms.getIdOffer());
        offer.getPARAMETER().add(parameter);
        offer.getCONTENT().add(content);

        PUSH push = new PUSH();
        push.setVERSION(VERSION);
        push.setADM(sms.getAdm());
        push.setICP(sms.getIcp());
        push.getOFFER().add(offer);

        return push;
    }

    /**
     * Build the bytel SMS message encoded in hexa
     *
     * @param vehicle Vehicle
     * @param sms     Sms
     * @return the message encoded in hexa
     */
    private String buildMessage(Vehicle vehicle, Sms sms) {
        StringBuilder builder = new StringBuilder(SMS_TEXT_CODE_01).append(intToHex(parameterService.getParameterValue(ParameterKey.BYTEL_SMS_MESSAGE_PROTOCOL_VERSION), SINGLE_BYTE))
                .append(SMS_TEXT_SEPARATOR).append(SMS_TEXT_CODE_02).append(stringToHex(vehicle.getShortVin(), TEN_BYTES))
                .append(SMS_TEXT_SEPARATOR).append(SMS_TEXT_CODE_03).append(intToHex(parameterService.getParameterValue(ParameterKey.BYTEL_SMS_DSPT), TWO_BYTES))
                .append(SMS_TEXT_SEPARATOR).append(SMS_TEXT_CODE_04).append(intToHex(parameterService.getParameterValue(ParameterKey.BYTEL_SMS_MESSAGE_ID), TWO_BYTES))
                .append(SMS_TEXT_SEPARATOR).append(SMS_TEXT_CODE_05).append(intToHex(parameterService.getParameterValue(ParameterKey.BYTEL_SMS_SERVICE_TYPE), SINGLE_BYTE))
                .append(SMS_TEXT_SEPARATOR).append(SMS_TEXT_CODE_06).append(intToHex(parameterService.getParameterValue(ParameterKey.BYTEL_SMS_MESSAGE_TYPE), SINGLE_BYTE))
                .append(SMS_TEXT_SEPARATOR).append(SMS_TEXT_CODE_07).append(dateToHex(sms.getSendingDate()))
                .append(SMS_TEXT_SEPARATOR).append(SMS_TEXT_CODE_08).append(intToHex(parameterService.getParameterValue(ParameterKey.BYTEL_SMS_MESSAGE_PROTOCOL_VERSION), SINGLE_BYTE))
                .append(SMS_TEXT_SEPARATOR).append(SMS_TEXT_CODE_09).append(intToHex(parameterService.getParameterValue(ParameterKey.BYTEL_DATA_LENGTH), THREE_BYTES));
        return builder.toString().toUpperCase();
    }

    /**
     * Internal Bytel exception
     */
    private class BytelException extends RuntimeException {
        public BytelException(String message) {
            super(message);
        }

        public BytelException(String message, Throwable cause) {
            super(message, cause);
        }
    }

    /**
     * convert XML to Object
     *
     * @param xmlMessage value
     * @param xmlClass   class
     * @param <T>        return type
     * @return generic object
     */
    private <T> T xmlToObject(String xmlMessage, Class<T> xmlClass) {
        try {
            return (T) JAXBContext.newInstance(xmlClass).createUnmarshaller().unmarshal(new StringReader(xmlMessage));
        } catch (JAXBException e) {
            throw new BytelException(BYTEL_UNMARSHALLING_ERROR, e);
        }
    }

    /**
     * Convert XML object to string
     *
     * @param xmlObject object to convert
     * @param <T>       generic type
     * @return string value
     */
    private <T> String xmlToString(T xmlObject) {
        try {
            final Marshaller m = JAXBContext.newInstance(xmlObject.getClass()).createMarshaller();
            m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            final StringWriter w = new StringWriter();
            m.marshal(xmlObject, w);
            return w.toString();
        } catch (JAXBException e) {
            throw new BytelException(BYTEL_MARSHALLING_ERROR, e);
        }
    }
}
