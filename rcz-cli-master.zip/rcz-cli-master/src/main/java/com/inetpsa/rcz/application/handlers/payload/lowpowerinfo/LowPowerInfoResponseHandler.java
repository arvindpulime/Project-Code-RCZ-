package com.inetpsa.rcz.application.handlers.payload.lowpowerinfo;

import com.fasterxml.jackson.core.type.TypeReference;
import com.inetpsa.rcz.application.handlers.payload.AbstractResponseHandler;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.payload.data.Data;
import com.inetpsa.rcz.domain.model.payload.data.LowPowerInfo;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;

public class LowPowerInfoResponseHandler extends AbstractResponseHandler<LowPowerInfo> {

    @Override
    protected LowPowerInfo handleResponseData(Data data, Exchange exchange) {
        LowPowerInfo result = JsonConverter.convert(data.getValue(), new TypeReference<LowPowerInfo>() {
        });
        return result;
    }
}
