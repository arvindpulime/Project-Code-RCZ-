package com.inetpsa.rcz.infrastructure.mqtt.publisher;

import com.google.inject.Injector;
import com.google.inject.Key;
import com.google.inject.name.Names;
import com.inetpsa.rcz.application.services.PublisherService;
import org.eclipse.paho.client.mqttv3.IMqttClient;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.MqttTopic;
import org.seedstack.seed.Application;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.Arrays;

@Named("mqtt")
public class MqttPublisherService implements PublisherService {

    public static final String RCZ_MQTT_CONFIG_PATH = "rcz.mqtt";
    @Inject
    private Injector injector;

    @Logging
    private Logger logger;

    private MqttConfig.PublisherConfig publisherConfig;

    @Inject
    public MqttPublisherService(Application application) {
        MqttConfig mqttConfig = application.getConfiguration().get(MqttConfig.class, RCZ_MQTT_CONFIG_PATH);
        this.publisherConfig = mqttConfig.getPublish();
    }

    private void publish(final MqttMessage message, final Target target, final String[] clients) {
        if (clients != null) {
            Arrays.asList(clients).forEach(client -> {
                IMqttClient mqttClient = injector.getInstance(Key.get(IMqttClient.class, Names.named(client)));
                try {
                    MqttTopic mqttTopic = mqttClient.getTopic(target.getTopic());
                    mqttTopic.publish(message);
                    logger.debug("PUBLISH TO SERVER : [{}], TOPIC [{}]", client, target.getTopic());
                } catch (Exception e) {//NOSONAR
                    logger.error(client, e);
                }
            });
        }
    }

    @Override
    public void publish(String message, Target target) {
        MqttMessage mqttMessage = getMqttMessage(message);
        publish(mqttMessage, target, publisherConfig.getClients());
    }

    private MqttMessage getMqttMessage(String message) {
        MqttMessage mqttMessage = new MqttMessage();
        mqttMessage.setPayload(message.getBytes());
        mqttMessage.setQos(publisherConfig.getQos());
        mqttMessage.setRetained(publisherConfig.getRetained());
        return mqttMessage;
    }

    @Override
    public void publish(String message, Target target, String... clients) {
        MqttMessage mqttMessage = getMqttMessage(message);
        publish(mqttMessage, target, clients);
    }
}
