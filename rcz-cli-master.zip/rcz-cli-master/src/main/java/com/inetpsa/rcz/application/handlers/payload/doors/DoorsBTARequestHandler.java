package com.inetpsa.rcz.application.handlers.payload.doors;

import com.inetpsa.rcz.application.handlers.payload.BTARequestHandler;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.payload.data.Doors;
import com.inetpsa.rcz.domain.model.payload.request.BTARequestPayload;
import com.inetpsa.rcz.domain.model.payload.request.RequestPayload;

import java.util.Date;

public class DoorsBTARequestHandler implements BTARequestHandler<Doors, Doors> {

    private static final String LOCK = "lock";

    @Override
    public BTARequestPayload<Doors> handle(Exchange exchange, RequestPayload<Doors> requestPayload) {
        BTARequestPayload<Doors> btaRequest = new BTARequestPayload<>();
        btaRequest.setRequestDate(new Date());
        if (requestPayload.getRequestParameters().getAction().contentEquals(LOCK)) {
            btaRequest.setData(new Doors(1));
        } else {
            btaRequest.setData(new Doors(0));
        }
        btaRequest.setRequestId(exchange.getId());
        return btaRequest;
    }
}

