package com.inetpsa.rcz.application.handlers.event;

import com.inetpsa.rcz.application.exceptions.ApplicationException;
import com.inetpsa.rcz.application.handlers.payload.RequestHandler;
import com.inetpsa.rcz.application.services.AuthorizationService;
import com.inetpsa.rcz.application.services.LocalizationService;
import com.inetpsa.rcz.application.services.PublisherService;
import com.inetpsa.rcz.application.services.ValidationService;
import com.inetpsa.rcz.application.util.LocalizationKey;
import com.inetpsa.rcz.domain.model.action.Action;
import com.inetpsa.rcz.domain.model.enums.CallerType;
import com.inetpsa.rcz.domain.model.enums.EventMessage;
import com.inetpsa.rcz.domain.model.enums.ExchangeStatus;
import com.inetpsa.rcz.domain.model.enums.ResponseStatus;
import com.inetpsa.rcz.domain.model.event.AbstractRequestReceivedEvent;
import com.inetpsa.rcz.domain.model.event.CustomerQuotaExceeded;
import com.inetpsa.rcz.domain.model.event.ErrorOccurred;
import com.inetpsa.rcz.domain.model.event.RequestAccepted;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.log.LogMessage;
import com.inetpsa.rcz.domain.model.payload.request.RequestPayload;
import com.inetpsa.rcz.domain.model.payload.topic.Topic;
import com.inetpsa.rcz.domain.model.shared.Payload;
import com.inetpsa.rcz.domain.services.ExchangeService;
import com.inetpsa.rcz.domain.services.LogService;
import org.seedstack.business.domain.BaseDomainEventHandler;
import org.seedstack.business.domain.DomainEventPublisher;
import org.seedstack.business.domain.DomainRegistry;
import org.seedstack.business.domain.Factory;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.Date;

import static com.inetpsa.rcz.application.util.TypeResolver.REQUEST_TYPES;
import static com.inetpsa.rcz.domain.model.payload.topic.Topic.Tag;

/**
 * @author tuan.docao@ext.mpsa.com
 */
public abstract class AbstractRequestReceivedHandler<E extends AbstractRequestReceivedEvent> extends BaseDomainEventHandler<E> {

    @Logging
    protected Logger logger;

    @Inject
    protected Factory<Exchange> exchangeFactory;

    @Inject
    protected ExchangeService exchangeService;

    @Inject
    protected DomainEventPublisher domainEventPublisher;

    @Inject
    protected AuthorizationService authorizationService;

    @Inject
    protected DomainRegistry domainRegistry;

    @Named("mqtt")
    @Inject
    protected PublisherService publisherService;

    @Inject
    protected ValidationService validationService;

    @Inject
    protected LogService logService;

    @Inject
    protected LocalizationService localizationService;

    public void onEvent(E event) {
        final Topic eventTopic = event.getTopic();
        Exchange exchange = initExchange(eventTopic, event.getMessage());
        logService.info(LogMessage.create(EventMessage.REQUEST_RECEIVED).data(event.getMessage()).topic(eventTopic.toString()), exchange);
        RequestHandler<?> requestHandler = domainRegistry.getService(REQUEST_TYPES.get(exchange.getAction()));
        try {
            processRequest(exchange, requestHandler);
        } catch (ApplicationException e) {//NOSONAR
            logger.error(e.getMessage(), e);
            domainEventPublisher.publish(new ErrorOccurred(exchange, e.getResponseStatus(), e.getMessage()));
        }
    }

    private void processRequest(Exchange exchange, RequestHandler<?> requestHandler) throws ApplicationException {
        RequestPayload requestPayload = requestHandler.handle(exchange.getRequest().getRawJson());
        checkForUniqueCorrelationId(requestPayload.getCorrelationId(), exchange.getCallerId());
        enrichExchangeFromRequestPayload(exchange, requestPayload);
        validateRequest(exchange, requestPayload);
        checkAuthorization(exchange);
        domainEventPublisher.publish(new RequestAccepted(exchange));
        process(exchange, requestPayload);
    }

    private void checkForUniqueCorrelationId(String correlationId, String callerId) throws ApplicationException {
        if (exchangeService.correlationIdExist(correlationId, callerId)) {
            throw new ApplicationException(localizationService.localize(LocalizationKey.REQUEST_ERROR_CORRELATION_ID_ERROR_MESSAGE_KEY), ResponseStatus.REQUEST_ERROR);
        }
    }

    private void checkAuthorization(Exchange exchange) throws ApplicationException {
        String uin = authorizationService.authorizeActionOnUIN(exchange);
        updateWithUIN(exchange, uin);
    }

    private void validateRequest(Exchange exchange, RequestPayload requestPayload) throws ApplicationException {
        validationService.validateRequest(requestPayload);
        //validationService.checkTimeout(exchange);
        validationService.checkQuota(exchange);
        validationService.checkDuplicate(exchange);
        validationService.checkActionRight(exchange);
        CheckQuotaForWarning(exchange);
    }

    private void CheckQuotaForWarning(Exchange exchange) {

        try {
            validationService.checkUserQuotaForWarning(exchange);
        } catch (ApplicationException e) {
            domainEventPublisher.publish(new CustomerQuotaExceeded(exchange));
        }
    }

    private Exchange initExchange(Topic topic, String request) {
        Exchange exchange = exchangeFactory.create();
        if (Tag.CID == topic.getTag()) {
            exchange.setCallerType(CallerType.CLIENT);
        } else if (Tag.UID == topic.getTag()) {
            exchange.setCallerType(CallerType.PARTNER);
        }
        exchange.setCallerId(topic.getId());
        exchange.setRequest(new Payload(new Date(), request));
        exchange.setAction(Action.create(topic.getActionService(), topic.getActionType()));
        exchange.setTopic(topic.toString());
        exchange.setStatus(ExchangeStatus.INITIAL);
        exchangeService.update(exchange);
        return exchange;
    }

    private void updateWithUIN(Exchange exchange, String uin) {
        exchange.setUin(uin);
        exchangeService.update(exchange);
    }

    private void enrichExchangeFromRequestPayload(Exchange exchange, RequestPayload requestPayload) {
        exchange.setCorrelationId(requestPayload.getCorrelationId());
        exchange.setVin(requestPayload.getVin());
        exchange.setStatus(ExchangeStatus.PENDING);
        exchange.getRequest().setSentDate(requestPayload.getRequestDate());
        exchangeService.update(exchange);
    }

    abstract void process(Exchange exchange, RequestPayload<?> requestPayload) throws ApplicationException;
}
