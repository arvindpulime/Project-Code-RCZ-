package com.inetpsa.rcz.infrastructure.mqtt.publisher;

import com.inetpsa.rcz.application.configuration.RczConfig;
import com.inetpsa.rcz.application.services.PublisherService;
import com.inetpsa.rcz.application.services.PublisherService.Target.TargetBuilder;
import com.inetpsa.rcz.fixtures.PublishedRczMessageListener;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.testing.junit4.SeedITRunner;

import javax.inject.Named;
import java.util.concurrent.TimeUnit;

@RunWith(SeedITRunner.class)
public class PublisherServiceTest {

    @Named("mqtt")
    @javax.inject.Inject
    private PublisherService publisherService;

    @Configuration
    private RczConfig rczConfig;

    @Test
    public void test() throws InterruptedException {
        Assertions.assertThat(publisherService).isNotNull();
        String message = "{\"req_date\": \"2016-07-07T10:30:00Z\",\n" +
                "\"vin\" : \"VF3CA5FV8CW100632\",\n" +
                "\"customer_id\" : \"987654\",\n" +
                "\"correlation_id\": \"ac8d1c2ccd8311e4341a1681e6b88ec1\",\n" +
                "\"action\": \"horn\",\n" +
                "\"req_parameters\":{\"nb_horn\":5}}";

        publisherService.publish(message, TargetBuilder.builder().withTopic("psa/RemoteServices/to/cid/987654/Test").build());
        try {
            Assertions.assertThat(PublishedRczMessageListener.messageReceivedCount.await(2000, TimeUnit.MILLISECONDS)).isTrue();
        } catch (InterruptedException e) {//NOSONAR
            Assertions.fail(e.getMessage());
        }
    }
}