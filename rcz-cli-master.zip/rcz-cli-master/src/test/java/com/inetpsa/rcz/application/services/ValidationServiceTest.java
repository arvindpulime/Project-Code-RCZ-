package com.inetpsa.rcz.application.services;

import com.fasterxml.jackson.core.type.TypeReference;
import com.inetpsa.rcz.application.exceptions.ApplicationException;
import com.inetpsa.rcz.domain.model.action.Action;
import com.inetpsa.rcz.domain.model.enums.CallerType;
import com.inetpsa.rcz.domain.model.enums.ExchangeStatus;
import com.inetpsa.rcz.domain.model.enums.ProcessStatus;
import com.inetpsa.rcz.domain.model.enums.ResponseStatus;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.payload.data.Horn;
import com.inetpsa.rcz.domain.model.payload.request.RequestPayload;
import com.inetpsa.rcz.domain.model.shared.Payload;
import com.inetpsa.rcz.domain.model.vehicle.Vehicle;
import com.inetpsa.rcz.domain.repository.ExchangeRepository;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;
import com.inetpsa.rcz.infrastructure.rest.commodore.VehicleCommodoreService;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.business.domain.Factory;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.testing.junit4.SeedITRunner;
import org.seedstack.seed.transaction.Transactional;

import javax.inject.Inject;
import java.util.Calendar;
import java.util.Date;

@JpaUnit("rcz")
@RunWith(SeedITRunner.class)
public class ValidationServiceTest {

    @Inject
    private Factory<Exchange> exchangeFactory;

    @Inject
    private ExchangeRepository exchangeRepository;

    @Inject
    private ValidationService validationService;

    @Test
    public void validateRequestErrorTest() throws ApplicationException {

        VehicleCommodoreService vehicleCommodoreService = new VehicleCommodoreService();
        Vehicle vehicle = new Vehicle("VERDFJEOL");
        vehicle.setVin("testVIN");
        vehicleCommodoreService.getFromCommodore(vehicle);
    }

    @Test
    public void validateRequestWithoutErrorTest() {

        try {

            RequestPayload<Horn> requestPayload = getRequestHorn();
            validationService.validateRequest(requestPayload);
        } catch (ApplicationException e) {//NOSONAR
            Assertions.fail(e.getMessage());
        }
    }

    public RequestPayload<Horn> getRequestHorn() {

        String json = "{\"req_date\": \"2016-07-07T10:30:00Z\",\n" +
                "\"vin\" : \"VF3CA5FV8CW100632\",\n" +
                "\"customer_id\" : \"987654\",\n" +
                "\"correlation_id\": \"ac8d1c2ccd8311e4341a1681e6b88ec1\",\n" +
                "\"req_parameters\":{\"nb_horn\":5, \"action\": \"activate\", \"activation\":0}}";
        return JsonConverter.convert(json, new TypeReference<RequestPayload<Horn>>() {
        });
    }

    @Test
    public void checkQuotaWithErrorTest() {

        Date date = new Date();
        Exchange exchange1 = newExchange(CallerType.CLIENT, "1", Action.HORN, date, ExchangeStatus.INITIAL);
        Exchange exchange2 = newExchange(CallerType.CLIENT, "1", Action.HORN, date, ExchangeStatus.INITIAL);
        Exchange exchange3 = newExchange(CallerType.CLIENT, "1", Action.HORN, date, ExchangeStatus.INITIAL);
        persist(exchange1);
        persist(exchange2);
        persist(exchange3);
        try {
            validationService.checkQuota(exchange3);
            Assertions.fail("Quota should have been exceeded");
        } catch (ApplicationException e) {//NOSONAR
            Assertions.assertThat(e.getResponseStatus()).isEqualTo(ResponseStatus.REQUESTS_QUOTA_EXCEEDED);
        }
    }

    @Test
    public void checkQuotaTest() {

        Date date = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.MINUTE, -2);
        Exchange exchange1 = newExchange(CallerType.CLIENT, "1", Action.DOORS, date, ExchangeStatus.INITIAL);
        Exchange exchange2 = newExchange(CallerType.CLIENT, "1", Action.DOORS, date, ExchangeStatus.INITIAL);
        Exchange exchange3 = newExchange(CallerType.CLIENT, "1", Action.DOORS, calendar.getTime(), ExchangeStatus.INITIAL);
        persist(exchange1);
        persist(exchange2);
        persist(exchange3);
        try {
            validationService.checkQuota(exchange3);
        } catch (ApplicationException e) {//NOSONAR
            Assertions.fail(e.getMessage(), e);
        }
    }

    @Transactional
    protected void persist(Exchange exchange1) {

        exchangeRepository.add(exchange1);
    }

    @Test
    public void checkDuplicateWithErrorTest() {

        Date date = new Date();
        Exchange exchange1 = newExchange(CallerType.CLIENT, "1", Action.HORN, date, ExchangeStatus.INITIAL);
        Exchange exchange2 = newExchange(CallerType.CLIENT, "1", Action.HORN, date, ExchangeStatus.PENDING);
        Exchange exchange3 = newExchange(CallerType.CLIENT, "1", Action.HORN, date, ExchangeStatus.INITIAL);
        persist(exchange1);
        persist(exchange2);
        persist(exchange3);
        try {
            validationService.checkDuplicate(exchange3);
        } catch (ApplicationException e) {//NOSONAR
            Assertions.assertThat(e.getResponseStatus()).isEqualTo(ResponseStatus.DUPLICATE);
        }
    }

    @Test
    public void checkDuplicateTest() {

        Date date = new Date();
        Exchange exchange1 = newExchange(CallerType.CLIENT, "2", Action.HORN, date, ExchangeStatus.FINISHED);
        Exchange exchange2 = newExchange(CallerType.CLIENT, "2", Action.HORN, date, ExchangeStatus.ERROR);
        Exchange exchange3 = newExchange(CallerType.CLIENT, "2", Action.HORN, date, ExchangeStatus.INITIAL);
        persist(exchange1);
        persist(exchange2);
        persist(exchange3);
        try {
            validationService.checkDuplicate(exchange3);
        } catch (ApplicationException e) {//NOSONAR
            Assertions.fail(e.getMessage(), e);
        }
    }

    @Test
    public void checkDuplicateOkTest() {

        Date date = new Date();
        Exchange exchange2 = newExchange(CallerType.CLIENT, "1", Action.HORN, date, ExchangeStatus.INITIAL);
        Exchange exchange3 = newExchange(CallerType.CLIENT, "1", Action.DOORS, date, ExchangeStatus.INITIAL);
        persist(exchange2);
        persist(exchange3);
        try {
            validationService.checkDuplicate(exchange3);
        } catch (ApplicationException e) {//NOSONAR
            Assertions.fail(e.getMessage(), e);
        }
    }

    private Exchange newExchange(CallerType callerType, String callerId, Action action, Date requestDate, ExchangeStatus status) {

        Exchange exchange = exchangeFactory.create();
        RequestPayload<Horn> requestPayload = getRequestHorn();
        exchange.setCallerId(callerId);
        exchange.setCallerType(callerType);
        exchange.setAction(action);
        exchange.setCorrelationId(requestPayload.getCorrelationId());
        exchange.setVin(requestPayload.getVin());
        Payload request = new Payload();
        request.setReceivedDate(requestDate);
        request.setRawJson(JsonConverter.convert(requestPayload));
        exchange.setRequest(request);
        exchange.setStatus(status);
        exchange.setProcessStatus(ProcessStatus.REQUEST_SENT_TO_BTA);

        return exchange;
    }

}
