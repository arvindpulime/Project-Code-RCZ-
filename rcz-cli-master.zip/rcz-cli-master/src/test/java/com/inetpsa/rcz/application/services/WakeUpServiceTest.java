package com.inetpsa.rcz.application.services;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.testing.junit4.SeedITRunner;

import javax.inject.Inject;

@Ignore
@RunWith(SeedITRunner.class)
public class WakeUpServiceTest {

    @Inject
    private WakeUpService wakeUpService;

    @Test
    public void validateRequestErrorTest() throws InterruptedException {

    }
}
