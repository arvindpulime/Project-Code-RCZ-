package com.inetpsa.rcz.infrastructure.rest.cvs;

import com.inetpsa.rcz.application.services.cvs.CVSService;
import com.inetpsa.rcz.rest.representation.request.BTARightsRequest;
import com.inetpsa.rcz.rest.representation.request.BTAServicesRequestLean;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 * @author tuan.docao@ext.mpsa.com
 */
@Path("/api-vehicle/v2")
public class CVSVehicleResource {

    @Inject
    @Named("cvs-mock")
    private CVSService cvsService;

    @POST
    @Path("/box-rights-control")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response postBTARights(BTARightsRequest btaRightsRequest) {
        try {
            return Response.ok().entity(cvsService.postBTARights(btaRightsRequest)).type(MediaType.APPLICATION_JSON_TYPE).build();
        } catch (Exception e) {//NOSONAR
            return Response.serverError().build();
        }
    }

    @GET
    @Path("/box-services/lean")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getBTAServices(@QueryParam("uin") String uin) {
        try {

            BTAServicesRequestLean btaServicesRequestLean = new BTAServicesRequestLean();
            btaServicesRequestLean.setUin(uin);
            return Response.ok().entity(cvsService.getBTAServices(btaServicesRequestLean)).type(MediaType.APPLICATION_JSON_TYPE).build();
        } catch (Exception e) {//NOSONAR
            return Response.serverError().build();
        }

    }
}
