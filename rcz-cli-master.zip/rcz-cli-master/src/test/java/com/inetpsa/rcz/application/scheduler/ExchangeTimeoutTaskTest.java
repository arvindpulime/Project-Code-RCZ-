package com.inetpsa.rcz.application.scheduler;

import com.inetpsa.rcz.domain.model.action.Action;
import com.inetpsa.rcz.domain.model.enums.CallerType;
import com.inetpsa.rcz.domain.model.enums.ExchangeStatus;
import com.inetpsa.rcz.domain.model.enums.ResponseStatus;
import com.inetpsa.rcz.domain.model.event.RequestTimeout;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.shared.Payload;
import com.inetpsa.rcz.domain.repository.ExchangeRepository;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.business.domain.DomainEventPublisher;
import org.seedstack.business.domain.Factory;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.testing.junit4.SeedITRunner;
import org.seedstack.seed.transaction.Transactional;

import javax.inject.Inject;
import java.util.Calendar;
import java.util.Date;

@RunWith(SeedITRunner.class)
@JpaUnit("rcz")
public class ExchangeTimeoutTaskTest {

    @Inject
    private DomainEventPublisher eventPublisher;

    @Inject
    private Factory<Exchange> exchangeFactory;

    @Inject
    private ExchangeRepository exchangeRepository;

    @Transactional
    protected void persist(Exchange exchange) {

        exchangeRepository.add(exchange);
    }

    @Transactional(readOnly = true)
    protected Exchange getExchange(String id) {
        return exchangeRepository.get(id).orElse(null);
    }

    @Test
    public void tesGetExpectedEventHandler() {
        Calendar now = Calendar.getInstance();
        now.setTime(new Date());
        now.add(Calendar.MINUTE, -16);
        String topic = "psa/RemoteServices/from/uid/test/Horn";

        Exchange exchange1 = newExchange(CallerType.CLIENT, "2", Action.DOORS, now.getTime(), "exchange1", ExchangeStatus.PENDING);
        exchange1.setTopic(topic);
        persist(exchange1);
        Exchange exchange2 = newExchange(CallerType.CLIENT, "2", Action.DOORS, now.getTime(), "exchange2", ExchangeStatus.INITIAL);
        exchange2.setTopic(topic);
        persist(exchange2);
        Exchange exchange3 = newExchange(CallerType.CLIENT, "2", Action.DOORS, now.getTime(), "exchange3", ExchangeStatus.FINISHED);
        exchange3.setTopic(topic);
        persist(exchange3);
        Exchange exchange4 = newExchange(CallerType.CLIENT, "2", Action.DOORS, now.getTime(), "exchange4", ExchangeStatus.ERROR);
        exchange4.setTopic(topic);
        persist(exchange4);
        eventPublisher.publish(new RequestTimeout());
        Assertions.assertThat(getExchange(exchange1.getId()).getResponseStatus()).isEqualTo(ResponseStatus.VEHICLE_CONNECTION_TIMEOUT);
        Assertions.assertThat(getExchange(exchange2.getId()).getResponseStatus()).isEqualTo(ResponseStatus.VEHICLE_CONNECTION_TIMEOUT);
        Assertions.assertThat(getExchange(exchange3.getId()).getResponseStatus()).isNotEqualTo(ResponseStatus.VEHICLE_CONNECTION_TIMEOUT);
        Assertions.assertThat(getExchange(exchange4.getId()).getResponseStatus()).isNotEqualTo(ResponseStatus.VEHICLE_CONNECTION_TIMEOUT);


    }

    private Exchange newExchange(CallerType callerType, String callerId, Action action, Date requestDate, String correlationId, ExchangeStatus status) {
        Exchange exchange = exchangeFactory.create();
        exchange.setCallerType(callerType);
        exchange.setCallerId(callerId);
        exchange.setAction(action);
        Payload request = new Payload();
        request.setReceivedDate(requestDate);
        request.setSentDate(requestDate);
        exchange.setRequest(request);
        exchange.setCorrelationId(correlationId);
        exchange.setStatus(status);
        return exchange;
    }
}
