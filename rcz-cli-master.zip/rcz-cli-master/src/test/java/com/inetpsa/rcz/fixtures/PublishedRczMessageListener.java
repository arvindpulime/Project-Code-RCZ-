package com.inetpsa.rcz.fixtures;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.seedstack.mqtt.MqttListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.charset.Charset;
import java.util.concurrent.CountDownLatch;

@MqttListener(clients = "${rcz.mqtt.subscribe.test.clients}", topics = {"psa/+/from/#", "psa/+/to/#"}, qos = {"1", "1"})
public class PublishedRczMessageListener implements MqttCallback {

    private static final Logger LOGGER = LoggerFactory.getLogger(PublishedRczMessageListener.class);

    public static CountDownLatch messageReceivedCount = new CountDownLatch(1);

    @Override
    public void connectionLost(Throwable cause) {
    }

    @Override
    public void messageArrived(String topic, MqttMessage message) throws Exception {
        LOGGER.info("BTA ORDER RECEIVE FROM : [{}]", topic);
        LOGGER.info("BTA ORDER CONTENT [{}]", new String(message.getPayload(), Charset.forName("UTF-8")));
        messageReceivedCount.countDown();
    }

    @Override
    public void deliveryComplete(IMqttDeliveryToken token) {

    }
}
