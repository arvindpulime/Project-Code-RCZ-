package com.inetpsa.rcz.infrastructure.rest.cvs;

import com.inetpsa.rcz.application.services.cvs.CVSService;
import com.inetpsa.rcz.rest.representation.request.ConsumerRightsRequest;
import com.inetpsa.rcz.rest.representation.request.ConsumerServicesRequestLean;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
@Path("/")
public class CVSConsumerResource {

    @Inject
    @Named("cvs-mock")
    private CVSService cvsService;

    @POST
    @Path("api-consumer/consumer-rights-control")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response postConsumerRights(ConsumerRightsRequest consumerRightsRequest) {
        try {
            return Response.ok().entity(cvsService.postConsumerRights(consumerRightsRequest)).type(MediaType.APPLICATION_JSON_TYPE).build();
        } catch (Exception e) {//NOSONAR
            return Response.serverError().build();
        }
    }

    @GET
    @Path("api-consumer/consumer-rights/lean")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getConsumerServices(@QueryParam("vin") String vin) {
        try {
            ConsumerServicesRequestLean consumerServicesRequestLean = new ConsumerServicesRequestLean();
            consumerServicesRequestLean.setVin(vin);
            return Response.ok().entity(cvsService.getConsumerServices(consumerServicesRequestLean)).type(MediaType.APPLICATION_JSON_TYPE).build();
        } catch (Exception e) {//NOSONAR
            return Response.serverError().build();
        }
    }

    @GET
    @Path("am/oauth2/tokeninfo")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getOAuthConsumerServices(@Context HttpHeaders httpheaders) {
        try {
            ConsumerServicesRequestLean consumerServicesRequestLean = new ConsumerServicesRequestLean();
            String accessToken = httpheaders.getRequestHeader(HttpHeaders.AUTHORIZATION).iterator().next().split(" ")[1];
            consumerServicesRequestLean.setToken(accessToken);
            return Response.ok().entity(cvsService.getOAuthConsumerServices(consumerServicesRequestLean)).type(MediaType.APPLICATION_JSON_TYPE).build();
        } catch (Exception e) {//NOSONAR
            return Response.serverError().build();
        }
    }

}
