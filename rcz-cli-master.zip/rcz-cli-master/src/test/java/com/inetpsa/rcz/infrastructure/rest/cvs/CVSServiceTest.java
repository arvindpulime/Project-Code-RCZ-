package com.inetpsa.rcz.infrastructure.rest.cvs;

import com.inetpsa.rcz.application.configuration.RczConfig;
import com.inetpsa.rcz.application.exceptions.AuthorizationException;
import com.inetpsa.rcz.application.services.cvs.CVSService;
import com.inetpsa.rcz.domain.model.parameter.ParameterFactory;
import com.inetpsa.rcz.domain.model.parameter.ParameterKey;
import com.inetpsa.rcz.domain.services.ParameterService;
import com.inetpsa.rcz.rest.representation.request.BTARightsRequest;
import com.inetpsa.rcz.rest.representation.request.BTAServicesRequestLean;
import com.inetpsa.rcz.rest.representation.request.ConsumerRightsRequest;
import com.inetpsa.rcz.rest.representation.request.ConsumerServicesRequestLean;
import com.inetpsa.rcz.rest.representation.response.*;
import org.assertj.core.api.Assertions;
import org.assertj.core.util.Lists;
import org.jboss.arquillian.container.test.api.Deployment;
import org.jboss.arquillian.container.test.api.RunAsClient;
import org.jboss.arquillian.junit.Arquillian;
import org.jboss.arquillian.test.api.ArquillianResource;
import org.jboss.shrinkwrap.api.ShrinkWrap;
import org.jboss.shrinkwrap.api.spec.WebArchive;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.Configuration;

import javax.inject.Inject;
import javax.inject.Named;
import java.net.URL;

/**
 * @author tuan.docao@ext.mpsa.com
 */
@RunWith(Arquillian.class)
public class CVSServiceTest {

    @ArquillianResource
    private URL baseURL;

    @Inject
    @Named("cvs-rest")
    private CVSService cvsService;

    @Inject
    private ParameterService parameterService;

    @Inject
    private ParameterFactory parameterFactory;

    @Configuration
    private RczConfig rczConfig;

    @Deployment
    public static WebArchive createDeployment() {
        return ShrinkWrap
                .create(WebArchive.class);
    }

    @Before
    public void setUp() throws Exception {
        parameterService.refreshCache();
        parameterService.updateAll(Lists.newArrayList(parameterFactory.create(ParameterKey.CVS_ENDPOINT_URL, baseURL.toString())));
        parameterService.updateAll(Lists.newArrayList(parameterFactory.create(ParameterKey.CVS_OAUTH_ENDPOINT_URL, baseURL.toString())));
        rczConfig.getCvs().setUsername("demo");
        rczConfig.getCvs().setPassword("dev");
    }

    @RunAsClient
    @Test
    public void testGetConsumerServices() throws NoSuchFieldException, IllegalAccessException, AuthorizationException {
        ConsumerServicesRequestLean consumerServicesRequestLean = new ConsumerServicesRequestLean();
        consumerServicesRequestLean.setVin("VF3CA5FV8CW100632");
        ConsumerServicesLean consumerServices = cvsService.getConsumerServices(consumerServicesRequestLean);
        Assertions.assertThat(consumerServices).isNotNull();
    }

    @RunAsClient
    @Test
    public void testGetOAuthConsumerServices() throws NoSuchFieldException, IllegalAccessException, AuthorizationException {
        ConsumerServicesRequestLean consumerServicesRequestLean = new ConsumerServicesRequestLean();
        consumerServicesRequestLean.setToken("ef7a7628-06ab-47bb-a110-b058270b6c80");
        OAuthConsumerServiceLean consumerServices = cvsService.getOAuthConsumerServices(consumerServicesRequestLean);
        Assertions.assertThat(consumerServices).isNotNull();
    }

    @RunAsClient
    @Test
    public void testGetBTAServices() throws NoSuchFieldException, IllegalAccessException, AuthorizationException {
        BTAServicesRequestLean btaServicesRequestLean = new BTAServicesRequestLean();
        btaServicesRequestLean.setUin("mdercz03");
        BTAServicesLean btaServices = cvsService.getBTAServices(btaServicesRequestLean);
        Assertions.assertThat(btaServices).isNotNull();
    }

    @RunAsClient
    @Test
    public void testPostConsumerRights() throws NoSuchFieldException, IllegalAccessException, AuthorizationException {
        ConsumerRightsRequest consumerRightsRequest = new ConsumerRightsRequest();
        consumerRightsRequest.setServiceCode("serviceCode");
        consumerRightsRequest.setVin("VF3CA5FV8CW100632");
        ConsumerRights consumerRights = cvsService.postConsumerRights(consumerRightsRequest);
        Assertions.assertThat(consumerRights).isNotNull();
    }

    @RunAsClient
    @Test
    public void testPostBTARights() throws NoSuchFieldException, IllegalAccessException, AuthorizationException {
        BTARightsRequest btaRightsRequest = new BTARightsRequest();
        btaRightsRequest.setServiceCode("serviceCode");
        btaRightsRequest.setUin("mdercz00");
        BTARights btaRights = cvsService.postBTARights(btaRightsRequest);
        Assertions.assertThat(btaRights).isNotNull();
    }

}