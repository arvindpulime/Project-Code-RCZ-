package com.inetpsa.rcz.requests;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.inetpsa.rcz.domain.model.payload.data.Horn;
import com.inetpsa.rcz.domain.model.payload.request.RequestPayload;
import org.assertj.core.api.Assertions;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.testing.junit4.SeedITRunner;

import javax.inject.Inject;
import javax.validation.ConstraintViolation;
import javax.validation.ValidatorFactory;
import java.io.IOException;
import java.util.Set;

@RunWith(SeedITRunner.class)
public class HornTest {

    private final ObjectMapper mapper = new ObjectMapper();

    private Set<ConstraintViolation<RequestPayload<Horn>>> violations = null;

    private static final String HORN_VALID_REQUEST = "{\"req_date\": \"2016-07-07T10:30:00Z\",\n" +
            "\"vin\" : \"VF3CA5FV8CW100632\",\n" +
            "\"customer_id\" : \"987654\",\n" +
            "\"correlation_id\": \"ac8d1c2ccd8311e4341a1681e6b88ec1\",\n" +
            "\"req_parameters\":{\"nb_horn\": 5, \"action\": \"activate\"}\n" +
            "}";

    private static final String HORN_INVALID_NESTED_OBJECT = "{\"req_date\": \"2016-07-07T10:30:00Z\",\n" +
            "\"vin\" : \"VF3CA5FV8CW100632\",\n" +
            "\"customer_id\" : \"987654\",\n" +
            "\"correlation_id\": \"ac8d1c2ccd8311e4341a1681e6b88ec1\",\n" +
            "\"req_parameters\":{\"nb_horn\": 6, \"action\": \"activate\"}\n" +

            "}";


    private static final String HORN_MISSING_NESTED_OBJECT = "{\"req_date\": \"2016-07-07T10:30:00Z\",\n" +
            "\"vin\" : \"VF3CA5FV8CW100632\",\n" +
            "\"customer_id\" : \"987654\",\n" +
            "\"correlation_id\": \"ac8d1c2ccd8311e4341a1681e6b88ec1\",\n" +
            "}";

    @Inject
    private ValidatorFactory validatorFactory;


    @Test
    public void testMapperOk() throws IOException {
        RequestPayload<Horn> payload = mapper.readValue(HORN_VALID_REQUEST, new TypeReference<RequestPayload<Horn>>() {
        });
        Set<ConstraintViolation<RequestPayload<Horn>>> violations = validatorFactory.getValidator().validate(payload);
        Assertions.assertThat(violations.isEmpty()).isTrue();
    }

    @Test
    public void testFailedValidation() {
        RequestPayload<Horn> request = new RequestPayload<>();
        Horn horn = new Horn();
        horn.setAction("horn");
        horn.setNbHorn(5);
        request.setRequestParameters(horn);
        violations = validatorFactory.getValidator().validate(request);
        Assertions.assertThat(violations).hasSize(5);
    }

    @Test
    public void testNestedObjectInvalid() throws IOException {
        RequestPayload<Horn> payload = mapper.readValue(HORN_INVALID_NESTED_OBJECT, new TypeReference<RequestPayload<Horn>>() {
        });
        violations = validatorFactory.getValidator().validate(payload);
        Assertions.assertThat(violations).hasSize(1);
    }

    @Test
    @Ignore
    public void testMandatoryNestedObjectNull() throws IOException {
        RequestPayload<Horn> payload = mapper.readValue(HORN_MISSING_NESTED_OBJECT, new TypeReference<RequestPayload<Horn>>() {
        });
        violations = validatorFactory.getValidator().validate(payload);
        Assertions.assertThat(violations).hasSize(1);
    }

}