export const environment = {
  production: false,
  ROOT_URI: '/api/',
};
