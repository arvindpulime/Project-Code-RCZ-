export const environment = {
  production: true,
  ROOT_URI: '/api/',
};
