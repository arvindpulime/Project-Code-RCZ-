import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {HttpClient, HttpHeaders} from "@angular/common/http";
import {map} from "rxjs/operators";
import {Authorization} from "./authorization.representation";
import {environment} from "../../environments/environment";

const LOGIN_ENDPOINT: string = 'web-bridge/security/authorizations?__v=1.0.0';
const LOGOUT_ENDPOINT: string = 'web-bridge/security/authentication?__v=1.0.0';

@Injectable()
export class AuthorizationService {

  private _auth: Authorization;

  constructor(private http: HttpClient) {
  }

  get auth(): Authorization {
    return this._auth;
  }

  checkPermissions(values: string[]): boolean {
    if (this.auth != null && this.auth.roles != null) {
      const roles = this.auth.roles;
      let isExist = false;
      roles.forEach(role => {
        values.forEach(value => {
          if (role.name === value) {
            isExist = true;
          }
        });
      });
      return isExist;
    }
    return true;
  }


  getUserAuthorization(): Observable<Authorization> {
    return this.http.get<Authorization>(environment.ROOT_URI + LOGIN_ENDPOINT)
      .pipe(
        map(value => this._auth = value),
      );
  }

  forceDeAuthenticate(): Observable<boolean> {
    const header = new HttpHeaders().append("Authorization", 'Basic ==forceDeAuthenticate');
    return this.http.get<boolean>(environment.ROOT_URI + LOGIN_ENDPOINT, {headers: header, observe: "response"})
      .pipe(
        map(() => Observable.create(true)),
      );
  }

  deAuthenticate(): Observable<boolean> {
    return this.http.delete<boolean>(environment.ROOT_URI + LOGOUT_ENDPOINT, {observe: "response"})
      .pipe(
        map(() => {
          this._auth = null;
          this.forceDeAuthenticate().subscribe();
          return Observable.create(true);
        }),
      );


  }

}
