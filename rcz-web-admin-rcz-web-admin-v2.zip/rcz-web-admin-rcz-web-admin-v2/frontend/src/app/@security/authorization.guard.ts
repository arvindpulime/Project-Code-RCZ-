import {Injectable} from '@angular/core';
import {ActivatedRouteSnapshot, CanActivate} from '@angular/router';
import {AuthorizationService} from "./authorization.service";

@Injectable()
export class AuthorizationGuard implements CanActivate {

  constructor(private authService: AuthorizationService) {
  }

  canActivate(route: ActivatedRouteSnapshot) {
    if (route.data.roles) {
      return this.authService.checkPermissions(route.data.roles);
    } else {
      return true;
    }
  }
}
