export class Authorization {
  id: string;
  type: string;
  principals: Principals;
  roles: Array<Role>;
  permissions: Array<string[]>;
}

export interface Principals {

  userId: string;
  locale: string;
  firstName: string;
  lastName: string;
  fullName: string;

}

export interface Role {

  name: string;
  attributes: Map<string, Array<string>>;
  permissions: Array<string[]>;

}

export enum Roles {
  SUPER_ADMIN = 'RCZ_SUPER_ADMIN',
  ADMIN = 'RCZ_ADMIN',
  READER = 'RCZ_READER',
}
