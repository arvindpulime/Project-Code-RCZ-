import {Component} from '@angular/core';

@Component({
  selector: 'ngx-monitoring',
  template: `
    <router-outlet></router-outlet>
  `,
})
export class MonitoringComponent {

}
