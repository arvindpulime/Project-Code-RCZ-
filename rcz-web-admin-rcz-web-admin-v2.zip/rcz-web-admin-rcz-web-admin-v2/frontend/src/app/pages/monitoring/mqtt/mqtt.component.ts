import {Component, OnInit, TemplateRef} from '@angular/core';
import {MqttResource} from "./mqtt.resource";
import {NbDialogService} from "@nebular/theme";
import {ActivatedRoute} from "@angular/router";
import {MqttService} from "./mqtt.service";


@Component({
  selector: 'ngx-exchanges',
  templateUrl: './mqtt.component.html',
  styleUrls: ['./mqtt.component.scss'],
})
export class MqttComponent implements OnInit {

  instances: Map<string, Array<MqttResource>>;

  constructor(private route: ActivatedRoute, private dialogService: NbDialogService, private mqttService: MqttService) {

  }

  ngOnInit() {
    this.route.data.subscribe((data: { instances: Map<string, Array<MqttResource>> }) => this.instances = data.instances);
  }

  showList(list: any, title: string, dialog: TemplateRef<any>): void {
    const data = {title: title, list: list};
    this.dialogService.open(dialog, {
      closeOnEsc: true,
      hasScroll: true,
      context: data,
    });
  }

  onOpenLogDialog(data: any, dialog: TemplateRef<any>): void {
    let content = JSON.parse('{"content": "no content"}');
    if (data !== null) {
      try {
        content = data;
      } catch (e) {
        content = JSON.parse(`{"message": "${data}"}`);
      }
    }

    this.dialogService.open(dialog, {
      closeOnEsc: true,
      hasScroll: true,
      context: content,
    });
  }

  copy(val: string) {
    const selBox = document.createElement('textarea');
    selBox.style.position = 'fixed';
    selBox.style.left = '0';
    selBox.style.top = '0';
    selBox.style.opacity = '0';
    selBox.value = JSON.stringify(val, null, 2);
    document.body.appendChild(selBox);
    selBox.focus();
    selBox.select();
    document.execCommand('copy');
    document.body.removeChild(selBox);
  }

  refresh() {
    this.mqttService.getInstances().subscribe(data => {
      this.instances = data;
    });
  }

}
