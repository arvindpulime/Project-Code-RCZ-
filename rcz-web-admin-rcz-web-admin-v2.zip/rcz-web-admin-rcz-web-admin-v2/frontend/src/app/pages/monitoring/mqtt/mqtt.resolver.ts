import {Injectable} from "@angular/core";
import {Resolve} from "@angular/router";
import {Observable} from "rxjs";
import {MqttResource} from "./mqtt.resource";
import {MqttService} from "./mqtt.service";

@Injectable()
export class MqttResolver implements Resolve<Map<string, Array<MqttResource>>> {

  constructor(private mqttService: MqttService) {
  }

  resolve(): Observable<Map<string, Array<MqttResource>>> {
    return this.mqttService.getInstances();
  }
}
