import {Injectable} from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";
import {environment} from "../../../../environments/environment";
import {MqttResource} from "./mqtt.resource";

@Injectable()
export class MqttService {

  constructor(private http: HttpClient) {
  }

  getInstances(): Observable<Map<string, Array<MqttResource>>> {
    return this.http.get<Map<string, Array<MqttResource>>>(environment.ROOT_URI + 'mqtt');
  }

}
