import {Injectable} from "@angular/core";


@Injectable()
export class MqttResource {
  clientId: string;
  connected: boolean;
  serverURIs: Array<string>;
  topics: Array<string>;
  reconnectionMode: string;
  reconnectionInterval: number;
  keepAliveInterval: number;
  cleanSession: boolean;
  mqttVersion: number;
  connectionTimeout: number;
  poolCoreSize: number;
  poolMaxSize: number;
  poolQueueSize: number;
  poolKeepAlive: number;
}
