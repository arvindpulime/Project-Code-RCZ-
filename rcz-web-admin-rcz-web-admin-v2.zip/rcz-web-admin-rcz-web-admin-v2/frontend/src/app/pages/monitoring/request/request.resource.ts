import {Resource} from "angular4-hal";
import {Injectable} from "@angular/core";
import {Action} from "../shared/action";

@Injectable()
export class RequestResource extends Resource {
  id: string;
  callerType: string;
  callerId: string;
  vin: string;
  action: Action;
  requestRawJson: string;
  status: string;
  requestReceivedDate: Date;
  customerId: string;
}
