import {Injectable, Injector} from "@angular/core";
import {RestService} from "angular4-hal";
import {RequestResource} from "./request.resource";
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";
import {Enums} from "../shared/enums";
import {environment} from "../../../../environments/environment";


@Injectable()
export class RequestService extends RestService<RequestResource> {

  constructor(injector: Injector, private http: HttpClient) {
    super(RequestResource, 'requests', injector);
  }

  getRequestEnums(): Observable<Enums> {
    return this.http.get<Enums>(environment.ROOT_URI + 'requests/enums');
  }


}
