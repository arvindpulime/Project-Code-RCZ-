import {Component, OnInit, TemplateRef} from '@angular/core';
import {Thead} from "../../../@theme/components/table/thead";
import {Enums} from "../shared/enums";
import {ActivatedRoute, Params, Router} from "@angular/router";
import {TheadComponent} from "../../../@theme/components";
import {HalParam} from "angular4-hal";
import {isNullOrUndefined} from "util";
import {NbCalendarRange, NbDialogService} from "@nebular/theme";
import {RequestResource} from "./request.resource";
import {RequestService} from "./request.service";


export interface Filter {
  dateRange?: NbCalendarRange<Date>;
  dateFrom?: number;
  dateTo?: number;
  pageNumber?: number;
  pageSize?: number;
  order?: string;
  sort?: string;
  id?: string;
  callerId?: string;
  customerId?: string;
  vin?: string;
  callerTypes?: string[];
  actionServices?: string[];
  actionTypes?: string[];
  requestStatuses?: string[];
}

@Component({
  selector: 'ngx-request',
  templateUrl: './request.component.html',
  styleUrls: ['./request.component.scss'],
})
export class RequestComponent implements OnInit {

  columns: Array<Thead> = [
    {name: "ID"},
    {name: "RECEIVED_DATE", filterName: "RECEIVED_DATE"},
    {name: "VIN", filterName: "VIN"},
    {name: "CUSTOMER_ID", filterName: "CUSTOMER_ID"},
    {name: "STATUS", filterName: "STATUS"},
    {name: "CALLER_ID", filterName: "CALLER_ID"},
    {name: "CALLER_TYPE", filterName: "CALLER_TYPE"},
    {name: "ACTION_TYPE", filterName: "ACTION_TYPE"},
    {name: "ACTION_SERVICE", filterName: "ACTION_SERVICE"},
    {name: "DATA"},
  ];
  enums: Enums = {
    actionServices: [],
    actionTypes: [],
    exchangeStatuses: [],
    responseStatuses: [],
    processStatuses: [],
    callerTypes: [],
  };
  loading: boolean = true;
  requests: RequestResource[] = [];
  filterParam: Filter = {
    dateRange: null,
    dateFrom: null,
    dateTo: null,
    pageNumber: null,
    pageSize: null,
    order: null,
    sort: null,
    id: null,
    callerId: null,
    customerId: null,
    vin: null,
    actionServices: [],
    callerTypes: [],
    actionTypes: [],
    requestStatuses: [],
  };
  pagination: any = {pageNumber: 10, pageSize: 1, totalElements: 10};

  constructor(
    private requestsService: RequestService,
    private route: ActivatedRoute,
    private router: Router,
    private dialogService: NbDialogService,
  ) {

  }

  ngOnInit() {
    this.initFilter();
    this.queryParam2Filter();
    this.processDataTable();
  }

  onSort(value): void {
    this.loading = true;
    this.filterParam.sort = value.sort;
    this.filterParam.order = value.order;
    this.getAll();
  }

  onPageChange(page: number): void {
    this.loading = true;
    this.filterParam.pageNumber = page;
    this.getAll();
  }

  onPageSizeChange(value: number): void {
    this.loading = true;
    this.filterParam.pageSize = value;
    this.getAll();
  }

  onClearFilter(): void {
    this.filterParam = {
      dateRange: null,
      dateFrom: null,
      dateTo: null,
      pageNumber: null,
      pageSize: null,
      order: null,
      sort: null,
      id: null,
      callerId: null,
      customerId: null,
      vin: null,
      actionServices: [],
      callerTypes: [],
      actionTypes: [],
      requestStatuses: [],
    };
    TheadComponent.resetSortIcon();
  }

  onSearch(): void {
    this.processDataTable();
  }

  private processDataTable(): void {
    this.loading = true;
    this.getAll();
  }

  private initFilter(): void {
    this.requestsService.getRequestEnums().subscribe(data => {
      this.enums = data;
    });
  }

  private getAll() {
    const params = this.buildHalParams();
    if (!isNullOrUndefined(params)) {
      this.filter2QueryParam(params);
    }
    this.requestsService.getAll({params: params}).subscribe(data => {
      this.updateData(data);
    });
  }

  private updateData(data) {
    this.loading = false;
    this.requests = data;
    this.pagination.totalElements = this.requestsService.resourceArray.totalElements;
    this.pagination.pageNumber = this.requestsService.resourceArray.pageNumber;
    this.pagination.pageSize = this.requestsService.resourceArray.pageSize;
  }

  private buildHalParams(): HalParam[] {

    if (!isNullOrUndefined(this.filterParam.dateRange)) {
      this.filterParam.dateFrom = this.filterParam.dateRange.start.getTime();
      this.filterParam.dateTo = this.filterParam.dateRange.end.getTime();
    }

    const params: HalParam[] = [];
    if (!isNullOrUndefined(this.filterParam)) {
      Object.keys(this.filterParam).forEach(key => {
        const value = this.filterParam[key];
        if (!isNullOrUndefined(value) && value !== [] && !/^\s*$/.test(value) && key !== "dateRange") {
          params.push({key: key, value: value});
        }
      });
    }

    return params;
  }

  onOpenLogDialog(id: string, dialog: TemplateRef<any>): void {
    this.requestsService.get(id).subscribe(
      request => {
        this.dialogService.open(dialog, {
          closeOnEsc: true,
          hasScroll: true,
          context: JSON.parse(!isNullOrUndefined(request.requestRawJson) !== null ? request.requestRawJson : '{"content": "no content"}'),
        });
      });
  }

  copy(val: string) {
    const selBox = document.createElement('textarea');
    selBox.style.position = 'fixed';
    selBox.style.left = '0';
    selBox.style.top = '0';
    selBox.style.opacity = '0';
    selBox.value = JSON.stringify(val, null, 2);
    document.body.appendChild(selBox);
    selBox.focus();
    selBox.select();
    document.execCommand('copy');
    document.body.removeChild(selBox);
  }

  refresh() {
    this.processDataTable();
  }

  private queryParam2Filter() {
    this.route.queryParams.subscribe(params => {
      if (!isNullOrUndefined(params)) {
        Object.keys(params).forEach(key => {
          if (this.filterParam.hasOwnProperty(key)) {
            this.filterParam[key] = params[key];
          }
        });
      }
    });
  }

  private filter2QueryParam(params: HalParam[]) {
    const queryParams: Params = [];
    params.forEach(el => queryParams[el.key] = el.value);
    this.router.navigate([], {
      queryParams: queryParams,
    });
  }

}
