import {Component, OnInit, TemplateRef} from '@angular/core';
import {Thead} from "../../../@theme/components/table/thead";
import {NbCalendarRange, NbDialogService} from "@nebular/theme";
import {HalParam} from "angular4-hal";
import {isNullOrUndefined} from "util";
import {TheadComponent} from "../../../@theme/components";
import {LogService} from "./log.service";
import {LogResource} from "./log.resource";
import {ActivatedRoute, Params, Router} from "@angular/router";


export interface Filter {
  logDateRange?: NbCalendarRange<Date>;
  logDateFrom?: number;
  logDateTo?: number;
  pageNumber?: number;
  pageSize?: number;
  order?: string;
  sort?: string;
  date?: string;
  logLevels?: string[];
  message?: string;
  exchange?: string;
  topic?: string;
  instances?: string[];
}

@Component({
  selector: 'ngx-log',
  templateUrl: './log.component.html',
  styleUrls: ['./log.component.scss'],
})
export class LogComponent implements OnInit {

  columns: Array<Thead> = [
    {name: "DATE", filterName: "LOG_DATE"},
    {name: "LEVEL", filterName: "LOG_LEVEL"},
    {name: "MESSAGE", filterName: "MESSAGE"},
    {name: "EXCHANGE", filterName: "EXCHANGE"},
    {name: "TOPIC", filterName: "TOPIC"},
    {name: "INSTANCE", filterName: "INSTANCE"},
    {name: "DATA"},
  ];

  loading: boolean = true;
  logs: LogResource[] = [];
  levels: string[] = [];
  instances: string[] = [];
  filterParam: Filter = {
    logDateRange: null,
    logDateFrom: LogComponent.getTenMinAgo(),
    logDateTo: LogComponent.getLastDayOfTheWeek(),
    pageNumber: null,
    pageSize: null,
    order: null,
    sort: null,
    date: null,
    logLevels: null,
    message: null,
    exchange: null,
    topic: null,
    instances: [],
  };
  pagination: any = {pageNumber: 10, pageSize: 1, totalElements: 10};

  constructor(
    private logService: LogService,
    private route: ActivatedRoute,
    private router: Router,
    private dialogService: NbDialogService,
  ) {
    const queryParam = this.route.snapshot.queryParamMap;
    if (queryParam.has('exchange'))
      this.filterParam.exchange = queryParam.get('exchange');
  }

  ngOnInit() {
    this.initFilter();
    this.queryParam2Filter();
    this.processDataTable();
  }

  onSort(value): void {
    this.loading = true;
    this.filterParam.sort = value.sort;
    this.filterParam.order = value.order;
    this.getAll();
  }

  onPageChange(page: number): void {
    this.loading = true;
    this.filterParam.pageNumber = page;
    this.getAll();
  }

  onPageSizeChange(value: number): void {
    this.loading = true;
    this.filterParam.pageSize = value;
    this.getAll();
  }

  onClearFilter(): void {
    this.filterParam = {
      logDateRange: null,
      logDateFrom: null,
      logDateTo: null,
      pageNumber: null,
      pageSize: null,
      order: null,
      sort: null,
      date: null,
      logLevels: [],
      message: null,
      exchange: null,
      topic: null,
      instances: [],
    };
    TheadComponent.resetSortIcon();
  }
  onReset(): void {
    this.filterParam = {
      pageNumber: null,
      pageSize: null,
      order: null,
      sort: null,
      date: null,
      logLevels: [],
      message: null,
      exchange: null,
      topic: null,
      instances: [],
    };
    TheadComponent.resetSortIcon();
  }
  onSearch(): void {
    this.processDataTable();
  }

  private processDataTable(): void {
    this.loading = true;
    this.getAll();
  }

  private initFilter(): void {
    this.logService.getAvailableLevels().subscribe(data => {
      this.levels = data;
    });
    this.logService.getAvailableInstances().subscribe(data => {
      this.instances = data;
    });
  }

  private getAll() {
    const params = this.buildHalParams();
    if (!isNullOrUndefined(params)) {
      this.filter2QueryParam(params);
    }
    this.logService.getAll({params: params}).subscribe(data => {
      this.updateData(data);
    });
  }

  private updateData(data) {
    this.loading = false;
    this.logs = data;
    this.pagination.totalElements = this.logService.resourceArray.totalElements;
    this.pagination.pageNumber = this.logService.resourceArray.pageNumber;
    this.pagination.pageSize = this.logService.resourceArray.pageSize;
  }

  private buildHalParams(): HalParam[] {
    this.filterParam.logDateFrom = null;
    this.filterParam.logDateTo = null;
    if (!isNullOrUndefined(this.filterParam.logDateRange)) {
      this.filterParam.logDateFrom = this.filterParam.logDateRange.start.getTime();
      this.filterParam.logDateTo = this.filterParam.logDateRange.end.getTime();
    }

    const params: HalParam[] = [];
    if (!isNullOrUndefined(this.filterParam)) {
      Object.keys(this.filterParam).forEach(key => {
        const value = this.filterParam[key];
        if (!isNullOrUndefined(value) && value !== [] && !/^\s*$/.test(value) && key !== "logDateRange") {
          params.push({key: key, value: value});
        }
      });
    }

    return params;
  }

  onOpenLogDialog(id: number, dialog: TemplateRef<any>): void {
    this.logService.get(id).subscribe((data) => {

      let content = JSON.parse('{"content": "no content"}');
      if (data.payload !== null) {
        try {
          content = JSON.parse(data.payload);
        } catch (e) {
          content = JSON.parse(`{"message": "${data.payload}"}`);
        }
      }

      this.dialogService.open(dialog, {
        closeOnEsc: true,
        hasScroll: true,
        context: content,
      });
    });
  }

  copy(val: string) {
    const selBox = document.createElement('textarea');
    selBox.style.position = 'fixed';
    selBox.style.left = '0';
    selBox.style.top = '0';
    selBox.style.opacity = '0';
    selBox.value = JSON.stringify(val, null, 2);
    document.body.appendChild(selBox);
    selBox.focus();
    selBox.select();
    document.execCommand('copy');
    document.body.removeChild(selBox);
  }

  refresh() {
    this.processDataTable();
  }

  private queryParam2Filter() {
    this.route.queryParams.subscribe(params => {
      if (!isNullOrUndefined(params)) {
        let keys = Object.keys(params);
        if ([] !== keys && keys.length > 0) {
          this.onClearFilter();
          keys.forEach(key => {
            if (this.filterParam.hasOwnProperty(key)) {
              this.filterParam[key] = params[key];
            }
          });
        }
        this.setDateRange();
      }
    });
  }

  private setDateRange() {
    if (!isNullOrUndefined(this.filterParam.logDateFrom) && !isNullOrUndefined(this.filterParam.logDateTo)) {
      this.filterParam.logDateRange = {
        start: new Date(),
        end: new Date(),
      };
      this.filterParam.logDateRange.start.setTime(this.filterParam.logDateFrom);
      this.filterParam.logDateRange.end.setTime(this.filterParam.logDateTo);
    }
  }

  private static getTenMinAgo(): number {
    var curr = new Date(); // get current date
    curr.setMinutes(curr.getMinutes() - 10);
    return curr.getTime();
  }

  private static getTimestamp(day): number {
    const date: Date = new Date();
    date.setDate(date.getDate() + day);
    date.setUTCHours(0, 0, 0, 0);
    return date.getTime();
  }

  private static getFirstDayOfTheWeek(): number {
    var curr = new Date(); // get current date
    curr.setHours(1, 0, 0, 0);
    var first = curr.getDate() - curr.getDay() + 1; // First day is the day of the month - the day of the week
    return new Date(curr.setDate(first)).getTime();
  }

  private static getLastDayOfTheWeek(): number {
    var curr = new Date(); // get current date
    curr.setHours(23, 59, 0, 0);
    var first = curr.getDate() - curr.getDay() + 1; // First day is the day of the month - the day of the week
    var last = first + 6; // last day is the first day + 6
    return new Date(curr.setDate(last)).getTime();
  }

  private filter2QueryParam(params: HalParam[]) {
    const queryParams: Params = [];
    if ([] !== params) {
      params.forEach(el => queryParams[el.key] = el.value);
      this.router.navigate([], {
        queryParams: queryParams,
      });
    }
  }

}
