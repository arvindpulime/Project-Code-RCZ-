import {Injectable, Injector} from '@angular/core';
import {RestService} from "angular4-hal";
import {HttpClient} from "@angular/common/http";
import {LogResource} from "./log.resource";
import {Observable} from "rxjs";
import {environment} from "../../../../environments/environment";

@Injectable()
export class LogService extends RestService<LogResource> {

  constructor(injector: Injector, private http: HttpClient) {
    super(LogResource, 'logs', injector);
  }

  getAvailableLevels(): Observable<string[]> {
    return this.http.get<string[]>(environment.ROOT_URI + 'logs-levels');
  }

  getAvailableInstances(): Observable<string[]> {
    return this.http.get<string[]>(environment.ROOT_URI + 'logs-instances');
  }

}
