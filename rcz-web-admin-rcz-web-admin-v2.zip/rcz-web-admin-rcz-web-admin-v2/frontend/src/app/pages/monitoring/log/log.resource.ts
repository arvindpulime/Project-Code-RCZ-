import {Resource} from "angular4-hal";
import {Injectable} from "@angular/core";


@Injectable()
export class LogResource extends Resource {
  id: string;
  date: Date;
  level: string;
  message: string;
  exchange: string;
  topic: string;
  serverInstance: string;
  payload: string;
}
