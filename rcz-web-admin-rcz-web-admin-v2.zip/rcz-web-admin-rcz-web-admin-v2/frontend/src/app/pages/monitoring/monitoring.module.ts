import {NgModule} from '@angular/core';
import {ApplicationComponent} from './application/application.component';
import {ExchangesComponent} from './exchanges/exchanges.component';
import {RequestComponent} from './request/request.component';
import {SmsComponent} from './sms/sms.component';
import {VehicleComponent} from './vehicle/vehicle.component';
import {MonitoringRoutingModule} from './monitoring-routing.module';
import {ThemeModule} from '../../@theme/theme.module';
import {MonitoringComponent} from './monitoring.component';
import {NgbPaginationModule} from '@ng-bootstrap/ng-bootstrap';
import {ExchangesService} from './exchanges/exchanges.service';
import {FormsModule as ngFormsModule} from '@angular/forms';
import {LogComponent} from './log/log.component';
import {LogService} from './log/log.service';
import {NgxJsonViewerModule} from 'ngx-json-viewer';
import {SmsService} from './sms/sms.service';
import {RequestService} from './request/request.service';
import {UserLogComponent} from './user-logs/user-log.component';
import {UserLogService} from './user-logs/user-log.service';
import {VehicleService} from './vehicle/vehicle.service';
import {ApplicationService} from './application/application.service';
import {MqttComponent} from "./mqtt/mqtt.component";
import {MqttService} from "./mqtt/mqtt.service";
import {MqttResolver} from "./mqtt/mqtt.resolver";
import {NbDateFnsDateModule} from "@nebular/date-fns";
import {
  NbAccordionModule,
  NbActionsModule,
  NbButtonModule,
  NbCardModule,
  NbCheckboxModule,
  NbDatepickerModule,
  NbIconModule,
  NbInputModule,
  NbLayoutModule,
  NbListModule,
  NbSelectModule,
  NbSpinnerModule,
  NbTabsetModule,
  NbTooltipModule,
} from "@nebular/theme";


const declarations = [
  MonitoringComponent,
  ApplicationComponent,
  ExchangesComponent,
  LogComponent,
  RequestComponent,
  SmsComponent,
  UserLogComponent,
  VehicleComponent,
  MqttComponent,
];

const imports = [
  ThemeModule,
  MonitoringRoutingModule,
  NbCardModule,
  NbIconModule,
  NbActionsModule,
  NgbPaginationModule,
  NbSpinnerModule,
  NbTooltipModule,
  NbSelectModule,
  NbCheckboxModule,
  NbAccordionModule,
  NbDatepickerModule,
  NbInputModule,
  ngFormsModule,
  NbButtonModule,
  NgxJsonViewerModule,
  NbLayoutModule,
  NbTabsetModule,
  NbListModule,
  NbDateFnsDateModule,
];

const providers = [
  ExchangesService,
  LogService,
  SmsService,
  RequestService,
  UserLogService,
  VehicleService,
  ApplicationService,
  MqttService,
  MqttResolver,
];

@NgModule({
  declarations: [...declarations],
  imports: [...imports],
  providers: providers,
})
export class MonitoringModule {
}
