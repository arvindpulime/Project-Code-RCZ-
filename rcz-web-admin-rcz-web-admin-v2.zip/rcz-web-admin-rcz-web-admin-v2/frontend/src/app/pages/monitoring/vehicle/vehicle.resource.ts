import {Resource} from "angular4-hal";
import {Injectable} from "@angular/core";

@Injectable()
export class VehicleResource extends Resource {
  id?: string;
  vin?: string;
  updateDate?: Date;
  btaType?: string;
  msisdn?: string;
  provider?: string;
  vehicleState?: State;
  serviceState?: State;
  vehicleInfo?: Payload;
  lowPowerInfo?: Payload;
  serviceInfo?: Payload;
}

export interface Payload {
  receivedDate?: Date;
  sentDate?: Date;
  rawJson?: string;
}

export interface State {
  connected?: boolean;
  receivedDate?: Date;
}
