import {Component, OnInit, TemplateRef} from '@angular/core';
import {Thead} from "../../../@theme/components/table/thead";
import {NbCalendarRange, NbDialogService} from "@nebular/theme";
import {TheadComponent} from "../../../@theme/components";
import {HalParam} from "angular4-hal";
import {isNullOrUndefined} from "util";
import {VehicleResource} from "./vehicle.resource";
import {VehicleService} from "./vehicle.service";
import {ActivatedRoute, Params, Router} from "@angular/router";


export interface Filter {
  vehicleDateRange?: NbCalendarRange<Date>;
  vehicleDateFrom?: number;
  vehicleDateTo?: number;
  pageNumber?: number;
  pageSize?: number;
  order?: string;
  sort?: string;
  id?: string;
  vin?: string;
  msisdn?: string;
}

@Component({
  selector: 'ngx-vehicle',
  templateUrl: './vehicle.component.html',
  styleUrls: ['./vehicle.component.scss'],
})
export class VehicleComponent implements OnInit {

  columns: Array<Thead> = [
    {name: "UPDATE DATE", filterName: "UPDATE_DATE"},
    {name: "UIN"},
    {name: "VIN"},
    {name: "BTA TYPE"},
    {name: "MSISDN"},
    {name: "PROVIDER"},
    {name: "VEHICLE STATE DATE", filterName: "VEHICLE_STATE_DATE"},
    {name: "SERVICE STATE DATE", filterName: "SERVICE_STATE_DATE"},
    {name: "VEHICLE INFO DATE", filterName: "VEHICLE_INFO_DATE"},
    {name: "VEHICLE INFO DETAIL"},
    {name: "LOW POWER INFO DATE", filterName: "LOW_POWER_INFO_DATE"},
    {name: "LOW POWER INFO DETAIL"},
    {name: "SERVICE INFO DATE", filterName: "SERVICE_INFO_DATE"},
    {name: "SERVICE INFO INFO DETAIL"},
  ];
  filterParam: Filter = {
    vehicleDateRange: null,
    vehicleDateFrom: null,
    vehicleDateTo: null,
    pageNumber: null,
    pageSize: null,
    order: null,
    sort: null,
    id: null,
    vin: null,
    msisdn: null,
  };
  loading: boolean = true;
  vehicles: VehicleResource[] = [];
  pagination: any = {pageNumber: 10, pageSize: 1, totalElements: 10};

  constructor(
    private vehicleService: VehicleService,
    private dialogService: NbDialogService,
    private route: ActivatedRoute,
    private router: Router,
  ) {
  }

  ngOnInit() {
    this.processDataTable();
    this.queryParam2Filter();
  }

  onSort(value): void {
    this.loading = true;
    this.filterParam.sort = value.sort;
    this.filterParam.order = value.order;
    this.getAll();
  }

  onPageChange(page: number): void {
    this.loading = true;
    this.filterParam.pageNumber = page;
    this.getAll();
  }

  onPageSizeChange(value: number): void {
    this.loading = true;
    this.filterParam.pageSize = value;
    this.getAll();
  }

  onClearFilter(): void {
    this.filterParam = {
      vehicleDateRange: null,
      vehicleDateFrom: null,
      vehicleDateTo: null,
      pageNumber: null,
      pageSize: null,
      order: null,
      sort: null,
      id: null,
      vin: null,
      msisdn: null,
    };
    TheadComponent.resetSortIcon();
  }

  onSearch(): void {
    this.processDataTable();
  }

  private processDataTable(): void {
    this.loading = true;
    this.getAll();
  }

  private getAll() {
    const params = this.buildHalParams();
    if (!isNullOrUndefined(params)) {
      this.filter2QueryParam(params);
    }
    this.vehicleService.getAll({params: params}).subscribe(data => {
      this.updateData(data);
    });
  }

  private updateData(data) {
    this.loading = false;
    this.vehicles = data;
    this.pagination.totalElements = this.vehicleService.resourceArray.totalElements;
    this.pagination.pageNumber = this.vehicleService.resourceArray.pageNumber;
    this.pagination.pageSize = this.vehicleService.resourceArray.pageSize;
  }

  private buildHalParams(): HalParam[] {

    if (!isNullOrUndefined(this.filterParam.vehicleDateRange)) {
      this.filterParam.vehicleDateFrom = this.filterParam.vehicleDateRange.start.getTime();
      this.filterParam.vehicleDateTo = this.filterParam.vehicleDateRange.end.getTime();
    }

    const params: HalParam[] = [];
    if (!isNullOrUndefined(this.filterParam)) {
      Object.keys(this.filterParam).forEach(key => {
        const value = this.filterParam[key];
        if (!isNullOrUndefined(value) && value !== [] && !/^\s*$/.test(value) && key !== "vehicleDateRange") {
          params.push({key: key, value: value});
        }
      });
    }

    return params;
  }

  onOpenVehicleDialog(data: any, dialog: TemplateRef<any>): void {
    this.dialogService.open(dialog, {
      closeOnEsc: true,
      hasScroll: true,
      context: JSON.parse(data !== null ? data : '{"content": "no content"}'),
    });
  }

  copy(val: string) {
    const selBox = document.createElement('textarea');
    selBox.style.position = 'fixed';
    selBox.style.left = '0';
    selBox.style.top = '0';
    selBox.style.opacity = '0';
    selBox.value = JSON.stringify(val, null, 2);
    document.body.appendChild(selBox);
    selBox.focus();
    selBox.select();
    document.execCommand('copy');
    document.body.removeChild(selBox);
  }

  refresh() {
    this.processDataTable();
  }

  private queryParam2Filter() {
    this.route.queryParams.subscribe(params => {
      if (!isNullOrUndefined(params)) {
        Object.keys(params).forEach(key => {
          if (this.filterParam.hasOwnProperty(key)) {
            this.filterParam[key] = params[key];
          }
        });
      }
    });
  }

  private filter2QueryParam(params: HalParam[]) {
    const queryParams: Params = [];
    params.forEach(el => queryParams[el.key] = el.value);
    this.router.navigate([], {
      queryParams: queryParams,
    });
  }

}
