import {Injectable, Injector} from '@angular/core';
import {RestService} from "angular4-hal";
import {HttpClient} from "@angular/common/http";
import {VehicleResource} from "./vehicle.resource";

@Injectable()
export class VehicleService extends RestService<VehicleResource> {

  constructor(injector: Injector, private http: HttpClient) {
    super(VehicleResource, 'vehicles', injector);
  }

}
