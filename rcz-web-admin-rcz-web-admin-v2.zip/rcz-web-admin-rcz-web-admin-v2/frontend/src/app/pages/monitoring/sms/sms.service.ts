import {Injectable, Injector} from '@angular/core';
import {RestService} from "angular4-hal";
import {HttpClient} from "@angular/common/http";
import {SmsResource} from "./sms.resource";

@Injectable()
export class SmsService extends RestService<SmsResource> {

  constructor(injector: Injector, private http: HttpClient) {
    super(SmsResource, 'sms', injector);
  }

}
