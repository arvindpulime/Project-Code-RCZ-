import {Component, OnInit, TemplateRef} from '@angular/core';
import {NbCalendarRange, NbDialogService} from "@nebular/theme";
import {Thead} from "../../../@theme/components/table/thead";
import {SmsResource} from "./sms.resource";
import {SmsService} from "./sms.service";
import {ActivatedRoute, Params, Router} from "@angular/router";
import {TheadComponent} from "../../../@theme/components";
import {HalParam} from "angular4-hal";
import {isNullOrUndefined} from "util";

export interface Filter {
  sendingDateRange?: NbCalendarRange<Date>;
  sendingDateFrom?: number;
  sendingDateTo?: number;
  pageNumber?: number;
  pageSize?: number;
  order?: string;
  sort?: string;
  date?: string;
  uin?: string;
  to?: string;
}

@Component({
  selector: 'ngx-sms',
  templateUrl: './sms.component.html',
  styleUrls: ['./sms.component.scss'],
})
export class SmsComponent implements OnInit {

  columns: Array<Thead> = [
    {name: "SENDING DATE", filterName: "SENDING_DATE"},
    {name: "PROVIDER"},
    {name: "UIN"},
    {name: "MSISDN", filterName: "TO"},
    {name: "ANSWER STATUS"},
    {name: "ACK CODE"},
    {name: "DETAIL"},
  ];

  loading: boolean = true;
  sms: SmsResource[] = [];
  filterParam: Filter = {
    sendingDateRange: null,
    sendingDateFrom: null,
    sendingDateTo: null,
    pageNumber: null,
    pageSize: null,
    order: null,
    sort: null,
    date: null,
    uin: null,
    to: null,
  };
  pagination: any = {pageNumber: 10, pageSize: 1, totalElements: 10};

  constructor(
    private smsService: SmsService,
    private route: ActivatedRoute,
    private router: Router,
    private dialogService: NbDialogService,
  ) {

  }

  ngOnInit() {
    this.processDataTable();
    this.queryParam2Filter();
  }

  onSort(value): void {
    this.loading = true;
    this.filterParam.sort = value.sort;
    this.filterParam.order = value.order;
    this.getAll();
  }

  onPageChange(page: number): void {
    this.loading = true;
    this.filterParam.pageNumber = page;
    this.getAll();
  }

  onPageSizeChange(value: number): void {
    this.loading = true;
    this.filterParam.pageSize = value;
    this.getAll();
  }

  onClearFilter(): void {
    this.filterParam = {
      sendingDateRange: null,
      sendingDateFrom: null,
      sendingDateTo: null,
      pageNumber: null,
      pageSize: null,
      order: null,
      sort: null,
      date: null,
      uin: null,
      to: null,
    };
    TheadComponent.resetSortIcon();
  }
  getDateFrom(value: string, from: number): number {
    return new Date(value).getTime() - from;
  }
  getDateTo(value: string, to: number): number {
    return new Date(value).getTime() + to;
  }
  onSearch(): void {
    this.processDataTable();
  }

  private processDataTable(): void {
    this.loading = true;
    this.getAll();
  }

  private getAll() {
    const params = this.buildHalParams();
    if (!isNullOrUndefined(params)) {
      this.filter2QueryParam(params);
    }
    this.smsService.getAll({params: params}).subscribe(data => {
      this.updateData(data);
    });
  }

  private updateData(data) {
    this.loading = false;
    this.sms = data;
    this.pagination.totalElements = this.smsService.resourceArray.totalElements;
    this.pagination.pageNumber = this.smsService.resourceArray.pageNumber;
    this.pagination.pageSize = this.smsService.resourceArray.pageSize;
  }

  private buildHalParams(): HalParam[] {

    if (!isNullOrUndefined(this.filterParam.sendingDateRange)) {
      this.filterParam.sendingDateFrom = this.filterParam.sendingDateRange.start.getTime();
      this.filterParam.sendingDateTo = this.filterParam.sendingDateRange.end.getTime();
    }

    const params: HalParam[] = [];
    if (!isNullOrUndefined(this.filterParam)) {
      Object.keys(this.filterParam).forEach(key => {
        const value = this.filterParam[key];
        if (!isNullOrUndefined(value) && value !== [] && !/^\s*$/.test(value) && key !== "sendingDateRange") {
          params.push({key: key, value: value});
        }
      });
    }

    return params;
  }

  onOpenUserLogDialog(data: any, dialog: TemplateRef<any>): void {
    this.dialogService.open(dialog, {
      closeOnEsc: true,
      hasScroll: true,
      context: data,
    });
  }

  refresh() {
    this.processDataTable();
  }

  private queryParam2Filter() {
    this.route.queryParams.subscribe(params => {
      if (!isNullOrUndefined(params)) {
        Object.keys(params).forEach(key => {
          if (this.filterParam.hasOwnProperty(key)) {
            this.filterParam[key] = params[key];
          }
        });
      }
      this.setDateRange();
    });
  }

  private setDateRange() {
    if (!isNullOrUndefined(this.filterParam.sendingDateFrom) && !isNullOrUndefined(this.filterParam.sendingDateTo)) {
      this.filterParam.sendingDateRange = {
        start: new Date(),
        end: new Date(),
      };
      this.filterParam.sendingDateRange.start.setTime(this.filterParam.sendingDateFrom);
      this.filterParam.sendingDateRange.end.setTime(this.filterParam.sendingDateTo);
    }
  }


  private filter2QueryParam(params: HalParam[]) {
    const queryParams: Params = [];
    params.forEach(el => queryParams[el.key] = el.value);
    this.router.navigate([], {
      queryParams: queryParams,
    });
  }

}
