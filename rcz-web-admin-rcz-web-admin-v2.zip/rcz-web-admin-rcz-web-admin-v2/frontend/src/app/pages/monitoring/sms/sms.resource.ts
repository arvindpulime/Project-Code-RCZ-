import {Resource} from "angular4-hal";
import {Injectable} from "@angular/core";


@Injectable()
export class SmsResource extends Resource {

  id: string;
  uin: string;
  icp: string;
  adm: string;
  version: string;
  idOffer: string;
  sendingDate: Date;
  to: string;
  answerStatus: string;
  ackCode: string;
  ackMessage: string;
  smsData: string;
  provider: string;
  ackDate: Date;

}
