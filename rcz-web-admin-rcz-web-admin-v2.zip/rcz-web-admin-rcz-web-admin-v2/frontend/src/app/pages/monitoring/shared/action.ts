export interface Action {
  actionService: string;
  actionType: string;
}
