export interface Enums {
  actionServices?: string[];
  actionTypes?: string[];
  exchangeStatuses?: string[];
  responseStatuses?: string[];
  processStatuses?: string[];
  callerTypes?: string[];
  requestStatus?: string[];
}
