import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {MonitoringComponent} from './monitoring.component';
import {ApplicationComponent} from './application/application.component';
import {ExchangesComponent} from './exchanges/exchanges.component';
import {RequestComponent} from './request/request.component';
import {SmsComponent} from './sms/sms.component';
import {VehicleComponent} from './vehicle/vehicle.component';
import {LogComponent} from './log/log.component';
import {UserLogComponent} from './user-logs/user-log.component';
import {MqttComponent} from "./mqtt/mqtt.component";
import {MqttResolver} from "./mqtt/mqtt.resolver";

const routes: Routes = [{
  path: '',
  component: MonitoringComponent,
  children: [
    {
      path: 'apps',
      component: ApplicationComponent,
    },
    {
      path: 'exchanges',
      component: ExchangesComponent,
    },
    {
      path: 'logs',
      component: LogComponent,
    },
    {
      path: 'request',
      component: RequestComponent,
    },
    {
      path: 'mqtt',
      component: MqttComponent,
      resolve: {
        instances: MqttResolver,
      },
    },
    {
      path: 'sms',
      component: SmsComponent,
    },
    {
      path: 'user-logs',
      component: UserLogComponent,
    },
    {
      path: 'vehicle',
      component: VehicleComponent,
    },
    {
      path: '', redirectTo: 'exchanges', pathMatch: 'full',
    },
  ],
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MonitoringRoutingModule {
}
