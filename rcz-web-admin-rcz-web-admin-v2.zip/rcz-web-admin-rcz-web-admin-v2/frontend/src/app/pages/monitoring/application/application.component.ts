import {Component, OnInit} from '@angular/core';
import {ApplicationService} from "./application.service";
import {ApplicationResource} from "./application.resource";

@Component({
  selector: 'ngx-application',
  templateUrl: './application.component.html',
  styleUrls: ['./application.component.scss'],
})
export class ApplicationComponent implements OnInit {

  appResources: ApplicationResource[] = [];

  constructor(private appService: ApplicationService) {
  }

  ngOnInit() {
    this.getData();
  }

  refresh() {
    this.getData();
  }

  getData() {
    this.appService.get().subscribe(data => {
      this.appResources = data;
    });
  }

}
