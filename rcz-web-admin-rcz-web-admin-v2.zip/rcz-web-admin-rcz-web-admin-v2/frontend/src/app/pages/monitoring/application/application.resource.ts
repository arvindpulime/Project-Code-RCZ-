import {Resource} from "angular4-hal";
import {Injectable} from "@angular/core";

@Injectable()
export class ApplicationResource extends Resource {
  instance: string;
  baseURL: string;
  buildDate: string;
  description: string;
  name: string;
  status: string;
  version: string;
}
