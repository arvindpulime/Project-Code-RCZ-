import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";
import {environment} from "../../../../environments/environment";
import {ApplicationResource} from "./application.resource";
import {Injectable} from "@angular/core";

@Injectable()
export class ApplicationService {

  constructor(private http: HttpClient) {
  }

  get(): Observable<ApplicationResource[]> {
    return this.http.get<ApplicationResource[]>(environment.ROOT_URI + 'app/info');
  }

}
