import {Component, OnInit} from '@angular/core';
import {Thead} from "../../../@theme/components/table/thead";
import {ExchangesService} from "./exchanges.service";
import {ExchangeResource} from "./exchange.resource";
import {NbCalendarRange} from "@nebular/theme";
import {HalParam} from "angular4-hal";
import {isNullOrUndefined} from "util";
import {Enums} from "../shared/enums";
import {TheadComponent} from "../../../@theme/components";
import {ActivatedRoute, Params, Router} from "@angular/router";
import {HttpParams} from "@angular/common/http";

export interface Alert {
  name?: string;
  status?: string;
  icon?: string;
  nb?: string;
  link?: string;
}

export interface Filter {
  receivedDateRange?: NbCalendarRange<Date>;
  receivedDateFrom?: number;
  receivedDateTo?: number;
  sentDateRange?: NbCalendarRange<Date>;
  sentDateFrom?: number;
  sentDateTo?: number;
  id?: string;
  actionServices?: string[];
  actionTypes?: string[];
  uin?: string;
  callerId?: string;
  callerTypes?: string[];
  vin?: string;
  processStatuses?: string[];
  correlationId?: string;
  responseStatuses?: string[];
  statuses?: string[];
  pageNumber?: number;
  pageSize?: number;
  order?: string;
  sort?: string;
}

@Component({
  selector: 'ngx-exchanges',
  templateUrl: './exchanges.component.html',
  styleUrls: ['./exchanges.component.scss'],
})
export class ExchangesComponent implements OnInit {

  alerts: Alert[] = [];
  columns: Array<Thead> = [
    {name: "LOGS"},
    {name: "SMS"},
    {name: "REQUEST"},
    {name: "SENT DATE", filterName: "SENT_DATE"},
    {name: "RECEIVED DATE", filterName: "RECEIVED_DATE"},
    //{name: "ID"},
    {name: "ACTION SERVICE", filterName: "ACTION_SERVICE"},
    {name: "ACTION TYPE", filterName: "ACTION_TYPE"},
    {name: "STATUS", filterName: "STATUS"},
    {name: "UIN", filterName: "UIN"},
    {name: "CALLER ID", filterName: "CALLER_ID"},
    {name: "CALLER TYPE", filterName: "CALLER_TYPE"},
    //{name: "CORRELATION ID", filterName: "CORRELATION_ID"},
    {name: "VIN", filterName: "VIN"},
    {name: "PROCESS STATUS", filterName: "PROCESS_STATUS"},
    {name: "RESPONSE STATUS", filterName: "RESPONSE_STATUS"},
  ];
  enums: Enums = {
    actionServices: [],
    actionTypes: [],
    exchangeStatuses: [],
    responseStatuses: [],
    processStatuses: [],
    callerTypes: [],
  };
  loading: boolean = true;
  exchanges: ExchangeResource[] = [];
  filterParam: Filter = {
    receivedDateRange: null,
    receivedDateFrom: ExchangesComponent.getOneHourAgo(),
    receivedDateTo: ExchangesComponent.getLastDayOfTheWeek(),
    sentDateRange: null,
    sentDateFrom: null,
    sentDateTo: null,
    id: null,
    actionServices: [],
    actionTypes: [],
    uin: null,
    callerId: null,
    callerTypes: ["CLIENT", "PARTNER"],
    vin: null,
    processStatuses: [],
    correlationId: null,
    responseStatuses: [],
    statuses: [],
    pageNumber: null,
    pageSize: null,
    order: null,
    sort: null,
  };
  pagination: any = {pageNumber: 10, pageSize: 1, totalElements: 10};

  constructor(
    private exchangesService: ExchangesService,
    private route: ActivatedRoute,
    private router: Router,
  ) {

  }


  ngOnInit() {
    this.initFilter();
    this.queryParam2Filter();
    this.processDataTable();
    this.showAlerts();
  }

  onSort(value): void {
    this.loading = true;
    this.filterParam.sort = value.sort;
    this.filterParam.order = value.order;
    this.getAll();
  }

  onPageChange(page: number): void {
    this.loading = true;
    this.filterParam.pageNumber = page;
    this.getAll();
  }

  onPageSizeChange(value: number): void {
    this.loading = true;
    this.filterParam.pageSize = value;
    this.getAll();
  }

  onClearFilter(): void {
    this.filterParam = {
      receivedDateRange: null,
      receivedDateFrom: null,
      receivedDateTo: null,
      sentDateRange: null,
      sentDateFrom: null,
      sentDateTo: null,
      id: null,
      actionServices: [],
      actionTypes: [],
      uin: null,
      callerId: null,
      callerTypes: [],
      vin: null,
      processStatuses: [],
      correlationId: null,
      responseStatuses: [],
      statuses: [],
      pageNumber: null,
      pageSize: null,
      order: null,
      sort: null,
    };
    TheadComponent.resetSortIcon();
  }

  onReset(): void {
    this.filterParam = {
      sentDateRange: null,
      sentDateFrom: null,
      sentDateTo: null,
      id: null,
      actionServices: [],
      actionTypes: [],
      uin: null,
      callerId: null,
      callerTypes: [],
      vin: null,
      processStatuses: [],
      correlationId: null,
      responseStatuses: [],
      statuses: [],
      pageNumber: null,
      pageSize: null,
      order: null,
      sort: null,
    };
    TheadComponent.resetSortIcon();
  }

  onSearch(): void {
    this.processDataTable();
  }

  private processDataTable(): void {
    this.loading = true;
    this.getAll();
  }

  private initFilter(): void {
    this.exchangesService.getExchangeEnums().subscribe(data => {
      this.enums = data;
    });
  }

  private getAll(): void {
    const params = this.buildHalParams();
    if (!isNullOrUndefined(params)) {
      this.filter2QueryParam(params);
    }
    this.exchangesService.getAll({params: params}).subscribe(data => {
      this.updateData(data);
    });
  }

  private updateData(data): void {
    this.loading = false;
    this.exchanges = data;
    this.pagination.totalElements = this.exchangesService.resourceArray.totalElements;
    this.pagination.pageNumber = this.exchangesService.resourceArray.pageNumber;
    this.pagination.pageSize = this.exchangesService.resourceArray.pageSize;
  }

  private buildHalParams(): HalParam[] {
    this.filterParam.receivedDateFrom = null;
    this.filterParam.receivedDateTo = null;
    this.filterParam.sentDateFrom = null;
    this.filterParam.sentDateTo = null;
    if (!isNullOrUndefined(this.filterParam.receivedDateRange)) {
      this.filterParam.receivedDateFrom = this.filterParam.receivedDateRange.start.getTime();
      this.filterParam.receivedDateTo = this.filterParam.receivedDateRange.end.getTime();
    }

    if (!isNullOrUndefined(this.filterParam.sentDateRange)) {
      this.filterParam.sentDateFrom = this.filterParam.sentDateRange.start.getTime();
      this.filterParam.sentDateTo = this.filterParam.sentDateRange.end.getTime();
    }

    const params: HalParam[] = [];
    if (!isNullOrUndefined(this.filterParam)) {
      Object.keys(this.filterParam).forEach(key => {
        const value = this.filterParam[key];
        if (!isNullOrUndefined(value) && value !== [] && !/^\s*$/.test(value) && key !== "receivedDateRange" && key !== "sentDateRange") {
          params.push({key: key, value: value});
        }
      });
    }
    return params;
  }

  private showAlerts(): void {
    this.alerts = [
      {name: "Lights quota exceeded", status: "LIGHTS_QUOTA_EXCEEDED", icon: 'bulb-outline'},
      {name: "Horn quota exceeded", status: "HORN_QUOTA_EXCEEDED", icon: 'volume-up-outline'},
      {name: "Requests quota exceeded", status: "REQUESTS_QUOTA_EXCEEDED", icon: 'wifi-outline'},
    ];
    this.alerts.forEach(alert => {
      const receivedDateFrom = ExchangesComponent.getTimestamp(0);
      const receivedDateTo = ExchangesComponent.getTimestamp(1);
      let params: HttpParams = new HttpParams();
      params = params.append('responseStatus', alert.status);
      params = params.append('receivedDateFrom', `${receivedDateFrom}`);
      params = params.append('receivedDateTo', `${receivedDateTo}`);
      this.exchangesService.getExchangeAlert(params).subscribe(value => {
        alert.nb = value._embedded.alerts.nbAlert;
        alert.link = `#/pages/monitoring/exchanges?responseStatus=${alert.status}&receivedDateFrom=${receivedDateFrom}&receivedDateTo=${receivedDateTo}`;
      });
    });
  }

  private static getTimestamp(day): number {
    const date: Date = new Date();
    date.setDate(date.getDate() + day);
    date.setUTCHours(0, 0, 0, 0);
    return date.getTime();
  }

  private static getFirstDayOfTheWeek(): number {
    var curr = new Date; // get current date
    curr.setHours(1, 0, 0, 0);
    var first = curr.getDate() - curr.getDay() + 1; // First day is the day of the month - the day of the week
    return new Date(curr.setDate(first)).getTime();
  }

  private static getOneHourAgo(): number {
    var curr = new Date(); // get current date
    curr.setHours(curr.getHours() - 1);
    return curr.getTime();
  }

  private static getLastDayOfTheWeek(): number {
    var curr = new Date; // get current date
    curr.setHours(23, 59, 0, 0);
    var first = curr.getDate() - curr.getDay() + 1; // First day is the day of the month - the day of the week
    var last = first + 6; // last day is the first day + 6
    return new Date(curr.setDate(last)).getTime();
  }

  showQuotaExceeded(status: string) {
    this.filterParam.responseStatuses = [status];
    this.filterParam.receivedDateFrom = ExchangesComponent.getTimestamp(0);
    this.filterParam.receivedDateTo = ExchangesComponent.getTimestamp(1);
    this.loading = true;
    this.getAll();
  }

  refresh() {
    this.processDataTable();
  }

  private queryParam2Filter() {
    this.route.queryParams.subscribe(params => {
      if (!isNullOrUndefined(params)) {
        let keys = Object.keys(params);
        if ([] !== keys && keys.length > 0) {
          this.onClearFilter();
          keys.forEach(key => {
            if (this.filterParam.hasOwnProperty(key)) {
              this.filterParam[key] = params[key];
            }
          });
        }
        this.setDateRange();
      }
    });
  }

  private setDateRange() {
    if (!isNullOrUndefined(this.filterParam.receivedDateFrom) && !isNullOrUndefined(this.filterParam.receivedDateTo)) {
      this.filterParam.receivedDateRange = {
        start: new Date(),
        end: new Date(),
      };
      this.filterParam.receivedDateRange.start.setTime(this.filterParam.receivedDateFrom);
      this.filterParam.receivedDateRange.end.setTime(this.filterParam.receivedDateTo);
    }
    if (!isNullOrUndefined(this.filterParam.sentDateFrom) && !isNullOrUndefined(this.filterParam.sentDateTo)) {
      this.filterParam.sentDateRange = {
        start: new Date(),
        end: new Date(),
      };
      this.filterParam.sentDateRange.start.setTime(this.filterParam.sentDateFrom);
      this.filterParam.sentDateRange.end.setTime(this.filterParam.sentDateTo);
    }
  }

  private filter2QueryParam(params: HalParam[]) {
    const queryParams: Params = [];
    if ([] !== params) {
      params.forEach(el => queryParams[el.key] = el.value);
      this.router.navigate([], {
        queryParams: queryParams,
      });
    }
  }
}
