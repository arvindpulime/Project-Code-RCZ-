import {Resource} from "angular4-hal";
import {Injectable} from "@angular/core";
import {Action} from "../shared/action";


@Injectable()
export class ExchangeResource extends Resource {
  action: Action;
  callerId: string;
  callerType: string;
  correlationId: string;
  id: string;
  processStatus: string;
  requestReceivedDate: Date;
  requestSentDate: Date;
  responseStatus: string;
  status: string;
  topic: string;
  uin: string;
  vin: string;
}
