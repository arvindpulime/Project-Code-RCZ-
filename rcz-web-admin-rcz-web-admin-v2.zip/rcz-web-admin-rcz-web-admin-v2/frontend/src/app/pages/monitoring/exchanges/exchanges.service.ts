import {Injectable, Injector} from '@angular/core';
import {RestService} from "angular4-hal";
import {HttpClient, HttpParams} from "@angular/common/http";
import {ExchangeResource} from "./exchange.resource";
import {Enums} from "../shared/enums";
import {Observable} from "rxjs";
import {environment} from "../../../../environments/environment";

@Injectable()
export class ExchangesService extends RestService<ExchangeResource> {

  constructor(injector: Injector, private http: HttpClient) {
    super(ExchangeResource, 'exchanges', injector);
  }

  getExchangeEnums(): Observable<Enums> {
    return this.http.get<Enums>(environment.ROOT_URI + 'exchanges/enums');
  }

  getExchangeAlert(params: HttpParams): Observable<any> {
    return this.http.get<any>(environment.ROOT_URI + 'exchanges/alert', {params: params});
  }

}
