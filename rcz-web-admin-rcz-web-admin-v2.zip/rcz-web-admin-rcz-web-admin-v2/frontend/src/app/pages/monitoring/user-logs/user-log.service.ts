import {Injectable, Injector} from "@angular/core";
import {RestService} from "angular4-hal";
import {UserLogResource} from "./user-log.resource";
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";
import {environment} from "../../../../environments/environment";

@Injectable()
export class UserLogService extends RestService<UserLogResource> {

  constructor(injector: Injector, private http: HttpClient) {
    super(UserLogResource, 'userlogs', injector);
  }

  getUserLogsResourceEnums(): Observable<string[]> {
    return this.http.get<string[]>(environment.ROOT_URI + 'userlogs/resources');
  }

}
