import {Resource} from "angular4-hal";
import {Injectable} from "@angular/core";

@Injectable()
export class UserLogResource extends Resource {

  id: number;
  userId: string;
  email: string;
  entryDate: Date;
  resource: string;
  log: string;

}
