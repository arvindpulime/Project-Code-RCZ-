import {Component, OnInit, TemplateRef} from '@angular/core';
import {NbCalendarRange, NbDialogService} from "@nebular/theme";
import {Thead} from "../../../@theme/components/table/thead";
import {ActivatedRoute, Params, Router} from "@angular/router";
import {TheadComponent} from "../../../@theme/components";
import {HalParam} from "angular4-hal";
import {isNullOrUndefined} from "util";
import {UserLogService} from "./user-log.service";
import {UserLogResource} from "./user-log.resource";

export interface Filter {
  entryDateRange?: NbCalendarRange<Date>;
  entryDateFrom?: number;
  entryDateTo?: number;
  pageNumber?: number;
  pageSize?: number;
  order?: string;
  sort?: string;

  resources?: string[];
  userId?: string;
  email?: string;
  log?: string;
}

@Component({
  selector: 'ngx-user-log',
  templateUrl: './user-log.component.html',
  styleUrls: ['./user-log.component.scss'],
})
export class UserLogComponent implements OnInit {

  columns: Array<Thead> = [
    {name: "DATE", filterName: "ENTRY_DATE"},
    {name: "USER ID", filterName: "USER_ID"},
    {name: "EMAIL", filterName: "EMAIL"},
    {name: "RESOURCE", filterName: "RESOURCE"},
    {name: "LOG"},
  ];

  loading: boolean = true;
  userLogs: UserLogResource[] = [];
  filterParam: Filter = {
    entryDateRange: null,
    entryDateFrom: null,
    entryDateTo: null,
    pageNumber: null,
    pageSize: null,
    order: null,
    sort: null,
    resources: [],
    userId: null,
    email: null,
    log: null,
  };
  pagination: any = {pageNumber: 10, pageSize: 1, totalElements: 10};
  userLogResourceEnums: string[];

  constructor(
    private userLogService: UserLogService,
    private route: ActivatedRoute,
    private router: Router,
    private dialogService: NbDialogService,
  ) {

  }

  ngOnInit() {
    this.initFilter();
    this.queryParam2Filter();
    this.processDataTable();
  }

  onSort(value): void {
    this.loading = true;
    this.filterParam.sort = value.sort;
    this.filterParam.order = value.order;
    this.getAll();
  }

  onPageChange(page: number): void {
    this.loading = true;
    this.filterParam.pageNumber = page;
    this.getAll();
  }

  onPageSizeChange(value: number): void {
    this.loading = true;
    this.filterParam.pageSize = value;
    this.getAll();
  }

  onClearFilter(): void {
    this.filterParam = {
      entryDateRange: null,
      entryDateFrom: null,
      entryDateTo: null,
      pageNumber: null,
      pageSize: null,
      order: null,
      sort: null,
      resources: [],
      userId: null,
      email: null,
      log: null,
    };
    TheadComponent.resetSortIcon();
  }

  onSearch(): void {
    this.processDataTable();
  }

  private processDataTable(): void {
    this.loading = true;
    this.getAll();
  }

  private getAll() {
    const params = this.buildHalParams();
    if (!isNullOrUndefined(params)) {
      this.filter2QueryParam(params);
    }
    this.userLogService.getAll({params: params}).subscribe(data => {
      this.updateData(data);
    });
  }

  private updateData(data) {
    this.loading = false;
    this.userLogs = data;
    this.pagination.totalElements = this.userLogService.resourceArray.totalElements;
    this.pagination.pageNumber = this.userLogService.resourceArray.pageNumber;
    this.pagination.pageSize = this.userLogService.resourceArray.pageSize;
  }


  private initFilter(): void {
    this.userLogService.getUserLogsResourceEnums().subscribe(data => {
      this.userLogResourceEnums = data;
    });
  }

  private buildHalParams(): HalParam[] {

    if (!isNullOrUndefined(this.filterParam.entryDateRange)) {
      this.filterParam.entryDateFrom = this.filterParam.entryDateRange.start.getTime();
      this.filterParam.entryDateTo = this.filterParam.entryDateRange.end.getTime();
    }

    const params: HalParam[] = [];
    if (!isNullOrUndefined(this.filterParam)) {
      Object.keys(this.filterParam).forEach(key => {
        const value = this.filterParam[key];
        if (!isNullOrUndefined(value) && value !== [] && !/^\s*$/.test(value) && key !== "entryDateRange") {
          params.push({key: key, value: value});
        }
      });
    }

    return params;
  }

  onOpenUserLogDialog(data: any, dialog: TemplateRef<any>): void {
    this.dialogService.open(dialog, {
      closeOnEsc: true,
      hasScroll: true,
      context: data,
    });
  }

  refresh() {
    this.processDataTable();
  }

  private queryParam2Filter() {
    this.route.queryParams.subscribe(params => {
      if (!isNullOrUndefined(params)) {
        Object.keys(params).forEach(key => {
          if (this.filterParam.hasOwnProperty(key)) {
            this.filterParam[key] = params[key];
          }
        });
      }
      this.setDateRange();
    });
  }

  private setDateRange() {
    if (!isNullOrUndefined(this.filterParam.entryDateFrom) && !isNullOrUndefined(this.filterParam.entryDateTo)) {
      this.filterParam.entryDateRange = {
        start: new Date(),
        end: new Date(),
      };
      this.filterParam.entryDateRange.start.setTime(this.filterParam.entryDateFrom);
      this.filterParam.entryDateRange.end.setTime(this.filterParam.entryDateTo);
    }
  }

  private filter2QueryParam(params: HalParam[]) {
    const queryParams: Params = [];
    params.forEach(el => queryParams[el.key] = el.value);
    this.router.navigate([], {
      queryParams: queryParams,
    });
  }

}
