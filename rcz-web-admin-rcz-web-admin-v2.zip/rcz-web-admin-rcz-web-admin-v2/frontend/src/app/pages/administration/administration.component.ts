import {Component} from '@angular/core';

@Component({
  selector: 'ngx-administration',
  template: `
    <router-outlet></router-outlet>
  `,
})
export class AdministrationComponent {


}
