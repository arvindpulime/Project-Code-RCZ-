import {Injectable} from "@angular/core";
import {ActionResource} from "./actionResource";
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";
import {environment} from "../../../../environments/environment";

@Injectable()
export class ActionService {

  PATH_GET_ALL_ACTION: string = "actions";

  constructor(private http: HttpClient) {
  }

  getAllAction(): Observable<ActionResource> {
    return this.http.get<ActionResource>(environment.ROOT_URI + this.PATH_GET_ALL_ACTION);
  }
}
