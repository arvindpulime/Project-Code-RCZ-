import {Injectable, Injector} from '@angular/core';
import {RestService} from "angular4-hal";
import {HttpClient} from "@angular/common/http";
import {ServiceFeatureResource} from "./serviceFeature.resource";
import {Observable} from "rxjs";
import {environment} from "../../../../environments/environment";

@Injectable()
export class ServiceFeaturesService extends RestService<ServiceFeatureResource> {

  private SERVICE_FEATURE: string = "servicefeature/";

  constructor(injector: Injector, private http: HttpClient) {
    super(ServiceFeatureResource, 'servicefeatures', injector);
  }

  deleteServiceFeature(code: String): Observable<any> {
    return this.http.delete(environment.ROOT_URI + this.SERVICE_FEATURE + code);
  }

  getServiceFeature(code: string): Observable<ServiceFeatureResource> {
    return this.http.get<ServiceFeatureResource>(environment.ROOT_URI + this.SERVICE_FEATURE + code);
  }

  updateActions(serviceFeatureResource: ServiceFeatureResource): Observable<any> {
    return this.http.put(environment.ROOT_URI + this.SERVICE_FEATURE + serviceFeatureResource.code,
      serviceFeatureResource);
  }
}
