import {Component, OnInit, TemplateRef} from '@angular/core';
import {Thead} from "../../../@theme/components/table/thead";
import {TheadComponent} from "../../../@theme/components";
import {HalParam} from "angular4-hal";
import {isNullOrUndefined} from "util";
import {NbCalendarRange, NbDialogService} from "@nebular/theme";
import {ActionEdit, ServiceFeatureResource} from "./serviceFeature.resource";
import {ServiceFeaturesService} from "./serviceFeatures.service";
import {ActionService} from "./actionService";
import {ActionResource} from "./actionResource";
import {ActivatedRoute, Params, Router} from "@angular/router";

export interface Filter {
  startDateRange?: NbCalendarRange<Date>;
  startDateFrom?: number;
  startDateTo?: number;
  endDateRange?: NbCalendarRange<Date>;
  endDateFrom?: number;
  endDateTo?: number;
  pageNumber?: number;
  pageSize?: number;
  order?: string;
  sort?: string;
  id?: string;
  code?: string;
  shortLabel?: string;
  label?: string;
  suspended?: boolean;
  deleted?: boolean;
}

export interface UserActive {
  date: string;
  pagesVisitCount: number;
  deltaUp: boolean;
  newVisits: number;
}

@Component({
  selector: 'ngx-service-features',
  templateUrl: './service-features.component.html',
  styleUrls: ['./service-features.component.scss'],
})
export class ServiceFeaturesComponent implements OnInit {

  columns: Array<Thead> = [
    {name: "DETAIL"},
    {name: "DELETE"},
    {name: 'label', filterName: 'label'},
    {name: "SHORT LABEL", filterName: "SHORT_LABEL"},
    {name: "CODE", filterName: "CODE"},
    {name: "START DATE", filterName: "START_DATE"},
    {name: "END DATE", filterName: "END_DATE"},
    {name: "SUSPENDED", filterName: "SUSPENDED"},
    {name: "DELETED", filterName: "DELETED"},
  ];
  loading: boolean = true;
  // @ts-ignore
  serviceFeatures: ServiceFeatureResource[] = [];
  selectEle: number = -1;
  edit: ActionEdit = new ActionEdit();
  filterParam: Filter = {
    startDateRange: null,
    startDateFrom: null,
    startDateTo: null,
    endDateRange: null,
    endDateFrom: null,
    endDateTo: null,
    pageNumber: null,
    pageSize: null,
    order: null,
    sort: null,
    id: null,
    code: null,
    shortLabel: null,
    label: null,
    suspended: null,
    deleted: null,
  };
  pagination: any = {pageNumber: 10, pageSize: 1, totalElements: 10};
  searchStolen: string;
  searchRemote: string;

  constructor(
    private serviceFeaturesService: ServiceFeaturesService,
    private dialogService: NbDialogService,
    private actionService: ActionService,
    private route: ActivatedRoute,
    private router: Router,
  ) {
  }


  ngOnInit() {
    this.queryParam2Filter();
    this.processDataTable();
    this.getAllAction();
  }

  onSort(value): void {
    this.loading = true;
    this.filterParam.sort = value.sort;
    this.filterParam.order = value.order;
    this.getAll();
  }

  onPageChange(page: number): void {
    this.loading = true;
    this.filterParam.pageNumber = page;
    this.getAll();
  }

  onPageSizeChange(value: number): void {
    this.loading = true;
    this.filterParam.pageSize = value;
    this.getAll();
  }

  onClearFilter(): void {
    this.filterParam = {
      startDateRange: null,
      startDateFrom: null,
      startDateTo: null,
      endDateRange: null,
      endDateFrom: null,
      endDateTo: null,
      pageNumber: null,
      pageSize: null,
      order: null,
      sort: null,
      id: null,
      code: null,
      shortLabel: null,
      label: null,
      suspended: null,
      deleted: null,
    };
    TheadComponent.resetSortIcon();
  }

  onSearch(): void {
    this.processDataTable();
  }

  private processDataTable(): void {
    this.loading = true;
    this.getAll();
  }

  private getAll() {
    const params = this.buildHalParams();
    if (!isNullOrUndefined(params)) {
      this.filter2QueryParam(params);
    }
    this.serviceFeaturesService.getAll({params: params}).subscribe(data => {
      this.updateData(data);
    });
  }

  private updateData(data) {
    this.loading = false;
    this.serviceFeatures = data;
    this.pagination.totalElements = this.serviceFeaturesService.resourceArray.totalElements;
    this.pagination.pageNumber = this.serviceFeaturesService.resourceArray.pageNumber;
    this.pagination.pageSize = this.serviceFeaturesService.resourceArray.pageSize;
  }

  private buildHalParams(): HalParam[] {

    if (!isNullOrUndefined(this.filterParam.startDateRange)) {
      this.filterParam.startDateFrom = this.filterParam.startDateRange.start.getTime();
      this.filterParam.startDateTo = this.filterParam.startDateRange.end.getTime();
    }
    if (!isNullOrUndefined(this.filterParam.endDateRange)) {
      this.filterParam.endDateFrom = this.filterParam.endDateRange.start.getTime();
      this.filterParam.endDateTo = this.filterParam.endDateRange.end.getTime();
    }

    const params: HalParam[] = [];
    if (!isNullOrUndefined(this.filterParam)) {
      Object.keys(this.filterParam).forEach(key => {
        const value = this.filterParam[key];
        if (!isNullOrUndefined(value) && value !== [] && !/^\s*$/.test(value) &&
          key !== "startDateRange" && key !== "endDateRange") {
          params.push({key: key, value: value});
        }
      });
    }

    return params;
  }

  refresh() {
    this.processDataTable();
  }

  onOpenUserLogDialog(data: any, dialog: TemplateRef<any>, index): void {
    this.selectEle = index;
    this.uploadAction(this.serviceFeatures[this.selectEle].actions.stolen, this.edit.stolen);
    this.uploadAction(this.serviceFeatures[this.selectEle].actions.remote, this.edit.remote);
    this.dialogService.open(dialog, {
      closeOnEsc: true,
      hasScroll: true,
      context: data,
    });
  }

  selectList(list: any, value: boolean): void {
    list.forEach(act => {
      if (act.show === true) {
        act.value = value;
      }
    });
  }

  uploadAction(eleService, listEdit): void {
    listEdit.forEach(editAct => {
      editAct.show = true;
      if (eleService !== null && eleService.includes(editAct.text)) {
        editAct.value = true;
      } else {
        editAct.value = false;
      }
    });
  }

  saveServiceFeatures(ref) {
    this.serviceFeatures[this.selectEle].actions = new ActionResource();
    this.edit.remote.forEach(data => {
      if (data.value === true) {
        this.serviceFeatures[this.selectEle].actions.remote.push(data.text);
      }
    });
    this.edit.stolen.forEach(data => {
      if (data.value === true) {
        this.serviceFeatures[this.selectEle].actions.stolen.push(data.text);
      }
    });

    this.serviceFeaturesService.updateActions(this.serviceFeatures[this.selectEle])
      .subscribe(data => {
          ref.close();
        },
        err => console.error(err));
  }

  search(event: string, list: any) {
    if (event === null || event === "") {
      list.forEach(act => {
        act.show = true;
      });
      return;
    }

    list.forEach(act => {
      if (act.text.toLocaleLowerCase().indexOf(event.toLocaleLowerCase()) !== 0) {
        act.show = false;
      } else {
        act.show = true;
      }
    });
  }

  private getAllAction(): void {
    this.actionService.getAllAction().subscribe(data => {
      if (data !== null) {
        if (data.stolen !== null) {
          data.stolen.forEach(act => {
            this.edit.stolen.push({text: act, value: false, show: true});
          });
        }
        if (data.remote !== null) {
          data.remote.forEach(act => {
            this.edit.remote.push({text: act, value: false, show: true});
          });
        }
      }
    });
  }

  onOpenSupFeaturesDialog(data: any, dialog: TemplateRef<any>, index): void {
    this.selectEle = index;
    this.dialogService
      .open(dialog, {
        closeOnEsc: true,
        hasScroll: true,
        context: data,
      });
  }

  supFreatures(ref): void {
    this.serviceFeaturesService.deleteServiceFeature(this.serviceFeatures[this.selectEle].code)
      .subscribe(date => {
          this.serviceFeatures.splice(this.selectEle, 1);
          ref.close();
        },
        err => {
        });
  }

  private queryParam2Filter() {
    this.route.queryParams.subscribe(params => {
      if (!isNullOrUndefined(params)) {
        Object.keys(params).forEach(key => {
          if (this.filterParam.hasOwnProperty(key)) {
            this.filterParam[key] = params[key];
          }
        });
      }
      this.setDateRange();
    });
  }

  private setDateRange() {
    if (!isNullOrUndefined(this.filterParam.startDateFrom) && !isNullOrUndefined(this.filterParam.startDateTo)) {
      this.filterParam.startDateRange = {
        start: new Date(),
        end: new Date(),
      };
      this.filterParam.startDateRange.start.setTime(this.filterParam.startDateFrom);
      this.filterParam.startDateRange.end.setTime(this.filterParam.startDateTo);
    }
    if (!isNullOrUndefined(this.filterParam.endDateFrom) && !isNullOrUndefined(this.filterParam.endDateTo)) {
      this.filterParam.endDateRange = {
        start: new Date(),
        end: new Date(),
      };
      this.filterParam.endDateRange.start.setTime(this.filterParam.endDateFrom);
      this.filterParam.endDateRange.end.setTime(this.filterParam.endDateTo);
    }
  }

  private filter2QueryParam(params: HalParam[]) {
    const queryParams: Params = [];
    if ([] !== params) {
      params.forEach(el => queryParams[el.key] = el.value);
      this.router.navigate([], {
        queryParams: queryParams,
      });
    }
  }
}

