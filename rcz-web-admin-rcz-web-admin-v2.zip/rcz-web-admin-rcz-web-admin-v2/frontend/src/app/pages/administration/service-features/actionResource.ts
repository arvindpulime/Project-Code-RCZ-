import {Resource} from "angular4-hal";
import {Injectable} from "@angular/core";

@Injectable()
export class ActionResource extends Resource {
  remote: string[] = [];
  stolen: string[] = [];
}
