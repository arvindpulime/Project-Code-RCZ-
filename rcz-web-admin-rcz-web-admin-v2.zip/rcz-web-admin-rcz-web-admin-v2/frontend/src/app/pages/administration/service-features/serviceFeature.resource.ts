import {Resource} from "angular4-hal";
import {Injectable} from "@angular/core";
import {ActionResource} from "./actionResource";


@Injectable()
export class ServiceFeatureResource extends Resource {
  code: string;
  shortLabel: string;
  label: string;
  startDate: Date;
  endDate: Date;
  suspended: boolean;
  deleted: boolean;
  actions: ActionResource;
}

export class ActionEdit {
  remote: TextValue[] = [];
  stolen: TextValue[] = [];
}

export interface TextValue {
  text: string;
  value: boolean;
  show: boolean;
}

