import {Injectable} from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";
import {environment} from "../../../../environments/environment";
import {HelpResource} from "./help.resource";

@Injectable()
export class HelpService {

  constructor(private http: HttpClient) {
  }

  get(): Observable<HelpResource> {
    return this.http.get<HelpResource>(environment.ROOT_URI + 'helper');
  }

  put(help: HelpResource): Observable<any> {
    return this.http.put<any>(environment.ROOT_URI + 'helper', help);
  }

}
