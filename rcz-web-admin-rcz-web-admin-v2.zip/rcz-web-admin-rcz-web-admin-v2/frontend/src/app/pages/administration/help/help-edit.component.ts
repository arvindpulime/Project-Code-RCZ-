import {Component, OnInit} from '@angular/core';
import {HelpService} from "./help.service";
import {HelpResource} from "./help.resource";
import {Router} from "@angular/router";

@Component({
  selector: 'ngx-help-edit',
  templateUrl: './help-edit.component.html',
  styleUrls: ['./help-edit.component.scss'],
})
export class HelpEditComponent implements OnInit {

  public loading = false;
  public help: HelpResource = {content: ''};
  public options = {
    toolbarTips: false,
    status: false,
    renderingConfig: {
      codeSyntaxHighlighting: true,
    },
  };

  constructor(private helpService: HelpService, private router: Router) {
  }

  ngOnInit() {
    this.helpService.get().subscribe(help => {
      this.help = help;
    });
  }

  public onSave() {
    this.loading = true;
    this.helpService.put(this.help).subscribe(value => {
      this.loading = false;
      this.onCancel();
    });
  }

  public onCancel() {
    this.router.navigate([`/pages/admin/help`]).then();
  }
}
