import {Component, OnInit} from '@angular/core';
import {HelpService} from "./help.service";
import {HelpResource} from "./help.resource";
import {Router} from "@angular/router";

@Component({
  selector: 'ngx-help',
  templateUrl: './help.component.html',
  styleUrls: ['./help.component.scss'],
})
export class HelpComponent implements OnInit {

  public help: HelpResource = {content: ''};

  constructor(private helpService: HelpService, private router: Router) {
  }

  ngOnInit() {
    this.helpService.get().subscribe(help => {
      this.help = help;
    });
  }

  onEdit() {
    this.router.navigate([`/pages/admin/help-edit`]).then();
  }
}
