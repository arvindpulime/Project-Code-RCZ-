import {Injectable} from "@angular/core";


@Injectable()
export class HelpResource {
  public id?: number;
  public createDate?: Date;
  public title?: string;
  public content: string;
}
