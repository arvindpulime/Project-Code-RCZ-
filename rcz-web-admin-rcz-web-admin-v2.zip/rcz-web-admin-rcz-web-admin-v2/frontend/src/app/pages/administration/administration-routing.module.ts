import {NgModule} from '@angular/core';
import {RouterModule, Routes} from "@angular/router";
import {AdministrationComponent} from './administration.component';
import {I18nComponent} from './i18n/i18n.component';
import {SettingsComponent} from './settings/settings.component';
import {ServiceFeaturesComponent} from './service-features/service-features.component';
import {HelpComponent} from './help/help.component';
import {HelpEditComponent} from "./help/help-edit.component";

const routes: Routes = [{
  path: '',
  component: AdministrationComponent,
  children: [{
    path: 'i18n',
    component: I18nComponent,
  }, {
    path: 'settings',
    component: SettingsComponent,
  }, {
    path: 'service-features',
    component: ServiceFeaturesComponent,
  }, {
    path: 'help',
    component: HelpComponent,
  }, {
    path: 'help-edit',
    component: HelpEditComponent,
  },
  ],
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdministrationRoutingModule {
}
