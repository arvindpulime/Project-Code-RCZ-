import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {I18nComponent} from './i18n/i18n.component';
import {SettingsComponent} from './settings/settings.component';
import {ServiceFeaturesComponent} from './service-features/service-features.component';
import {HelpComponent} from './help/help.component';
import {AdministrationRoutingModule} from "./administration-routing.module";
import {AdministrationComponent} from "./administration.component";
import {ThemeModule} from "../../@theme/theme.module";
import {
  NbAccordionModule,
  NbActionsModule,
  NbButtonModule,
  NbCardModule,
  NbCheckboxModule,
  NbDatepickerModule,
  NbIconModule,
  NbInputModule,
  NbLayoutModule,
  NbListModule,
  NbMenuModule,
  NbSelectModule,
  NbSpinnerModule,
  NbStepperModule,
  NbTabsetModule,
  NbTooltipModule,
  NbUserModule,
} from "@nebular/theme";
import {NgbPaginationModule} from "@ng-bootstrap/ng-bootstrap";
import {NbDateFnsDateModule} from "@nebular/date-fns";
import {FormsModule as ngFormsModule, ReactiveFormsModule} from "@angular/forms";
import {NgxJsonViewerModule} from "ngx-json-viewer";
import {ServiceFeaturesService} from "./service-features/serviceFeatures.service";
import {SimplemdeModule} from "ngx-simplemde";
import {MarkdownModule} from "ngx-markdown";
import {HelpService} from "./help/help.service";
import {HelpEditComponent} from "./help/help-edit.component";
import {ActionService} from "./service-features/actionService";
import {ParameterService} from "./settings/ParameterService";
import {I18nLocalesComponent} from './i18n/i18n-locales/i18n-locales.component';
import {I18nKeysComponent} from './i18n/i18n-keys/i18n-keys.component';
import {I18nTranslationsComponent} from './i18n/i18n-translations/i18n-translations.component';
import {ServiceLocalesi18nService} from "./i18n/i18n-locales/service-localesi18n.service";
import {KeyService} from "./i18n/i18n-keys/Key.service";
import {TranslationService} from "./i18n/i18n-translations/translation.service";

const declarations = [
  AdministrationComponent,
  HelpComponent,
  HelpEditComponent,
  I18nComponent,
  ServiceFeaturesComponent,
  SettingsComponent,
];

const imports = [
  CommonModule,
  AdministrationRoutingModule,
  ThemeModule,
  NbCardModule,
  NbIconModule,
  NbActionsModule,
  NgbPaginationModule,
  NbSpinnerModule,
  NbTooltipModule,
  NbSelectModule,
  NbCheckboxModule,
  NbAccordionModule,
  NbDatepickerModule,
  NbDateFnsDateModule,
  NbInputModule,
  ngFormsModule,
  NbButtonModule,
  NgxJsonViewerModule,
  NbLayoutModule,
  NbSpinnerModule,
  SimplemdeModule.forRoot({style: "antd"}),
  MarkdownModule.forRoot(),
];
const providers = [
  ServiceFeaturesService,
  ActionService,
  ParameterService,
  HelpService,
  ServiceLocalesi18nService,
  KeyService,
  TranslationService,
];

@NgModule({
  declarations: [...declarations, I18nLocalesComponent, I18nKeysComponent, I18nTranslationsComponent],
  imports: [...imports, NbListModule, NbTabsetModule, NbStepperModule, ReactiveFormsModule, NbMenuModule, NbUserModule],
  providers: providers,
})
export class AdministrationModule {
}
