import {Injectable} from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {from, Observable} from "rxjs";
import {LocaleDisplayResource} from "./localeDisplay.resource";
import {environment} from "../../../../../environments/environment";
import {LocaleResource} from "./locale.resource";
import {map, toArray} from "rxjs/operators";

@Injectable()
export class ServiceLocalesi18nService {

  private PATH_AVAILABLE_LOCALE: string = "seed-i18n/available-locales";
  private PATH_DEFAULT_LOCALE: string = "seed-i18n/default-locale";
  private PATH_LOCALE: string = "seed-i18n/locales";

  constructor(private http: HttpClient) {
  }

  getAvialibleLocales(): Observable<LocaleDisplayResource[]> {
    return this.http.get<LocaleDisplayResource[]>(environment.ROOT_URI + this.PATH_AVAILABLE_LOCALE);
  }

  getlocales(): Observable<LocaleDisplayResource[]> {
    return this.http.get<LocaleDisplayResource[]>(environment.ROOT_URI + this.PATH_LOCALE);
  }

  getDefaultLocale(): Observable<LocaleDisplayResource> {
    return this.http.get<LocaleDisplayResource>(environment.ROOT_URI + this.PATH_DEFAULT_LOCALE);
  }

  putDefaultLocale(localeResource: LocaleDisplayResource): Observable<LocaleDisplayResource> {
    return this.http.put<LocaleDisplayResource>(environment.ROOT_URI + this.PATH_DEFAULT_LOCALE,
      new LocaleResource(localeResource));
  }

  putAvialibleLocales(listAvialible: LocaleDisplayResource[]): Observable<LocaleResource[]> {
    let locales = null;
    from(listAvialible).pipe(map((locDisp) => new LocaleResource(locDisp)), toArray(),
    ).subscribe(data => locales = data);
    return this.http.put<LocaleResource[]>(environment.ROOT_URI + this.PATH_AVAILABLE_LOCALE, locales);
  }

  deleteAvialibleLocales(codeLeng: string): Observable<any> {
    return this.http.delete(environment.ROOT_URI + this.PATH_AVAILABLE_LOCALE + "/" + codeLeng);
  }
}
