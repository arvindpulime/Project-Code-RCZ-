import {Injectable} from "@angular/core";
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";
import {environment} from "../../../../../environments/environment";
import {TranslationRepresentation} from "./translation.representation";


@Injectable()
export class TranslationService {

  private PATH_TRANSLATIONS: string = "seed-i18n/translations/";

  constructor(private http: HttpClient) {
  }

  getAll(filtre: string, codeLang: string): Observable<TranslationRepresentation[]> {
    codeLang = (codeLang == null) ? ("en") : (codeLang);
    return this.http.get<TranslationRepresentation[]>(environment.ROOT_URI + this.PATH_TRANSLATIONS
      + codeLang + "/" + filtre);
  }

  putTranslation(translation: TranslationRepresentation, codeLang: string): Observable<any> {
    return this.http.put<any>(environment.ROOT_URI + this.PATH_TRANSLATIONS
      + codeLang + "/" + translation.name, translation);
  }
}





