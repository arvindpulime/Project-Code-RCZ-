import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { I18nKeysComponent } from './i18n-keys.component';

describe('I18nKeysComponent', () => {
  let component: I18nKeysComponent;
  let fixture: ComponentFixture<I18nKeysComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ I18nKeysComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(I18nKeysComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
