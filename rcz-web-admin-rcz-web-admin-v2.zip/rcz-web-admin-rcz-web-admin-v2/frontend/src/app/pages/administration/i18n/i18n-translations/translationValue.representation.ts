import {Injectable} from "@angular/core";


@Injectable()
export class TranslationValueRepresentation {

  locale: string;
  translation: string;
  outdated: boolean;
  approx: boolean;

  constructor() {
    this.locale = "";
    this.translation = "";
    this.outdated = null;
    this.approx = null;
  }
}
