import {Injectable} from "@angular/core";
import {HttpClient} from "@angular/common/http";
import {KeyResource} from "./Key.resource";
import {Observable} from "rxjs";
import {environment} from "../../../../../environments/environment";


@Injectable()
export class KeyService {

  private PATH_KEY: string = "seed-i18n/keys";
  private PATH_KEY_FILE: string = "seed-i18n/keys/file";

  constructor(private http: HttpClient) {
  }

  getAll(filtre: string): Observable<any> {
    return this.http.get<any>(environment.ROOT_URI + this.PATH_KEY + filtre);
  }

  putKey(key: KeyResource): Observable<any> {
    return this.http.put<any>(environment.ROOT_URI + this.PATH_KEY + '/' + key.name, key);
  }

  deleteKey(nameKey: string): Observable<any> {
    return this.http.delete<any>(environment.ROOT_URI + this.PATH_KEY + '/' + nameKey);
  }

  addNewKey(key: KeyResource): Observable<any> {
    key.translation = key.defaultLocale;
    return this.http.post<any>(environment.ROOT_URI + this.PATH_KEY, key);
  }

  downloadFile() {
    return this.http.get<any>(environment.ROOT_URI + this.PATH_KEY_FILE);

  }
}
