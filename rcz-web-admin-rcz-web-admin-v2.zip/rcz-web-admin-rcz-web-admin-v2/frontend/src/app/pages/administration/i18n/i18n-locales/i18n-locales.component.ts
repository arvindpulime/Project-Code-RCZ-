import {Component, OnInit} from '@angular/core';
import {LocaleDisplayResource} from "./localeDisplay.resource";
import {ServiceLocalesi18nService} from "./service-localesi18n.service";

@Component({
  selector: 'ngx-i18n-locales',
  templateUrl: './i18n-locales.component.html',
  styleUrls: ['./i18n-locales.component.scss'],
})
export class I18nLocalesComponent implements OnInit {

  availableLocales: LocaleDisplayResource[] = [];
  locales: LocaleDisplayResource[] = [];
  defaultLocale: LocaleDisplayResource = new LocaleDisplayResource();

  searchlocale: string = null;
  searchAvailableLocale?: string = null;

  constructor(private serviceLocalesi18nService: ServiceLocalesi18nService) {
  }

  ngOnInit() {
    this.serviceLocalesi18nService.getAvialibleLocales().subscribe(
      data => {
        this.availableLocales = data;
      },
      error => console.error(error),
      () => {
        this.serviceLocalesi18nService.getDefaultLocale().subscribe(
          def => {
            this.availableLocales.forEach((elem) => {
              if (elem.code === def.code) {
                this.defaultLocale = elem;
              }
              elem.display = true;
            });
          });
      });

    this.serviceLocalesi18nService.getlocales().subscribe(
      data => {
        this.locales = data;
        this.locales.forEach(elem => {
          elem.display = true;
        });
      });
  }

  addToList(listIn: LocaleDisplayResource[], listTo: LocaleDisplayResource[], type: String): void {
    const listDelete: LocaleDisplayResource[] = [];
    for (let i = listIn.length - 1; i >= 0; i--) {
      if (listIn[i].selected) {
        listIn[i].selected = false;
        listTo.push(listIn[i]);
        listDelete.push(listIn[i]);
        listIn.splice(i, 1);
      }
    }
    listTo.sort((a, b) => {
      return (a.englishLanguage > b.englishLanguage) ? 1 : ((b.englishLanguage > a.englishLanguage) ? -1 : 0);
    });

    if (type === "addToAvailableLocale") {
      this.serviceLocalesi18nService.putAvialibleLocales(listTo).subscribe(data => {
      });
    } else if (type === "addToLocales") {
      listDelete.forEach(elemt => {
        this.serviceLocalesi18nService.deleteAvialibleLocales(elemt.code).subscribe(data => {
        });
      });
    }
  }

  searchLocale(event: string, list: LocaleDisplayResource[]) {
    if (event === null || event === "") {
      list.forEach(elem => {
        elem.display = true;
      });
      return;
    }
    list.forEach((elem, index) => {
      if (elem.englishLanguage.toLocaleLowerCase().indexOf(event.toLocaleLowerCase()) !== 0) {
        elem.display = false;
      } else {
        elem.display = true;
      }
    });
  }

  toggle(checked: boolean, list, index) {
    list[index].selected = checked;
  }

  onUpDefauLocal(event: LocaleDisplayResource) {
    this.serviceLocalesi18nService.putDefaultLocale(event).subscribe(data => {
    });
  }
}
