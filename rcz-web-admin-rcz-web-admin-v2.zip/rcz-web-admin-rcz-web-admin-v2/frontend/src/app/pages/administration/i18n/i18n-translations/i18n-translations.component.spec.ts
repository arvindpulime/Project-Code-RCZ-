import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { I18nTranslationsComponent } from './i18n-translations.component';

describe('I18nTranslationsComponent', () => {
  let component: I18nTranslationsComponent;
  let fixture: ComponentFixture<I18nTranslationsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ I18nTranslationsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(I18nTranslationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
