import {inject, Injectable} from "@angular/core";
import {TranslationValueRepresentation} from "./translationValue.representation";


@Injectable()
export class TranslationRepresentation {

  name: string;
  comment: string;
  source: TranslationValueRepresentation;
  target: TranslationValueRepresentation;
  missing: boolean;

  constructor() {
    this.name = "";
    this.comment = "";
    this.source = new TranslationValueRepresentation();
    this.target = new TranslationValueRepresentation();
  }
}

