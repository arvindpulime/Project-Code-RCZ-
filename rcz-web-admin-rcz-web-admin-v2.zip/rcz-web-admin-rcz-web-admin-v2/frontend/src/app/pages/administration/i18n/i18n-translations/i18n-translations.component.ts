import {Component, OnInit} from '@angular/core';
import {TranslationRepresentation} from "./translation.representation";
import {isNullOrUndefined} from "util";
import {TranslationService} from "./translation.service";
import {TranslationValueRepresentation} from "./translationValue.representation";
import {ServiceLocalesi18nService} from "../i18n-locales/service-localesi18n.service";
import {LocaleResource} from "../i18n-locales/locale.resource";

@Component({
  selector: 'ngx-i18n-translations',
  templateUrl: './i18n-translations.component.html',
  styleUrls: ['./i18n-translations.component.scss'],
})
export class I18nTranslationsComponent implements OnInit {
  translations: TranslationRepresentation[] = [];
  translationSelectedIndex: number = -1;
  translationSelected: TranslationRepresentation = new TranslationRepresentation();
  pagination: any = {pageIndex: 0, pageSize: 5, resultSize: 10, pagesCount: 0};
  disabledNext: boolean = true;
  disabledPrevious: boolean = true;
  filterParam = {
    isApprox: null,
    isMissing: null,
    isOutdated: null,
    pageIndex: 0,
    pageSize: 5,
    searchName: null,
  };
  availableLocales: LocaleResource[] = [];
  defaultLocale: LocaleResource;


  constructor(private translationService: TranslationService,
              private serviceLocalesi18nService: ServiceLocalesi18nService) {
  }

  ngOnInit() {
    this.serviceLocalesi18nService.getAvialibleLocales().subscribe(
      data => {
        this.availableLocales = data;
      },
      error => console.error(error),
      () => {
        this.serviceLocalesi18nService.getDefaultLocale().subscribe(
          def => {
            this.availableLocales.forEach((varl) => {
              if (varl.code === def.code) {
                this.defaultLocale = varl;
              }
            });
            this.getAll();
          });
      });
  }

  private getAll() {
    const params = this.buildHalParams();
    this.translationService.getAll(params, this.defaultLocale.code).subscribe(
      data => {
        this.updateData(data);
      });
  }

  search(): void {
    this.getAll();
  }

  selcteTranslation(index: number) {
    this.translationSelected = this.translations[index];
    this.translationSelectedIndex = index;
  }

  private updateData(data) {
    this.translations = data.view;
    this.pagination.resultSize = data.resultSize;
    this.pagination.pageIndex = data.pageIndex + 1;
    this.pagination.pageSize = data.pageSize;
    this.pagination.pagesCount = data.pagesCount;
    if (this.translations.length > 0) {
      this.translationSelectedIndex = 0;
      this.translations.forEach((trans) => {
        if (trans.comment === undefined || trans.comment === null) {
          trans.comment = "";
        }
        if (trans.target === undefined || trans.target === null) {
          trans.target = new TranslationValueRepresentation();
        }
        if (trans.source === undefined || trans.source === null) {
          trans.source = new TranslationValueRepresentation();
        }
      });
      this.translationSelected = this.translations[0];
    }
    this.updateDisabledFunc();
  }

  updateDisabledFunc() {
    if (this.translationSelectedIndex > 0 || this.pagination.pageIndex > 1) {
      this.disabledPrevious = false;
    } else {
      this.disabledPrevious = true;
    }
    if (this.translationSelectedIndex < this.translations.length - 1 ||
      this.pagination.pageIndex < this.pagination.pagesCount) {
      this.disabledNext = false;
    } else {
      this.disabledNext = true;
    }
  }

  private buildHalParams(): string {
    let params: string = "?";
    if (!isNullOrUndefined(this.filterParam)) {
      Object.keys(this.filterParam).forEach(key => {
        const value = this.filterParam[key];
        if (!isNullOrUndefined(value) && value !== [] && !/^\s*$/.test(value)) {
          params += key + "=" + value + "&";
        }
      });
    }
    params = params.substring(0, params.length - 1);
    return params;
  }

  previousTranslation() {
    if (this.translationSelectedIndex > 0) {
      this.translationSelectedIndex--;
      this.selcteTranslation(this.translationSelectedIndex);
    } else if (this.pagination.pageIndex > 1) {
      this.onPageChange(this.pagination.pageIndex - 1);
    }
    this.updateDisabledFunc();
  }

  nextKey() {
    if (this.translationSelectedIndex < this.translations.length - 1) {
      this.translationSelectedIndex++;
      this.selcteTranslation(this.translationSelectedIndex);
    } else if (this.pagination.pageIndex < this.pagination.pagesCount) {
      this.onPageChange(this.pagination.pageIndex + 1);
    }
    this.updateDisabledFunc();
  }

  onPageChange(page: number): void {
    if (page !== this.filterParam.pageIndex + 1) {
      this.filterParam.pageIndex = page - 1;
      this.getAll();
    }
  }

  clearTranslation() {
    this.translationSelected = new TranslationRepresentation();
  }


  SaveTranslation() {
    this.translationService.putTranslation(this.translationSelected, this.defaultLocale.code).subscribe((data) => {
    });
  }

  onUpDefauLocal(event: LocaleResource[] | LocaleResource) {
    this.getAll();
  }
}
