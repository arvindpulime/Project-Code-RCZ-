import {Component, OnInit, TemplateRef} from '@angular/core';
import {KeyService} from "./Key.service";
import {isNullOrUndefined} from "util";
import {KeyResource} from "./Key.resource";
import {NbDialogService} from "@nebular/theme";

@Component({
  selector: 'ngx-i18n-keys',
  templateUrl: './i18n-keys.component.html',
  styleUrls: ['./i18n-keys.component.scss'],
})
export class I18nKeysComponent implements OnInit {

  keys: KeyResource[] = [];
  keySelectedIndex: number = -1;
  keySelected: KeyResource = new KeyResource();
  pagination: any = {pageIndex: 0, pageSize: 5, resultSize: 10, pagesCount: 0};
  disabledNext: boolean = true;
  disabledPrevious: boolean = true;
  filterParam = {
    isMissing: null,
    isOutdated: null,
    pageIndex: 0,
    pageSize: 5,
    searchName: null,
  };
  addKey: KeyResource = new KeyResource();

  constructor(private keyService: KeyService, private dialogService: NbDialogService) {
  }

  ngOnInit() {
    this.getAll();
  }

  private getAll() {
    const params = this.buildHalParams();
    this.keyService.getAll(params).subscribe(
      data => {
        this.updateData(data);
      });
  }

  private updateData(data) {
    this.keys = data.view;
    this.pagination.resultSize = data.resultSize;
    this.pagination.pageIndex = data.pageIndex + 1;
    this.pagination.pageSize = data.pageSize;
    this.pagination.pagesCount = data.pagesCount;
    if (this.keys.length > 0) {
      this.keySelectedIndex = 0;
      this.keySelected = this.keys[0];
    }
    this.updateDisabledFunc();
  }

  private buildHalParams(): string {
    let params: string = "?";
    if (!isNullOrUndefined(this.filterParam)) {
      Object.keys(this.filterParam).forEach(key => {
        const value = this.filterParam[key];
        if (!isNullOrUndefined(value) && value !== [] && !/^\s*$/.test(value)) {
          params += key + "=" + value + "&";
        }
      });
    }
    params = params.substring(0, params.length - 1);
    return params;
  }

  onPageChange(page: number): void {
    if (page !== this.filterParam.pageIndex + 1) {
      this.filterParam.pageIndex = page - 1;
      this.getAll();
    }
  }

  search(): void {
    this.getAll();
  }

  selcteKey(index: number) {
    this.keySelected = this.keys[index];
    this.keySelectedIndex = index;
  }

  deleteKey() {
    this.keyService.deleteKey(this.keys[this.keySelectedIndex].name).subscribe(() => this.getAll());
  }

  nextKey() {
    if (this.keySelectedIndex < this.keys.length - 1) {
      this.keySelectedIndex++;
      this.selcteKey(this.keySelectedIndex);
    } else if (this.pagination.pageIndex < this.pagination.pagesCount) {
      this.onPageChange(this.pagination.pageIndex + 1);
    }
    this.updateDisabledFunc();
  }

  previousKey() {
    if (this.keySelectedIndex > 0) {
      this.keySelectedIndex--;
      this.selcteKey(this.keySelectedIndex);
    } else if (this.pagination.pageIndex > 1) {
      this.onPageChange(this.pagination.pageIndex - 1);
    }
    this.updateDisabledFunc();
  }

  SaveKey() {
    this.keyService.putKey(this.keySelected).subscribe(data => {
    });
  }

  clearKey() {
    this.keySelected = new KeyResource();
  }

  downloadFile() {
    this.keyService.downloadFile().subscribe(data => {
    });
  }

  updateDisabledFunc() {
    if (this.keySelectedIndex > 0 || this.pagination.pageIndex > 1) {
      this.disabledPrevious = false;
    } else {
      this.disabledPrevious = true;
    }
    if (this.keySelectedIndex < this.keys.length - 1 || this.pagination.pageIndex < this.pagination.pagesCount) {
      this.disabledNext = false;
    } else {
      this.disabledNext = true;
    }
  }

  onOpenSupFeaturesDialog(index: number, dialog: TemplateRef<any>): void {
    this.selcteKey(index);
    this.dialogService
      .open(dialog, {
        closeOnEsc: true,
        hasScroll: true,
      });
  }

  onOpenAddKeyDialog(dialog: TemplateRef<any>) {
    this.dialogService
      .open(dialog, {
        closeOnEsc: true,
        hasScroll: true,
      });
  }

  clearAddKey() {
    this.addKey = new KeyResource();
  }

  saveAddKey() {
    this.keyService.addNewKey(this.addKey).subscribe(data => {
    });
  }

  saveAndNewKey() {
    this.saveAddKey();
    this.clearAddKey();
  }
}
