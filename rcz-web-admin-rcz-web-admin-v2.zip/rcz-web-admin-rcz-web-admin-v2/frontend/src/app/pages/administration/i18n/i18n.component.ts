import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";


@Component({
  selector: 'ngx-i18n',
  templateUrl: './i18n.component.html',
  styleUrls: ['./i18n.component.scss'],
})
export class I18nComponent implements OnInit {
  firstForm: FormGroup;
  secondForm: FormGroup;
  thirdForm: FormGroup;

  disabledIconConfig: any = { icon: 'settings-2-outline', pack: 'eva' };

  constructor(private fb: FormBuilder) {
  }

  ngOnInit() {
    this.firstForm = this.fb.group({
      firstCtrl: ['', Validators.required],
    });
    this.secondForm = this.fb.group({
      secondCtrl: ['', Validators.required],
    });
    this.thirdForm = this.fb.group({
      thirdCtrl: ['', Validators.required],
    });
  }





}
