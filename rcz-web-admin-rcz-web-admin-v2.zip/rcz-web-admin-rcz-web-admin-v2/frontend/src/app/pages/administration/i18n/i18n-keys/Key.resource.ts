import {Injectable} from "@angular/core";
import {Resource} from "angular4-hal";


@Injectable()
export class KeyResource  {
  name: string;
  comment: string;
  translation: string;
  defaultLocale: string;
  missing: boolean;
  approx: boolean;
  outdated: boolean;
  constructor () {
    this.name = "";
    this.comment = "";
    this.translation = "";
    this.defaultLocale = "";
    this.missing = false;
    this.approx = false;
    this.outdated = false;
  }
}
