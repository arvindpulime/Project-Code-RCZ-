import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { I18nLocalesComponent } from './i18n-locales.component';

describe('I18nLocalesComponent', () => {
  let component: I18nLocalesComponent;
  let fixture: ComponentFixture<I18nLocalesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ I18nLocalesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(I18nLocalesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
