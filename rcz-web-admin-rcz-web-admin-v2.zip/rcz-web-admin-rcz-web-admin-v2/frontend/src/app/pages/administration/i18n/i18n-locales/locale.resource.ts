import {LocaleDisplayResource} from "./localeDisplay.resource";

export class LocaleResource {

  code?: string;
  language?: string;
  englishLanguage?: string;

  constructor(localDis: LocaleDisplayResource) {
    this.code = localDis.code;
    this.language = localDis.language;
    this.englishLanguage = this.englishLanguage;
  }
}
