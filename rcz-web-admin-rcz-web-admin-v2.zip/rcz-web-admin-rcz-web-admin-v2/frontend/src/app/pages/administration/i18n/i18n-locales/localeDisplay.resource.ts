import {Injectable} from "@angular/core";

@Injectable()
export  class LocaleDisplayResource {
  code?: string ;
  language?: string ;
  englishLanguage?: string ;
  defaultLocale?: boolean;
  display: boolean;
  selected: boolean;
  constructor() {

  }
}

