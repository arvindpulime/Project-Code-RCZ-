import {Injectable} from "@angular/core";
import {HttpClient} from "@angular/common/http";
import {ParameterResource} from "./ParameterResource";
import {Observable} from "rxjs";
import {environment} from "../../../../environments/environment";


@Injectable()
export class ParameterService {


  PATH_PARAMETER = "parameter";

  constructor(private http: HttpClient) {

  }

  get(): Observable<ParameterResource> {
    return this.http.get<ParameterResource>(environment.ROOT_URI + this.PATH_PARAMETER);
  }

  save(parameter: ParameterResource): Observable<ParameterResource> {
    return this.http.put<ParameterResource>(environment.ROOT_URI + this.PATH_PARAMETER, parameter);
  }

}
