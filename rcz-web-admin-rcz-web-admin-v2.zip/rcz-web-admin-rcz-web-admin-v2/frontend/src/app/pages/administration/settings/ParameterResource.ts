import {Resource} from "angular4-hal";
import {Injectable} from "@angular/core";


@Injectable()
export class ParameterResource extends Resource {
  id?: string;
  rcz?: RczParam;
  commodore?: CommodoreParam;
  sms?: Sms;
  cvs?: CvsParam;
}

export class RczParam {
  automaticVehicleState?: boolean;
  callerDailyQuotaDurationMin?: number;
  callerDailyQuotaEnabled?: boolean;
  callerDailyQuota?: number;
  callerQuotaDurationMin?: number;
  callerQuota?: number;
  callerQuotaWarningDurationMin?: number;
  callerQuotaWarning?: number;
  clientResponseDebug?: boolean;
  exchangeTimeoutMin?: number;
  hornQuotaDurationMin?: number;
  hornQuota?: number;
  lightsQuotaDurationMin?: number;
  lightsQuota?: number;
  openBar?: boolean;
  proxy?: boolean;
  remoteAlarmId?: string;
}

export class CommodoreParam {
  vehicleRequestMaxDuration?: number;
  vehicleRequestMock?: boolean;
  vehicleRequestNbRetry?: number;
  vehicleRequestPath?: string;
  vehicleRequestRetryDelay?: number;
  vehicleRequestUri?: string;
}

export class Sms {
  nbRetry?: number;
  retryDelay?: number;
  messageLength?: number;
  dataLength?: number;
  dspt?: number;
  messageId?: number;
  messageVersion?: number;
  messageType?: number;
  serviceType?: number;
  byTel?: ByTelParam;
  orange?: OrangeParam;
}

export class ByTelParam {
  protocolVersion?: number;
  adm?: string;
  idOffer?: string;
  messageFormat?: string;
  path?: string;
  targetType?: string;
  uri?: string;
  icp?: string;
}

export class OrangeParam {
  host?: string;
  path?: string;
  username?: string;
  password?: string;
  senderAddress?: string;
  headerHost?: string;
  requestTimeout?: number;
  connectionTimeout?: number;
  headerVersion?: string;
  ecuType?: string;
  serviceType?: string;
  objectType?: string;
  objectVersion?: string;
  objectId?: string;
  messageBinary?: boolean;

}

export class CvsParam {
  cvsAuthAccess?: boolean;
  cvsEndpointUrl?: string;
  cvsMock?: boolean;
  cvsOauthEndpointUrl?: string;
}
