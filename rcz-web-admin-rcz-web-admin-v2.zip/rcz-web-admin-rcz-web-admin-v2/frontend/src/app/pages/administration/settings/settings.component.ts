import {Component, OnInit} from '@angular/core';
import {
  ByTelParam,
  CommodoreParam,
  CvsParam,
  OrangeParam,
  ParameterResource,
  RczParam,
  Sms,
} from "./ParameterResource";
import {ParameterService} from "./ParameterService";

@Component({
  selector: 'ngx-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.scss'],
})
export class SettingsComponent implements OnInit {

  parameterResource: ParameterResource;

  constructor(private parameterService: ParameterService) {
    this.parameterResource = new ParameterResource();
    this.parameterResource.rcz = new RczParam();
    this.parameterResource.commodore = new CommodoreParam();
    this.parameterResource.sms = new Sms();
    this.parameterResource.sms.byTel = new ByTelParam();
    this.parameterResource.sms.orange = new OrangeParam();
    this.parameterResource.cvs = new CvsParam();
  }

  ngOnInit() {
    this.get();
  }

  get(): void {
    this.parameterService.get().subscribe(data => {
      this.parameterResource = data;
    });
  }

  save(): void {
    this.parameterService.save(this.parameterResource).subscribe(data => {
      this.parameterResource = data;
    });
  }
}
