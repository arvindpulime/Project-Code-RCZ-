import {NbMenuItem} from '@nebular/theme';

export const MENU_ITEMS: NbMenuItem[] = [

  {
    title: 'Monitoring',
    group: true,
  },
  {
    title: 'Exchanges',
    icon: 'repeat-outline',
    link: '/pages/monitoring/exchanges',
    pathMatch: 'prefix',
  },
  {
    title: 'Logs',
    icon: 'file-text-outline',
    link: '/pages/monitoring/logs',
    pathMatch: 'prefix',
  },
  {
    title: 'User logs',
    icon: 'file-text-outline',
    link: '/pages/monitoring/user-logs',
    pathMatch: 'prefix',
  },
  {
    title: 'SMS',
    icon: 'email-outline',
    link: '/pages/monitoring/sms',
    pathMatch: 'prefix',
  },
  {
    title: 'Vehicle',
    icon: 'car-outline',
    link: '/pages/monitoring/vehicle',
    pathMatch: 'prefix',
  },
  {
    title: 'Request',
    icon: 'wifi-outline',
    link: '/pages/monitoring/request',
    pathMatch: 'prefix',
  },
  {
    title: 'MQTT',
    icon: 'activity-outline',
    link: '/pages/monitoring/mqtt',
    pathMatch: 'prefix',
  },
  {
    title: 'Application',
    icon: 'cube-outline',
    link: '/pages/monitoring/apps',
    pathMatch: 'prefix',
  },

  {
    title: 'Administration',
    group: true,
  },
  {
    title: 'Internationalization',
    icon: 'globe-outline',
    link: '/pages/admin/i18n',
    home: true,
    pathMatch: 'prefix',
  },
  {
    title: 'Settings',
    icon: 'settings-2-outline',
    link: '/pages/admin/settings',
    pathMatch: 'prefix',
  },
  {
    title: 'Service features',
    icon: 'bulb-outline',
    link: '/pages/admin/service-features',
    pathMatch: 'prefix',
  },
  {
    title: 'Help',
    icon: 'question-mark-outline',
    link: '/pages/admin/help',
    pathMatch: 'prefix',
  },

];
