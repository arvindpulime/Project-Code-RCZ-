import {NgModule} from '@angular/core';
import {NbMenuModule} from '@nebular/theme';

import {ThemeModule} from '../@theme/theme.module';
import {PagesComponent} from './pages.component';
import {PagesRoutingModule} from './pages-routing.module';
import {MiscellaneousModule} from './miscellaneous/miscellaneous.module';
import {MonitoringModule} from './monitoring/monitoring.module';
import {AdministrationModule} from './administration/administration.module';
import {NbEvaIconsModule} from '@nebular/eva-icons';

const imports = [
  PagesRoutingModule,
  ThemeModule,
  NbMenuModule,
  MiscellaneousModule,
  AdministrationModule,
  MonitoringModule,
  NbEvaIconsModule,
];

const declarations = [
  PagesComponent,
];

@NgModule({
  imports: imports,
  declarations: declarations,
})
export class PagesModule {
}
