/**
 * @license
 * Copyright Akveo. All Rights Reserved.
 * Licensed under the MIT License. See License.txt in the project root for license information.
 */
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {NgModule} from '@angular/core';
import {HttpClientModule} from '@angular/common/http';
import {CoreModule} from './@core/core.module';
import {ThemeModule} from './@theme/theme.module';
import {AppComponent} from './app.component';
import {AppRoutingModule} from './app-routing.module';
import {NbChatModule, NbDatepickerModule, NbDialogModule, NbLayoutModule, NbMenuModule, NbSidebarModule, NbToastrModule, NbWindowModule} from '@nebular/theme';
import {AuthorizationService} from "./@security/authorization.service";
import {AuthorizationGuard} from "./@security/authorization.guard";
import {APP_BASE_HREF} from "@angular/common";
import {ExternalConfigService} from "./@common/external-config.service";
import {AngularHalModule} from "angular4-hal";

const imports = [
  BrowserModule,
  BrowserAnimationsModule,
  HttpClientModule,
  AppRoutingModule,
  ThemeModule.forRoot(),
  NbSidebarModule.forRoot(),
  NbMenuModule.forRoot(),
  NbDialogModule.forRoot(),
  NbWindowModule.forRoot(),
  NbToastrModule.forRoot(),
  NbDatepickerModule.forRoot(),
  NbLayoutModule,
  NbChatModule.forRoot({
    messageGoogleMapKey: 'AIzaSyA_wNuCzia92MAmdLRzmqitRGvCF7wCZPY',
  }),
  CoreModule.forRoot(),
  AngularHalModule.forRoot(),

];

const declarations = [AppComponent];

const bootstrap = [AppComponent];

const providers = [
  AuthorizationService,
  AuthorizationGuard,
  {provide: 'ExternalConfigurationService', useClass: ExternalConfigService},
  {provide: APP_BASE_HREF, useValue: '/'},
];

@NgModule({
  declarations: declarations,
  imports: imports,
  bootstrap: bootstrap,
  providers: providers,
})
export class AppModule {
}
