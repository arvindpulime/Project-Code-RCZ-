import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {Thead} from "../thead";

@Component({
  selector: 'thead[ngx-thead]',
  templateUrl: './thead.component.html',
  styleUrls: ['./thead.component.scss']
})
export class TheadComponent implements OnInit {

  @Input() columns: Array<Thead>;
  @Output() paramsEmitter = new EventEmitter();

  constructor() {

  }

  ngOnInit() {
  }

  onSortClickListener(event, column) {

    let params = {sort: column, order: 'ASCENDING'};

    if (event.target.classList.contains('fa-sort')) {
      TheadComponent.resetSortIcon();
      event.target.classList.replace('fa-sort', 'fa-sort-up');
    } else if (event.target.classList.contains('fa-sort-up')) {
      TheadComponent.resetSortIcon();
      event.target.classList.replace('fa-sort', 'fa-sort-down');
      params = {sort: column, order: 'DESCENDING'};
    } else if (event.target.classList.contains('fa-sort-down')) {
      TheadComponent.resetSortIcon();
    }

    this.paramsEmitter.emit(params);

  }

  public static resetSortIcon() {
    let elements = document.getElementsByClassName('fa-fw');
    Array.prototype.forEach.call(elements, (el) => {
      if (!el.classList.contains('fa-sort')) {
        el.classList.remove('fa-sort-up', 'fa-sort-down');
        el.classList.add('fa-sort')
      }
    });
  }

}
