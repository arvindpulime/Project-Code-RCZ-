export interface Thead {
  name: string;
  filterName?: string;
}
