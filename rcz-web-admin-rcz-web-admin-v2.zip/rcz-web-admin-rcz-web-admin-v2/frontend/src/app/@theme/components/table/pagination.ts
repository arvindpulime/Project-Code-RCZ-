export interface Pagination {
  totalElements: number;
  pageNumber: number;
  pageSize: number;
}
