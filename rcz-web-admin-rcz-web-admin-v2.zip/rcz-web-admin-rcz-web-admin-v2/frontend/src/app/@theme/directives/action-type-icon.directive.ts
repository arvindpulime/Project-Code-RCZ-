import {Directive, ElementRef, Input, Renderer2} from '@angular/core';

@Directive({
  selector: '[actionTypeIcon]'
})
export class ActionTypeIconDirective {

  constructor(private renderer: Renderer2, private el: ElementRef) {
  }

  @Input() set actionTypeIcon(type: string) {
    this.el.nativeElement.style.color = "#3366ff";
    this.el.nativeElement.style.fontSize = "1.75em";
    this.el.nativeElement.className = ActionTypeIconDirective.getClass(type);
  }

  private static getClass(type: string) {
    switch (type) {

      case 'DOORS':
        return 'fas fa-door-open';

      case 'HORN':
        return 'fas fa-bullhorn';

      case 'IMMOBILIZATION':
        return 'fas fa-car';

      case 'IMMO_DATA':
        return 'fas fa-database';

      case 'LIGHTS':
        return 'far fa-lightbulb';

      case 'REQUEST_STATE':
        return 'fas fa-car';

      case 'SERVICE_STATE':
        return 'fas fa-car';

      case 'REQUEST_STATE_STOLEN':
        return 'fas fa-car';

      case 'REMOTE_ALARM':
        return 'far fa-bell';

      case 'MOTION_ALERT':
        return 'fas fa-car';

      case 'STOLEN_VIN':
        return 'fas fa-mask';

      case 'TRACKING':
        return 'fas fa-map-marker-alt';

      case 'VEHICLE_STATE':
        return 'fas fa-car';

      case 'VEHICLE_STATE_STOLEN':
        return 'fas fa-car';

      case 'VEHICLE_INFO':
        return 'fas fa-car';

      case 'VEHICLE_STATE_MANAGEMENT':
        return 'fas fa-car';

      case 'CHARGING':
        return 'fas fa-charging-station';

      case 'CHARGING_STATE':
        return 'fas fa-car';

      case 'LOW_POWER_INFO':
        return 'fas fa-battery-quarter';

      case 'LOW_POWER_INFO_STOLEN':
        return 'fas fa-battery-quarter';

      case 'THERMAL_PRECONDITIONING':
        return 'fas fa-thermometer-three-quarters';

      case 'BTA_DELAYED_CHARGE':
        return 'fas fa-car';

      case 'THERMAL_PRECONDITIONING_PROGRAMED':
        return 'fas fa-car';

      case 'CLIENT':
        return 'fas fa-user';

      case 'PARTNER':
        return 'fas fa-handshake';

      case 'VEHICLE':
        return 'fas fa-car';

    }

  }

}
