import {Directive, ElementRef, Input, Renderer2} from '@angular/core';

@Directive({
  selector: '[statusBadge]'
})
export class StatusBadgeDirective {

  constructor(private renderer: Renderer2, private el: ElementRef) {
  }

  @Input() set statusBadge(status: string) {
    this.el.nativeElement.innerHTML = status;
    this.el.nativeElement.className = StatusBadgeDirective.getStatus(status);
  }

  private static getStatus(status: string) {
    switch (status) {
      case 'PENDING':
      case 'REMOTE':
      case 'BTA_ASLEEP':
      case 'PSA_VEH_STATE_REQUEST':
      case 'REQUEST_SENT_TO_BTA':
      case 'INFO':
      case 'TRACE':
      case 'DEBUG':
      case 'OFF':
        return 'badge badge-pill badge-primary';

      case 'FINISH':
      case 'SUCCESS':
      case 'SENT':
      case 'REQUEST_ACCEPTED':
        return 'badge badge-pill badge-success';

      case 'QUOTA_EXCEEDED_WARNING':
      case 'WARN':
        return 'badge badge-pill badge-warning';

      case 'STOLEN':
      case 'ERROR':
      case 'FATAL':
        return 'badge badge-pill badge-danger';

      default:
        return 'badge badge-pill badge-info';

    }


  }

}
