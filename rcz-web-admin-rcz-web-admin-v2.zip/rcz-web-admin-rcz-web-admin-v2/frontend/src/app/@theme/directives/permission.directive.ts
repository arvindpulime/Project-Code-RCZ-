import {Directive, Input, OnDestroy, TemplateRef, ViewContainerRef} from '@angular/core';
import {AuthorizationService} from "../../@security/authorization.service";

@Directive({
  selector: "[isPermitted]",
})
export class PermissionDirective implements OnDestroy {

  private alive = true;
  private hasView = false;

  constructor(
    private _authService: AuthorizationService,
    private templateRef: TemplateRef<any>,
    private viewContainer: ViewContainerRef,
  ) {
  }

  @Input() set isPermitted(roles: string[]) {
    const can = this._authService.checkPermissions(roles);
    if (can && !this.hasView) {
      this.viewContainer.createEmbeddedView(this.templateRef);
      this.hasView = true;
    } else if (!can && this.hasView) {
      this.viewContainer.clear();
      this.hasView = false;
    }
  }

  ngOnDestroy(): void {
    this.alive = false;
  }


}
