import {Component, OnInit} from '@angular/core';
import {AuthorizationService} from "./@security/authorization.service";

@Component({
  selector: 'ngx-app',
  template: '<router-outlet></router-outlet>',
})
export class AppComponent implements OnInit {

  constructor(private authService: AuthorizationService) {
  }

  ngOnInit(): void {
    this.authService.getUserAuthorization().subscribe();
  }
}
