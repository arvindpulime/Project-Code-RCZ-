drop table rczqtexchange;
drop table rczqtlog;




create table if not exists rczqtexchange
(
    id             varchar(255) not null,
    actionservice  varchar(255) not null,
    actiontype     varchar(255) not null,
    callerid       varchar(255) not null,
    callertype     varchar(255) not null,
    correlationid  varchar(255),
    processstatus  varchar(255),
    request        text,
    receiveddate   timestamp,
    sentdate       timestamp,
    responsestatus varchar(255),
    status         varchar(255),
    topic          varchar(255),
    uin            varchar(255),
    vin            varchar(255)
) PARTITION BY RANGE (receiveddate);


create table if not exists rczqtlog
(
    id         bigint       not null,
    exchangeid varchar(255),
    instanceid varchar(255),
    logdate    timestamp,
    loglevel   varchar(255),
    data       text,
    message    varchar(255) not null,
    topic      varchar(255)
) PARTITION BY RANGE (logdate);

-- PARTITIONS AND INDEXES FOR WEEK 8
CREATE TABLE rczqtexchange_21W8 PARTITION OF rczqtexchange
    FOR VALUES FROM ('2021-02-23') TO ('2021-02-28');
ALTER TABLE rczqtexchange_21W8 ADD PRIMARY KEY (id);
create index ndx_exchange_21W8_id on rczqtexchange_21W8(id);
create index ndx_exchange_21W8_uin on rczqtexchange_21W8(uin);
create index ndx_exchange_21W8_vin on rczqtexchange_21W8(vin);
create index ndx_exchange_21W8_correlationid on rczqtexchange_21W8(correlationid);
create index ndx_exchange_21W8_corrid_status on rczqtexchange_21W8(correlationid, status);
create index ndx_exchange_21W8_quota on rczqtexchange_21W8(callerid, receiveddate);
create index ndx_exchange_21W8_duplicate on rczqtexchange_21W8(id, callerid, actionservice, actiontype, status);
create index ndx_exchange_21W8_callerid on rczqtexchange_21W8(callerid);
create index ndx_exchange_21W8_quota_action on rczqtexchange_21W8(vin,processstatus, callerid, actionservice, actiontype, receiveddate);
create index ndx_exchange_21W8_quota_wakeup on rczqtexchange_21W8(processstatus, callerid, receiveddate);
create index ndx_exchange_21W8_alert on rczqtexchange_21W8(responsestatus, receiveddate);
create index ndx_exchange_21W8_list on rczqtexchange_21W8(receiveddate desc, callertype);
create index ndx_exchange_21W8_alert2 on rczqtexchange_21W8(receiveddate desc, responsestatus, sentdate);
create index ndx_exchange_21W8_timeout on rczqtexchange_21W8(receiveddate desc, status);
create index ndx_exchange_21W8_pending_asleep on rczqtexchange_21W8(uin, status, processstatus);


CREATE TABLE rczqtlog_21W8 PARTITION OF rczqtlog
    FOR VALUES FROM ('2021-02-23') TO ('2021-02-28');
ALTER TABLE rczqtlog_21W8 ADD PRIMARY KEY (id);
create index ndx_log_21W8_id on rczqtlog_21W8( id);
create index ndx_log_21W8_criteria on rczqtlog_21W8( logdate, loglevel);
create index ndx_log_21W8_exchange_id on rczqtlog_21W8(exchangeid);
create index ndx_log_21W8_date on rczqtlog_21W8( logdate);


-- PARTITIONS AND INDEXES FOR WEEK 9
CREATE TABLE rczqtexchange_21W9 PARTITION OF rczqtexchange
    FOR VALUES FROM ('2021-02-28') TO ('2021-03-07');
ALTER TABLE rczqtexchange_21W9 ADD PRIMARY KEY (id);
create index ndx_exchange_21W9_id on rczqtexchange_21W9(id);
create index ndx_exchange_21W9_uin on rczqtexchange_21W9(uin);
create index ndx_exchange_21W9_vin on rczqtexchange_21W9(vin);
create index ndx_exchange_21W9_correlationid on rczqtexchange_21W9(correlationid);
create index ndx_exchange_21W9_corrid_status on rczqtexchange_21W9(correlationid, status);
create index ndx_exchange_21W9_quota on rczqtexchange_21W9(callerid, receiveddate);
create index ndx_exchange_21W9_duplicate on rczqtexchange_21W9(id, callerid, actionservice, actiontype, status);
create index ndx_exchange_21W9_callerid on rczqtexchange_21W9(callerid);
create index ndx_exchange_21W9_quota_action on rczqtexchange_21W9(vin,processstatus, callerid, actionservice, actiontype, receiveddate);
create index ndx_exchange_21W9_quota_wakeup on rczqtexchange_21W9(processstatus, callerid, receiveddate);
create index ndx_exchange_21W9_alert on rczqtexchange_21W9(responsestatus, receiveddate);
create index ndx_exchange_21W9_list on rczqtexchange_21W9(receiveddate desc, callertype);
create index ndx_exchange_21W9_alert2 on rczqtexchange_21W9(receiveddate desc, responsestatus, sentdate);
create index ndx_exchange_21W9_timeout on rczqtexchange_21W9(receiveddate desc, status);
create index ndx_exchange_21W9_pending_asleep on rczqtexchange_21W9(uin, status, processstatus);


CREATE TABLE rczqtlog_21W9 PARTITION OF rczqtlog
    FOR VALUES FROM ('2021-02-28') TO ('2021-03-07');
ALTER TABLE rczqtlog_21W9 ADD PRIMARY KEY (id);
create index ndx_log_21W9_id on rczqtlog_21W9( id);
create index ndx_log_21W9_criteria on rczqtlog_21W9( logdate, loglevel);
create index ndx_log_21W9_exchange_id on rczqtlog_21W9(exchangeid);
create index ndx_log_21W9_date on rczqtlog_21W9( logdate);



-- PARTITIONS AND INDEXES FOR WEEK 10
CREATE TABLE rczqtexchange_21W10 PARTITION OF rczqtexchange
    FOR VALUES FROM ('2021-03-07') TO ('2021-03-14');
ALTER TABLE rczqtexchange_21W10 ADD PRIMARY KEY (id);
create index ndx_exchange_21W10_id on rczqtexchange_21W10(id);
create index ndx_exchange_21W10_uin on rczqtexchange_21W10(uin);
create index ndx_exchange_21W10_vin on rczqtexchange_21W10(vin);
create index ndx_exchange_21W10_correlationid on rczqtexchange_21W10(correlationid);
create index ndx_exchange_21W10_corrid_status on rczqtexchange_21W10(correlationid, status);
create index ndx_exchange_21W10_quota on rczqtexchange_21W10(callerid, receiveddate);
create index ndx_exchange_21W10_duplicate on rczqtexchange_21W10(id, callerid, actionservice, actiontype, status);
create index ndx_exchange_21W10_callerid on rczqtexchange_21W10(callerid);
create index ndx_exchange_21W10_quota_action on rczqtexchange_21W10(vin,processstatus, callerid, actionservice, actiontype, receiveddate);
create index ndx_exchange_21W10_quota_wakeup on rczqtexchange_21W10(processstatus, callerid, receiveddate);
create index ndx_exchange_21W10_alert on rczqtexchange_21W10(responsestatus, receiveddate);
create index ndx_exchange_21W10_list on rczqtexchange_21W10(receiveddate desc, callertype);
create index ndx_exchange_21W10_alert2 on rczqtexchange_21W10(receiveddate desc, responsestatus, sentdate);
create index ndx_exchange_21W10_timeout on rczqtexchange_21W10(receiveddate desc, status);
create index ndx_exchange_21W10_pending_asleep on rczqtexchange_21W10(uin, status, processstatus);


CREATE TABLE rczqtlog_21W10 PARTITION OF rczqtlog
    FOR VALUES FROM ('2021-03-07') TO ('2021-03-14');
ALTER TABLE rczqtlog_21W10 ADD PRIMARY KEY (id);
create index ndx_log_21W10_id on rczqtlog_21W10( id);
create index ndx_log_21W10_criteria on rczqtlog_21W10( logdate, loglevel);
create index ndx_log_21W10_exchange_id on rczqtlog_21W10(exchangeid);
create index ndx_log_21W10_date on rczqtlog_21W10( logdate);


-- PARTITIONS AND INDEXES FOR WEEK 11
CREATE TABLE rczqtexchange_21W11 PARTITION OF rczqtexchange
    FOR VALUES FROM ('2021-03-14') TO ('2021-03-21');
ALTER TABLE rczqtexchange_21W11 ADD PRIMARY KEY (id);
create index ndx_exchange_21W11_id on rczqtexchange_21W11(id);
create index ndx_exchange_21W11_uin on rczqtexchange_21W11(uin);
create index ndx_exchange_21W11_vin on rczqtexchange_21W11(vin);
create index ndx_exchange_21W11_correlationid on rczqtexchange_21W11(correlationid);
create index ndx_exchange_21W11_corrid_status on rczqtexchange_21W11(correlationid, status);
create index ndx_exchange_21W11_quota on rczqtexchange_21W11(callerid, receiveddate);
create index ndx_exchange_21W11_duplicate on rczqtexchange_21W11(id, callerid, actionservice, actiontype, status);
create index ndx_exchange_21W11_callerid on rczqtexchange_21W11(callerid);
create index ndx_exchange_21W11_quota_action on rczqtexchange_21W11(vin,processstatus, callerid, actionservice, actiontype, receiveddate);
create index ndx_exchange_21W11_quota_wakeup on rczqtexchange_21W11(processstatus, callerid, receiveddate);
create index ndx_exchange_21W11_alert on rczqtexchange_21W11(responsestatus, receiveddate);
create index ndx_exchange_21W11_list on rczqtexchange_21W11(receiveddate desc, callertype);
create index ndx_exchange_21W11_alert2 on rczqtexchange_21W11(receiveddate desc, responsestatus, sentdate);
create index ndx_exchange_21W11_timeout on rczqtexchange_21W11(receiveddate desc, status);
create index ndx_exchange_21W11_pending_asleep on rczqtexchange_21W11(uin, status, processstatus);


CREATE TABLE rczqtlog_21W11 PARTITION OF rczqtlog
    FOR VALUES FROM ('2021-03-14') TO ('2021-03-21');
ALTER TABLE rczqtlog_21W11 ADD PRIMARY KEY (id);
create index ndx_log_21W11_id on rczqtlog_21W11( id);
create index ndx_log_21W11_criteria on rczqtlog_21W11( logdate, loglevel);
create index ndx_log_21W11_exchange_id on rczqtlog_21W11(exchangeid);
create index ndx_log_21W11_date on rczqtlog_21W11( logdate);


-- PARTITIONS AND INDEXES FOR WEEK 12
CREATE TABLE rczqtexchange_21W12 PARTITION OF rczqtexchange
    FOR VALUES FROM ('2021-03-21') TO ('2021-03-28');
ALTER TABLE rczqtexchange_21W12 ADD PRIMARY KEY (id);
create index ndx_exchange_21W12_id on rczqtexchange_21W12(id);
create index ndx_exchange_21W12_uin on rczqtexchange_21W12(uin);
create index ndx_exchange_21W12_vin on rczqtexchange_21W12(vin);
create index ndx_exchange_21W12_correlationid on rczqtexchange_21W12(correlationid);
create index ndx_exchange_21W12_corrid_status on rczqtexchange_21W12(correlationid, status);
create index ndx_exchange_21W12_quota on rczqtexchange_21W12(callerid, receiveddate);
create index ndx_exchange_21W12_duplicate on rczqtexchange_21W12(id, callerid, actionservice, actiontype, status);
create index ndx_exchange_21W12_callerid on rczqtexchange_21W12(callerid);
create index ndx_exchange_21W12_quota_action on rczqtexchange_21W12(vin,processstatus, callerid, actionservice, actiontype, receiveddate);
create index ndx_exchange_21W12_quota_wakeup on rczqtexchange_21W12(processstatus, callerid, receiveddate);
create index ndx_exchange_21W12_alert on rczqtexchange_21W12(responsestatus, receiveddate);
create index ndx_exchange_21W12_list on rczqtexchange_21W12(receiveddate desc, callertype);
create index ndx_exchange_21W12_alert2 on rczqtexchange_21W12(receiveddate desc, responsestatus, sentdate);
create index ndx_exchange_21W12_timeout on rczqtexchange_21W12(receiveddate desc, status);
create index ndx_exchange_21W12_pending_asleep on rczqtexchange_21W12(uin, status, processstatus);

CREATE TABLE rczqtlog_21W12 PARTITION OF rczqtlog
    FOR VALUES FROM ('2021-03-21') TO ('2021-03-28');
ALTER TABLE rczqtlog_21W12 ADD PRIMARY KEY (id);
create index ndx_log_21W12_id on rczqtlog_21W12( id);
create index ndx_log_21W12_criteria on rczqtlog_21W12( logdate, loglevel);
create index ndx_log_21W12_exchange_id on rczqtlog_21W12(exchangeid);
create index ndx_log_21W12_date on rczqtlog_21W12( logdate);



-- PARTITIONS AND INDEXES FOR WEEK 13
CREATE TABLE rczqtexchange_21W13 PARTITION OF rczqtexchange
    FOR VALUES FROM ('2021-03-28') TO ('2021-04-04');
ALTER TABLE rczqtexchange_21W13 ADD PRIMARY KEY (id);
create index ndx_exchange_21W13_id on rczqtexchange_21W13(id);
create index ndx_exchange_21W13_uin on rczqtexchange_21W13(uin);
create index ndx_exchange_21W13_vin on rczqtexchange_21W13(vin);
create index ndx_exchange_21W13_correlationid on rczqtexchange_21W13(correlationid);
create index ndx_exchange_21W13_corrid_status on rczqtexchange_21W13(correlationid, status);
create index ndx_exchange_21W13_quota on rczqtexchange_21W13(callerid, receiveddate);
create index ndx_exchange_21W13_duplicate on rczqtexchange_21W13(id, callerid, actionservice, actiontype, status);
create index ndx_exchange_21W13_callerid on rczqtexchange_21W13(callerid);
create index ndx_exchange_21W13_quota_action on rczqtexchange_21W13(vin,processstatus, callerid, actionservice, actiontype, receiveddate);
create index ndx_exchange_21W13_quota_wakeup on rczqtexchange_21W13(processstatus, callerid, receiveddate);
create index ndx_exchange_21W13_alert on rczqtexchange_21W13(responsestatus, receiveddate);
create index ndx_exchange_21W13_list on rczqtexchange_21W13(receiveddate desc, callertype);
create index ndx_exchange_21W13_alert2 on rczqtexchange_21W13(receiveddate desc, responsestatus, sentdate);
create index ndx_exchange_21W13_timeout on rczqtexchange_21W13(receiveddate desc, status);
create index ndx_exchange_21W13_pending_asleep on rczqtexchange_21W13(uin, status, processstatus);


CREATE TABLE rczqtlog_21W13 PARTITION OF rczqtlog
    FOR VALUES FROM ('2021-03-28') TO ('2021-04-04');
ALTER TABLE rczqtlog_21W13 ADD PRIMARY KEY (id);
create index ndx_log_21W13_id on rczqtlog_21W13( id);
create index ndx_log_21W13_criteria on rczqtlog_21W13( logdate, loglevel);
create index ndx_log_21W13_exchange_id on rczqtlog_21W13(exchangeid);
create index ndx_log_21W13_date on rczqtlog_21W13( logdate);



-- PARTITIONS AND INDEXES FOR WEEK 14
CREATE TABLE rczqtexchange_21W14 PARTITION OF rczqtexchange
    FOR VALUES FROM ('2021-04-04') TO ('2021-04-11');
ALTER TABLE rczqtexchange_21W14 ADD PRIMARY KEY (id);
create index ndx_exchange_21W14_id on rczqtexchange_21W14(id);
create index ndx_exchange_21W14_uin on rczqtexchange_21W14(uin);
create index ndx_exchange_21W14_vin on rczqtexchange_21W14(vin);
create index ndx_exchange_21W14_correlationid on rczqtexchange_21W14(correlationid);
create index ndx_exchange_21W14_corrid_status on rczqtexchange_21W14(correlationid, status);
create index ndx_exchange_21W14_quota on rczqtexchange_21W14(callerid, receiveddate);
create index ndx_exchange_21W14_duplicate on rczqtexchange_21W14(id, callerid, actionservice, actiontype, status);
create index ndx_exchange_21W14_callerid on rczqtexchange_21W14(callerid);
create index ndx_exchange_21W14_quota_action on rczqtexchange_21W14(vin,processstatus, callerid, actionservice, actiontype, receiveddate);
create index ndx_exchange_21W14_quota_wakeup on rczqtexchange_21W14(processstatus, callerid, receiveddate);
create index ndx_exchange_21W14_alert on rczqtexchange_21W14(responsestatus, receiveddate);
create index ndx_exchange_21W14_list on rczqtexchange_21W14(receiveddate desc, callertype);
create index ndx_exchange_21W14_alert2 on rczqtexchange_21W14(receiveddate desc, responsestatus, sentdate);
create index ndx_exchange_21W14_timeout on rczqtexchange_21W14(receiveddate desc, status);
create index ndx_exchange_21W14_pending_asleep on rczqtexchange_21W14(uin, status, processstatus);


CREATE TABLE rczqtlog_21W14 PARTITION OF rczqtlog
    FOR VALUES FROM ('2021-04-04') TO ('2021-04-11');
ALTER TABLE rczqtlog_21W14 ADD PRIMARY KEY (id);
create index ndx_log_21W14_id on rczqtlog_21W14( id);
create index ndx_log_21W14_criteria on rczqtlog_21W14( logdate, loglevel);
create index ndx_log_21W14_exchange_id on rczqtlog_21W14(exchangeid);
create index ndx_log_21W14_date on rczqtlog_21W14( logdate);



-- HOW TO DETACH AND DELETE A PARTITION --
-- ALTER TABLE rczqtexchange DETACH PARTITION rczqtexchange_21W8;
-- Make a copy in archive DB
-- DROP TABLE rczqtexchange_21W8;
-- ALTER TABLE rczqtlog DETACH PARTITION rczqtlog_21W8;
-- Make a copy in archive DB
-- DROP TABLE rczqtlog_21W8;