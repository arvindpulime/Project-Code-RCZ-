package com.inetpsa.rcz.infrastructure.websocket.orange;

import com.fasterxml.jackson.core.type.TypeReference;
import com.inetpsa.rcz.application.exceptions.WebExeption;
import com.inetpsa.rcz.domain.model.sms.Sms;
import com.inetpsa.rcz.domain.services.SmsService;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;
import com.inetpsa.rcz.infrastructure.websocket.stomp.client.WsStompClient;
import com.inetpsa.rcz.infrastructure.websocket.stomp.client.WsStompConfig;
import com.inetpsa.rcz.infrastructure.websocket.stomp.client.WsStompException;
import com.inetpsa.rcz.infrastructure.websocket.stomp.client.spec.StompFrame;
import org.seedstack.seed.Bind;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.LifecycleListener;
import org.seedstack.seed.Logging;
import org.seedstack.seed.web.websocket.BaseClientEndpointConfigurator;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.websocket.ClientEndpoint;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import java.text.MessageFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;
@ClientEndpoint(configurator = BaseClientEndpointConfigurator.class)
public class OrangeAck implements LifecycleListener {
    public static final String ORANGE_ACKNOWLEDGMENT_PARSING_ERROR = "ORANGE Acknowledgment parsing error : [{0}] :";
    public static final String ORANGE_ACKNOWLEDGMENT_UNKNOWN_SMS_ID = "ORANGE Acknowledgment unknown SMS ID : [{0}] :";

    private WsStompClient wsStompClient;
    public static final String WS_ORANGE = "wsOrange";
    @Configuration(WS_ORANGE)
    private WsStompConfig wsStompConfig;
    @Logging
    private Logger logger;
    @Inject
    private SmsService smsService;
    private Session session;

    @OnOpen
    public void onOpen(Session session) {
        try {
            this.session = session;
            connect(session);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
    }

    private void connect(Session session) {
        wsStompClient = new WsStompClient(session, wsStompConfig);
        wsStompClient.connect();
        wsStompClient.subscribe(wsStompConfig.getTopic(), stompFrame -> processAck(stompFrame));
    }


    protected void processAck(StompFrame stompFrame) throws WebExeption {
        AcknowledgementOrange orangeAck = JsonConverter.convert(stompFrame.getBody(), new TypeReference<AcknowledgementOrange>() {
        });
        if (orangeAck != null || orangeAck.getDeliveryInfo() != null && orangeAck.getDeliveryInfo().getRequestId() != null) {
            Sms sms = smsService.findByMessageId(orangeAck.getDeliveryInfo().getRequestId()).orElseThrow(() -> new WebExeption(MessageFormat.format(ORANGE_ACKNOWLEDGMENT_UNKNOWN_SMS_ID, JsonConverter.convert(stompFrame))));
            sms.getAcknowledgement().setAckCode(orangeAck.getDeliveryInfo().getDeliveryStatus());
            if (orangeAck.getDeliveryInfo().getDetailedDeliveryStatus() != null) {
                sms.getAcknowledgement().setReason(orangeAck.getDeliveryInfo().getDetailedDeliveryStatus().toString());
            }
            sms.getAcknowledgement().setAckDate(new Date());
            smsService.update(sms);
        } else {
            throw new WebExeption(MessageFormat.format(ORANGE_ACKNOWLEDGMENT_PARSING_ERROR, JsonConverter.convert(stompFrame)));
        }
    }

    @OnMessage
    public void processMessage(String message) {
        try {

            wsStompClient.onMessage(message);
        } catch (WsStompException e) {

        }
    }

    @Override
    public void started() {
    }

    @Override
    public void stopping() {
        stop();
    }

    private void stop() {
        if (wsStompClient != null) {

            wsStompClient.close();
        }
    }

    private void reconnect() {
        final Timer timer = new Timer();
        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                try {
                    connect(session);
                    timer.cancel();
                } catch (Exception e) {
                    logger.error("Can not connect to Orange ACK broker", e);
                }

            }
        };
        timer.scheduleAtFixedRate(
                task,
                wsStompConfig.getReconnectionInterval() * 1000,
                wsStompConfig.getReconnectionInterval() * 1000
        );
    }
}