package com.inetpsa.rcz.infrastructure.jpa;

import com.inetpsa.rcz.domain.model.service.ServiceFeature;
import com.inetpsa.rcz.rest.elementaryservice.ServiceFeatureFinder;
import com.inetpsa.rcz.rest.elementaryservice.ServiceFeatureRepresentation;
import com.inetpsa.rcz.rest.elementaryservice.ServiceFeatureSort;
import com.inetpsa.rcz.rest.shared.Range;
import com.inetpsa.rcz.rest.shared.Result;
import org.seedstack.business.assembler.Assembler;
import org.seedstack.business.domain.Repository;
import org.seedstack.business.pagination.Slice;
import org.seedstack.business.pagination.dsl.Paginator;
import org.seedstack.jpa.Jpa;
import org.seedstack.jpa.JpaUnit;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;

@JpaUnit("rcz")
public class ServiceJpaFeatureFinder implements ServiceFeatureFinder {


    @Inject
    @Jpa
    private Repository<ServiceFeature, String> serviceFeatureRepository;

    @Inject
    private Assembler<ServiceFeature, ServiceFeatureRepresentation> serviceFeatureAssembler;

    @Inject
    private Paginator paginator;

    @Override
    public Result<ServiceFeatureRepresentation> findAll(Range range, ServiceFeatureSort serviceFeatureSort) {

        Slice<ServiceFeature> serviceFeatures = paginator.paginate(serviceFeatureRepository)
                .withOptions(serviceFeatureSort.getSortOption())
                .byOffset(range.getOffset())
                .limit(range.getSize())
                .all();
        if (serviceFeatures != null && !serviceFeatures.getItems().isEmpty()) {
            final List<ServiceFeatureRepresentation> serviceFeatureDetails = new ArrayList<>();
            serviceFeatures.forEach(elm -> serviceFeatureDetails.add(serviceFeatureAssembler.createDtoFromAggregate(elm)));
            return new Result<>(serviceFeatureDetails, range.getOffset(), serviceFeatureRepository.count(serviceFeatureRepository.getSpecificationBuilder().ofAggregate(ServiceFeature.class).all().build()));
        }
        return new Result<>(new ArrayList<>(), range.getOffset(), 0);
    }

}
