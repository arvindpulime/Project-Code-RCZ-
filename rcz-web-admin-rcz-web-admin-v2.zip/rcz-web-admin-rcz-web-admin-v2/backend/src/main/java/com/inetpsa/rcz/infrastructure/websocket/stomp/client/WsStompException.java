package com.inetpsa.rcz.infrastructure.websocket.stomp.client;

public class WsStompException extends RuntimeException {

    public WsStompException() {
        super();
    }

    public WsStompException(String message) {
        super(message);
    }

    public WsStompException(String message, Throwable cause) {
        super(message, cause);
    }

    public WsStompException(Throwable cause) {
        super(cause);
    }

    protected WsStompException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
