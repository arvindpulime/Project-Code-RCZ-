package com.inetpsa.rcz.rest.helper;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.inetpsa.rcz.domain.model.helper.Helper;
import org.seedstack.business.assembler.AggregateId;
import org.seedstack.business.assembler.DtoOf;

import java.util.Date;

import static com.inetpsa.rcz.domain.model.payload.ValidationPattern.PATTERN_DATE;
import static com.inetpsa.rcz.domain.model.payload.ValidationPattern.PATTERN_DATE_FRONT;

@DtoOf(Helper.class)
public class HelperRepresentation {
    public Long id;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = PATTERN_DATE_FRONT)
    public Date createDate;
    public String title;
    public String content;


    public HelperRepresentation() {
    }

    @AggregateId
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
