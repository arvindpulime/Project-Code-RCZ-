package com.inetpsa.rcz.domain.model.service.sms;

import com.inetpsa.rcz.domain.model.repository.SmsRepository;
import com.inetpsa.rcz.domain.model.sms.Sms;
import com.inetpsa.rcz.rest.shared.hal.HalPageCriteria;
import com.inetpsa.rcz.rest.sms.SmsCriteria;
import com.inetpsa.rcz.rest.sms.SmsSort;
import org.seedstack.business.pagination.Page;
import org.seedstack.business.pagination.dsl.Paginator;
import org.seedstack.business.specification.AndSpecification;
import org.seedstack.business.specification.Specification;
import org.seedstack.business.specification.dsl.SpecificationBuilder;
import org.seedstack.jpa.Jpa;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static com.inetpsa.rcz.rest.sms.SmsCriteria.*;

public class SmsPaginatorServiceImpl implements SmsPaginatorService {

    @Inject
    private Paginator paginator;

    @Jpa
    @Inject
    private SmsRepository SmsRepository;

    @Override
    public Page<Sms> search(SmsSort sort, SmsCriteria criteria, HalPageCriteria halPageCriteria) {
        Specification<Sms> specification = getSpecification(criteria);

        return paginator
                .paginate(SmsRepository)
                .withOptions(sort.getSortOption())
                .byPage(halPageCriteria.getPageNumber())
                .limit(halPageCriteria.getPageSize())
                .matching(specification)
                ;
    }


    private Specification<Sms> getSpecification(SmsCriteria criteria) {

        SpecificationBuilder specificationBuilder = SmsRepository.getSpecificationBuilder();

        List<Specification<Sms>> specifications = new ArrayList<>();

        if (criteria.getUin() != null) {
            specifications.add(specificationBuilder.ofAggregate(Sms.class).property(COL_UIN).equalTo(criteria.getUin()).build());
        }

        if (criteria.getTo() != null) {
            specifications.add(specificationBuilder.ofAggregate(Sms.class).property(COL_TO).matching(criteria.getTo()).trimming().ignoringCase().build());
        }

        if (criteria.getSendingDateFrom() != null && criteria.getSendingDateTo() != null) {
            specifications.add(specificationBuilder.ofAggregate(Sms.class)
                    .property(COL_SENDING_DATE).equalTo(new Date(criteria.getSendingDateFrom()))
                    .or()
                    .property(COL_SENDING_DATE).greaterThan(new Date(criteria.getSendingDateFrom())).build());
            specifications.add(specificationBuilder.ofAggregate(Sms.class)
                    .property(COL_SENDING_DATE).equalTo(new Date(criteria.getSendingDateTo()))
                    .or()
                    .property(COL_SENDING_DATE).lessThan(new Date(criteria.getSendingDateTo())).build());
        }

        if (specifications.isEmpty()) {
            return SmsRepository.getSpecificationBuilder().of(Sms.class).all().build();
        }

        return new AndSpecification<>(specifications.toArray(new Specification[0]));
    }

}
