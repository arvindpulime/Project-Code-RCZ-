package com.inetpsa.rcz.infrastructure.websocket.stomp.client;

import com.google.common.collect.Maps;
import com.inetpsa.rcz.application.shared.ClientConfig;
import org.seedstack.coffig.Config;

import java.util.Map;
import java.util.Properties;

@Config("wsOrange")
public class WsStompConfig {
    private String host;
    private String topic;
    private int reconnectionInterval = 5;
    private Properties headers = new Properties();
    private String login;
    private String passCode;
    private boolean enabled = false;
    private ClientConfig.SSLConfig sslConfig = new ClientConfig.SSLConfig();


    public WsStompConfig() {
    }

    public String getHost() {
        return host;
    }

    public WsStompConfig setHost(String host) {
        this.host = host;
        return this;
    }

    public Properties getHeaders() {
        return headers;
    }

    public WsStompConfig setHeaders(Properties headers) {
        this.headers = headers;
        return this;
    }

    public Map<String, String> getHeadersMap() {
        return Maps.fromProperties(headers);
    }

    public String getTopic() {
        return topic;
    }

    public WsStompConfig setTopic(String topic) {
        this.topic = topic;
        return this;
    }

    public int getReconnectionInterval() {
        return reconnectionInterval;
    }

    public WsStompConfig setReconnectionInterval(int reconnectionInterval) {
        this.reconnectionInterval = reconnectionInterval;
        return this;
    }

    public String getLogin() {
        return login;
    }

    public WsStompConfig setLogin(String login) {
        this.login = login;
        return this;
    }

    public String getPassCode() {
        return passCode;
    }

    public WsStompConfig setPassCode(String passCode) {
        this.passCode = passCode;
        return this;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public WsStompConfig setEnabled(boolean enabled) {
        this.enabled = enabled;
        return this;
    }

    public ClientConfig.SSLConfig getSslConfig() {
        return sslConfig;
    }
}
