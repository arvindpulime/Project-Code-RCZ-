package com.inetpsa.rcz.rest.vehicle;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.inetpsa.rcz.domain.model.shared.Payload;
import com.inetpsa.rcz.domain.model.vehicle.State;
import com.inetpsa.rcz.domain.model.vehicle.Vehicle;
import lombok.Data;
import org.seedstack.business.assembler.DtoOf;
import org.seedstack.seed.rest.hal.HalRepresentation;

import java.util.Date;

import static com.fasterxml.jackson.annotation.JsonFormat.Shape.STRING;
import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;
import static com.inetpsa.rcz.domain.model.payload.ValidationPattern.PATTERN_DATE_FRONT;

@Data
@DtoOf(Vehicle.class)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(NON_NULL)
public class VehicleRepresentation extends HalRepresentation {

    private String id;

    private String vin;

    @JsonFormat(shape = STRING, pattern = PATTERN_DATE_FRONT)
    private Date updateDate;

    private String btaType;

    private String msisdn;

    private String provider;

    private State vehicleState;

    private State serviceState;

    private Payload vehicleInfo;

    private Payload lowPowerInfo;

    private Payload serviceInfo;

}
