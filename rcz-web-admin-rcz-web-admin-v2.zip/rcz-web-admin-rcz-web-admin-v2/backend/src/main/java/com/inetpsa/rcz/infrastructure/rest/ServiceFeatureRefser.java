package com.inetpsa.rcz.infrastructure.rest;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.inetpsa.rcz.domain.model.action.Action;
import com.inetpsa.rcz.domain.model.action.ActionService;
import com.inetpsa.rcz.domain.model.action.ActionType;
import com.inetpsa.rcz.domain.model.service.ServiceFeature;
import org.seedstack.business.assembler.DtoOf;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.*;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(NON_NULL)
@DtoOf(ServiceFeature.class)
public class ServiceFeatureRefser implements Serializable {

    public static final String REFSER_REMOTE_DATA_SET_ERROR_FOR_LABEL = "Refser remote DataSet Error for label :";
    private String code;
    private String shortLabel;
    private String label;
    private Date startDate;
    private Date endDate = defaultEndDate();
    private List<ActionsDataSet> remoteActionsDataset = new ArrayList<>();
    private static final Logger LOGGER = LoggerFactory.getLogger(ServiceFeatureRefser.class);

    @JsonIgnore
    private static Date defaultEndDate() {
        return Date.from(LocalDate                         // Represents a date-only value, without time-of-day and without time zone.
                .of(2099, 1, 1)              // Specify year-month-day. Notice sane counting, unlike legacy classes: 2014 means year 2014, 1-12 for Jan-Dec.
                .atStartOfDay()                                 // Returns a `ZonedDateTime`.
                .toInstant(ZoneOffset.UTC));
    }

    private boolean suspended;
    private boolean deleted;

    public String getCode() {
        return code;
    }

    public ServiceFeatureRefser setCode(String code) {
        this.code = code;
        return this;
    }

    public String getShortLabel() {
        return shortLabel;
    }

    public ServiceFeatureRefser setShortLabel(String shortLabel) {
        this.shortLabel = shortLabel;
        return this;
    }

    public String getLabel() {
        return label;
    }

    public ServiceFeatureRefser setLabel(String label) {
        this.label = label;
        return this;
    }

    public Date getStartDate() {
        return startDate;
    }

    public ServiceFeatureRefser setStartDate(Date startDate) {
        this.startDate = startDate;
        return this;
    }

    public Date getEndDate() {
        return endDate;
    }

    public ServiceFeatureRefser setEndDate(Date endDate) {
        this.endDate = endDate;
        return this;
    }

    public boolean isSuspended() {
        return suspended;
    }

    public ServiceFeatureRefser setSuspended(boolean suspended) {
        this.suspended = suspended;
        return this;
    }

    public boolean isDeleted() {
        return deleted;
    }

    public ServiceFeatureRefser setDeleted(boolean deleted) {
        this.deleted = deleted;
        return this;
    }

    public List<ActionsDataSet> getRemoteActionsDataset() {
        return remoteActionsDataset;
    }

    public ServiceFeatureRefser setRemoteActionsDataset(List<ActionsDataSet> remoteActionsDataset) {
        this.remoteActionsDataset = remoteActionsDataset;
        return this;
    }

    @JsonIgnore
    public Set<Action> getActions() {
        Set<Action> actions = new HashSet<>();
        for (ActionsDataSet actionsDataSet : remoteActionsDataset) {
            String[] actionValues = actionsDataSet.getLabel().split("\\.");
            try {

                Action action = Action.create(ActionService.valueOf(actionValues[0]), ActionType.valueOf(actionValues[1]));
                if (Action.ACTION_SET.contains(action)) {
                    actions.add(action);
                } else {
                    LOGGER.warn(REFSER_REMOTE_DATA_SET_ERROR_FOR_LABEL + actionsDataSet.getLabel());
                }
            } catch (Exception e) {
                LOGGER.warn(REFSER_REMOTE_DATA_SET_ERROR_FOR_LABEL + actionsDataSet.getLabel(), e);
            }

        }
        return actions;
    }

}