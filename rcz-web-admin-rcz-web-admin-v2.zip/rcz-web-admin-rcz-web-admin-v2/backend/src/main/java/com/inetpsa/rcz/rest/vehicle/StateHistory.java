package com.inetpsa.rcz.rest.vehicle;

import com.inetpsa.rcz.domain.model.vehicle.State;

import java.util.List;

public class StateHistory {

    private String id;

    private List<State> statesHistory;

    public StateHistory(String id, List<State> statesHistory) {
        this.id = id;
        this.statesHistory = statesHistory;
    }

    public String getId() {
        return id;
    }

    public List<State> getStatesHistory() {
        return statesHistory;
    }
}
