package com.inetpsa.rcz.rest.log.list;

import com.inetpsa.rcz.rest.shared.SortOrder;
import lombok.Data;
import org.seedstack.business.domain.SortOption;

import javax.ws.rs.DefaultValue;
import javax.ws.rs.QueryParam;

@Data
public class LogSort {


    public static final String SORT = "sort";
    public static final String ORDER = "order";

    @QueryParam(SORT)
    @DefaultValue("LOG_DATE")
    private ColumnSort sort;

    @QueryParam(ORDER)
    @DefaultValue("DESCENDING")
    private SortOrder order;

    public SortOption getSortOption() {
        return new SortOption().add(this.getSort().literal(), SortOption.Direction.valueOf(this.getOrder().name()));
    }

    public enum ColumnSort {

        ID("id"),
        INSTANCE("instanceId"),
        LOG_LEVEL("logLevel"),
        LOG_DATE("logDate"),
        MESSAGE("message.message"),
        DATA("message.data"),
        TOPIC("message.topic"),
        EXCHANGE("exchangeId");

        private String literal;

        ColumnSort(String literal) {
            this.literal = literal;
        }

        public String literal() {
            return literal;
        }
    }
}
