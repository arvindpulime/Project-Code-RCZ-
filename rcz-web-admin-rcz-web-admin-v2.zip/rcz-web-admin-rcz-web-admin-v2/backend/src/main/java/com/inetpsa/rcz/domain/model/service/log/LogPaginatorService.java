package com.inetpsa.rcz.domain.model.service.log;

import com.inetpsa.rcz.domain.model.log.Log;
import com.inetpsa.rcz.rest.log.list.LogCriteria;
import com.inetpsa.rcz.rest.log.list.LogSort;
import com.inetpsa.rcz.rest.shared.hal.HalPageCriteria;
import org.seedstack.business.Service;
import org.seedstack.business.pagination.Page;

@Service
public interface LogPaginatorService {

    Page<Log> search(LogSort sort, LogCriteria criteria, HalPageCriteria halPageCriteria);

}
