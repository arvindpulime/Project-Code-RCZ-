package com.inetpsa.rcz.rest.elementaryservice;

import com.inetpsa.rcz.application.exceptions.WebExeption;
import com.inetpsa.rcz.application.services.ServiceFeatureUpstreamService;
import com.inetpsa.rcz.application.services.UserLogService;
import com.inetpsa.rcz.domain.model.service.ServiceFeature;
import com.inetpsa.rcz.domain.model.service.elementaryservice.ServiceFeaturePaginatorService;
import com.inetpsa.rcz.domain.model.user.ResourceType;
import com.inetpsa.rcz.rest.shared.hal.HalPageCriteria;
import com.inetpsa.rcz.rest.shared.hal.HalPageRepresentation;
import io.swagger.annotations.Api;
import org.seedstack.business.assembler.Assembler;
import org.seedstack.business.assembler.dsl.FluentAssembler;
import org.seedstack.business.domain.AggregateNotFoundException;
import org.seedstack.business.domain.Repository;
import org.seedstack.business.pagination.Page;
import org.seedstack.jpa.Jpa;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.Logging;
import org.seedstack.seed.rest.Rel;
import org.seedstack.seed.rest.RelRegistry;
import org.seedstack.seed.rest.hal.Link;
import org.seedstack.seed.security.Logical;
import org.seedstack.seed.security.RequiresRoles;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.persistence.EntityNotFoundException;
import javax.validation.constraints.NotNull;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.inetpsa.rcz.rest.elementaryservice.ServiceFeatureCriteria.*;
import static com.inetpsa.rcz.rest.exchange.ExchangeSort.ORDER;
import static com.inetpsa.rcz.rest.exchange.ExchangeSort.SORT;
import static com.inetpsa.rcz.rest.shared.Rels.SERVICE_FEATURE;
import static com.inetpsa.rcz.rest.shared.Rels.SERVICE_FEATURES;

@Api
@Path("/")
@Produces({"application/json", "application/hal+json"})
public class ServiceFeatureResource {

    @Logging
    Logger logger;

    @Inject
    @Jpa
    private Repository<ServiceFeature, String> serviceFeatureRepository;

    @Inject
    private Assembler<ServiceFeature, ServiceFeatureRepresentation> assembler;

    @Inject
    private RelRegistry relRegistry;

    @Inject
    private FluentAssembler fluentAssembler;

    @Inject
    private UserLogService userLogService;

    @Inject
    private ServiceFeatureUpstreamService serviceFeatureUpstreamService;

    @Inject
    private ServiceFeaturePaginatorService serviceFeaturePaginatorService;

    private static final String SERVICE_FEATURE_CODE = "code";
    private static final String SERVICE_FEATURE_CODE_PATH = SERVICE_FEATURE + "/{" + SERVICE_FEATURE_CODE + "}";


    @GET
    @JpaUnit("rcz")
    @Transactional()
    @Path(SERVICE_FEATURES)
    @Rel(value = SERVICE_FEATURES, home = true)
    @RequiresRoles(logical = Logical.OR, value = {"role_super_administrator", "role_administrator", "role_reader"})
    public Response search(@BeanParam ServiceFeatureSort sort, @BeanParam ServiceFeatureCriteria criteria, @BeanParam HalPageCriteria pageCriteria) {

        try {
            serviceFeatureUpstreamService.update();
        } catch (WebExeption e) {
            logger.error(e.getMessage(), e);
        }

        Page<ServiceFeature> page = this.serviceFeaturePaginatorService.search(sort, criteria, pageCriteria);

        List<ServiceFeatureRepresentation> result = page.getItems().stream().map(serviceFeature -> assembler.createDtoFromAggregate(serviceFeature)).collect(Collectors.toList());

        Link self = relRegistry.uri(SERVICE_FEATURES);
        addParameters(self, criteria, sort);
        HalPageRepresentation<ServiceFeatureRepresentation> serviceFeatures = new HalPageRepresentation<>("serviceFeatures", self, result, pageCriteria.getPageNumber(), pageCriteria.getPageSize(), page.getTotalSize());
        return Response.ok(serviceFeatures).build();
    }

    private void addParameters(Link self, ServiceFeatureCriteria criteria, ServiceFeatureSort sort) {
        if (criteria.getCode() != null) {
            self.set(CODE, criteria.getCode());
        }
        if (criteria.getLabel() != null) {
            self.set(LABEL, criteria.getLabel());
        }
        if (criteria.getShortLabel() != null) {
            self.set(SHORT_LABEL, criteria.getShortLabel());
        }
        if (criteria.getDeleted() != null) {
            self.set(DELETED, criteria.getDeleted());
        }
        if (criteria.getSuspended() != null) {
            self.set(SUSPENDED, criteria.getSuspended());
        }

        self.set(ORDER, sort.getOrder().name());
        self.set(SORT, sort.getSort().name());
    }

    @GET
    @Path(SERVICE_FEATURE_CODE_PATH)
    @JpaUnit("rcz")
    @Rel(value = SERVICE_FEATURE)
    @Transactional
    @RequiresRoles(logical = Logical.OR, value = {"role_super_administrator", "role_administrator", "role_reader"})
    public Response getElementaryService(@PathParam(SERVICE_FEATURE_CODE) @NotNull String code) {
        try {
            ServiceFeatureRepresentation serviceFeatureRepresentation = fluentAssembler.assemble(serviceFeatureRepository.get(code).orElse(null)).to(ServiceFeatureRepresentation.class);
            return Response.ok(serviceFeatureRepresentation).build();
        } catch (EntityNotFoundException e) {
            return Response.status(Response.Status.NOT_FOUND).build();
        }
    }

    @JpaUnit("rcz")
    @Transactional
    @PUT
    @Path(SERVICE_FEATURE_CODE_PATH)
    @Rel(value = SERVICE_FEATURE)
    @Consumes(MediaType.APPLICATION_JSON)
    @RequiresRoles(logical = Logical.OR, value = {"role_super_administrator"})
    public Response updateActions(ServiceFeatureRepresentation serviceFeatureRepresentation, @PathParam(SERVICE_FEATURE_CODE) @NotNull String code) {
        if (!serviceFeatureRepresentation.getCode().contentEquals(code)) {
            return Response.status(Response.Status.BAD_REQUEST).type(MediaType.TEXT_PLAIN_TYPE).entity("ElementaryService code cannot be updated").build();
        }
        try {
            userLogService.addEntry(ResourceType.SERVICE_FEATURE_UPDATE_ACTION, "Actions from ElementaryService code " + serviceFeatureRepresentation.getCode() + " has been modified");
            Optional<ServiceFeature> serviceFeature = serviceFeatureRepository.get(serviceFeatureRepresentation.getCode());
            if (serviceFeature.isPresent()) {
                assembler.mergeDtoIntoAggregate(serviceFeatureRepresentation, serviceFeature.get());
                serviceFeatureRepository.update(serviceFeature.get());
                return Response.ok().build();
            }
            return Response.status(Response.Status.NOT_FOUND).build();
        } catch (EntityNotFoundException | AggregateNotFoundException e) {
            return Response.status(Response.Status.NOT_FOUND).build();
        }
    }

    @DELETE
    @Path(SERVICE_FEATURE_CODE_PATH)
    @Rel(value = SERVICE_FEATURE)
    @JpaUnit("rcz")
    @Transactional
    @RequiresRoles(logical = Logical.OR, value = {"role_super_administrator"})
    public Response delete(@PathParam(SERVICE_FEATURE_CODE) @NotNull String code) {

        try {
            userLogService.addEntry(ResourceType.SERVICE_FEATURE_DELETE, "ElementaryService with code " + code + " has been deleted");
            serviceFeatureRepository.remove(code);
        } catch (EntityNotFoundException e) {
            logger.error(e.getMessage(), e);
            return Response.status(Response.Status.NOT_FOUND).type(MediaType.TEXT_PLAIN_TYPE).entity(e.getMessage()).build();
        }
        return Response.status(Response.Status.ACCEPTED).build();
    }
}
