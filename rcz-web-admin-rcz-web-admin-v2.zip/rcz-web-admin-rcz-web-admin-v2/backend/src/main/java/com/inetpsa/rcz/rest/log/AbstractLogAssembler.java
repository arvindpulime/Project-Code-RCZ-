package com.inetpsa.rcz.rest.log;

import com.inetpsa.rcz.domain.model.log.Log;
import com.inetpsa.rcz.rest.shared.Rels;
import org.seedstack.business.assembler.BaseAssembler;
import org.seedstack.seed.rest.RelRegistry;
import org.seedstack.seed.rest.hal.HalRepresentation;

import javax.inject.Inject;

import static com.inetpsa.rcz.rest.log.detail.LogResource.LOG_ID;

/**
 * @author tuan.docao@ext.mpsa.com
 */
public abstract class AbstractLogAssembler<T extends HalRepresentation> extends BaseAssembler<Log, T> {

    @Inject
    protected RelRegistry relRegistry;

    @Override
    public void mergeDtoIntoAggregate(T sourceDto, Log targetAggregate) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void mergeAggregateIntoDto(Log sourceAggregate, T targetDto) {
        doAssemble(targetDto, sourceAggregate);
        String id = sourceAggregate.getId();
        targetDto.self(relRegistry
                .uri(Rels.LOG)
                .set(LOG_ID, id));
    }


    protected abstract void doAssemble(T t, Log log);

}
