package com.inetpsa.rcz.rest.shared;

public final class Rels {

    /* Elementary Services */
    public static final String SERVICE_FEATURES = "servicefeatures";
    public static final String SERVICE_FEATURE = "servicefeature";

    /* Logs */
    public static final String LOGS = "logs";
    public static final String LOGS_LEVELS = "logs-levels";
    public static final String LOGS_INSTANCES = "logs-instances";
    public static final String LOG = "log";

    /* UserLogs */
    public static final String USER_LOGS = "userlogs";
    public static final String USER_RESOURCES = USER_LOGS + "/resources";

    /* Exchanges */
    public static final String EXCHANGES = "exchanges";
    public static final String EXCHANGES_ENUMS = EXCHANGES + "/enums";
    public static final String EXCHANGES_ALERT = EXCHANGES + "/alert";

    /* MQTT */
    public static final String MQTT = "mqtt";

    /* App Info */
    public static final String APP_INFO = "/app/info";

    /* Sms */
    public static final String SMS = "sms";

    /* Requests */
    public static final String REQUESTS = "requests";
    public static final String REQUEST_ID = "requests/{id}";
    public static final String REQUEST_ENUMS = REQUESTS + "/enums";

    /* Vehicles */
    public static final String PATH_VEHICLES = "vehicles";

    public static final String REL_VEHICLES = "vehicles";

    /* Parameter */
    public static final String PATH_PARAMETER = "/parameter";

    /* Action */
    public static final String PATH_GET_ALL_ACTION = "/actions";

}
