package com.inetpsa.rcz.rest.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import javax.ws.rs.QueryParam;


@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RequestCriteria {

    public static final String COL_ID = "id";
    public static final String COL_CALLER_ID = "callerId";
    public static final String COL_CUSTOMER_ID = "customerId";
    public static final String COL_VIN = "vin";
    public static final String COL_ACTION_SERVICE = "action.actionService";
    public static final String COL_ACTION_TYPE = "action.actionType";
    public static final String COL_CALLER_TYPE = "callerType";
    public static final String COL_STATUS = "status";

    public static final String PARAM_ID = "id";
    public static final String PARAM_CUSTOMER_ID = "customerId";
    public static final String PARAM_CALLER_ID = "callerId";
    public static final String PARAM_VIN = "vin";
    public static final String PARAM_CALLER_TYPES = "callerTypes";
    public static final String PARAM_ACTION_SERVICES = "actionServices";
    public static final String PARAM_ACTION_TYPES = "actionTypes";
    public static final String PARAM_STATUSES = "requestStatuses";

    @QueryParam(PARAM_ID)
    private String id;

    @QueryParam(PARAM_CALLER_ID)
    private String callerId;

    @QueryParam(PARAM_CUSTOMER_ID)
    private String customerId;

    @QueryParam(PARAM_VIN)
    private String vin;

    @QueryParam(PARAM_CALLER_TYPES)
    private String callerTypes;

    @QueryParam(PARAM_ACTION_SERVICES)
    private String actionServices;

    @QueryParam(PARAM_ACTION_TYPES)
    private String actionTypes;

    @QueryParam(PARAM_STATUSES)
    private String requestStatuses;


}
