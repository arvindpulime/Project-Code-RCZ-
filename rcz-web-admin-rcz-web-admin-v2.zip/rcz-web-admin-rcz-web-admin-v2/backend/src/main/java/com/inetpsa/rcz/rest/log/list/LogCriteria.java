package com.inetpsa.rcz.rest.log.list;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.inetpsa.rcz.domain.model.enums.LogLevel;
import lombok.Data;

import javax.ws.rs.QueryParam;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LogCriteria {

    public static final String COL_ID = "id";
    public static final String COL_INSTANCE_ID = "instanceId";
    public static final String COL_LOG_LEVEL = "logLevel";
    public static final String COL_LOG_DATE = "logDate";
    public static final String COL_MESSAGE = "message.message";
    public static final String COL_DATA = "message.data";
    public static final String COL_TOPIC = "message.topic";
    public static final String COL_EXCHANGE_ID = "exchangeId";
    public static final String COL_LOG_DATE_FROM = "logDateFrom";
    public static final String COL_LOG_DATE_TO = "logDateTo";

    public static final String PARAM_ID = "id";
    public static final String PARAM_INSTANCES = "instances";
    public static final String PARAM_LOG_LEVEL = "logLevel";
    public static final String PARAM_LOG_LEVELS = "logLevels";
    public static final String PARAM_LOG_DATE = "logDate";
    public static final String PARAM_MESSAGE = "message";
    public static final String PARAM_DATA = "data";
    public static final String PARAM_TOPIC = "topic";
    public static final String PARAM_EXCHANGE = "exchange";
    public static final String PARAM_LOG_DATE_FROM = "logDateFrom";
    public static final String PARAM_LOG_DATE_TO = "logDateTo";

    @QueryParam(PARAM_ID)
    private String id;

    @QueryParam(PARAM_INSTANCES)
    private String instanceId;

    @QueryParam(PARAM_LOG_LEVEL)
    private LogLevel logLevel;

    @QueryParam(PARAM_LOG_LEVELS)
    private String logLevels;

    @QueryParam(PARAM_LOG_DATE)
    private String logDate;

    @QueryParam(PARAM_LOG_DATE_FROM)
    private Long logDateFrom;

    @QueryParam(PARAM_LOG_DATE_TO)
    private Long logDateTo;

    @QueryParam(PARAM_MESSAGE)
    private String message;

    @QueryParam(PARAM_DATA)
    private String data;

    @QueryParam(PARAM_TOPIC)
    private String topic;

    @QueryParam(PARAM_EXCHANGE)
    private String exchangeId;

}
