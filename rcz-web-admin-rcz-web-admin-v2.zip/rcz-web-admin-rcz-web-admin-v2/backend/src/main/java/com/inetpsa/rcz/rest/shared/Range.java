package com.inetpsa.rcz.rest.shared;

/**
 * This class represents a Range: an offset and a size.
 */
public final class Range {

    private long offset;
    private long size;

    /**
     * Constructor.
     *
     * @param offset the range offset
     * @param size   the range size
     */
    public Range(long offset, long size) {
        this.offset = offset;
        this.size = size;
    }

    /**
     * The range from the chunk info.
     *
     * @param chunkOffset the chunk offset
     * @param chunkSize   the chunk size
     * @return the range
     */
    public static Range rangeFromChunkInfo(long chunkOffset, long chunkSize) {
        return new Range(chunkOffset, chunkSize);
    }

    /**
     * The range from the page info.
     *
     * @param pageIndex the page index
     * @param pageSize  the page size
     * @return the range
     */
    public static Range rangeFromPageInfo(long pageIndex, long pageSize) {
        return new Range(pageIndex * pageSize, pageSize);
    }

    /**
     * Returns the offset.
     *
     * @return the range offset
     */
    public long getOffset() {
        return offset;
    }

    /**
     * Returns the size.
     *
     * @return the range size
     */
    public long getSize() {
        return size;
    }

    @Override
    public String toString() {
        return String.format("Range [offset=%s, size=%s]", offset, size);
    }

}
