package com.inetpsa.rcz.rest.shared;

import org.seedstack.coffig.Config;

@Config("rcz.api")
public class ApiConfiguration {

    @Config("security.user")
    private String user;

    @Config("security.password")
    private String password;

    @Config("path.parameters.refresh")
    private String parametersRefreshPath;

    @Config("path.app.info")
    private String appInfoPath;

    @Config("path.app.db")
    private String appDatabaseInfoPath;

    @Config("path.app.health")
    private String appHealthPath;

    public String getUser() {
        return user;
    }

    public String getPassword() {
        return password;
    }

    public String getParametersRefreshPath() {
        return parametersRefreshPath;
    }

    public String getAppInfoPath() {
        return appInfoPath;
    }

    public String getAppDatabaseInfoPath() {
        return appDatabaseInfoPath;
    }

    public String getAppHealthPath() {
        return appHealthPath;
    }
}
