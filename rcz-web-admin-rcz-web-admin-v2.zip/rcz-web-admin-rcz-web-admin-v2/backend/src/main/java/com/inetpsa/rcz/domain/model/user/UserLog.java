package com.inetpsa.rcz.domain.model.user;

import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;
import org.seedstack.business.util.SequenceGenerator;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "RCZQTUSERLOG")
public class UserLog extends BaseAggregateRoot<Long> {

    @Id
    @Identity(generator = SequenceGenerator.class)
    private Long id;

    private String userId;

    private String email;

    private Date entryDate;

    @Enumerated(EnumType.STRING)
    @Column(name = "resourceType")
    private ResourceType resource;

    @Column(length = 4000)
    private String log;

    UserLog() {
    }

    UserLog(String userId, String email, Date entryDate, ResourceType resource, String log) {
        this.userId = userId;
        this.email = email;
        this.entryDate = entryDate;
        this.resource = resource;
        this.log = log;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Date getEntryDate() {
        return entryDate;
    }

    public void setEntryDate(Date entryDate) {
        this.entryDate = entryDate;
    }

    public ResourceType getResource() {
        return resource;
    }

    public void setResource(ResourceType resource) {
        this.resource = resource;
    }

    public String getLog() {
        return log;
    }

    public void setLog(String log) {
        this.log = log;
    }
}
