package com.inetpsa.rcz.rest.log.list;

import com.inetpsa.rcz.domain.model.log.Log;
import com.inetpsa.rcz.domain.model.log.LogMessage;
import com.inetpsa.rcz.rest.log.AbstractLogAssembler;

/**
 * @author tuan.docao@ext.mpsa.com
 */
public class LogRepresentationAssembler extends AbstractLogAssembler<LogRepresentation> {

    @Override
    protected void doAssemble(LogRepresentation dto, Log agg) {
        dto.setId(agg.getId());
        if (agg.getLogLevel() != null) {
            dto.setLevel(agg.getLogLevel().name());
        }
        dto.setDate(agg.getLogDate());
        dto.setExchange(agg.getExchangeId());
        dto.setServerInstance(agg.getInstanceId());

        LogMessage message;
        if ((message = agg.getMessage()) != null) {
            dto.setMessage(message.getMessage());
            dto.setTopic(message.getTopic());
        }
    }
}
