package com.inetpsa.rcz.rest.exchange;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.inetpsa.rcz.domain.model.action.ActionService;
import com.inetpsa.rcz.domain.model.action.ActionType;
import com.inetpsa.rcz.domain.model.enums.CallerType;
import com.inetpsa.rcz.domain.model.enums.ExchangeStatus;
import com.inetpsa.rcz.domain.model.enums.ProcessStatus;
import com.inetpsa.rcz.domain.model.enums.ResponseStatus;
import lombok.Data;

import javax.ws.rs.QueryParam;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ExchangeCriteria {

    public static final String ID = "id";
    public static final String ACTION_SERVICE = "action.actionService";
    public static final String ACTION_SERVICES = "actionServices";
    public static final String ACTION_TYPES = "actionTypes";
    public static final String ACTION_TYPE = "action.actionType";
    public static final String STATUS = "status";
    public static final String STATUSES = "statuses";
    public static final String UIN = "uin";
    public static final String CALLER_ID = "callerId";
    public static final String CALLER_TYPE = "callerType";
    public static final String CALLER_TYPES = "callerTypes";
    public static final String CORRELATION_ID = "correlationId";
    public static final String VIN = "vin";
    public static final String PROCESS_STATUS = "processStatus";
    public static final String PROCESS_STATUSES = "processStatuses";
    public static final String RESPONSE_STATUS = "responseStatus";
    public static final String RESPONSE_STATUSES = "responseStatuses";
    public static final String RECEIVED_DATE_FROM = "receivedDateFrom";
    public static final String RECEIVED_DATE_TO = "receivedDateTo";
    public static final String SENT_DATE_FROM = "sentDateFrom";
    public static final String SENT_DATE_TO = "sentDateTo";
    public static final String RECEIVED_DATE = "request.receivedDate";
    public static final String SENT_DATE = "request.sentDate";


    @QueryParam(ID)
    private String id;

    @QueryParam(ACTION_SERVICE)
    private ActionService actionService;


    @QueryParam(ACTION_SERVICES)
    private String actionServices;

    @QueryParam(ACTION_TYPE)
    private ActionType actionType;

    @QueryParam(ACTION_TYPES)
    private String actionTypes;

    @QueryParam(STATUS)
    private ExchangeStatus status;

    @QueryParam(STATUSES)
    private String statuses;

    @QueryParam(UIN)
    private String uin;

    @QueryParam(CALLER_ID)
    private String callerId;

    @QueryParam(CALLER_TYPE)
    private CallerType callerType;

    @QueryParam(CALLER_TYPES)
    private String callerTypes;

    @QueryParam(CORRELATION_ID)
    private String correlationId;

    @QueryParam(VIN)
    private String vin;

    @QueryParam(PROCESS_STATUS)
    private ProcessStatus processStatus;

    @QueryParam(PROCESS_STATUSES)
    private String processStatuses;

    @QueryParam(RESPONSE_STATUS)
    private ResponseStatus responseStatus;

    @QueryParam(RESPONSE_STATUSES)
    private String responseStatuses;

    @QueryParam(RECEIVED_DATE_FROM)
    private Long receivedDateFrom;

    @QueryParam(RECEIVED_DATE_TO)
    private Long receivedDateTo;

    @QueryParam(SENT_DATE_FROM)
    private Long sentDateFrom;

    @QueryParam(SENT_DATE_TO)
    private Long sentDateTo;

}
