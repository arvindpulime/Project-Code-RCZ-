package com.inetpsa.rcz.rest.exchange;

import com.google.common.collect.Lists;
import com.inetpsa.rcz.domain.model.action.ActionService;
import com.inetpsa.rcz.domain.model.action.ActionType;
import com.inetpsa.rcz.domain.model.enums.CallerType;
import com.inetpsa.rcz.domain.model.enums.ExchangeStatus;
import com.inetpsa.rcz.domain.model.enums.ProcessStatus;
import com.inetpsa.rcz.domain.model.enums.ResponseStatus;
import com.inetpsa.rcz.domain.model.exchange.ExchangeLight;
import com.inetpsa.rcz.domain.model.service.exchange.ExchangePaginatorService;
import com.inetpsa.rcz.rest.shared.hal.HalPageCriteria;
import com.inetpsa.rcz.rest.shared.hal.HalPageRepresentation;
import org.seedstack.business.assembler.Assembler;
import org.seedstack.business.modelmapper.ModelMapper;
import org.seedstack.business.pagination.Page;
import org.seedstack.seed.rest.Rel;
import org.seedstack.seed.rest.RelRegistry;
import org.seedstack.seed.rest.hal.HalRepresentation;
import org.seedstack.seed.rest.hal.Link;
import org.seedstack.seed.security.Logical;
import org.seedstack.seed.security.RequiresRoles;

import javax.inject.Inject;
import javax.ws.rs.BeanParam;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;
import java.util.List;
import java.util.stream.Collectors;

import static com.inetpsa.rcz.rest.exchange.ExchangeCriteria.ACTION_SERVICE;
import static com.inetpsa.rcz.rest.exchange.ExchangeCriteria.ACTION_TYPE;
import static com.inetpsa.rcz.rest.exchange.ExchangeCriteria.CALLER_ID;
import static com.inetpsa.rcz.rest.exchange.ExchangeCriteria.CALLER_TYPE;
import static com.inetpsa.rcz.rest.exchange.ExchangeCriteria.CORRELATION_ID;
import static com.inetpsa.rcz.rest.exchange.ExchangeCriteria.ID;
import static com.inetpsa.rcz.rest.exchange.ExchangeCriteria.PROCESS_STATUS;
import static com.inetpsa.rcz.rest.exchange.ExchangeCriteria.RECEIVED_DATE_FROM;
import static com.inetpsa.rcz.rest.exchange.ExchangeCriteria.RECEIVED_DATE_TO;
import static com.inetpsa.rcz.rest.exchange.ExchangeCriteria.SENT_DATE_FROM;
import static com.inetpsa.rcz.rest.exchange.ExchangeCriteria.SENT_DATE_TO;
import static com.inetpsa.rcz.rest.exchange.ExchangeCriteria.RESPONSE_STATUS;
import static com.inetpsa.rcz.rest.exchange.ExchangeCriteria.STATUS;
import static com.inetpsa.rcz.rest.exchange.ExchangeCriteria.UIN;
import static com.inetpsa.rcz.rest.exchange.ExchangeCriteria.VIN;
import static com.inetpsa.rcz.rest.exchange.ExchangeSort.ORDER;
import static com.inetpsa.rcz.rest.exchange.ExchangeSort.SORT;
import static com.inetpsa.rcz.rest.shared.Rels.EXCHANGES;
import static com.inetpsa.rcz.rest.shared.Rels.EXCHANGES_ALERT;
import static com.inetpsa.rcz.rest.shared.Rels.EXCHANGES_ENUMS;

@Path("/")
@Produces({"application/json", "application/hal+json"})
public class ExchangesResource {

    public static final String ALERTS = "alerts";

    @Inject
    private RelRegistry relRegistry;

    @Inject
    private ExchangePaginatorService exchangePaginatorService;

    @Inject
    @ModelMapper
    private Assembler<ExchangeLight, ExchangeRepresentation> assembler;

    @GET
    @Path(EXCHANGES)
    @Rel(value = EXCHANGES, home = true)
    @RequiresRoles(logical = Logical.OR, value = {"role_super_administrator", "role_administrator", "role_reader"})
    public Response search(@BeanParam ExchangeSort sort, @BeanParam ExchangeCriteria criteria, @BeanParam HalPageCriteria pageCriteria) {

        Page<ExchangeLight> page = this.exchangePaginatorService.search(sort, criteria, pageCriteria);

        List<ExchangeRepresentation> result = page.getItems().stream().map(exchange -> {
            ExchangeRepresentation representation = new ExchangeRepresentation();
            assembler.mergeAggregateIntoDto(exchange, representation);
            return representation;
        }).collect(Collectors.toList());

        Link self = relRegistry.uri(EXCHANGES);
        addParameters(self, criteria, sort);
        HalPageRepresentation<ExchangeRepresentation> exchanges = new HalPageRepresentation<>("exchanges", self, result, pageCriteria.getPageNumber(), pageCriteria.getPageSize(), page.getTotalSize());
        return Response.ok(exchanges).build();
    }

    private void addParameters(Link self, ExchangeCriteria criteria, ExchangeSort sort) {
        if (criteria.getId() != null) {
            self.set(ID, criteria.getId());
        }
        if (criteria.getActionType() != null) {
            self.set(ACTION_TYPE, criteria.getActionType());
        }
        if (criteria.getActionService() != null) {
            self.set(ACTION_SERVICE, criteria.getActionService());
        }
        if (criteria.getStatus() != null) {
            self.set(STATUS, criteria.getStatus());
        }
        if (criteria.getUin() != null) {
            self.set(UIN, criteria.getUin());
        }
        if (criteria.getCallerId() != null) {
            self.set(CALLER_ID, criteria.getCallerId());
        }
        if (criteria.getCallerType() != null) {
            self.set(CALLER_TYPE, criteria.getCallerType());
        }
        if (criteria.getCorrelationId() != null) {
            self.set(CORRELATION_ID, criteria.getCorrelationId());
        }
        if (criteria.getVin() != null) {
            self.set(VIN, criteria.getVin());
        }
        if (criteria.getProcessStatus() != null) {
            self.set(PROCESS_STATUS, criteria.getProcessStatus());
        }
        if (criteria.getResponseStatus() != null) {
            self.set(RESPONSE_STATUS, criteria.getResponseStatus());
        }
        if (criteria.getReceivedDateFrom() != null) {
            self.set(RECEIVED_DATE_FROM, criteria.getReceivedDateFrom());
        }
        if (criteria.getReceivedDateTo() != null) {
            self.set(RECEIVED_DATE_TO, criteria.getReceivedDateTo());
        }
		if (criteria.getSentDateFrom() != null) {
            self.set(SENT_DATE_FROM, criteria.getSentDateFrom());
        }
        if (criteria.getSentDateTo() != null) {
            self.set(SENT_DATE_TO, criteria.getSentDateTo());
        }
        self.set(ORDER, sort.getOrder().name());
        self.set(SORT, sort.getSort().name());
    }

    @GET
    @Path(EXCHANGES_ENUMS)
    @Rel(value = EXCHANGES_ENUMS, home = true)
    @RequiresRoles(logical = Logical.OR, value = {"role_super_administrator", "role_administrator", "role_reader"})
    public Response resources() {
        return Response.ok(new ExchangesResource.ExchangeEnums()).build();
    }

    @GET
    @Path(EXCHANGES_ALERT)
    @Rel(value = EXCHANGES_ALERT, home = true)
    @RequiresRoles(logical = Logical.OR, value = {"role_super_administrator", "role_administrator", "role_reader"})
    public Response alerts(@BeanParam ExchangeCriteria exchangeCriteria) {
        HalRepresentation halRepresentation = new HalRepresentation();
        halRepresentation.embedded(ALERTS, new Alert(exchangePaginatorService.count(exchangeCriteria)));
        return Response.ok(halRepresentation).build();
    }

    public class ExchangeEnums {
        List<ActionService> actionServices;
        List<ActionType> actionTypes;
        List<ExchangeStatus> exchangeStatuses;
        List<ResponseStatus> responseStatuses;
        List<ProcessStatus> processStatuses;
        List<CallerType> callerTypes;

        public ExchangeEnums() {
            this.actionServices = Lists.newArrayList(ActionService.values());
            this.actionTypes = Lists.newArrayList(ActionType.values());
            this.exchangeStatuses = Lists.newArrayList(ExchangeStatus.values());
            this.responseStatuses = Lists.newArrayList(ResponseStatus.values());
            this.processStatuses = Lists.newArrayList(ProcessStatus.values());
            this.callerTypes = Lists.newArrayList(CallerType.values());
        }

        public List<ActionService> getActionServices() {
            return actionServices;
        }

        public List<ActionType> getActionTypes() {
            return actionTypes;
        }

        public List<ExchangeStatus> getExchangeStatuses() {
            return exchangeStatuses;
        }

        public List<ResponseStatus> getResponseStatuses() {
            return responseStatuses;
        }

        public List<ProcessStatus> getProcessStatuses() {
            return processStatuses;
        }

        public List<CallerType> getCallerTypes() {
            return callerTypes;
        }
    }

    public class Alert {
        long nbAlert;

        public Alert(long nbAlert) {
            this.nbAlert = nbAlert;
        }

        public long getNbAlert() {
            return nbAlert;
        }
    }

}
