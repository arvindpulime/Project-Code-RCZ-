package com.inetpsa.rcz.rest.shared.hal;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;

import javax.validation.constraints.Min;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.QueryParam;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class HalPageCriteria {

    public static final String PAGE = "pageNumber";
    public static final String SIZE = "pageSize";
    private static final String DEFAULT_PAGE = "1";
    private static final String DEFAULT_SIZE = "10";

    @Min(0)
    @QueryParam(PAGE)
    @DefaultValue(DEFAULT_PAGE)
    @Getter
    private long pageNumber;

    @Min(1)
    @QueryParam(SIZE)
    @DefaultValue(DEFAULT_SIZE)
    @Getter
    private long pageSize;

    public HalPageCriteria() {
    }

    public HalPageCriteria(long pageNumber, long pageSize) {
        this.pageNumber = pageNumber;
        this.pageSize = pageSize;
    }
}
