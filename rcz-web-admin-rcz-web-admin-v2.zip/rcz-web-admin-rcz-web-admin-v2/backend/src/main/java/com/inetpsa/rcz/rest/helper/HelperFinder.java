package com.inetpsa.rcz.rest.helper;

import org.seedstack.business.Service;

import java.util.List;

@Service
public interface HelperFinder {
    List<HelperRepresentation> findAll();
}
