package com.inetpsa.rcz.rest.parameter.representation;

import com.inetpsa.rcz.domain.utils.Base64Utils;
import lombok.Data;
import lombok.experimental.Accessors;

import javax.persistence.Column;

@Data
@Accessors(chain = true)
public class OrangeParamRepresentation {

    private String host;
    private String path;
    private String username;
    private String password;
    private String senderAddress;
    private String headerHost;
    private Integer requestTimeout;
    private Integer connectionTimeout;
    private String headerVersion;
    private String ecuType;
    private String serviceType;
    private String objectType;
    private String objectVersion;
    private String objectId;
    private boolean messageBinary;

}