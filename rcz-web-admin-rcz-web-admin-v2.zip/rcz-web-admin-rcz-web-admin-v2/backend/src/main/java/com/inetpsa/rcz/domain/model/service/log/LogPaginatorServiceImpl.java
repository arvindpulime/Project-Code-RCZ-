package com.inetpsa.rcz.domain.model.service.log;

import com.inetpsa.rcz.domain.model.enums.LogLevel;
import com.inetpsa.rcz.domain.model.log.Log;
import com.inetpsa.rcz.domain.repository.LogRepository;
import com.inetpsa.rcz.rest.log.list.LogCriteria;
import com.inetpsa.rcz.rest.log.list.LogSort;
import com.inetpsa.rcz.rest.shared.hal.HalPageCriteria;
import org.apache.commons.lang3.EnumUtils;
import org.seedstack.business.pagination.Page;
import org.seedstack.business.pagination.dsl.Paginator;
import org.seedstack.business.specification.AndSpecification;
import org.seedstack.business.specification.OrSpecification;
import org.seedstack.business.specification.Specification;
import org.seedstack.business.specification.dsl.SpecificationBuilder;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static com.inetpsa.rcz.rest.log.list.LogCriteria.*;

@Transactional
@JpaUnit("rcz")
public class LogPaginatorServiceImpl implements LogPaginatorService {

    @Inject
    private Paginator paginator;

    @Inject
    private LogRepository logRepository;

    @Override
    public Page<Log> search(LogSort sort, LogCriteria criteria, HalPageCriteria halPageCriteria) {
        Specification<Log> specification = getSpecification(criteria);

        return paginator
                .paginate(logRepository)
                .withOptions(sort.getSortOption())
                .byPage(halPageCriteria.getPageNumber())
                .limit(halPageCriteria.getPageSize())
                .matching(specification)
                ;
    }


    private Specification<Log> getSpecification(LogCriteria criteria) {

        SpecificationBuilder specificationBuilder = logRepository.getSpecificationBuilder();

        List<Specification<Log>> specifications = new ArrayList<>();

        if (criteria.getLogDateTo() != null && criteria.getLogDateFrom() != null) {
            specifications.add(specificationBuilder.ofAggregate(Log.class).property(COL_LOG_DATE).greaterThanOrEqualTo(new Date(criteria.getLogDateFrom())).build());
            specifications.add(specificationBuilder.ofAggregate(Log.class).property(COL_LOG_DATE).lessThanOrEqualTo(new Date(criteria.getLogDateTo())).build());
        }

        if (criteria.getId() != null) {
            specifications.add(specificationBuilder.ofAggregate(Log.class).property(COL_ID).equalTo(criteria.getId()).build());
        }

        if (criteria.getInstanceId() != null) {
            specifications.add(buildMultiStringSpecification(specificationBuilder, criteria.getInstanceId(), COL_INSTANCE_ID));
        }

        if (criteria.getLogLevels() != null && !criteria.getLogLevels().isEmpty()) {
            specifications.add(buildEnumSpecification(specificationBuilder, criteria.getLogLevels(), COL_LOG_LEVEL, LogLevel.class));
        }


        if (criteria.getMessage() != null) {
            specifications.add(specificationBuilder.ofAggregate(Log.class).property(COL_MESSAGE).matching(criteria.getMessage()).trimming().ignoringCase().build());
        }

        if (criteria.getData() != null) {
            specifications.add(specificationBuilder.ofAggregate(Log.class).property(COL_DATA).matching(criteria.getData()).trimming().ignoringCase().build());
        }

        if (criteria.getTopic() != null) {
            specifications.add(specificationBuilder.ofAggregate(Log.class).property(COL_TOPIC).matching(criteria.getTopic()).trimming().ignoringCase().build());
        }

        if (criteria.getExchangeId() != null) {
            specifications.add(specificationBuilder.ofAggregate(Log.class).property(COL_EXCHANGE_ID).equalTo(criteria.getExchangeId()).build());
        }


        if (specifications.isEmpty()) {
            return logRepository.getSpecificationBuilder().of(Log.class).all().build();
        }

        return new AndSpecification<>(specifications.toArray(new Specification[0]));
    }

    private <E extends Enum<E>> Specification<Log> buildEnumSpecification(SpecificationBuilder specificationBuilder, String enums, String property, Class<E> clazz) {
        String[] values = enums.split(",");
        List<Specification<Log>> specifications = new ArrayList<>();
        for (String value : values) {
            specifications.add(specificationBuilder.ofAggregate(Log.class).property(property).equalTo(EnumUtils.getEnum(clazz, value)).build());

        }
        return new OrSpecification<>(specifications.toArray(new Specification[0]));
    }

    private Specification<Log> buildMultiStringSpecification(SpecificationBuilder specificationBuilder, String enums, String property) {
        String[] values = enums.split(",");
        List<Specification<Log>> specifications = new ArrayList<>();
        for (String value : values) {
            specifications.add(specificationBuilder.ofAggregate(Log.class).property(property).equalTo(value).build());

        }
        return new OrSpecification<>(specifications.toArray(new Specification[0]));
    }


}
