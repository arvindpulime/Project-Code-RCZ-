package com.inetpsa.rcz.rest.log.list;

import com.inetpsa.rcz.rest.shared.SortOrder;

/**
 * @author tuan.docao@ext.mpsa.com
 */
public class LogOrder {

    private SortType sortType;

    private SortOrder sortOrder;

    private LogOrder(SortType sortType, SortOrder sortOrder) {
        this.sortType = sortType;
        this.sortOrder = sortOrder;
    }

    public static LogOrder fromTypeAndDirection(final SortType sortType, final SortOrder sortOrder) {
        return new LogOrder(sortType, sortOrder);
    }

    public SortType getSortType() {
        return sortType;
    }

    public void setSortType(SortType sortType) {
        this.sortType = sortType;
    }

    public SortOrder getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(SortOrder sortOrder) {
        this.sortOrder = sortOrder;
    }
}
