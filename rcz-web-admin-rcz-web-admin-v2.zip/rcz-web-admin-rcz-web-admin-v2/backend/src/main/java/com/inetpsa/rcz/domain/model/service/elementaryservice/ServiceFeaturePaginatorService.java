package com.inetpsa.rcz.domain.model.service.elementaryservice;

import com.inetpsa.rcz.domain.model.service.ServiceFeature;
import com.inetpsa.rcz.rest.elementaryservice.ServiceFeatureCriteria;
import com.inetpsa.rcz.rest.elementaryservice.ServiceFeatureSort;
import com.inetpsa.rcz.rest.shared.hal.HalPageCriteria;
import org.seedstack.business.Service;
import org.seedstack.business.pagination.Page;

@Service
public interface ServiceFeaturePaginatorService {

    Page<ServiceFeature> search(ServiceFeatureSort sort, ServiceFeatureCriteria criteria, HalPageCriteria halPageCriteria);

}
