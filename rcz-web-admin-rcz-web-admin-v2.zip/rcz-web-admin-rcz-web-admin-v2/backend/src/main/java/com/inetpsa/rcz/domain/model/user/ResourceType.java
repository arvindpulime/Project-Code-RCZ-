package com.inetpsa.rcz.domain.model.user;

public enum ResourceType {

    SERVICE_FEATURE_UPDATE_ACTION,
    HELPER_UPDATE_ACTION,
    SERVICE_FEATURE_DELETE,
    PARAMETER_UPDATE
}