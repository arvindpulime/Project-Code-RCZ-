package com.inetpsa.rcz.domain.model.repository;

import com.inetpsa.rcz.domain.model.service.ServiceFeature;
import org.seedstack.business.domain.Repository;

public interface ServiceFeatureRepository extends Repository<ServiceFeature, String> {
}