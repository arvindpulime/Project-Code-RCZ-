package com.inetpsa.rcz.rest.parameter.representation;

import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;

@Data
@Accessors(chain = true)
public class SmsParamRepresentation implements Serializable {

    private Integer nbRetry;
    private Integer retryDelay;
    private Integer messageLength;
    private Integer dataLength;
    private Integer dspt;
    private Integer messageId;
    private Integer messageVersion;
    private Integer messageType;
    private Integer serviceType;

    private ByTelParamRepresentation byTel = new ByTelParamRepresentation();

    private OrangeParamRepresentation orange = new OrangeParamRepresentation();
}
