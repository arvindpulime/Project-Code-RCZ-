package com.inetpsa.rcz.rest.helper;

import com.inetpsa.rcz.application.services.UserLogService;
import com.inetpsa.rcz.domain.model.helper.Helper;
import com.inetpsa.rcz.domain.model.user.ResourceType;
import io.swagger.annotations.Api;
import org.seedstack.business.assembler.Assembler;
import org.seedstack.business.domain.Repository;
import org.seedstack.business.modelmapper.ModelMapper;
import org.seedstack.jpa.Jpa;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.security.Logical;
import org.seedstack.seed.security.RequiresRoles;
import org.seedstack.seed.transaction.Transactional;

import javax.inject.Inject;
import javax.persistence.EntityNotFoundException;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;
import java.util.Optional;

@Api
@Path("/helper")
@Produces({"application/json", "application/hal+json"})
public class HelperResource {

    @Inject
    private HelperFinder helperFinder;

    @Inject
    @ModelMapper
    private Assembler<Helper, HelperRepresentation> helperAssembler;

    @Inject
    @Jpa
    private Repository<Helper, Long> helperRepository;

    @Inject
    private UserLogService userLogService;

    @GET
    @RequiresRoles(logical = Logical.OR, value = {"role_super_administrator", "role_administrator", "role_reader"})
    public Response get() {
        List<HelperRepresentation> result = helperFinder.findAll();
        if (result != null && !result.isEmpty()) {
            return Response.ok(result.iterator().next()).build();
        }
        return Response.status(Response.Status.NOT_FOUND).build();
    }

    @PUT
    @JpaUnit("rcz")
    @Transactional
    @Consumes(MediaType.APPLICATION_JSON)
    @RequiresRoles(logical = Logical.OR, value = {"role_super_administrator", "role_administrator"})
    public Response updateActions(HelperRepresentation helperRepresentation) {
        try {
            userLogService.addEntry(ResourceType.HELPER_UPDATE_ACTION, "Helper with title \"" + helperRepresentation.getTitle() + "\" has been modified");
            Optional<Helper> helper = helperRepository.get(helperRepresentation.getId());
            helper.ifPresent(h -> {
                helperAssembler.mergeDtoIntoAggregate(helperRepresentation, h);
                helperRepository.update(h);
            });

            return Response.ok().build();
        } catch (EntityNotFoundException e) {
            return Response.status(Response.Status.NOT_FOUND).build();
        }
    }
}
