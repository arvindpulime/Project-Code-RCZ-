package com.inetpsa.rcz.domain.model.service.sms;

import com.inetpsa.rcz.domain.model.sms.Sms;
import com.inetpsa.rcz.rest.shared.hal.HalPageCriteria;
import com.inetpsa.rcz.rest.sms.SmsCriteria;
import com.inetpsa.rcz.rest.sms.SmsSort;
import org.seedstack.business.Service;
import org.seedstack.business.pagination.Page;

@Service
public interface SmsPaginatorService {

    Page<Sms> search(SmsSort sort, SmsCriteria criteria, HalPageCriteria halPageCriteria);

}
