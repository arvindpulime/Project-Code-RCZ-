package com.inetpsa.rcz.infrastructure.jpa;

import javax.persistence.criteria.Expression;
import javax.persistence.criteria.From;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Root;

public class JoinResolver {

    /**
     * resolve join on internal aggregates.
     *
     * @param from     : From clause for current aggregate
     * @param property is an attribute of the current aggregate.
     *                 This attribute can point on an entity of the current aggregate by using this form :
     *                 <ul><li> "entity.attribute"</li> <li>"entity.entity.attribute"</li></ul>.
     * @return Expression
     */
    public static <T> Expression<T> resolve(Root<?> from, String property) {
        Expression<T> path = null;

        String[] properties = property.split("\\.");
        if (properties != null) {
            if (properties.length > 1) {
                path = joinRecursively(properties,
                        searchOrCreatJoin(properties[0], from), 1).get(
                        properties[properties.length - 1]);
            } else {
                path = from.get(properties[0]);
            }
        }
        return path;
    }

    /**
     * searchOrCreatJoin
     *
     * @param property : property to be join
     * @param from     : Clause From let us keep track of all existing joins
     * @return Join
     */
    private static Join<?, ?> searchOrCreatJoin(String property, From<?, ?> from) {
        for (Join<?, ?> rootJoin : from.getJoins()) {
            if (rootJoin.getAttribute().getName().equals(property)) {
                return rootJoin;
            }
        }
        return from.join(property);
    }

    /**
     * joinRecursively
     *
     * @param properties String[]
     * @param join       current Join
     * @param index      : index of the current property to be join
     * @return Join
     */
    private static Join<?, ?> joinRecursively(String[] properties,
                                              Join<?, ?> join, int index) {
        while (index < properties.length - 1) {
            return joinRecursively(properties,
                    searchOrCreatJoin(properties[index], join), index + 1);
        }
        return join;
    }
}
