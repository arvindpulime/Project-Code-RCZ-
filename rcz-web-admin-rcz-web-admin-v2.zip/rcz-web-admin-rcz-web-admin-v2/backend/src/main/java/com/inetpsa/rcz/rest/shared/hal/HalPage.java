package com.inetpsa.rcz.rest.shared.hal;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public final class HalPage {
    private long number;
    private long size;
    private long totalPages;
    private long totalElements;

    public HalPage(long number, long size, long totalElements) {
        this.number = number;
        this.size = size;
        this.totalElements = totalElements;
        Double value = Math.ceil((float) totalElements / (float) size);
        this.totalPages = value.longValue();
    }

    public long getNumber() {
        return number;
    }

    public long getSize() {
        return size;
    }

    public long getTotalPages() {
        return totalPages;
    }

    public long getTotalElements() {
        return totalElements;
    }
}