package com.inetpsa.rcz.rest.elementaryservice;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.inetpsa.rcz.domain.model.service.ServiceFeature;
import com.inetpsa.rcz.rest.action.Actions;
import lombok.Data;
import org.seedstack.business.assembler.DtoOf;
import org.seedstack.seed.rest.hal.HalRepresentation;

import java.util.Date;

import static com.inetpsa.rcz.domain.model.payload.ValidationPattern.PATTERN_DATE_FRONT;

@Data
@DtoOf(ServiceFeature.class)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ServiceFeatureRepresentation extends HalRepresentation {

    private String code;

    private String shortLabel;

    private String label;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = PATTERN_DATE_FRONT)
    private Date startDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = PATTERN_DATE_FRONT)
    private Date endDate;

    private Boolean suspended;

    private Boolean deleted;

    private Actions actions = new Actions();
}
