package com.inetpsa.rcz.rest.elementaryservice;

import com.inetpsa.rcz.rest.shared.SortOrder;
import lombok.Data;
import org.seedstack.business.domain.SortOption;

import javax.ws.rs.DefaultValue;
import javax.ws.rs.QueryParam;

@Data
public class ServiceFeatureSort {

    public static final String SORT = "sort";
    public static final String ORDER = "order";

    @QueryParam(SORT)
    @DefaultValue("CODE")
    private ColumnSort sort;

    @QueryParam(ORDER)
    @DefaultValue("DESCENDING")
    private SortOrder order;

    public SortOption getSortOption() {
        return new SortOption().add(this.getSort().literal(), SortOption.Direction.valueOf(this.getOrder().name()));
    }

    public enum ColumnSort {

        CODE("code"),
        LABEL("label"),
        SHORT_LABEL("shortLabel"),
        START_DATE("startDate"),
        END_DATE("endDate"),
        SUSPENDED("suspended"),
        DELETED("deleted");

        private String literal;

        ColumnSort(String literal) {
            this.literal = literal;
        }

        public String literal() {
            return literal;
        }
    }

}
