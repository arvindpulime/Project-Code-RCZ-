package com.inetpsa.rcz.infrastructure.websocket.orange;

import org.seedstack.seed.web.websocket.BaseClientEndpointConfigurator;

import java.util.List;
import java.util.Map;

public class  OrangeAckConfigurator extends BaseClientEndpointConfigurator {


    @Override
    public void beforeRequest(Map<String, List<String>> headers) {
        super.beforeRequest(headers);
    }
}
