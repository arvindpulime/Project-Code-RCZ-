package com.inetpsa.rcz.rest.request;

import com.google.common.collect.Lists;
import com.inetpsa.rcz.domain.model.action.ActionService;
import com.inetpsa.rcz.domain.model.action.ActionType;
import com.inetpsa.rcz.domain.model.api.request.Request;
import com.inetpsa.rcz.domain.model.api.request.RequestLight;
import com.inetpsa.rcz.domain.model.api.request.RequestStatus;
import com.inetpsa.rcz.domain.model.enums.CallerType;
import com.inetpsa.rcz.domain.model.service.request.RequestService;
import com.inetpsa.rcz.rest.shared.hal.HalPageCriteria;
import com.inetpsa.rcz.rest.shared.hal.HalPageRepresentation;
import org.seedstack.business.assembler.Assembler;
import org.seedstack.business.modelmapper.ModelMapper;
import org.seedstack.business.pagination.Page;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.rest.Rel;
import org.seedstack.seed.rest.RelRegistry;
import org.seedstack.seed.rest.hal.Link;
import org.seedstack.seed.security.Logical;
import org.seedstack.seed.security.RequiresRoles;
import org.seedstack.seed.transaction.Transactional;

import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import java.util.List;
import java.util.stream.Collectors;

import static com.inetpsa.rcz.rest.request.RequestCriteria.*;
import static com.inetpsa.rcz.rest.shared.Rels.*;
import static com.inetpsa.rcz.rest.sms.SmsSort.ORDER;
import static com.inetpsa.rcz.rest.sms.SmsSort.SORT;
import static javax.ws.rs.core.Response.Status.NOT_FOUND;

@Path("/")
@Produces({"application/json", "application/hal+json"})
public class RequestResource {

    @Inject
    private RelRegistry relRegistry;

    @Inject
    private RequestService requestService;

    @Inject
    @ModelMapper
    private Assembler<RequestLight, RequestLightRepresentation> requestLightAssembler;

    @Inject
    @ModelMapper
    private Assembler<Request, RequestRepresentation> requestAssembler;

    @GET
    @Path(REQUEST_ID)
    @JpaUnit("rcz")
    @Transactional()
    @RequiresRoles(logical = Logical.OR, value = {"role_super_administrator", "role_administrator", "role_reader"})
    public Response get(@PathParam(value = "id") String id) {
        if (!requestService.getRequest(id).isPresent()) {
            return Response.status(NOT_FOUND).build();
        }
        return Response.ok(requestAssembler.createDtoFromAggregate(requestService.getRequest(id).get())).build();
    }

    @GET
    @Path(REQUESTS)
    @JpaUnit("rcz")
    @Transactional()
    @Rel(value = REQUESTS, home = true)
    @RequiresRoles(logical = Logical.OR, value = {"role_super_administrator", "role_administrator", "role_reader"})
    public Response list(@BeanParam RequestSort sort,
                         @BeanParam RequestCriteria criteria,
                         @BeanParam HalPageCriteria halPageCriteria) {

        Page<RequestLight> page = requestService.search(sort, criteria, halPageCriteria);

        List<RequestLightRepresentation> result = page.getItems().stream().map(request -> {
            RequestLightRepresentation representation = new RequestLightRepresentation();
            requestLightAssembler.mergeAggregateIntoDto(request, representation);
            return representation;
        }).collect(Collectors.toList());

        Link self = relRegistry.uri(EXCHANGES);
        addParameters(self, criteria, sort);
        HalPageRepresentation<RequestLightRepresentation> exchanges = new HalPageRepresentation<>("requests", self, result, halPageCriteria.getPageNumber(), halPageCriteria.getPageSize(), page.getTotalSize());
        return Response.ok(exchanges).build();
    }

    @GET
    @Path(REQUEST_ENUMS)
    @Rel(value = REQUEST_ENUMS, home = true)
    @RequiresRoles(logical = Logical.OR, value = {"role_super_administrator", "role_administrator", "role_reader"})
    public Response enums() {
        return Response.ok(new RequestResource.RequestEnums()).build();
    }

    private void addParameters(Link self, RequestCriteria criteria, RequestSort sort) {
        if (criteria.getId() != null) {
            self.set(PARAM_ID, criteria.getId());
        }
        if (criteria.getCallerId() != null) {
            self.set(PARAM_CALLER_ID, criteria.getCallerId());
        }
        if (criteria.getCustomerId() != null) {
            self.set(PARAM_CUSTOMER_ID, criteria.getCustomerId());
        }
        if (criteria.getVin() != null) {
            self.set(PARAM_VIN, criteria.getVin());
        }
        if (criteria.getActionServices() != null) {
            self.set(PARAM_ACTION_SERVICES, criteria.getActionServices());
        }
        if (criteria.getActionTypes() != null) {
            self.set(PARAM_ACTION_TYPES, criteria.getActionTypes());
        }
        if (criteria.getCallerTypes() != null) {
            self.set(PARAM_CALLER_TYPES, criteria.getCallerTypes());
        }
        if (criteria.getRequestStatuses() != null) {
            self.set(PARAM_STATUSES, criteria.getRequestStatuses());
        }
        self.set(ORDER, sort.getOrder().name());
        self.set(SORT, sort.getSort().name());
    }

    public class RequestEnums {
        List<ActionService> actionServices;
        List<ActionType> actionTypes;
        List<CallerType> callerTypes;
        List<RequestStatus> requestStatus;

        public RequestEnums() {
            this.actionServices = Lists.newArrayList(ActionService.values());
            this.actionTypes = Lists.newArrayList(ActionType.values());
            this.callerTypes = Lists.newArrayList(CallerType.values());
            this.requestStatus = Lists.newArrayList(RequestStatus.values());
        }

        public List<ActionService> getActionServices() {
            return actionServices;
        }

        public List<ActionType> getActionTypes() {
            return actionTypes;
        }

        public List<CallerType> getCallerTypes() {
            return callerTypes;
        }

        public List<RequestStatus> getRequestStatus() {
            return requestStatus;
        }
    }

}
