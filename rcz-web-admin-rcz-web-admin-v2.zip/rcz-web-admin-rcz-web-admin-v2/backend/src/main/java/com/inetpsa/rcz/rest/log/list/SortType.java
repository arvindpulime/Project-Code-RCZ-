package com.inetpsa.rcz.rest.log.list;

public enum SortType {
    ID, DATE, LEVEL, MESSAGE, EXCHANGE, TOPIC;

    public static SortType fromOrDefault(String sort) {
        if (sort != null && !sort.equals("")) {
            try {
                return SortType.valueOf(sort.toUpperCase());
            } catch (IllegalArgumentException e) {
                throw new IllegalArgumentException("The sort value can only be: ID, DATE, LEVEL, MESSAGE, EXCHANGE or TOPIC");
            }
        } else {
            return SortType.ID;
        }
    }
}