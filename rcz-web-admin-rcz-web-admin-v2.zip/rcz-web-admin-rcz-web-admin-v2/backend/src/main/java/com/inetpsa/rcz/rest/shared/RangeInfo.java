package com.inetpsa.rcz.rest.shared;

import javax.validation.constraints.Min;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.QueryParam;

public class RangeInfo {

    private static final String DEFAULT_OFFSET = "0";
    private static final String DEFAULT_SIZE = "12";
    public static final String OFFSET_NAME = "offset";
    public static final String SIZE_NAME = "size";

    @Min(0)
    @QueryParam(OFFSET_NAME)
    @DefaultValue(DEFAULT_OFFSET)
    private long offset;

    @Min(1)
    @QueryParam(SIZE_NAME)
    @DefaultValue(DEFAULT_SIZE)
    private long size;

    public RangeInfo() {
    }

    public RangeInfo(long offset, long size) {
        this.offset = offset;
        this.size = size;
    }

    public Range range() {
        return new Range(offset, size);
    }

    public long getOffset() {
        return offset;
    }

    public long getSize() {
        return size;
    }
}
