package com.inetpsa.rcz.rest.shared;

public class UriBuilder {

    private UriBuilder() {
    }

    /**
     * Constructs a URI. The final slash will always be removed.
     * <p>
     * No encoding or replacement will be done.
     * </p>
     * The paths can be null or empty, in this case they wont be added.
     *
     * @param paths the paths
     * @return the built path
     */
    public static String uri(final String... paths) {
        StringBuilder sb = new StringBuilder();
        boolean firstPath = true;
        for (String s : paths) {
            if (s == null || s.isEmpty()) {
                continue;
            }
            if (!s.startsWith("/") && !firstPath) {
                sb.append("/");
            }
            sb.append(stripLeadingSlash(s));
            firstPath = false;
        }
        return sb.toString();
    }

    /**
     * Removes the leading slash in the given path.
     *
     * @param path the path
     * @return the new path
     */
    public static String stripLeadingSlash(String path) {
        if (path.endsWith("/")) {
            return path.substring(0, path.length() - 1);
        } else {
            return path;
        }
    }
}