package com.inetpsa.rcz.rest.sms;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.inetpsa.rcz.domain.model.sms.Sms;
import lombok.Data;
import lombok.experimental.Accessors;
import org.seedstack.business.assembler.AggregateId;
import org.seedstack.business.assembler.DtoOf;

import java.util.Date;

import static com.fasterxml.jackson.annotation.JsonFormat.Shape.STRING;
import static com.inetpsa.rcz.domain.model.payload.ValidationPattern.PATTERN_DATE_FRONT;

@Data
@DtoOf(Sms.class)
@Accessors(chain = true)
public class SmsRepresentation {

    private String id;

    private String uin;

    private String icp;

    private String adm;

    private String version;

    private String idOffer;

    @JsonFormat(shape = STRING, pattern = PATTERN_DATE_FRONT)
    private Date sendingDate;

    private String to;

    private String answerStatus;

    private String ackCode;

    private String ackMessage;

    private String smsData;

    @JsonFormat(shape = STRING, pattern = PATTERN_DATE_FRONT)
    private Date ackDate;

    private String provider;

    public SmsRepresentation() {
    }

    @AggregateId
    public String getId() {
        return id;
    }

    public SmsRepresentation setId(String id) {
        this.id = id;
        return this;
    }

    public SmsRepresentation setTo(String to) {
        this.to = to;
        return this;
    }
}
