package com.inetpsa.rcz.rest.mqtt;

import com.inetpsa.rcz.domain.services.MonitoringService;
import org.seedstack.seed.rest.Rel;
import org.seedstack.seed.security.Logical;
import org.seedstack.seed.security.RequiresRoles;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import static com.inetpsa.rcz.rest.shared.Rels.MQTT;

@Path(MQTT)
@Produces({MediaType.APPLICATION_JSON, "application/hal+json"})
public class MqttMonitoringResource {

    @Inject
    private MonitoringService monitoringService;

    @GET
    @Rel(value = MQTT, home = true)
    @RequiresRoles(logical = Logical.OR, value = {"role_super_administrator", "role_administrator", "role_reader"})
    public Response getInstances() {
        return Response.ok(monitoringService.getAllMqttMonitoringData()).build();
    }

}
