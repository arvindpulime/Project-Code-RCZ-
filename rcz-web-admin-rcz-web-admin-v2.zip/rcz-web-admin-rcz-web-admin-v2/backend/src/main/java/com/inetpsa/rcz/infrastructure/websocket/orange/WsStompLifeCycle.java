package com.inetpsa.rcz.infrastructure.websocket.orange;

import com.inetpsa.rcz.application.shared.ClientConfig;
import com.inetpsa.rcz.infrastructure.websocket.stomp.client.WsStompConfig;
import io.undertow.websockets.jsr.DefaultWebSocketClientSslProvider;
import org.apache.commons.lang3.StringUtils;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.LifecycleListener;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;
import javax.websocket.ClientEndpointConfig;
import javax.websocket.ContainerProvider;
import javax.websocket.Session;
import javax.websocket.WebSocketContainer;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.security.KeyStore;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

public class WsStompLifeCycle implements LifecycleListener {
    @Logging
    private Logger logger;
    @Configuration
    private WsStompConfig wsStompConfig;
    @Inject
    private OrangeAck orangeAck;
    private Session session;

    private static final String ERROR_LOADING_KEY_STORE = "Error while loading keyStore [{0}]";

    @Override
    public void started() {
        if (wsStompConfig.isEnabled()) {
            try {
                connect();
            } catch (Exception e) {
                logger.error("ORANGE Websocket connection error", e);
                closeSession();
                reconnect();
            }
        }
    }

    private void closeSession() {
        if (session != null && session.isOpen()) {
            try {
                session.close();
            } catch (IOException e1) {
                logger.error("Error when attempting to close orange WebSocket Session", e1);
            }
        }
    }

    @Override
    public void stopping() {
        if (wsStompConfig.isEnabled()) {
            closeSession();
        }
    }


    private void reconnect() {
        final Timer timer = new Timer();
        TimerTask task = new TimerTask() {
            @Override
            public void run() {
                try {
                    connect();
                    timer.cancel();
                } catch (Exception e) {
                    logger.error("Can not connect to Orange ACK broker", e);
                }

            }
        };
        timer.scheduleAtFixedRate(
                task,
                wsStompConfig.getReconnectionInterval() * 1000,
                wsStompConfig.getReconnectionInterval() * 1000
        );
    }

    private void connect() throws Exception {
        WebSocketContainer container = ContainerProvider.getWebSocketContainer();
        this.session = container.connectToServer(orangeAck, new URI(wsStompConfig.getHost()));
    }

    public KeyStore loadKeyStore(ClientConfig.SSLConfig sslConfig) throws IOException {
        KeyStore store = null;
        try (InputStream is = WsStompLifeCycle.class.getClassLoader().getResourceAsStream(sslConfig.getTruststore().getFile())) {
            store = KeyStore.getInstance(KeyStore.getDefaultType());
            char[] password = sslConfig.getTruststore().getPassword().toCharArray();
            store.load(is, password);
        } catch (Exception e) {//NOSONAR
            logger.error(MessageFormat.format(ERROR_LOADING_KEY_STORE, sslConfig.getTruststore().getFile()), e);
            throw new IOException(MessageFormat.format(ERROR_LOADING_KEY_STORE, sslConfig.getTruststore().getFile()), e);
        }
        return store;
    }

    private ClientEndpointConfig createClientConfig() throws IOException {
        try {
            if (StringUtils.isBlank(wsStompConfig.getSslConfig().getTruststore().getFile())) {
                return null;
            }
            KeyStore ks = loadKeyStore(wsStompConfig.getSslConfig());
            KeyManagerFactory kmf = null;
            kmf = KeyManagerFactory.getInstance("SunX509");
            kmf.init(ks, wsStompConfig.getSslConfig().getTruststore().getPassword().toCharArray());
            TrustManagerFactory tmf = TrustManagerFactory.getInstance("SunX509");
            tmf.init(ks);
            SSLContext sslContext = null;
            sslContext = SSLContext.getInstance("TLS");
            sslContext.init(kmf.getKeyManagers(), tmf.getTrustManagers(), null);

            ClientEndpointConfig.Builder builder = ClientEndpointConfig.Builder.create();
            ClientEndpointConfig config = builder.decoders(new ArrayList<>()).encoders(new ArrayList<>())
                    .preferredSubprotocols(new ArrayList<>()).build();
            config.getUserProperties().put(DefaultWebSocketClientSslProvider.SSL_CONTEXT, sslContext);
            return config;
        } catch (Exception e) {
            throw new IOException(e.getMessage(), e);
        }
    }
}
