package com.inetpsa.rcz.domain.model.service.elementaryservice;


import com.inetpsa.rcz.domain.model.repository.ServiceFeatureRepository;
import com.inetpsa.rcz.domain.model.service.ServiceFeature;
import com.inetpsa.rcz.rest.elementaryservice.ServiceFeatureCriteria;
import com.inetpsa.rcz.rest.elementaryservice.ServiceFeatureSort;
import com.inetpsa.rcz.rest.shared.hal.HalPageCriteria;
import org.seedstack.business.pagination.Page;
import org.seedstack.business.pagination.dsl.Paginator;
import org.seedstack.business.specification.AndSpecification;
import org.seedstack.business.specification.Specification;
import org.seedstack.business.specification.dsl.SpecificationBuilder;
import org.seedstack.jpa.Jpa;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static com.inetpsa.rcz.rest.elementaryservice.ServiceFeatureCriteria.*;

public class ServiceFeaturePaginatorServiceImpl implements ServiceFeaturePaginatorService {

    @Inject
    private Paginator paginator;

    @Inject
    @Jpa
    private ServiceFeatureRepository serviceFeatureRepository;

    @Override
    public Page<ServiceFeature> search(ServiceFeatureSort sort, ServiceFeatureCriteria criteria, HalPageCriteria halPageCriteria) {
        Specification<ServiceFeature> specification = getSpecification(criteria);

        return paginator
                .paginate(serviceFeatureRepository)
                .withOptions(sort.getSortOption())
                .byPage(halPageCriteria.getPageNumber())
                .limit(halPageCriteria.getPageSize())
                .matching(specification)
                ;
    }


    private Specification<ServiceFeature> getSpecification(ServiceFeatureCriteria criteria) {

        SpecificationBuilder specificationBuilder = serviceFeatureRepository.getSpecificationBuilder();

        List<Specification<ServiceFeature>> specifications = new ArrayList<>();

        if (criteria.getCode() != null) {
            specifications.add(specificationBuilder.ofAggregate(ServiceFeature.class).property(CODE).matching(criteria.getCode()).trimming().ignoringCase().build());
        }
        if (criteria.getLabel() != null) {
            specifications.add(specificationBuilder.ofAggregate(ServiceFeature.class).property(LABEL).matching(criteria.getLabel()).trimming().ignoringCase().build());
        }
        if (criteria.getShortLabel() != null) {
            specifications.add(specificationBuilder.ofAggregate(ServiceFeature.class).property(SHORT_LABEL).matching(criteria.getShortLabel()).trimming().ignoringCase().build());
        }
        if (criteria.getDeleted() != null) {
            specifications.add(specificationBuilder.ofAggregate(ServiceFeature.class).property(DELETED).equalTo(criteria.getDeleted()).build());
        }
        if (criteria.getSuspended() != null) {
            specifications.add(specificationBuilder.ofAggregate(ServiceFeature.class).property(SUSPENDED).equalTo(criteria.getSuspended()).build());
        }
        if (criteria.getStartDateFrom() != null && criteria.getStartDateTo() != null) {
            specifications.add(specificationBuilder.ofAggregate(ServiceFeature.class)
                    .property(START_DATE).equalTo(new Date(criteria.getStartDateFrom()))
                    .or()
                    .property(START_DATE).greaterThan(new Date(criteria.getStartDateFrom())).build());
            specifications.add(specificationBuilder.ofAggregate(ServiceFeature.class)
                    .property(START_DATE).equalTo(new Date(criteria.getStartDateFrom()))
                    .or()
                    .property(START_DATE).lessThan(new Date(criteria.getStartDateFrom())).build());
        }
        if (criteria.getEndDateFrom() != null && criteria.getEndDateTo() != null) {
            specifications.add(specificationBuilder.ofAggregate(ServiceFeature.class)
                    .property(END_DATE).equalTo(new Date(criteria.getEndDateFrom()))
                    .or()
                    .property(END_DATE).greaterThan(new Date(criteria.getEndDateFrom())).build());
            specifications.add(specificationBuilder.ofAggregate(ServiceFeature.class)
                    .property(END_DATE).equalTo(new Date(criteria.getEndDateFrom()))
                    .or()
                    .property(END_DATE).lessThan(new Date(criteria.getEndDateFrom())).build());

        }
        if (specifications.isEmpty()) {
            return serviceFeatureRepository.getSpecificationBuilder().of(ServiceFeature.class).all().build();
        }

        return new AndSpecification<>(specifications.toArray(new Specification[0]));
    }

}
