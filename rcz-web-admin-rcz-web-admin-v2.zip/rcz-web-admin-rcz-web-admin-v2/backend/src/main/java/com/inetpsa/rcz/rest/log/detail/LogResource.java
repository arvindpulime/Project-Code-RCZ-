package com.inetpsa.rcz.rest.log.detail;

import com.inetpsa.rcz.domain.model.log.Log;
import com.inetpsa.rcz.rest.shared.Rels;
import io.swagger.annotations.Api;
import org.seedstack.business.assembler.dsl.FluentAssembler;
import org.seedstack.business.domain.Repository;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.rest.Rel;
import org.seedstack.seed.security.Logical;
import org.seedstack.seed.security.RequiresRoles;
import org.seedstack.seed.transaction.Transactional;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;
import java.util.Optional;

/**
 * @author tuan.docao@ext.mpsa.com
 */

@Api(tags = {"Log"})
@Path("/logs/{logId}")
@Produces({"application/json", "application/hal+json"})
@Rel(value = Rels.LOG)
@JpaUnit("rcz")
public class LogResource {

    public static final String LOG_ID = "logId";

    @Inject
    private Repository<Log, String> logRepository;

    @Inject
    private FluentAssembler fluentAssembler;

    @PathParam(LOG_ID)
    private String logId;

    @GET
    @Transactional
    @RequiresRoles(logical = Logical.OR , value = {"role_super_administrator", "role_administrator", "role_reader"})
    public Response getLogDetail() {
        Optional<Log> log = logRepository.get(logId);
        if (log.isPresent()) {
            return Response.ok(fluentAssembler.assemble(log.get()).to(LogDetail.class)).build();
        }
        return Response.status(Response.Status.NOT_FOUND).build();
    }
}
