package com.inetpsa.rcz.application.services;

import com.inetpsa.clp.LDAPUser;
import com.inetpsa.clp.exception.LDAPException;
import com.inetpsa.rcz.application.exceptions.WebExeption;
import com.inetpsa.rcz.domain.model.user.ResourceType;
import com.inetpsa.rcz.domain.model.user.UserLog;
import org.seedstack.business.domain.Factory;
import org.seedstack.business.domain.Repository;
import org.seedstack.jpa.Jpa;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.security.SecuritySupport;
import org.seedstack.seed.security.principals.PrincipalProvider;
import org.seedstack.seed.transaction.Transactional;

import javax.inject.Inject;
import java.util.Collection;
import java.util.Date;


@JpaUnit("rcz")
public class UserLogServiceImpl implements UserLogService {


    @Jpa
    @Inject
    private Repository<UserLog, Long> userLogRepository;

    @Inject
    private Factory<UserLog> userLogFactory;

    @Inject
    private SecuritySupport securitySupport;


    @Transactional
    @Override
    public void addEntry(ResourceType resource, String description) {
        try {
            Collection<PrincipalProvider<LDAPUser>> principalProviders = securitySupport.getPrincipalsByType(LDAPUser.class);
            if (principalProviders != null && !principalProviders.isEmpty()) {
                LDAPUser ldapUser = principalProviders.iterator().next().getPrincipal();
                UserLog userLog = userLogFactory.create(ldapUser.getUid(),
                                                        ldapUser.getEmail(),
                                                        new Date(),
                                                        resource,
                                                        description);
                userLogRepository.add(userLog);
            }
        } catch (LDAPException e) {
            throw new WebExeption(e);
        }
    }
}
