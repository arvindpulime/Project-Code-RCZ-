package com.inetpsa.rcz.rest.parameter.representation;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class RczParamRepresentation {

    private Boolean automaticVehicleState;

    private Boolean callerDailyQuotaEnabled;

    private Boolean clientResponseDebug;

    private Boolean openBar;

    private Boolean proxy;

    private Integer callerDailyQuotaDurationMin;

    private Integer callerDailyQuota;

    private Integer callerQuotaDurationMin;

    private Integer callerQuota;

    private Integer callerQuotaWarningDurationMin;

    private Integer callerQuotaWarning;

    private Integer exchangeTimeoutMin;

    private Integer hornQuotaDurationMin;

    private Integer hornQuota;

    private Integer lightsQuotaDurationMin;

    private Integer lightsQuota;

    private String remoteAlarmId;
}