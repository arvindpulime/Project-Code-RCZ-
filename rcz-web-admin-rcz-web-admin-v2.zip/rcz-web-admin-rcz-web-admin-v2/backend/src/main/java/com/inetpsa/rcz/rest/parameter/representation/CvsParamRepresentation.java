package com.inetpsa.rcz.rest.parameter.representation;

import lombok.Data;
import lombok.experimental.Accessors;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Data
@Accessors(chain = true)
@Embeddable
public class CvsParamRepresentation {

    private Boolean cvsAuthAccess;

    private Boolean cvsMock = true;

    private String cvsEndpointUrl;

    private String cvsOauthEndpointUrl;

}