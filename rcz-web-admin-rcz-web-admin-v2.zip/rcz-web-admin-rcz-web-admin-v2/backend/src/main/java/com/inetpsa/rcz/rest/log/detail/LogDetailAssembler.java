package com.inetpsa.rcz.rest.log.detail;

import com.inetpsa.rcz.domain.model.log.Log;
import com.inetpsa.rcz.domain.model.log.LogMessage;
import com.inetpsa.rcz.rest.log.AbstractLogAssembler;

/**
 * @author tuan.docao@ext.mpsa.com
 */
public class LogDetailAssembler extends AbstractLogAssembler<LogDetail> {

    @Override
    protected void doAssemble(LogDetail dto, Log agg) {
        dto.setId(agg.getId());
        if (agg.getLogLevel() != null) {
            dto.setLevel(agg.getLogLevel().name());
        }
        dto.setDate(agg.getLogDate());
        dto.setExchange(agg.getExchangeId());
        dto.setServerInstance(agg.getInstanceId());

        LogMessage message;
        if ((message = agg.getMessage()) != null) {
            dto.setMessage(message.getMessage());
            dto.setData(message.getData());
            dto.setTopic(message.getTopic());
        }
    }
}
