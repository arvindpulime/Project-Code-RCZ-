package com.inetpsa.rcz.rest.sms;

import com.inetpsa.rcz.domain.model.service.sms.SmsPaginatorService;
import com.inetpsa.rcz.domain.model.sms.Sms;
import com.inetpsa.rcz.rest.shared.hal.HalPageCriteria;
import com.inetpsa.rcz.rest.shared.hal.HalPageRepresentation;
import org.apache.commons.lang3.StringUtils;
import org.seedstack.business.assembler.Assembler;
import org.seedstack.business.pagination.Page;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.rest.Rel;
import org.seedstack.seed.rest.RelRegistry;
import org.seedstack.seed.rest.hal.Link;
import org.seedstack.seed.security.Logical;
import org.seedstack.seed.security.RequiresRoles;
import org.seedstack.seed.transaction.Transactional;

import javax.inject.Inject;
import javax.ws.rs.BeanParam;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;
import java.util.List;
import java.util.stream.Collectors;

import static com.inetpsa.rcz.rest.shared.Rels.EXCHANGES;
import static com.inetpsa.rcz.rest.shared.Rels.SMS;
import static com.inetpsa.rcz.rest.sms.SmsCriteria.PARAM_SENDING_DATE_FROM;
import static com.inetpsa.rcz.rest.sms.SmsCriteria.PARAM_SENDING_DATE_TO;
import static com.inetpsa.rcz.rest.sms.SmsCriteria.PARAM_TO;
import static com.inetpsa.rcz.rest.sms.SmsCriteria.PARAM_UIN;
import static com.inetpsa.rcz.rest.sms.SmsSort.ORDER;
import static com.inetpsa.rcz.rest.sms.SmsSort.SORT;

@Path("/")
@JpaUnit("rcz")
@Transactional()
@Produces({"application/json", "application/hal+json"})
public class SmsResource {

    @Inject
    private RelRegistry relRegistry;

    @Inject
    private SmsPaginatorService smsPaginatorService;

    @Inject
    private Assembler<Sms, SmsRepresentation> assembler;

    @GET
    @Path(SMS)
    @Rel(value = SMS, home = true)
    @RequiresRoles(logical = Logical.OR, value = {"role_super_administrator", "role_administrator", "role_reader"})
    public Response list(@BeanParam SmsSort sort,
                         @BeanParam SmsCriteria criteria,
                         @BeanParam HalPageCriteria halPageCriteria) {

        Page<Sms> page = smsPaginatorService.search(sort, criteria, halPageCriteria);

        List<SmsRepresentation> result = page.getItems().stream().map(sms -> {
            SmsRepresentation representation = new SmsRepresentation();
            assembler.mergeAggregateIntoDto(sms, representation);
            return representation;
        }).collect(Collectors.toList());

        Link self = relRegistry.uri(EXCHANGES);
        addParameters(self, criteria, sort);
        HalPageRepresentation<SmsRepresentation> exchanges = new HalPageRepresentation<>("sms", self, result, halPageCriteria.getPageNumber(), halPageCriteria.getPageSize(), page.getTotalSize());
        return Response.ok(exchanges).build();

    }

    private void addParameters(Link self, SmsCriteria criteria, SmsSort sort) {
        if (criteria.getSendingDateFrom() != null) {
            self.set(PARAM_SENDING_DATE_FROM, criteria.getSendingDateFrom());
        }
        if (criteria.getSendingDateTo() != null) {
            self.set(PARAM_SENDING_DATE_TO, criteria.getSendingDateTo());
        }
        if (StringUtils.isNotBlank(criteria.getUin())) {
            self.set(PARAM_UIN, criteria.getUin());
        }
        if (StringUtils.isNotBlank(criteria.getTo())) {
            self.set(PARAM_TO, criteria.getTo());
        }
        self.set(ORDER, sort.getOrder().name());
        self.set(SORT, sort.getSort().name());
    }

}
