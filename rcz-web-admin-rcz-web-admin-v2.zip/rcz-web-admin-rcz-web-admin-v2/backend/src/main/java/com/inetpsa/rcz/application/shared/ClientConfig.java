package com.inetpsa.rcz.application.shared;

import java.util.HashMap;
import java.util.Map;

public class ClientConfig {

    private String username;
    private String password;
    private String host;
    private SSLConfig ssl;
    private Map<String, String> headers = new HashMap<>();

    public String getUsername() {
        return username;
    }

    public ClientConfig setUsername(String username) {
        this.username = username;
        return this;
    }

    public String getPassword() {
        return password;
    }

    public ClientConfig setPassword(String password) {
        this.password = password;
        return this;
    }

    public String getHost() {
        return host;
    }

    public ClientConfig setHost(String host) {
        this.host = host;
        return this;
    }

    public SSLConfig getSsl() {
        return ssl;
    }

    public ClientConfig setSsl(SSLConfig ssl) {
        this.ssl = ssl;
        return this;
    }

    public Map<String, String> getHeaders() {
        return headers;
    }

    public ClientConfig setHeaders(Map<String, String> headers) {
        this.headers = headers;
        return this;
    }

    public static class SSLConfig {
        private TrustStoreConfig truststore = new TrustStoreConfig();

        public TrustStoreConfig getTruststore() {
            return truststore;
        }

        public static class TrustStoreConfig{

            private String file;
            private String password;

            public String getFile() {
                return file;
            }

            public String getPassword() {
                return password;
            }
        }
    }
}
