package com.inetpsa.rcz.domain.model.service.request;


import com.inetpsa.rcz.domain.model.api.request.Request;
import com.inetpsa.rcz.domain.model.api.request.RequestLight;
import com.inetpsa.rcz.rest.request.RequestCriteria;
import com.inetpsa.rcz.rest.request.RequestSort;
import com.inetpsa.rcz.rest.shared.hal.HalPageCriteria;
import org.seedstack.business.Service;
import org.seedstack.business.pagination.Page;

import java.util.Optional;

@Service
public interface RequestService {

    Page<RequestLight> search(RequestSort sort, RequestCriteria criteria, HalPageCriteria halPageCriteria);

    Optional<Request> getRequest(String id);

}
