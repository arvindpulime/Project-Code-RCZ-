package com.inetpsa.rcz.application.services;

import org.omg.CORBA.portable.ApplicationException;
import org.seedstack.business.Service;

@Service
public interface ServiceFeatureUpstreamService {

    /**
     * @return List<ServiceFeatureRefser>
     * @throws ApplicationException
     */
    void update();

}