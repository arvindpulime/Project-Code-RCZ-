package com.inetpsa.rcz.infrastructure.websocket.stomp.client.spec;

/**
 * STOMP headers.
 */
public enum StompHeader {
    ACCEPT_VERSION("accept-version"),
    CONTENT_LENGTH("content-length"),
    CONTENT_TYPE("content-type"),
    DESTINATION("destination"),
    HOST("host"),
    ID("id"),
    LOGIN("login"),
    PASSCODE("passcode"),
    HEART_BEAT("heart-beat"),
    MESSAGE_ID("message-id"),
    RECEIPT_ID("receipt-id"),
    RECEIPT("receipt"),
    SUBSCRIPTION("subscription"),
    VERSION("version");

    private final String value;

    private StompHeader(String value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return this.value;
    }
}