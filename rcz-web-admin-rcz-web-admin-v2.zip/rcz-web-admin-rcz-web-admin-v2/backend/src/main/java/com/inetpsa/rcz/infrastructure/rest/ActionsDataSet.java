package com.inetpsa.rcz.infrastructure.rest;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.inetpsa.rcz.domain.model.service.ServiceFeature;
import org.seedstack.business.assembler.DtoOf;

import java.io.Serializable;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(NON_NULL)
@DtoOf(ServiceFeature.class)
public class ActionsDataSet implements Serializable {
    private String label;
    private String remoteActionId;
    private String description;
    private String range;

    public ActionsDataSet() {
    }

    public String getLabel() {
        return label;
    }

    public ActionsDataSet setLabel(String label) {
        this.label = label;
        return this;
    }

    public String getRemoteActionId() {
        return remoteActionId;
    }

    public ActionsDataSet setRemoteActionId(String remoteActionId) {
        this.remoteActionId = remoteActionId;
        return this;
    }

    public String getDescription() {
        return description;
    }

    public ActionsDataSet setDescription(String description) {
        this.description = description;
        return this;
    }

    public String getRange() {
        return range;
    }

    public ActionsDataSet setRange(String range) {
        this.range = range;
        return this;
    }
}
