package com.inetpsa.rcz.domain.model.repository;

import com.inetpsa.rcz.domain.model.user.UserLog;
import org.seedstack.business.domain.Repository;

public interface UserLogRepository extends Repository<UserLog, Long> {
}