package com.inetpsa.rcz.rest.log.list;

import com.inetpsa.rcz.domain.model.log.Log;
import com.inetpsa.rcz.domain.model.service.log.LogPaginatorService;
import com.inetpsa.rcz.rest.shared.hal.HalPageCriteria;
import com.inetpsa.rcz.rest.shared.hal.HalPageRepresentation;
import org.apache.commons.lang3.StringUtils;
import org.seedstack.business.assembler.Assembler;
import org.seedstack.business.assembler.dsl.FluentAssembler;
import org.seedstack.business.modelmapper.ModelMapper;
import org.seedstack.business.pagination.Page;
import org.seedstack.seed.rest.Rel;
import org.seedstack.seed.rest.RelRegistry;
import org.seedstack.seed.rest.hal.Link;
import org.seedstack.seed.security.Logical;
import org.seedstack.seed.security.RequiresRoles;

import javax.inject.Inject;
import javax.ws.rs.BeanParam;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;
import java.util.List;

import static com.inetpsa.rcz.rest.log.list.LogCriteria.PARAM_DATA;
import static com.inetpsa.rcz.rest.log.list.LogCriteria.PARAM_EXCHANGE;
import static com.inetpsa.rcz.rest.log.list.LogCriteria.PARAM_ID;
import static com.inetpsa.rcz.rest.log.list.LogCriteria.PARAM_INSTANCES;
import static com.inetpsa.rcz.rest.log.list.LogCriteria.PARAM_LOG_DATE_FROM;
import static com.inetpsa.rcz.rest.log.list.LogCriteria.PARAM_LOG_DATE_TO;
import static com.inetpsa.rcz.rest.log.list.LogCriteria.PARAM_LOG_LEVELS;
import static com.inetpsa.rcz.rest.log.list.LogCriteria.PARAM_MESSAGE;
import static com.inetpsa.rcz.rest.log.list.LogCriteria.PARAM_TOPIC;
import static com.inetpsa.rcz.rest.log.list.LogSort.ORDER;
import static com.inetpsa.rcz.rest.log.list.LogSort.SORT;
import static com.inetpsa.rcz.rest.shared.Rels.LOGS;
import static com.inetpsa.rcz.rest.shared.Rels.LOGS_INSTANCES;
import static com.inetpsa.rcz.rest.shared.Rels.LOGS_LEVELS;

@Path("/")
@Produces({"application/json", "application/hal+json"})
public class LogsResource {

    @Inject
    private LogFinder logFinder;

    @Inject
    private RelRegistry relRegistry;

    @Inject
    private LogPaginatorService logsPaginatorService;

    @Inject
    private FluentAssembler fluentAssembler;

    @Inject
    @ModelMapper
    private Assembler<Log, LogRepresentation> assembler;

    @GET
    @Path(LOGS)
    @Rel(value = LOGS, home = true)
    @RequiresRoles(logical = Logical.OR, value = {"role_super_administrator", "role_administrator", "role_reader"})
    public Response search(@BeanParam LogSort sort, @BeanParam LogCriteria criteria, @BeanParam HalPageCriteria halPageCriteria) {

        Page<Log> page = this.logsPaginatorService.search(sort, criteria, halPageCriteria);

        List<LogRepresentation> result = fluentAssembler.assemble(page.getItems()).toListOf(LogRepresentation.class);

        Link self = relRegistry.uri(LOGS);
        addParameters(self, criteria, sort);
        HalPageRepresentation<LogRepresentation> logs = new HalPageRepresentation<>("logs", self, result, halPageCriteria.getPageNumber(), halPageCriteria.getPageSize(), page.getTotalSize());
        return Response.ok(logs).build();
    }

    @GET
    @Path(LOGS_LEVELS)
    @RequiresRoles(logical = Logical.OR, value = {"role_super_administrator", "role_administrator", "role_reader"})
    public Response levels() {
        String [] levels = {"WARN", "ERROR", "INFO"};
        return Response.ok(levels).build();
    }

    @GET
    @Path(LOGS_INSTANCES)
    public Response instances() {
        return Response.ok(logFinder.findAvailableInstances()).build();
    }

    private void addParameters(Link self, LogCriteria criteria, LogSort sort) {
        if (StringUtils.isNotBlank(criteria.getId())) {
            self.set(PARAM_ID, criteria.getId());
        }
        if (criteria.getInstanceId() != null) {
            self.set(PARAM_INSTANCES, criteria.getInstanceId());
        }
        if (criteria.getLogLevels() != null) {
            self.set(PARAM_LOG_LEVELS, criteria.getLogLevels());
        }
        if (criteria.getMessage() != null) {
            self.set(PARAM_MESSAGE, criteria.getMessage());
        }
        if (criteria.getData() != null) {
            self.set(PARAM_DATA, criteria.getData());
        }
        if (criteria.getTopic() != null) {
            self.set(PARAM_TOPIC, criteria.getTopic());
        }
        if (criteria.getExchangeId() != null) {
            self.set(PARAM_EXCHANGE, criteria.getExchangeId());
        }
        if (criteria.getLogDateFrom() != null) {
            self.set(PARAM_LOG_DATE_FROM, criteria.getLogDateFrom());
        }
        if (criteria.getLogDateTo() != null) {
            self.set(PARAM_LOG_DATE_TO, criteria.getLogDateTo());
        }
        self.set(ORDER, sort.getOrder().name());
        self.set(SORT, sort.getSort().name());
    }
}
