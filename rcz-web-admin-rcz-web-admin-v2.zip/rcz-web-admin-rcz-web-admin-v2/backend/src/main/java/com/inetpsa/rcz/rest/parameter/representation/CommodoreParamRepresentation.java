package com.inetpsa.rcz.rest.parameter.representation;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class CommodoreParamRepresentation {

    private Boolean vehicleRequestMock;

    private Integer vehicleRequestMaxDuration;

    private Integer vehicleRequestNbRetry;

    private Integer vehicleRequestRetryDelay;

    private String vehicleRequestPath;

    private String vehicleRequestUri;
}