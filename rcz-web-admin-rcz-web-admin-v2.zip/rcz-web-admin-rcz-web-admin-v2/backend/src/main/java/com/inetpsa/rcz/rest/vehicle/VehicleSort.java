package com.inetpsa.rcz.rest.vehicle;

import com.inetpsa.rcz.rest.shared.SortOrder;
import lombok.Data;
import org.seedstack.business.domain.SortOption;

import javax.ws.rs.DefaultValue;
import javax.ws.rs.QueryParam;

@Data
public class VehicleSort {

    public static final String SORT = "sort";
    public static final String ORDER = "order";

    @QueryParam(SORT)
    @DefaultValue("UPDATE_DATE")
    private ColumnSort sort;

    @QueryParam(ORDER)
    @DefaultValue("DESCENDING")
    private SortOrder order;

    public SortOption getSortOption() {
        return new SortOption().add(this.getSort().literal(), SortOption.Direction.valueOf(this.getOrder().name()));
    }

    public enum ColumnSort {

        VEHICLE_STATE_DATE("vehicleState.receivedDate"),
        SERVICE_STATE_DATE("serviceState.receivedDate"),
        VEHICLE_INFO_DATE("vehicleInfo.receivedDate"),
        LOW_POWER_INFO_DATE("lowPowerInfo.receivedDate"),
        SERVICE_INFO_DATE("serviceInfo.receivedDate"),
        UPDATE_DATE("updateDate");

        private String literal;

        ColumnSort(String literal) {
            this.literal = literal;
        }

        public String literal() {
            return literal;
        }
    }
}
