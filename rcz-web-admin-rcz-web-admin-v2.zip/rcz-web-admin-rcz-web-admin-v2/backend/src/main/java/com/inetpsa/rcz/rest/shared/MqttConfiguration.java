package com.inetpsa.rcz.rest.shared;

import org.seedstack.coffig.Config;

@Config("rcz.mqtt.configuration")
public class MqttConfiguration {

    @Config("instance.01.id")
    private String id01;

    @Config("instance.01.baseUrl")
    private String baseURL01;

    @Config("instance.01.path")
    private String mqttPath01;

    @Config("instance.02.id")
    private String id02;

    @Config("instance.02.baseUrl")
    private String baseURL02;

    @Config("instance.02.path")
    private String mqttPath02;

    private int timeout = 2000;

    public String getId01() {
        return id01;
    }

    public String getBaseURL01() {
        return baseURL01;
    }

    public String getMqttPath01() {
        return mqttPath01;
    }

    public String getId02() {
        return id02;
    }

    public String getBaseURL02() {
        return baseURL02;
    }

    public String getMqttPath02() {
        return mqttPath02;
    }

    public int getTimeout() {
        return timeout;
    }
}
