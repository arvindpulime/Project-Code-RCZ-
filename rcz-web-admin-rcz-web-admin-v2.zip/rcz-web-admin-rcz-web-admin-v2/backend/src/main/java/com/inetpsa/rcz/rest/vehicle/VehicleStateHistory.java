package com.inetpsa.rcz.rest.vehicle;

import com.inetpsa.rcz.domain.model.payload.data.VehicleState;

import java.util.List;

public class VehicleStateHistory {

    private String id;

    private List<VehicleState> vehicleStatesHistory;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public List<VehicleState> getVehicleStatesHistory() {
        return vehicleStatesHistory;
    }

    public void setVehicleStatesHistory(List<VehicleState> vehicleStatesHistory) {
        this.vehicleStatesHistory = vehicleStatesHistory;
    }
}
