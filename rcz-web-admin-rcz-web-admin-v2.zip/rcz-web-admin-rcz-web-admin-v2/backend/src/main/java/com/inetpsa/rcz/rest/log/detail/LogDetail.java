package com.inetpsa.rcz.rest.log.detail;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.inetpsa.rcz.rest.log.list.LogRepresentation;
import org.apache.commons.lang3.StringUtils;

import java.util.Date;
import java.util.regex.Pattern;

/**
 * @author tuan.docao@ext.mpsa.com
 */
public class LogDetail extends LogRepresentation {

    @JsonProperty("payload")
    private String data;
    public static final Pattern REGEX_JSON_PASSWORD = Pattern.compile("\"(?i)(password|pwd|token|access_token)\\s*\":\\s*\"[\\w\\p{Punct}&&[^&]]*?\"");

    public LogDetail() {

    }

    public LogDetail(String data) {
        this.data = data;
    }

    public LogDetail(String id, String level, Date date, String message, String exchange, String topic, String serverInstance, String data) {
        super(id, level, date, message, exchange, topic, serverInstance);
        this.data = data;
    }

    public String getData() {
        if (StringUtils.isNotBlank(data)) {
            return REGEX_JSON_PASSWORD.matcher(data).replaceAll("\"$1\":\"XXXXXXXXXXXXXXXX\"");
        }
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
}
