package com.inetpsa.rcz.infrastructure.security;

import org.apache.shiro.cache.ehcache.EhCacheManager;

public class CustomCacheManager extends EhCacheManager {

    public CustomCacheManager() {
        setCacheManagerConfigFile("classpath:security-ehcache.xml");
    }
}
