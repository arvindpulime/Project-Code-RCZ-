package com.inetpsa.rcz.application.services;

import com.inetpsa.rcz.domain.model.user.ResourceType;
import org.seedstack.business.Service;

@Service
public interface UserLogService {

    void addEntry(ResourceType resource, String description);
}
