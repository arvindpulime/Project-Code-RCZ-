package com.inetpsa.rcz.rest.action;

import java.util.ArrayList;
import java.util.List;

public class Actions {

    List<String> remote;
    List<String> stolen;

    public Actions() {
    }

    public List<String> getRemote() {
        return remote;
    }

    public List<String> getStolen() {
        return stolen;
    }

    public void addRemote(String remote) {
        if (this.remote == null) {
            this.remote = new ArrayList<>();
        }
        this.remote.add(remote);
    }

    public void addStolen(String stolen) {
        if (this.stolen == null) {
            this.stolen = new ArrayList<>();
        }
        this.stolen.add(stolen);
    }

}
