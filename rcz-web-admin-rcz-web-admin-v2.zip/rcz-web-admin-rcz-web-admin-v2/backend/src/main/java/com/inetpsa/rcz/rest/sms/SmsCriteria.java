package com.inetpsa.rcz.rest.sms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import javax.ws.rs.QueryParam;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(NON_NULL)
public class SmsCriteria {

    public static final String COL_SENDING_DATE = "sendingDate";
    public static final String COL_TO = "messages.to.value";
    public static final String COL_UIN = "uin";
    public static final String COL_PROVIDER = "provider";

    public static final String PARAM_SENDING_DATE_FROM = "sendingDateFrom";
    public static final String PARAM_SENDING_DATE_TO = "sendingDateTo";
    public static final String PARAM_TO = "to";
    public static final String PARAM_UIN = "uin";
    public static final String PARAM_PROVIDER = "provider";

    @QueryParam(PARAM_SENDING_DATE_FROM)
    private Long sendingDateFrom;

    @QueryParam(PARAM_SENDING_DATE_TO)
    private Long sendingDateTo;

    @QueryParam(PARAM_TO)
    private String to;

    @QueryParam(PARAM_UIN)
    private String uin;

    @QueryParam(PARAM_PROVIDER)
    private String provider;

}
