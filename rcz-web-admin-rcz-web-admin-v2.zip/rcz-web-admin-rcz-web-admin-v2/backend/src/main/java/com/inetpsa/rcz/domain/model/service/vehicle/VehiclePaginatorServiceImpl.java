package com.inetpsa.rcz.domain.model.service.vehicle;

import com.inetpsa.rcz.domain.model.vehicle.Vehicle;
import com.inetpsa.rcz.domain.repository.VehicleRepository;
import com.inetpsa.rcz.rest.shared.hal.HalPageCriteria;
import com.inetpsa.rcz.rest.vehicle.VehicleCriteria;
import com.inetpsa.rcz.rest.vehicle.VehicleSort;
import org.seedstack.business.pagination.Page;
import org.seedstack.business.pagination.dsl.Paginator;
import org.seedstack.business.specification.AndSpecification;
import org.seedstack.business.specification.Specification;
import org.seedstack.business.specification.dsl.SpecificationBuilder;
import org.seedstack.jpa.Jpa;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;

import static com.inetpsa.rcz.rest.vehicle.VehicleCriteria.COL_ID;
import static com.inetpsa.rcz.rest.vehicle.VehicleCriteria.COL_MSISDN;
import static com.inetpsa.rcz.rest.vehicle.VehicleCriteria.COL_VIN;

public class VehiclePaginatorServiceImpl implements VehiclePaginatorService {

    @Inject
    private Paginator paginator;

    @Inject
    private VehicleRepository VehicleRepository;

    @Override
    public Page<Vehicle> search(VehicleSort sort, VehicleCriteria criteria, HalPageCriteria halPageCriteria) {
        Specification<Vehicle> specification = getSpecification(criteria);

        return paginator
                .paginate(VehicleRepository)
                .withOptions(sort.getSortOption())
                .byPage(halPageCriteria.getPageNumber())
                .limit(halPageCriteria.getPageSize())
                .matching(specification)
                ;
    }


    private Specification<Vehicle> getSpecification(VehicleCriteria criteria) {

        SpecificationBuilder specificationBuilder = VehicleRepository.getSpecificationBuilder();

        List<Specification<Vehicle>> specifications = new ArrayList<>();

        if (criteria.getId() != null) {
            specifications.add(specificationBuilder.ofAggregate(Vehicle.class).property(COL_ID).equalTo(criteria.getId()).build());
        }

        if (criteria.getVin() != null) {
            specifications.add(specificationBuilder.ofAggregate(Vehicle.class).property(COL_VIN).matching(criteria.getVin()).trimming().ignoringCase().build());
        }

        if (criteria.getMsisdn() != null) {
            specifications.add(specificationBuilder.ofAggregate(Vehicle.class).property(COL_MSISDN).matching(criteria.getMsisdn()).trimming().ignoringCase().build());
        }

        if (specifications.isEmpty()) {
            return VehicleRepository.getSpecificationBuilder().of(Vehicle.class).all().build();
        }

        return new AndSpecification<>(specifications.toArray(new Specification[0]));
    }

}
