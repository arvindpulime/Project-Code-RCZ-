package com.inetpsa.rcz.infrastructure.security;

import com.inetpsa.clp.LDAPUser;
import com.inetpsa.clp.exception.LDAPException;
import edu.emory.mathcs.backport.java.util.Collections;
import org.apache.shiro.web.filter.authz.PermissionsAuthorizationFilter;
import org.seedstack.seed.Logging;
import org.seedstack.seed.security.SecuritySupport;
import org.seedstack.seed.security.principals.PrincipalProvider;
import org.seedstack.seed.web.SecurityFilter;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import java.io.IOException;
import java.security.cert.X509Certificate;
import java.util.Collection;

@SecurityFilter("basicX509")
public class CustomBasicX509Filter extends PermissionsAuthorizationFilter {

    public static final String X509_CERTIFICATE_PROPERTY = "javax.servlet.request.X509Certificate";
    @Inject
    private SecuritySupport securitySupport;

    @Logging
    private Logger logger;

    public CustomBasicX509Filter() {
    }

    @Override
    public boolean isAccessAllowed(ServletRequest request, ServletResponse response, Object mappedValue) throws IOException {
        try {
            X509Certificate[] certificates = (X509Certificate[]) request.getAttribute(X509_CERTIFICATE_PROPERTY);
            if (certificates != null) {
                Collection<PrincipalProvider<LDAPUser>> principalProviders = securitySupport.getPrincipalsByType(LDAPUser.class);
                if (principalProviders != null && !principalProviders.isEmpty()) {
                    LDAPUser ldapUser = principalProviders.iterator().next().getPrincipal();
                    for (X509Certificate ldapCertificate : certificates) {
                        for (Object certificate : Collections.list(ldapUser.getCertificates())) {
                            if (ldapCertificate.equals(certificate)) {
                                return super.isAccessAllowed(request, response, mappedValue);
                            }
                        }
                    }
                }
            }
            return false;
        } catch (LDAPException e) {
            return false;
        }
    }
}

