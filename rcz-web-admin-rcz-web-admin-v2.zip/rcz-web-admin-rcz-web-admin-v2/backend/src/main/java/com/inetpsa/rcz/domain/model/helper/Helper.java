package com.inetpsa.rcz.domain.model.helper;

import org.apache.commons.lang3.StringUtils;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;
import org.seedstack.business.util.SequenceGenerator;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import java.util.Date;

@Entity
@Table(name = "RCZQTHELPER")
public class Helper extends BaseAggregateRoot<Long> {

    @Id
    @Identity(generator = SequenceGenerator.class)
    public Long id;
    public Date createDate;
    public String title;
    @Lob
    public String content;

    Helper() {
    }

    Helper(Date createDate, String title, String content) {
        this.createDate = createDate;
        this.title = title;
        if (StringUtils.isNotBlank(content)) {
            this.content = content.replaceAll("\u0000", "");
        } else {
            this.content = content;
        }

    }

    @Override
    public Long getId() {
        return id;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        if (StringUtils.isNotBlank(content)) {
            this.content = content.replaceAll("\u0000", "");
        } else {
            this.content = content;
        }    }

}
