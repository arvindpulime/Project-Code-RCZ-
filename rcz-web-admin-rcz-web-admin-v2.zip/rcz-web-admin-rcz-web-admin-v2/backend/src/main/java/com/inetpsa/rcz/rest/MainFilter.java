package com.inetpsa.rcz.rest;

import com.google.common.base.Charsets;
import com.google.common.io.CharStreams;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Response;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

@WebFilter(value = "/")
public class MainFilter implements Filter {


    public static final String REST_PATH = "rest.path";
    public static final String WS_PATH = "/ws";
    public static final String INDEX_PATH = "/META-INF/resources/index.html";
    public static final String ERROR_WHILE_FETCHING_INDEX_FILE = "Error while fetching index file";
    public static final String DEFAULT_REST_PATH = "/api";
    @Configuration(REST_PATH)
    private String restPath = DEFAULT_REST_PATH;
    private static final Logger LOGGER = LoggerFactory.getLogger(MainFilter.class);

    protected void loadMainPage(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        if (req.getRequestURI().contentEquals("/") || req.getRequestURI().isEmpty()) {
            InputStream stream = MainFilter.class.getResourceAsStream(INDEX_PATH);
            if (stream == null) {
                resp.setStatus(Response.Status.NOT_FOUND.getStatusCode());
            } else {
                try {
                    resp.getWriter().write(CharStreams.toString(new InputStreamReader(stream, Charsets.UTF_8)));
                } catch (IOException e) {
                    LOGGER.error(ERROR_WHILE_FETCHING_INDEX_FILE, e);
                    resp.setStatus(Response.Status.NOT_FOUND.getStatusCode());
                }
            }
        } else {
            resp.setStatus(Response.Status.NOT_FOUND.getStatusCode());
        }
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;
        if (req.getRequestURI().startsWith(restPath)
                || req.getRequestURI().startsWith(WS_PATH)) {
            chain.doFilter(request, response);
        } else {
            loadMainPage(req, resp);
        }
    }

    @Override
    public void destroy() {
    }
}