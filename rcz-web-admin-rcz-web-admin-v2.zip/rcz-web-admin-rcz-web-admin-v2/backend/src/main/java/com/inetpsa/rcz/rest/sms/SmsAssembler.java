package com.inetpsa.rcz.rest.sms;

import com.inetpsa.rcz.domain.model.sms.Message;
import com.inetpsa.rcz.domain.model.sms.Sms;
import org.seedstack.business.assembler.BaseAssembler;

public class SmsAssembler extends BaseAssembler<Sms, SmsRepresentation> {


    private void initMessage(Message message, SmsRepresentation smsRepresentation) {
        smsRepresentation.setTo(message.getTo().getValue())
                .setSmsData(message.getText());
    }


    @Override
    public void mergeAggregateIntoDto(Sms aggregate, SmsRepresentation dto) {
        if (aggregate.getMessages() != null) {
            aggregate.getMessages().stream().findFirst().ifPresent(message -> initMessage(message, dto));
        }
        if (aggregate.getAcknowledgement() != null) {
            dto.setAckCode(aggregate.getAcknowledgement().getAckCode())
                    .setAckMessage(aggregate.getAcknowledgement().getReason())
                    .setAckDate(aggregate.getAcknowledgement().getAckDate());
        }
        dto.setAdm(aggregate.getAdm())
                .setAnswerStatus(aggregate.getAnswerStatus())
                .setIcp(aggregate.getIcp())
                .setIdOffer(aggregate.getIdOffer())
                .setUin(aggregate.getUin())
                .setVersion(aggregate.getVersion())
                .setSendingDate(aggregate.getSendingDate())
                .setId(aggregate.getId())
                .setProvider(aggregate.getProvider() != null ? aggregate.getProvider().name() : null);
    }

    @Override
    public void mergeDtoIntoAggregate(SmsRepresentation sourceDto, Sms targetAggregate) {

    }
}
