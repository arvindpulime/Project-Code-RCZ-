package com.inetpsa.rcz.rest.vehicle;

import com.inetpsa.rcz.rest.shared.RangeInfo;
import com.inetpsa.rcz.rest.shared.ResultHal;
import org.seedstack.business.Service;
import org.seedstack.seed.rest.hal.HalRepresentation;
import org.seedstack.seed.transaction.Transactional;

import java.util.List;

@Service
public interface VehicleFinder {
    ResultHal<HalRepresentation> getListOfVehicle(VehicleCriteria vehicleCriteria, VehicleSort vehicleSort, RangeInfo rangeInfo);

    long count(VehicleCriteria vehicleCriteria);
}
