package com.inetpsa.rcz.domain.model.service.log;

import com.inetpsa.rcz.domain.model.repository.UserLogRepository;
import com.inetpsa.rcz.domain.model.sms.Sms;
import com.inetpsa.rcz.domain.model.user.ResourceType;
import com.inetpsa.rcz.domain.model.user.UserLog;
import com.inetpsa.rcz.rest.log.user.UserLogCriteria;
import com.inetpsa.rcz.rest.log.user.UserLogSort;
import com.inetpsa.rcz.rest.shared.hal.HalPageCriteria;
import org.apache.commons.lang3.EnumUtils;
import org.seedstack.business.pagination.Page;
import org.seedstack.business.pagination.dsl.Paginator;
import org.seedstack.business.specification.AndSpecification;
import org.seedstack.business.specification.OrSpecification;
import org.seedstack.business.specification.Specification;
import org.seedstack.business.specification.dsl.SpecificationBuilder;
import org.seedstack.jpa.Jpa;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static com.inetpsa.rcz.rest.log.user.UserLogCriteria.COL_EMAIL;
import static com.inetpsa.rcz.rest.log.user.UserLogCriteria.COL_ENTRY_DATE;
import static com.inetpsa.rcz.rest.log.user.UserLogCriteria.COL_LOG;
import static com.inetpsa.rcz.rest.log.user.UserLogCriteria.COL_RESOURCE;
import static com.inetpsa.rcz.rest.log.user.UserLogCriteria.COL_USER_ID;
import static com.inetpsa.rcz.rest.sms.SmsCriteria.COL_SENDING_DATE;

public class UserLogPaginatorServiceImpl implements UserLogPaginatorService {

    @Inject
    private Paginator paginator;

    @Inject
    @Jpa
    private UserLogRepository logRepository;

    @Override
    public Page<UserLog> search(UserLogSort sort, UserLogCriteria criteria, HalPageCriteria halPageCriteria) {
        Specification<UserLog> specification = getSpecification(criteria);

        return paginator
                .paginate(logRepository)
                .withOptions(sort.getSortOption())
                .byPage(halPageCriteria.getPageNumber())
                .limit(halPageCriteria.getPageSize())
                .matching(specification)
                ;
    }


    private Specification<UserLog> getSpecification(UserLogCriteria criteria) {

        SpecificationBuilder specificationBuilder = logRepository.getSpecificationBuilder();

        List<Specification<UserLog>> specifications = new ArrayList<>();

        if (criteria.getUserId() != null) {
            specifications.add(specificationBuilder.ofAggregate(UserLog.class).property(COL_USER_ID).matching(criteria.getUserId()).trimming().ignoringCase().build());
        }
        if (criteria.getEmail() != null) {
            specifications.add(specificationBuilder.ofAggregate(UserLog.class).property(COL_EMAIL).matching(criteria.getEmail()).trimming().ignoringCase().build());
        }
        if (criteria.getLog() != null) {
            specifications.add(specificationBuilder.ofAggregate(UserLog.class).property(COL_LOG).matching(criteria.getLog()).trimming().ignoringCase().build());
        }
        if (criteria.getResources() != null && !criteria.getResources().isEmpty()) {
            specifications.add(buildEnumSpecification(specificationBuilder, criteria.getResources(), COL_RESOURCE, ResourceType.class));
        }

        if (criteria.getEntryDateFrom() != null && criteria.getEntryDateTo() != null) {
            specifications.add(specificationBuilder.ofAggregate(UserLog.class)
                    .property(COL_ENTRY_DATE).equalTo(new Date(criteria.getEntryDateFrom()))
                    .or()
                    .property(COL_ENTRY_DATE).greaterThan(new Date(criteria.getEntryDateFrom())).build());
            specifications.add(specificationBuilder.ofAggregate(UserLog.class)
                    .property(COL_ENTRY_DATE).equalTo(new Date(criteria.getEntryDateTo()))
                    .or()
                    .property(COL_ENTRY_DATE).lessThan(new Date(criteria.getEntryDateTo())).build());
        }

        if (specifications.isEmpty()) {
            return logRepository.getSpecificationBuilder().of(UserLog.class).all().build();
        }

        return new AndSpecification<>(specifications.toArray(new Specification[0]));
    }

    private <E extends Enum<E>> Specification<UserLog> buildEnumSpecification(SpecificationBuilder specificationBuilder, String enums, String property, Class<E> clazz) {
        String[] values = enums.split(",");
        List<Specification<UserLog>> specifications = new ArrayList<>();
        for (String value : values) {
            specifications.add(specificationBuilder.ofAggregate(UserLog.class).property(property).equalTo(EnumUtils.getEnum(clazz, value)).build());

        }
        return new OrSpecification<>(specifications.toArray(new Specification[0]));
    }

}
