package com.inetpsa.rcz.domain.model.service.exchange;

import com.inetpsa.rcz.domain.model.exchange.ExchangeLight;
import com.inetpsa.rcz.rest.exchange.ExchangeCriteria;
import com.inetpsa.rcz.rest.exchange.ExchangeSort;
import com.inetpsa.rcz.rest.shared.hal.HalPageCriteria;
import org.seedstack.business.Service;
import org.seedstack.business.pagination.Page;

@Service
public interface ExchangePaginatorService {

    Page<ExchangeLight> search(ExchangeSort sort, ExchangeCriteria criteria, HalPageCriteria halPageCriteria);

    long count(ExchangeCriteria criteria);
}
