package com.inetpsa.rcz.rest.shared.hal;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.experimental.Accessors;
import org.seedstack.seed.rest.hal.HalRepresentation;
import org.seedstack.seed.rest.hal.Link;

import java.util.List;

import static com.inetpsa.rcz.rest.shared.hal.HalPageCriteria.PAGE;
import static com.inetpsa.rcz.rest.shared.hal.HalPageCriteria.SIZE;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Accessors(chain = true)
public class HalPageRepresentation<T> extends HalRepresentation {

    private HalPage page;

    public HalPageRepresentation(String embeddedName, Link selfBuilder, List<T> items, long pageNumber, long pageSize, long totalElement) {
        embedded(embeddedName, items);

        page = new HalPage(pageNumber, pageSize, totalElement);

        self(new Link(selfBuilder.set(PAGE, pageNumber).set(SIZE, pageSize)));

        if (pageNumber < page.getTotalPages()) {
            link("next", new Link(selfBuilder
                    .set(PAGE, pageNumber + 1)
                    .set(SIZE, pageSize)));
        }

        if (pageNumber > 1) {
            link("prev", new Link(selfBuilder
                    .set(PAGE, pageNumber - 1)
                    .set(SIZE, pageSize)));
        }
        if (page.getTotalPages() > 1) {
            link("first", new Link(selfBuilder
                    .set(PAGE, 1)
                    .set(SIZE, pageSize)));
        }
        if (page.getTotalPages() > 1) {
            link("last", new Link(selfBuilder
                    .set(PAGE, page.getTotalPages())
                    .set(SIZE, pageSize)));
        }

    }


}