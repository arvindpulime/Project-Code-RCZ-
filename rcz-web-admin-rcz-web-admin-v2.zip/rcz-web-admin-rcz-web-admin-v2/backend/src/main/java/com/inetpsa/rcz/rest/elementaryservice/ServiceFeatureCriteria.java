package com.inetpsa.rcz.rest.elementaryservice;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import javax.ws.rs.QueryParam;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ServiceFeatureCriteria {

    public static final String CODE = "code";
    public static final String SHORT_LABEL = "shortLabel";
    public static final String LABEL = "label";
    public static final String SUSPENDED = "suspended";
    public static final String DELETED = "deleted";
    public static final String START_DATE = "startDate";
    public static final String START_DATE_FROM = "startDateFrom";
    public static final String START_DATE_TO = "startDateTo";
    public static final String END_DATE = "endDate";
    public static final String END_DATE_FROM = "endDateFrom";
    public static final String END_DATE_TO = "endDateTo";


    @QueryParam(CODE)
    private String code;
    @QueryParam(SHORT_LABEL)
    private String shortLabel;
    @QueryParam(LABEL)
    private String label;
    @QueryParam(SUSPENDED)
    private Boolean suspended;
    @QueryParam(DELETED)
    private Boolean deleted;
    @QueryParam(START_DATE_FROM)
    private Long startDateFrom;
    @QueryParam(START_DATE_TO)
    private Long startDateTo;
    @QueryParam(END_DATE_FROM)
    private Long endDateFrom;
    @QueryParam(END_DATE_TO)
    private Long endDateTo;




}
