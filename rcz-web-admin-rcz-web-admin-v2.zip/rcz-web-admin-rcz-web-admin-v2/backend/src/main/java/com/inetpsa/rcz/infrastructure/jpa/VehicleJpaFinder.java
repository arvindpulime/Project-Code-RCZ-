package com.inetpsa.rcz.infrastructure.jpa;

import com.inetpsa.rcz.domain.model.vehicle.Vehicle;
import com.inetpsa.rcz.domain.repository.VehicleRepository;
import com.inetpsa.rcz.rest.shared.RangeInfo;
import com.inetpsa.rcz.rest.shared.Result;
import com.inetpsa.rcz.rest.shared.ResultHal;
import com.inetpsa.rcz.rest.vehicle.VehicleCriteria;
import com.inetpsa.rcz.rest.vehicle.VehicleFinder;
import com.inetpsa.rcz.rest.vehicle.VehicleRepresentation;
import com.inetpsa.rcz.rest.vehicle.VehicleSort;
import org.apache.commons.lang3.StringUtils;
import org.seedstack.business.assembler.Assembler;
import org.seedstack.business.modelmapper.ModelMapper;
import org.seedstack.business.pagination.Slice;
import org.seedstack.business.pagination.dsl.Paginator;
import org.seedstack.business.specification.AndSpecification;
import org.seedstack.business.specification.Specification;
import org.seedstack.business.specification.dsl.SpecificationBuilder;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.rest.RelRegistry;
import org.seedstack.seed.rest.hal.HalRepresentation;
import org.seedstack.seed.rest.hal.Link;
import org.seedstack.seed.transaction.Transactional;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;

import static com.inetpsa.rcz.rest.shared.Rels.PATH_VEHICLES;
import static com.inetpsa.rcz.rest.vehicle.VehicleCriteria.*;
import static com.inetpsa.rcz.rest.vehicle.VehicleSort.ORDER;
import static com.inetpsa.rcz.rest.vehicle.VehicleSort.SORT;

@JpaUnit("rcz")
public class VehicleJpaFinder implements VehicleFinder {

    public static final String VEHICLES = "vehicles";
    @Inject
    private VehicleRepository vehicleRepository;
    @Inject
    private Paginator paginator;
    @Inject
    private RelRegistry relRegistry;
    @ModelMapper
    @Inject
    private Assembler<Vehicle, VehicleRepresentation> vehicleAssembler;

    @Transactional
    @Override
    public ResultHal<HalRepresentation> getListOfVehicle(VehicleCriteria vehicleCriteria, VehicleSort vehicleSort, RangeInfo rangeInfo) {
        Specification<Vehicle> specification = getSpecification(vehicleCriteria);
        Slice<Vehicle> result = paginator
                .paginate(vehicleRepository)
                .withOptions(vehicleSort.getSortOption())
                .byOffset(rangeInfo.getOffset())
                .limit(rangeInfo.getSize())
                .matching(specification);

        Link self = relRegistry.uri(VEHICLES);
        addParameters(self, vehicleCriteria, vehicleSort);
        List<HalRepresentation> vehicleRepresentations = new ArrayList<>();
        result.getItems().forEach(vehicle -> vehicleRepresentations.add(vehicleAssembler.createDtoFromAggregate(vehicle)
                .self(relRegistry.uri(PATH_VEHICLES))));
        if (result.getItems() != null && !result.getItems().isEmpty()) {
            return new ResultHal<>(VEHICLES, new Result<>(vehicleRepresentations, rangeInfo.getOffset(), count(vehicleCriteria)), self, rangeInfo);
        }
        return null;
    }

    private void addParameters(Link self, VehicleCriteria criteria, VehicleSort sort) {
        if (StringUtils.isNotBlank(criteria.getId())) {
            self.set(PARAM_ID, criteria.getId());
        }
        if (criteria.getId() != null) {
            self.set(PARAM_ID, criteria.getId());
        }
        if (criteria.getVin() != null) {
            self.set(PARAM_VIN, criteria.getVin());
        }
        if (criteria.getMsisdn() != null) {
            self.set(PARAM_MSISDN, criteria.getMsisdn());
        }
        if (criteria.getBtaType() != null) {
            self.set(PARAM_BTA_TYPE, criteria.getMsisdn());
        }
        self.set(ORDER, sort.getOrder().name());
        self.set(SORT, sort.getSort().name());
    }

    @Override
    public long count(VehicleCriteria vehicleCriteria) {
        return vehicleRepository.count(getSpecification(vehicleCriteria));
    }

    @Transactional
    private Specification<Vehicle> getSpecification(VehicleCriteria vehicleCriteria) {
        SpecificationBuilder specificationBuilder = vehicleRepository.getSpecificationBuilder();
        List<Specification<Vehicle>> specifications = new ArrayList<>();
        if (vehicleCriteria.getId() != null) {
            specifications.add(specificationBuilder.ofAggregate(Vehicle.class)
                    .property(COL_ID)
                    .equalTo(vehicleCriteria.getId()).build());
        }
        if (vehicleCriteria.getVin() != null) {
            specifications.add(specificationBuilder.ofAggregate(Vehicle.class)
                    .property(COL_VIN)
                    .matching(vehicleCriteria.getVin()).ignoringCase().trimming().build());
        }
        if (vehicleCriteria.getMsisdn() != null) {
            specifications.add(specificationBuilder.ofAggregate(Vehicle.class)
                    .property(COL_MSISDN)
                    .matching(vehicleCriteria.getMsisdn()).ignoringCase().trimming().build());
        }
        if (specifications.isEmpty()) {
            return specificationBuilder.ofAggregate(Vehicle.class).all().build();
        }
        return new AndSpecification<>(specifications.toArray(new Specification[specifications.size()]));
    }
}
