package com.inetpsa.rcz.rest.parameter.representation;


import com.inetpsa.rcz.domain.model.parameter.Parameter;
import lombok.Data;
import lombok.experimental.Accessors;
import org.seedstack.business.assembler.DtoOf;

@Data
@DtoOf(Parameter.class)
@Accessors(chain = true)
public class ParameterRepresentation {

    private String id;
    private RczParamRepresentation rcz = new RczParamRepresentation();
    private CommodoreParamRepresentation commodore = new CommodoreParamRepresentation();
    private SmsParamRepresentation sms = new SmsParamRepresentation();
    private CvsParamRepresentation cvs = new CvsParamRepresentation();

}