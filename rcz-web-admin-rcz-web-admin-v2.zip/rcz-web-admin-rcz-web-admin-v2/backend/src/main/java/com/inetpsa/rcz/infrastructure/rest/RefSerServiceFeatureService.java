package com.inetpsa.rcz.infrastructure.rest;

import com.fasterxml.jackson.core.type.TypeReference;
import com.inetpsa.rcz.application.exceptions.WebExeption;
import com.inetpsa.rcz.application.services.ServiceFeatureUpstreamService;
import com.inetpsa.rcz.application.shared.ClientConfig;
import com.inetpsa.rcz.domain.model.service.ServiceFeature;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;
import com.inetpsa.rcz.infrastructure.json.JsonParseException;
import org.seedstack.business.assembler.Assembler;
import org.seedstack.business.domain.Factory;
import org.seedstack.business.domain.Repository;
import org.seedstack.business.modelmapper.ModelMapper;
import org.seedstack.jpa.Jpa;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;

import javax.cache.annotation.CacheResult;
import javax.inject.Inject;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.core.Response;
import java.util.List;
import java.util.Optional;

public class RefSerServiceFeatureService implements ServiceFeatureUpstreamService {

    public static final String REFSER = "refser";
    public static final String ERROR_WHEN_TRYING_UPDATE_SERVICE_FEATURES_FROM_REFSER_S = "Error when trying update service features from REFSER [%s]";
    public static final String ERROR_WHEN_TRYING_UPDATE_SERVICE_FEATURES_FROM_REFSER = "Error when trying update service features from REFSER (): HTTP ERROR CODE [%s], Reason [%s]";
    @Logging
    private Logger log;

    @Configuration(REFSER)
    private ClientConfig config;

    private static final String SERVICE = "RefSer";

    @Jpa
    @Inject
    private Repository<ServiceFeature, String> serviceFeatureRepository;

    @Inject
    private Factory<ServiceFeature> serviceFeatureFactory;

    @Inject
    @ModelMapper
    private Assembler<ServiceFeature, ServiceFeatureRefser> serviceFeatureAssembler;


    private List<ServiceFeatureRefser> getUpstreamServiceFeatures() {
        try {
            Invocation.Builder builder = RestClientUtilities.prepareBuilder(config);
            Response response = builder.get();
            return processResponse(response);
        } catch (Exception e) {
            throw new WebExeption(String.format(ERROR_WHEN_TRYING_UPDATE_SERVICE_FEATURES_FROM_REFSER_S, e.getMessage()), e);
        }
    }


    private List<ServiceFeatureRefser> processResponse(Response response) {
        switch (response.getStatus()) {
            case 200:
                String payload = response.readEntity(String.class);
                try {
                    return JsonConverter.convert(payload, new TypeReference<List<ServiceFeatureRefser>>() {
                    });
                } catch (JsonParseException e) {
                    throw new WebExeption(e.getMessage(), e);
                }
            default:
                throw new WebExeption(String.format(ERROR_WHEN_TRYING_UPDATE_SERVICE_FEATURES_FROM_REFSER, response.getStatus(), response.getStatusInfo().getReasonPhrase()));
        }
    }

    @Override
    @Transactional
    @JpaUnit("rcz")
    public void update() {
        log.info("start recovery of service feature by the cache service");
        updateFromUpstream();
    }

    @CacheResult(cacheName = "refSer")
    protected List<ServiceFeatureRefser> updateFromUpstream() {
        final List<ServiceFeatureRefser> upstreamServiceFeatures = getUpstreamServiceFeatures();
        upstreamServiceFeatures.forEach(item -> {
            ServiceFeature serviceFeature = serviceFeatureFactory.create();
            Optional<ServiceFeature> optServiceFeature = serviceFeatureRepository.get(item.getCode());
            if (optServiceFeature.isPresent()) {
                serviceFeature = optServiceFeature.orElseThrow(WebExeption::new);
            }
            serviceFeatureAssembler.mergeDtoIntoAggregate(item, serviceFeature);
            serviceFeatureRepository.addOrUpdate(serviceFeature);
        });
        return upstreamServiceFeatures;
    }


}
