package com.inetpsa.rcz.rest.action;

import com.inetpsa.rcz.domain.model.action.Action;
import com.inetpsa.rcz.domain.model.action.ActionService;
import com.inetpsa.rcz.rest.shared.Rels;
import io.swagger.annotations.Api;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

@Api
@Path(Rels.PATH_GET_ALL_ACTION)
@Produces({"application/json", "application/hal+json"})
public class ActionResource {

    @GET
    public Actions getActions() {
        Actions actions = new Actions();
        Action.ACTION_SET.stream().forEach(action -> {
            if (ActionService.REMOTE.equals(action.getActionService())) {
                actions.addRemote(action.getActionType().literal());
            } else if (ActionService.STOLEN.equals(action.getActionService())) {
                actions.addStolen(action.getActionType().literal());
            }
        });
        return actions;
    }
}
