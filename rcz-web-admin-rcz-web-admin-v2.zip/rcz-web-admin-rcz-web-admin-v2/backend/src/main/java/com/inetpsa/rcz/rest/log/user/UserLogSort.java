package com.inetpsa.rcz.rest.log.user;

import com.inetpsa.rcz.rest.shared.SortOrder;
import lombok.Data;
import org.seedstack.business.domain.SortOption;

import javax.ws.rs.DefaultValue;
import javax.ws.rs.QueryParam;

@Data
public class UserLogSort {

    public static final String SORT = "sort";
    public static final String ORDER = "order";

    @QueryParam(SORT)
    @DefaultValue("ENTRY_DATE")
    private ColumnSort sort;

    @QueryParam(ORDER)
    @DefaultValue("DESCENDING")
    private SortOrder order;

    public SortOption getSortOption() {
        return new SortOption().add(this.getSort().literal(), SortOption.Direction.valueOf(this.getOrder().name()));
    }

    public enum ColumnSort {

        USER_ID("userId"),
        EMAIL("email"),
        ENTRY_DATE("entryDate"),
        RESOURCE("resource"),
        LOG("log");

        private String literal;

        ColumnSort(String literal) {
            this.literal = literal;
        }

        public String literal() {
            return literal;
        }
    }
}
