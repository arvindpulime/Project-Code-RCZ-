package com.inetpsa.rcz.infrastructure.websocket.orange;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.text.MessageFormat;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DetailedDeliveryStatus {
    String commandStatus;
    String messageState;
    String networkErrorCode;

    @Override
    public String toString() {
        return MessageFormat.format("Detailed delivery status, command status[[0}], message state[{1}], network error code[{2}]", commandStatus, messageState, networkErrorCode);
    }
}