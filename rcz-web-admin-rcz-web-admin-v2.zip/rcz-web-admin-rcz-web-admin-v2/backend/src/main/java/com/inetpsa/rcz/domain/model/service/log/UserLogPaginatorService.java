package com.inetpsa.rcz.domain.model.service.log;

import com.inetpsa.rcz.domain.model.user.UserLog;
import com.inetpsa.rcz.rest.log.user.UserLogCriteria;
import com.inetpsa.rcz.rest.log.user.UserLogSort;
import com.inetpsa.rcz.rest.shared.hal.HalPageCriteria;
import org.seedstack.business.Service;
import org.seedstack.business.pagination.Page;

@Service
public interface UserLogPaginatorService {

    Page<UserLog> search(UserLogSort sort, UserLogCriteria criteria, HalPageCriteria halPageCriteria);

}
