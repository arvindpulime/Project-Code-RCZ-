package com.inetpsa.rcz.rest.sms;

import com.inetpsa.rcz.rest.shared.SortOrder;
import lombok.Data;
import org.seedstack.business.domain.SortOption;

import javax.ws.rs.DefaultValue;
import javax.ws.rs.QueryParam;

@Data
public class SmsSort {

    public static final String SORT = "sort";
    public static final String ORDER = "order";

    @QueryParam(SORT)
    @DefaultValue("SENDING_DATE")
    private ColumnSort sort;

    @QueryParam(ORDER)
    @DefaultValue("DESCENDING")
    private SortOrder order;

    public SortOption getSortOption() {
        return new SortOption().add(this.getSort().literal(), SortOption.Direction.valueOf(this.getOrder().name()));
    }

    public enum ColumnSort {

        UIN("uin"),
        TO("messages.to.value"),
        SENDING_DATE("sendingDate");

        private String literal;

        ColumnSort(String literal) {
            this.literal = literal;
        }

        public String literal() {
            return literal;
        }
    }
}
