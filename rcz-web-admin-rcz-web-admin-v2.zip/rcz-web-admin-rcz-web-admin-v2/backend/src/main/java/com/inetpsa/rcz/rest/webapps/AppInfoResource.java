package com.inetpsa.rcz.rest.webapps;


import com.inetpsa.rcz.domain.services.MonitoringService;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;

import static com.inetpsa.rcz.rest.shared.Rels.APP_INFO;
import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

@Path(APP_INFO)
public class AppInfoResource {

    @Inject
    private MonitoringService monitoringService;

    @GET
    @Produces({APPLICATION_JSON})
    public Response get() {
        return Response.ok(monitoringService.getAllApplicationMonitoringData()).build();
    }


}
