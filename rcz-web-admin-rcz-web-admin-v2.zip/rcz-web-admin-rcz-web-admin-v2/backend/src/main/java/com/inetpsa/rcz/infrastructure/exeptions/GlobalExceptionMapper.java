package com.inetpsa.rcz.infrastructure.exeptions;

import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

@Provider
public class GlobalExceptionMapper implements ExceptionMapper<Throwable> {
    @Override
    public Response toResponse(Throwable ex) {

        return Response
                .status(Response.Status.BAD_REQUEST)
                .build();
    }
}
