package com.inetpsa.rcz.rest.parameter;

import com.inetpsa.rcz.application.services.UserLogService;
import com.inetpsa.rcz.domain.model.parameter.Parameter;
import com.inetpsa.rcz.domain.model.user.ResourceType;
import com.inetpsa.rcz.domain.services.ParameterService;
import com.inetpsa.rcz.domain.utils.Base64Utils;
import com.inetpsa.rcz.rest.parameter.representation.ParameterRepresentation;
import org.seedstack.business.assembler.Assembler;
import org.seedstack.business.modelmapper.ModelMapper;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.LifecycleListener;
import org.seedstack.seed.Logging;
import org.seedstack.seed.security.Logical;
import org.seedstack.seed.security.RequiresRoles;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import java.lang.reflect.Field;

import static com.inetpsa.rcz.rest.shared.Rels.PATH_PARAMETER;
import static javax.ws.rs.core.MediaType.APPLICATION_JSON;

@Singleton
@JpaUnit("rcz")
@Path(PATH_PARAMETER)
public class ParametersResource implements LifecycleListener {

    @Inject
    private ParameterService parameterService;

    @Inject
    private UserLogService userLogService;

    @Logging
    private Logger logger;

    @Inject
    @ModelMapper
    Assembler<Parameter, ParameterRepresentation> assembler;

    @GET
    @Produces(APPLICATION_JSON)
    @RequiresRoles(logical = Logical.OR, value = {"role_super_administrator", "role_administrator"})
    public Response get() {
        try {
            return Response.ok(assembler.createDtoFromAggregate(parameterService.getAll())).build();
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PUT
    @Consumes(APPLICATION_JSON)
    @Produces(APPLICATION_JSON)
    @RequiresRoles(logical = Logical.OR, value = {"role_super_administrator"})
    public Response update(ParameterRepresentation newParameter) {
        try {

            Parameter parameter = parameterService.getAll();
            if (null != newParameter.getSms().getOrange().getPassword()
                    && !newParameter.getSms().getOrange().getPassword().isEmpty()
                    && !parameter.getSms().getOrange().getPassword()
                    .equals(newParameter.getSms().getOrange().getPassword())
            ) {
                newParameter.getSms().getOrange().setPassword(Base64Utils.encode(newParameter.getSms().getOrange().getPassword()));
            }
            assembler.mergeDtoIntoAggregate(newParameter, parameter);
            String userLogDescription = buildUserLogDescription(parameter, parameterService.getAll());

            parameterService.update(parameter);
            userLogService.addEntry(ResourceType.PARAMETER_UPDATE, userLogDescription);
            return Response.ok(assembler.createDtoFromAggregate(parameter)).build();
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).build();
        }
    }

    private String buildUserLogDescription(Object toUpdate, Object parameter) {

        Class classParameter = parameter.getClass();
        Class classToUpdate = toUpdate.getClass();

        StringBuilder builder = new StringBuilder("Changed values : ");
        for (Field oldField : classParameter.getDeclaredFields()) {
            Field newField = null;
            String oldValue = null;
            String newValue = null;
            try {
                oldField.setAccessible(true);
                System.out.println("oldField.getName = " + oldField.getName());
                oldValue = oldField.get(parameter).toString();
                newField = classToUpdate.getDeclaredField(oldField.getName());
                newField.setAccessible(true);
                newValue = newField.get(toUpdate).toString();
            } catch (IllegalAccessException | NoSuchFieldException e) {
                e.printStackTrace();
            }
            if (!oldValue.equals(newValue)) {
                builder.append("[ The parameter ");
                builder.append(oldField.getName());
                builder.append(" went from ");
                builder.append("'");
                builder.append(oldValue);
                builder.append("' ");
                builder.append("to ");
                builder.append("'");
                builder.append(newValue);
                builder.append("'");
                builder.append(" ] ");
            }
            oldField.setAccessible(false);
            newField.setAccessible(false);
        }
//        System.out.println("builder = " + builder);
        return builder.toString();
    }

}
