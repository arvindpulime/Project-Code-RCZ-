package com.inetpsa.rcz.rest.exchange;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.inetpsa.rcz.domain.model.action.Action;
import com.inetpsa.rcz.domain.model.enums.CallerType;
import com.inetpsa.rcz.domain.model.enums.ExchangeStatus;
import com.inetpsa.rcz.domain.model.enums.ProcessStatus;
import com.inetpsa.rcz.domain.model.enums.ResponseStatus;
import com.inetpsa.rcz.domain.model.exchange.ExchangeLight;
import lombok.Data;
import org.seedstack.business.assembler.DtoOf;
import org.seedstack.seed.rest.hal.HalRepresentation;

import java.util.Date;

import static com.inetpsa.rcz.domain.model.payload.ValidationPattern.PATTERN_DATE_FRONT;

@Data
@DtoOf(ExchangeLight.class)
public class ExchangeRepresentation extends HalRepresentation {

    private String id;

    private Action action;

    private ExchangeStatus status;

    private String topic;

    private String uin;

    private String callerId;

    private CallerType callerType;

    private String correlationId;

    private String vin;

    private ProcessStatus processStatus;

    private ResponseStatus responseStatus;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = PATTERN_DATE_FRONT)
    private Date requestReceivedDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = PATTERN_DATE_FRONT)
    private Date requestSentDate;
}
