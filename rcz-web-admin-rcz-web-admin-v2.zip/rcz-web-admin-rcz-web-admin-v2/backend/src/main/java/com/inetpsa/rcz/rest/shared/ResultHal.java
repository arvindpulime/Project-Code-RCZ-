package com.inetpsa.rcz.rest.shared;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import org.seedstack.seed.rest.hal.HalRepresentation;
import org.seedstack.seed.rest.hal.Link;

public class ResultHal<T> extends HalRepresentation {

    private Page page;

    public ResultHal() {
    }

    public ResultHal(String name, Result<T> result, Link selfBuilder, RangeInfo rangeInfo) {
        embedded(name, result.getResult());

        page = new Page(rangeInfo.getOffset(), rangeInfo.getSize(), result.getFullSize());


        self(new Link(selfBuilder
                .set(RangeInfo.OFFSET_NAME, result.getOffset())
                .set(RangeInfo.SIZE_NAME, result.getSize())));

        if (((result.getOffset() + 1) + result.getSize()) < result.getFullSize()) {
            link("next", new Link(selfBuilder
                    .set(RangeInfo.OFFSET_NAME, result.getOffset() + result.getSize())
                    .set(RangeInfo.SIZE_NAME, result.getSize())));
        }

        if (result.getOffset() != 0) {
            link("previous", new Link(selfBuilder
                    .set(RangeInfo.OFFSET_NAME, (rangeInfo.getOffset() - rangeInfo.getSize()))
                    .set(RangeInfo.SIZE_NAME, rangeInfo.getSize())));
        }
    }

    public Page getPage() {
        return page;
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public final class Page {
        private long number;
        private long size;
        private long totalPages;
        private long totalElements;

        public Page(long number, long size, long totalElements) {
            this.number = number;
            this.size = size;
            this.totalElements = totalElements;
            Double value = Math.ceil((float) totalElements / (float) size);
            this.totalPages = value.longValue();
        }

        public long getNumber() {
            return number;
        }

        public long getSize() {
            return size;
        }

        public long getTotalPages() {
            return totalPages;
        }

        public long getTotalElements() {
            return totalElements;
        }
    }
}
