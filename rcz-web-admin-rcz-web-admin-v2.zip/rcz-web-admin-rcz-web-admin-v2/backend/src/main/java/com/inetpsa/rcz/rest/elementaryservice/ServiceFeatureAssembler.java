package com.inetpsa.rcz.rest.elementaryservice;

import com.inetpsa.rcz.domain.model.action.Action;
import com.inetpsa.rcz.domain.model.action.ActionService;
import com.inetpsa.rcz.domain.model.action.ActionType;
import com.inetpsa.rcz.domain.model.service.ServiceFeature;
import com.inetpsa.rcz.rest.shared.Rels;
import org.seedstack.business.assembler.BaseAssembler;
import org.seedstack.seed.rest.RelRegistry;
import org.seedstack.seed.rest.hal.Link;

import javax.inject.Inject;

public class ServiceFeatureAssembler extends BaseAssembler<ServiceFeature, ServiceFeatureRepresentation> {


    public static final String CODE = "code";
    @Inject
    private RelRegistry relRegistry;


    @Override
    public void mergeAggregateIntoDto(ServiceFeature serviceFeature, ServiceFeatureRepresentation serviceFeatureRepresentation) {
        serviceFeatureRepresentation.setCode(serviceFeature.getId());
        serviceFeatureRepresentation.setLabel(serviceFeature.getLabel());
        serviceFeatureRepresentation.setShortLabel(serviceFeature.getShortLabel());
        serviceFeatureRepresentation.setStartDate(serviceFeature.getStartDate());
        serviceFeatureRepresentation.setEndDate(serviceFeature.getEndDate());
        serviceFeatureRepresentation.setSuspended(serviceFeature.getSuspended());
        serviceFeatureRepresentation.setDeleted(serviceFeature.getDeleted());


        if (serviceFeature.getActions() != null) {
            serviceFeature.getActions().stream().forEach(action -> {
                if (ActionService.REMOTE.equals(action.getActionService()) && !ActionType.VEHICLE_STATE.equals(action.getActionType()) && !ActionType.REQUEST_STATE.equals(action.getActionType()) && !ActionType.VEHICLE_INFO.equals(action.getActionType())) {
                    serviceFeatureRepresentation.getActions().addRemote(action.getActionType().literal());
                } else if (ActionService.STOLEN.equals(action.getActionService()) && !ActionType.VEHICLE_STATE.equals(action.getActionType()) && !ActionType.REQUEST_STATE.equals(action.getActionType())) {
                    serviceFeatureRepresentation.getActions().addStolen(action.getActionType().literal());
                }
            });
        }
        Link self = relRegistry.uri(Rels.SERVICE_FEATURE);
        self.set(CODE, serviceFeatureRepresentation.getCode());
        serviceFeatureRepresentation.self(self);
    }

    @Override
    public void mergeDtoIntoAggregate(ServiceFeatureRepresentation serviceFeatureRepresentation, ServiceFeature serviceFeature) {
        serviceFeature.getActions().clear();
        if (serviceFeatureRepresentation.getActions() != null) {
            if (serviceFeatureRepresentation.getActions().getRemote() != null && !serviceFeatureRepresentation.getActions().getRemote().isEmpty()) {
                serviceFeature.addAction(Action.VEHICLE_STATE);
                serviceFeature.addAction(Action.REQUEST_STATE);
                serviceFeature.addAction(Action.LOW_POWER_INFO);
                serviceFeatureRepresentation.getActions().getRemote().stream().forEach(action -> serviceFeature.addAction(Action.create(ActionService.REMOTE, ActionType.fromValue(action))));
            }
            if (serviceFeatureRepresentation.getActions().getStolen() != null && !serviceFeatureRepresentation.getActions().getStolen().isEmpty()) {
                serviceFeature.addAction(Action.VEHICLE_STATE_STOLEN);
                serviceFeature.addAction(Action.REQUEST_STATE_STOLEN);
                serviceFeature.addAction(Action.LOW_POWER_INFO_STOLEN);
                serviceFeatureRepresentation.getActions().getStolen().stream().forEach(action -> serviceFeature.addAction(Action.create(ActionService.STOLEN, ActionType.fromValue(action))));
            }
        }
        if (serviceFeature.getActions() != null && !serviceFeature.getActions().isEmpty()) {
            serviceFeature.addAction(Action.VEHICLE_INFO);
        }
    }
}
