package com.inetpsa.rcz.rest.log;

import javax.ws.rs.QueryParam;

/**
 * @author tuan.docao@ext.mpsa.com
 */
public class SearchQuery {

    @QueryParam("level")
    private String level;

    @QueryParam("exchange")
    private String exchange;

    @QueryParam("from")
    private Long from;

    @QueryParam("to")
    private Long to;

    @QueryParam("instance")
    private String instance;

    public SearchQuery() {
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getExchange() {
        return exchange;
    }

    public void setExchange(String exchange) {
        this.exchange = exchange;
    }

    public Long getFrom() {
        return from;
    }

    public void setFrom(Long from) {
        this.from = from;
    }

    public Long getTo() {
        return to;
    }

    public void setTo(Long to) {
        this.to = to;
    }

    public String getInstance() {
        return instance;
    }

    public void setInstance(String instance) {
        this.instance = instance;
    }
}
