package com.inetpsa.rcz.rest.vehicle;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import javax.ws.rs.QueryParam;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(NON_NULL)
public class VehicleCriteria {

    public static final String COL_ID = "id";
    public static final String COL_VIN = "vin";
    public static final String COL_BTA_TYPE = "btaType";
    public static final String COL_MSISDN = "msisdn";

    public static final String PARAM_ID = "id";
    public static final String PARAM_VIN = "vin";
    public static final String PARAM_BTA_TYPE = "btaType";
    public static final String PARAM_MSISDN = "msisdn";


    @QueryParam(PARAM_ID)
    private String id;

    @QueryParam(PARAM_VIN)
    private String vin;

    @QueryParam(PARAM_BTA_TYPE)
    private String btaType;

    @QueryParam(PARAM_MSISDN)
    private String msisdn;

}
