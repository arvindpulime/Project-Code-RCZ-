package com.inetpsa.rcz.rest.log.list;

import com.inetpsa.rcz.rest.log.SearchQuery;
import com.inetpsa.rcz.rest.shared.Range;
import com.inetpsa.rcz.rest.shared.Result;
import com.inetpsa.rcz.rest.shared.SortOrder;
import org.seedstack.business.Service;

import java.util.List;
import java.util.Set;

/**
 * @author tuan.docao@ext.mpsa.com
 */
@Service
public interface LogFinder {

    Result<LogRepresentation> findLogRepresentations(Range range, SortType sortType, SortOrder sortOrder, SearchQuery searchQuery);

    List<String> findAvailableLevels();

    Set<String> findAvailableInstances();
}
