package com.inetpsa.rcz.domain.model.repository;

import com.inetpsa.rcz.domain.model.sms.Sms;
import org.seedstack.business.domain.Repository;

public interface SmsRepository extends Repository<Sms, String> {
}