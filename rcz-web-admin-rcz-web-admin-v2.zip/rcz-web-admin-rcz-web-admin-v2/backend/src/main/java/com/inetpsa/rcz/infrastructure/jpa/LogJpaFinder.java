package com.inetpsa.rcz.infrastructure.jpa;

import com.google.common.collect.Lists;
import com.inetpsa.rcz.domain.model.enums.LogLevel;
import com.inetpsa.rcz.domain.model.log.Log;
import com.inetpsa.rcz.domain.services.MonitoringService;
import com.inetpsa.rcz.rest.log.SearchQuery;
import com.inetpsa.rcz.rest.log.list.LogFinder;
import com.inetpsa.rcz.rest.log.list.LogOrder;
import com.inetpsa.rcz.rest.log.list.LogRepresentation;
import com.inetpsa.rcz.rest.log.list.SortType;
import com.inetpsa.rcz.rest.shared.Range;
import com.inetpsa.rcz.rest.shared.Result;
import com.inetpsa.rcz.rest.shared.SortOrder;
import org.seedstack.business.assembler.dsl.FluentAssembler;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.Logging;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.*;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import static com.inetpsa.rcz.rest.shared.MathUtils.long2int;

/**
 * @author tuan.docao@ext.mpsa.com
 */
@JpaUnit("rcz")
@Transactional
public class LogJpaFinder implements LogFinder {

    @Logging
    private Logger logger;

    @Inject
    private EntityManager entityManager;

    @Inject
    private FluentAssembler fluentAssembler;

    @Inject
    private MonitoringService monitoringService;

    private ParameterExpression<String> exchangeParam;

    private ParameterExpression<LogLevel> levelParam;

    private ParameterExpression<Date> fromParam, toParam;

    private ParameterExpression<String> instanceParam;

    private static final String EXCHANGE = "exchangeId";

    private static final String LEVEL = "logLevel";

    private static final String LOGDATE = "logDate";

    private static final String INSTANCE = "instanceId";

    private static final String QRY_LEVELS = "SELECT DISTINCT l.logLevel FROM Log AS l";

    private static final String QRY_INST = "SELECT DISTINCT l.instanceId FROM Log AS l";

    @Override
    public Result<LogRepresentation> findLogRepresentations(Range range, SortType sortType, SortOrder sortOrder, SearchQuery parameters) {
        LogOrder order = LogOrder.fromTypeAndDirection(sortType, sortOrder);

        CriteriaBuilder builder = entityManager.getCriteriaBuilder();
        exchangeParam = builder.parameter(String.class);
        levelParam = builder.parameter(LogLevel.class);
        fromParam = builder.parameter(Date.class);
        toParam = builder.parameter(Date.class);
        instanceParam = builder.parameter(String.class);

        List<Log> logs = getLogsOnCriteria(range, parameters, order);
        List<LogRepresentation> logRepresentations = fluentAssembler.assemble(logs).toListOf(LogRepresentation.class);

        return new Result<>(logRepresentations, range.getOffset(), countOnCriteria(parameters));
    }

    @Override
    public List<String> findAvailableLevels() {
        TypedQuery<LogLevel> query = entityManager.createQuery(QRY_LEVELS, LogLevel.class);
        List<LogLevel> result = query.getResultList();
        List<String> levels = Lists.newArrayList();
        levels.addAll(result.stream().map(Enum::name).collect(Collectors.toList()));
        return levels;
    }

    @Override
    public Set<String> findAvailableInstances() {
        return monitoringService.getAllMqttMonitoringData().keySet();
    }

    private Predicate[] where(Root<Log> root) {
        CriteriaBuilder builder = entityManager.getCriteriaBuilder();
        Predicate exchangeIdPredicate = builder.or(builder.isNull(exchangeParam), builder.equal(builder.upper(root.get(EXCHANGE)), exchangeParam));
        Predicate logLevelPredicate = builder.or(builder.isNull(levelParam), builder.equal(root.get(LEVEL), levelParam));
        Predicate fromPredicate = builder.or(builder.isNull(fromParam), builder.greaterThanOrEqualTo(root.get(LOGDATE), fromParam));
        Predicate toPredicate = builder.or(builder.isNull(toParam), builder.lessThanOrEqualTo(root.get(LOGDATE), toParam));
        Predicate instancePredicate = builder.or(builder.isNull(instanceParam), builder.equal(builder.upper(root.get(INSTANCE)), instanceParam));
        return new Predicate[]{exchangeIdPredicate, logLevelPredicate, fromPredicate, toPredicate, instancePredicate};
    }

    private <T> void setQueryParameters(TypedQuery<T> typedQuery, SearchQuery parameters) {
        String exchange = parameters.getExchange();
        if (exchange != null) {
            typedQuery.setParameter(exchangeParam, exchange.toUpperCase());
        } else {
            typedQuery.setParameter(exchangeParam, null);
        }

        LogLevel logLevel = null;
        if (parameters.getLevel() != null && !parameters.getLevel().equals("")) {
            try {
                String upperLevel = parameters.getLevel().toUpperCase();
                logLevel = LogLevel.valueOf(upperLevel);
            } catch (IllegalArgumentException e) {
                logger.warn("No such level");
            }
        }
        typedQuery.setParameter(levelParam, logLevel);

        Date from = null;
        if (parameters.getFrom() != null) {
            from = new Date(parameters.getFrom());
        }
        Date to = null;
        if (parameters.getTo() != null) {
            to = new Date(parameters.getTo());
        }

        typedQuery.setParameter(fromParam, from);
        typedQuery.setParameter(toParam, to);

        String instance = parameters.getInstance();
        if (instance != null) {
            typedQuery.setParameter(instanceParam, instance.toUpperCase());
        } else {
            typedQuery.setParameter(instanceParam, null);
        }
    }

    private Order orderBy(Root<Log> root, LogOrder logOrder) {
        CriteriaBuilder builder = entityManager.getCriteriaBuilder();
        Expression<Log> exp = root.get(logOrder.getSortType().name().toLowerCase());

        if (SortOrder.ASCENDING.equals(logOrder.getSortOrder())) {
            return builder.asc(exp);
        }
        return builder.desc(exp);
    }

    private long countOnCriteria(SearchQuery parameters) {
        CriteriaBuilder builder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Long> cq = builder.createQuery(Long.class);
        Root<Log> root = cq.from(Log.class);

        cq.select(builder.count(root));
        cq.where(where(root));

        TypedQuery<Long> query = entityManager.createQuery(cq);
        setQueryParameters(query, parameters);

        return query.getSingleResult();
    }

    private List<Log> getLogsOnCriteria(Range range, SearchQuery parameters, LogOrder order) {
        CriteriaBuilder builder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Log> cq = builder.createQuery(Log.class);
        Root<Log> root = cq.from(Log.class);

        cq.select(root);
        cq.where(where(root));
        cq.orderBy(orderBy(root, order));

        TypedQuery<Log> query = entityManager.createQuery(cq)
                .setFirstResult(long2int(range.getOffset()))
                .setMaxResults(long2int(range.getSize()));
        setQueryParameters(query, parameters);

        return query.getResultList();
    }

}
