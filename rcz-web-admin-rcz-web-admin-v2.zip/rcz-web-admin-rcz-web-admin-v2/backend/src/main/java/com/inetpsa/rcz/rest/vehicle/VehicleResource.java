package com.inetpsa.rcz.rest.vehicle;

import com.inetpsa.rcz.domain.model.service.vehicle.VehiclePaginatorService;
import com.inetpsa.rcz.domain.model.vehicle.Vehicle;
import com.inetpsa.rcz.domain.services.VehicleService;
import com.inetpsa.rcz.rest.shared.hal.HalPageCriteria;
import com.inetpsa.rcz.rest.shared.hal.HalPageRepresentation;
import org.apache.commons.lang3.StringUtils;
import org.seedstack.business.assembler.Assembler;
import org.seedstack.business.modelmapper.ModelMapper;
import org.seedstack.business.pagination.Page;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.rest.Rel;
import org.seedstack.seed.rest.RelRegistry;
import org.seedstack.seed.rest.hal.Link;
import org.seedstack.seed.security.Logical;
import org.seedstack.seed.security.RequiresRoles;
import org.seedstack.seed.transaction.Transactional;

import javax.inject.Inject;
import javax.ws.rs.BeanParam;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;
import java.util.List;
import java.util.stream.Collectors;

import static com.inetpsa.rcz.rest.shared.Rels.*;
import static com.inetpsa.rcz.rest.vehicle.VehicleCriteria.*;
import static com.inetpsa.rcz.rest.vehicle.VehicleSort.ORDER;
import static com.inetpsa.rcz.rest.vehicle.VehicleSort.SORT;

@Path("/")
@JpaUnit("rcz")
@Produces({"application/json", "application/hal+json"})
public class VehicleResource {

    @Inject
    private VehicleService vehicleService;

    @Inject
    private VehiclePaginatorService vehiclePaginatorService;

    @Inject
    private RelRegistry relRegistry;

    @Inject
    @ModelMapper
    private Assembler<Vehicle, VehicleRepresentation> vehicleAssembler;

    @GET
    @Path(PATH_VEHICLES)
    @Transactional
    @Rel(value = REL_VEHICLES, home = true)
    @RequiresRoles(logical = Logical.OR, value = {"role_super_administrator", "role_administrator", "role_reader"})
    public Response list(@BeanParam VehicleSort sort,
                         @BeanParam VehicleCriteria criteria,
                         @BeanParam HalPageCriteria halPageCriteria) {


        Page<Vehicle> page = vehiclePaginatorService.search(sort, criteria, halPageCriteria);

        List<VehicleRepresentation> result = page.getItems().stream().map(vehicle ->
                (VehicleRepresentation) vehicleAssembler.createDtoFromAggregate(vehicle)
                        .self(relRegistry.uri(REL_VEHICLES))).collect(Collectors.toList());

        Link self = relRegistry.uri(EXCHANGES);
        addParameters(self, criteria, sort);
        HalPageRepresentation<VehicleRepresentation> exchanges = new HalPageRepresentation<>("vehicles", self, result, halPageCriteria.getPageNumber(), halPageCriteria.getPageSize(), page.getTotalSize());
        return Response.ok(exchanges).build();


    }


    private void addParameters(Link self, VehicleCriteria criteria, VehicleSort sort) {
        if (StringUtils.isNotBlank(criteria.getId())) {
            self.set(PARAM_ID, criteria.getId());
        }
        if (criteria.getId() != null) {
            self.set(PARAM_ID, criteria.getId());
        }
        if (criteria.getVin() != null) {
            self.set(PARAM_VIN, criteria.getVin());
        }
        if (criteria.getMsisdn() != null) {
            self.set(PARAM_MSISDN, criteria.getMsisdn());
        }
        if (criteria.getBtaType() != null) {
            self.set(PARAM_BTA_TYPE, criteria.getMsisdn());
        }
        self.set(ORDER, sort.getOrder().name());
        self.set(SORT, sort.getSort().name());
    }
}
