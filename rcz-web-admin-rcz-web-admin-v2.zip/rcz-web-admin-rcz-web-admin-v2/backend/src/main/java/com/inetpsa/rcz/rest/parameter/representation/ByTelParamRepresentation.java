package com.inetpsa.rcz.rest.parameter.representation;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class ByTelParamRepresentation {

    private String protocolVersion;
    private String adm;
    private String idOffer;
    private String messageFormat;
    private String path;
    private String targetType;
    private String uri;
    private String icp;
}