package com.inetpsa.rcz.domain.model.service.request;


import com.inetpsa.rcz.domain.model.action.ActionService;
import com.inetpsa.rcz.domain.model.action.ActionType;
import com.inetpsa.rcz.domain.model.api.request.Request;
import com.inetpsa.rcz.domain.model.api.request.RequestLight;
import com.inetpsa.rcz.domain.model.api.request.RequestStatus;
import com.inetpsa.rcz.domain.model.enums.CallerType;
import com.inetpsa.rcz.rest.request.RequestCriteria;
import com.inetpsa.rcz.rest.request.RequestSort;
import com.inetpsa.rcz.rest.shared.hal.HalPageCriteria;
import org.apache.commons.lang3.EnumUtils;
import org.seedstack.business.domain.Repository;
import org.seedstack.business.pagination.Page;
import org.seedstack.business.pagination.dsl.Paginator;
import org.seedstack.business.specification.AndSpecification;
import org.seedstack.business.specification.OrSpecification;
import org.seedstack.business.specification.Specification;
import org.seedstack.business.specification.dsl.SpecificationBuilder;
import org.seedstack.jpa.Jpa;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static com.inetpsa.rcz.rest.request.RequestCriteria.*;

public class RequestServiceImpl implements RequestService {

    @Inject
    private Paginator paginator;

    @Jpa
    @Inject
    private Repository<RequestLight, String> requestLightRepository;

    @Jpa
    @Inject
    private Repository<Request, String> requestRepository;

    @Override
    public Page<RequestLight> search(RequestSort sort, RequestCriteria criteria, HalPageCriteria halPageCriteria) {
        Specification<RequestLight> specification = getSpecification(criteria);

        return paginator
                .paginate(requestLightRepository)
                .withOptions(sort.getSortOption())
                .byPage(halPageCriteria.getPageNumber())
                .limit(halPageCriteria.getPageSize())
                .matching(specification)
                ;
    }

    @Override
    public Optional<Request> getRequest(String id) {
        return requestRepository.get(id);
    }


    private Specification<RequestLight> getSpecification(RequestCriteria criteria) {

        SpecificationBuilder specificationBuilder = requestLightRepository.getSpecificationBuilder();

        List<Specification<RequestLight>> specifications = new ArrayList<>();


        if (criteria.getId() != null) {
            specifications.add(specificationBuilder.ofAggregate(RequestLight.class).property(COL_ID).equalTo(criteria.getId()).build());
        }
        if (criteria.getVin() != null) {
            specifications.add(specificationBuilder.ofAggregate(RequestLight.class).property(COL_VIN).equalTo(criteria.getVin().trim()).ignoringCase().build());
        }
        if (criteria.getCallerId() != null) {
            specifications.add(specificationBuilder.ofAggregate(RequestLight.class).property(COL_CALLER_ID).equalTo(criteria.getCallerId().trim()).ignoringCase().build());
        }
        if (criteria.getCustomerId() != null) {
            specifications.add(specificationBuilder.ofAggregate(RequestLight.class).property(COL_CUSTOMER_ID).equalTo(criteria.getCustomerId().trim()).ignoringCase().build());
        }

        if (criteria.getCallerTypes() != null) {
            specifications.add(buildEnumSpecification(specificationBuilder, criteria.getCallerTypes(), COL_CALLER_TYPE, CallerType.class));
        }
        if (criteria.getActionTypes() != null) {
            specifications.add(buildEnumSpecification(specificationBuilder, criteria.getActionTypes(), COL_ACTION_TYPE, ActionType.class));
        }
        if (criteria.getActionServices() != null) {
            specifications.add(buildEnumSpecification(specificationBuilder, criteria.getActionServices(), COL_ACTION_SERVICE, ActionService.class));
        }
        if (criteria.getRequestStatuses() != null) {
            specifications.add(buildEnumSpecification(specificationBuilder, criteria.getRequestStatuses(), COL_STATUS, RequestStatus.class));
        }

        if (specifications.isEmpty()) {
            return requestLightRepository.getSpecificationBuilder().of(RequestLight.class).all().build();
        }

        return new AndSpecification<>(specifications.toArray(new Specification[0]));
    }

    private <E extends Enum<E>> Specification<RequestLight> buildEnumSpecification(SpecificationBuilder specificationBuilder, String enums, String property, Class<E> clazz) {
        String[] values = enums.split(",");
        List<Specification<RequestLight>> specifications = new ArrayList<>();
        for (String value : values) {
            specifications.add(specificationBuilder.ofAggregate(RequestLight.class).property(property).equalTo(EnumUtils.getEnum(clazz, value)).build());

        }
        return new OrSpecification<>(specifications.toArray(new Specification[0]));
    }

}
