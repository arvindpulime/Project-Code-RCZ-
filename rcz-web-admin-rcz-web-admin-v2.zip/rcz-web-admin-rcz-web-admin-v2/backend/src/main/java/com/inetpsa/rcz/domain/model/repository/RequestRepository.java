package com.inetpsa.rcz.domain.model.repository;

import com.inetpsa.rcz.domain.model.api.request.Request;
import com.inetpsa.rcz.domain.model.api.request.RequestLight;
import org.seedstack.business.domain.Repository;

public interface RequestRepository extends Repository<RequestLight, String> {
}