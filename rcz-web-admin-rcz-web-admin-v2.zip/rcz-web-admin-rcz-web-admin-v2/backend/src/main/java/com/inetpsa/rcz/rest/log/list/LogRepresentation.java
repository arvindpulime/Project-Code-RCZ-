package com.inetpsa.rcz.rest.log.list;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.inetpsa.rcz.domain.model.log.Log;
import org.seedstack.business.assembler.AggregateId;
import org.seedstack.business.assembler.DtoOf;
import org.seedstack.seed.rest.hal.HalRepresentation;

import java.util.Date;

import static com.inetpsa.rcz.domain.model.payload.ValidationPattern.PATTERN_DATE_FRONT;

/**
 * @author tuan.docao@ext.mpsa.com
 */
@DtoOf(Log.class)
public class LogRepresentation extends HalRepresentation {

    protected String id;

    protected String level;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = PATTERN_DATE_FRONT)
    protected Date date;

    protected String message;

    protected String exchange;

    protected String topic;

    protected String serverInstance;

    public LogRepresentation() {
    }

    public LogRepresentation(String id, String level, Date date, String message, String exchange, String topic, String serverInstance) {
        this.id = id;
        this.level = level;
        this.date = date;
        this.message = message;
        this.exchange = exchange;
        this.topic = topic;
        this.serverInstance = serverInstance;
    }

    @AggregateId
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getExchange() {
        return exchange;
    }

    public void setExchange(String exchange) {
        this.exchange = exchange;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public String getServerInstance() {
        return serverInstance;
    }

    public void setServerInstance(String serverInstance) {
        this.serverInstance = serverInstance;
    }
}
