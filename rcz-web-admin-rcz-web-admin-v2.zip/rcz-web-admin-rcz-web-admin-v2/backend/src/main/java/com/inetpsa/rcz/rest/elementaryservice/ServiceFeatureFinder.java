package com.inetpsa.rcz.rest.elementaryservice;

import com.inetpsa.rcz.rest.shared.Range;
import com.inetpsa.rcz.rest.shared.Result;
import org.seedstack.business.Service;

@Service
public interface ServiceFeatureFinder {
    Result<ServiceFeatureRepresentation> findAll(Range range, ServiceFeatureSort serviceFeatureSort);
}
