package com.inetpsa.rcz.rest.log.user;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.inetpsa.rcz.domain.model.user.ResourceType;
import com.inetpsa.rcz.domain.model.user.UserLog;
import lombok.Data;
import org.seedstack.business.assembler.DtoOf;

import java.util.Date;

import static com.fasterxml.jackson.annotation.JsonFormat.Shape.STRING;
import static com.inetpsa.rcz.domain.model.payload.ValidationPattern.PATTERN_DATE_FRONT;

@Data
@DtoOf(UserLog.class)
public class UserLogRepresentation {

    private Long id;

    private String userId;

    private String email;

    @JsonFormat(shape = STRING, pattern = PATTERN_DATE_FRONT)
    private Date entryDate;

    private ResourceType resource;

    private String log;

}
