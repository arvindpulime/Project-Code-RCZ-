package com.inetpsa.rcz.rest.log.user;

import com.google.common.collect.Lists;
import com.inetpsa.rcz.domain.model.service.log.UserLogPaginatorService;
import com.inetpsa.rcz.domain.model.user.ResourceType;
import com.inetpsa.rcz.domain.model.user.UserLog;
import com.inetpsa.rcz.rest.shared.hal.HalPageCriteria;
import com.inetpsa.rcz.rest.shared.hal.HalPageRepresentation;
import io.swagger.annotations.Api;
import org.apache.commons.lang3.StringUtils;
import org.seedstack.business.assembler.Assembler;
import org.seedstack.business.modelmapper.ModelMapper;
import org.seedstack.business.pagination.Page;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.rest.Rel;
import org.seedstack.seed.rest.RelRegistry;
import org.seedstack.seed.rest.hal.Link;
import org.seedstack.seed.security.Logical;
import org.seedstack.seed.security.RequiresRoles;
import org.seedstack.seed.transaction.Transactional;

import javax.inject.Inject;
import javax.ws.rs.BeanParam;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;
import java.util.List;
import java.util.stream.Collectors;

import static com.inetpsa.rcz.rest.log.user.UserLogCriteria.PARAM_EMAIL;
import static com.inetpsa.rcz.rest.log.user.UserLogCriteria.PARAM_ENTRY_DATE_FROM;
import static com.inetpsa.rcz.rest.log.user.UserLogCriteria.PARAM_ENTRY_DATE_TO;
import static com.inetpsa.rcz.rest.log.user.UserLogCriteria.PARAM_RESOURCES;
import static com.inetpsa.rcz.rest.log.user.UserLogCriteria.PARAM_USER_ID;
import static com.inetpsa.rcz.rest.shared.Rels.USER_LOGS;
import static com.inetpsa.rcz.rest.shared.Rels.USER_RESOURCES;
import static com.inetpsa.rcz.rest.sms.SmsSort.ORDER;
import static com.inetpsa.rcz.rest.sms.SmsSort.SORT;

@Api
@Path("/")
@Transactional
@JpaUnit("rcz")
@Produces({"application/json", "application/hal+json"})
public class UserLogsResource {

    @Inject
    private RelRegistry relRegistry;

    @Inject
    private UserLogPaginatorService userLogPaginatorService;

    @Inject
    @ModelMapper
    private Assembler<UserLog, UserLogRepresentation> assembler;

    @GET
    @Path(USER_LOGS)
    @Rel(value = USER_LOGS, home = true)
    @RequiresRoles(logical = Logical.OR, value = {"role_super_administrator", "role_administrator", "role_reader"})
    public Response list(@BeanParam UserLogSort sort,
                         @BeanParam UserLogCriteria criteria,
                         @BeanParam HalPageCriteria halPageCriteria) {
        Page<UserLog> page = userLogPaginatorService.search(sort, criteria, halPageCriteria);
        List<UserLogRepresentation> result = page.getItems().stream().map(userLog -> {
            UserLogRepresentation representation = new UserLogRepresentation();
            assembler.mergeAggregateIntoDto(userLog, representation);
            return representation;
        }).collect(Collectors.toList());

        Link self = relRegistry.uri(USER_LOGS);
        addParameters(self, criteria, sort);
        HalPageRepresentation<UserLogRepresentation> exchanges = new HalPageRepresentation<>("userLogs", self, result, halPageCriteria.getPageNumber(), halPageCriteria.getPageSize(), page.getTotalSize());
        return Response.ok(exchanges).build();
    }

    @GET
    @Path(USER_RESOURCES)
    @Rel(value = USER_RESOURCES, home = true)
    @RequiresRoles(logical = Logical.OR, value = {"role_super_administrator", "role_administrator", "role_reader"})
    public Response resources() {
        return Response.ok(Lists.newArrayList(ResourceType.values())).build();
    }

    private void addParameters(Link self, UserLogCriteria criteria, UserLogSort sort) {
        if (StringUtils.isNotBlank(criteria.getUserId())) {
            self.set(PARAM_USER_ID, criteria.getUserId());
        }
        if (StringUtils.isNotBlank(criteria.getEmail())) {
            self.set(PARAM_EMAIL, criteria.getEmail());
        }
        if (criteria.getEntryDateFrom() != null) {
            self.set(PARAM_ENTRY_DATE_FROM, criteria.getEntryDateFrom());
        }
        if (criteria.getEntryDateTo() != null) {
            self.set(PARAM_ENTRY_DATE_TO, criteria.getEntryDateTo());
        }
        if (StringUtils.isNotBlank(criteria.getResources())) {
            self.set(PARAM_RESOURCES, criteria.getResources());
        }
        self.set(ORDER, sort.getOrder().name());
        self.set(SORT, sort.getSort().name());
    }

}
