package com.inetpsa.rcz.domain.model.service.vehicle;


import com.inetpsa.rcz.domain.model.vehicle.Vehicle;
import com.inetpsa.rcz.rest.shared.hal.HalPageCriteria;
import com.inetpsa.rcz.rest.vehicle.VehicleCriteria;
import com.inetpsa.rcz.rest.vehicle.VehicleSort;
import org.seedstack.business.Service;
import org.seedstack.business.pagination.Page;

@Service
public interface VehiclePaginatorService {

    Page<Vehicle> search(VehicleSort sort, VehicleCriteria criteria, HalPageCriteria halPageCriteria);

}
