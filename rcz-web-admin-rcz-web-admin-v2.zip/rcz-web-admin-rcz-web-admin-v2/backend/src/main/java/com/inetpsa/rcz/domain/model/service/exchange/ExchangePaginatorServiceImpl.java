package com.inetpsa.rcz.domain.model.service.exchange;

import com.inetpsa.rcz.domain.model.action.ActionService;
import com.inetpsa.rcz.domain.model.action.ActionType;
import com.inetpsa.rcz.domain.model.enums.CallerType;
import com.inetpsa.rcz.domain.model.enums.ExchangeStatus;
import com.inetpsa.rcz.domain.model.enums.ProcessStatus;
import com.inetpsa.rcz.domain.model.enums.ResponseStatus;
import com.inetpsa.rcz.domain.model.exchange.ExchangeLight;
import com.inetpsa.rcz.domain.model.service.ServiceFeature;
import com.inetpsa.rcz.rest.exchange.ExchangeCriteria;
import com.inetpsa.rcz.rest.exchange.ExchangeSort;
import com.inetpsa.rcz.rest.shared.hal.HalPageCriteria;
import org.apache.commons.lang3.EnumUtils;
import org.seedstack.business.domain.Repository;
import org.seedstack.business.pagination.Page;
import org.seedstack.business.pagination.dsl.Paginator;
import org.seedstack.business.specification.AndSpecification;
import org.seedstack.business.specification.OrSpecification;
import org.seedstack.business.specification.Specification;
import org.seedstack.business.specification.dsl.SpecificationBuilder;
import org.seedstack.jpa.Jpa;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static com.inetpsa.rcz.rest.elementaryservice.ServiceFeatureCriteria.END_DATE;
import static com.inetpsa.rcz.rest.exchange.ExchangeCriteria.*;

@Transactional
@JpaUnit("rcz")
public class ExchangePaginatorServiceImpl implements ExchangePaginatorService {

    @Inject
    private Paginator paginator;

    @Inject
    @Jpa
    private Repository<ExchangeLight, String> exchangeRepository;

    @Override
    public Page<ExchangeLight> search(ExchangeSort sort, ExchangeCriteria criteria, HalPageCriteria halPageCriteria) {
        Specification<ExchangeLight> specification = getSpecification(criteria);

        return paginator
                .paginate(exchangeRepository)
                .withOptions(sort.getSortOption())
                .byPage(halPageCriteria.getPageNumber())
                .limit(halPageCriteria.getPageSize())
                .matching(specification)
                ;
    }

    @Override
    public long count(ExchangeCriteria criteria) {
        return exchangeRepository.count(getSpecification(criteria));
    }

    private Specification<ExchangeLight> getSpecification(ExchangeCriteria criteria) {

        SpecificationBuilder specificationBuilder = exchangeRepository.getSpecificationBuilder();

        List<Specification<ExchangeLight>> specifications = new ArrayList<>();

        if (criteria.getReceivedDateFrom() != null && criteria.getReceivedDateTo() != null) {
            specifications.add(specificationBuilder.ofAggregate(ExchangeLight.class)
                    .property(RECEIVED_DATE).greaterThanOrEqualTo(new Date(criteria.getReceivedDateFrom())).build());
            specifications.add(specificationBuilder.ofAggregate(ExchangeLight.class)
                    .property(RECEIVED_DATE).lessThanOrEqualTo(new Date(criteria.getReceivedDateTo())).build());
        }

        if (criteria.getId() != null) {
            specifications.add(specificationBuilder.ofAggregate(ExchangeLight.class).property(ID).equalTo(criteria.getId().trim()).build());
        }



        if (criteria.getActionTypes() != null && !criteria.getActionTypes().isEmpty()) {
            specifications.add(buildEnumSpecification(specificationBuilder, criteria.getActionTypes(), ACTION_TYPE, ActionType.class));
        }

        if (criteria.getActionServices() != null && !criteria.getActionServices().isEmpty()) {
            specifications.add(buildEnumSpecification(specificationBuilder, criteria.getActionServices(), ACTION_SERVICE, ActionService.class));
        }

        if (criteria.getStatuses() != null && !criteria.getStatuses().isEmpty()) {
            specifications.add(buildEnumSpecification(specificationBuilder, criteria.getStatuses(), STATUS, ExchangeStatus.class));
        }

        if (criteria.getProcessStatuses() != null && !criteria.getProcessStatuses().isEmpty()) {
            specifications.add(buildEnumSpecification(specificationBuilder, criteria.getProcessStatuses(), PROCESS_STATUS, ProcessStatus.class));
        }

        if (criteria.getResponseStatuses() != null && !criteria.getResponseStatuses().isEmpty()) {
            specifications.add(buildEnumSpecification(specificationBuilder, criteria.getResponseStatuses(), RESPONSE_STATUS, ResponseStatus.class));
        }

        if (criteria.getCallerTypes() != null && !criteria.getCallerTypes().isEmpty()) {
            specifications.add(buildEnumSpecification(specificationBuilder, criteria.getCallerTypes(), CALLER_TYPE, CallerType.class));
        }

        if (criteria.getUin() != null) {
            specifications.add(specificationBuilder.ofAggregate(ExchangeLight.class).property(UIN).equalTo(criteria.getUin().trim()).ignoringCase().build());
        }

        if (criteria.getCallerId() != null) {
            specifications.add(specificationBuilder.ofAggregate(ExchangeLight.class).property(CALLER_ID).equalTo(criteria.getCallerId().trim()).build());
        }

        if (criteria.getCorrelationId() != null) {
            specifications.add(specificationBuilder.ofAggregate(ExchangeLight.class).property(CORRELATION_ID).equalTo(criteria.getCorrelationId().trim()).build());
        }

        if (criteria.getVin() != null) {
            specifications.add(specificationBuilder.ofAggregate(ExchangeLight.class).property(VIN).equalTo(criteria.getVin().trim()).ignoringCase().build());
        }

        if (criteria.getProcessStatus() != null) {
            specifications.add(specificationBuilder.ofAggregate(ExchangeLight.class).property(PROCESS_STATUS).equalTo(criteria.getProcessStatus()).build());
        }

        if (criteria.getResponseStatus() != null) {
            specifications.add(specificationBuilder.ofAggregate(ExchangeLight.class).property(RESPONSE_STATUS).equalTo(criteria.getResponseStatus()).build());
        }


        if (criteria.getSentDateFrom() != null && criteria.getSentDateTo() != null) {
            specifications.add(specificationBuilder.ofAggregate(ExchangeLight.class)
                    .property(SENT_DATE).greaterThanOrEqualTo(new Date(criteria.getSentDateFrom())).build());
            specifications.add(specificationBuilder.ofAggregate(ExchangeLight.class)
                    .property(SENT_DATE).lessThanOrEqualTo(new Date(criteria.getSentDateTo())).build());
        }

        if (specifications.isEmpty()) {
            return exchangeRepository.getSpecificationBuilder().of(ExchangeLight.class).all().build();
        }

        return new AndSpecification<>(specifications.toArray(new Specification[0]));
    }

    private <E extends Enum<E>> Specification<ExchangeLight> buildEnumSpecification(SpecificationBuilder specificationBuilder, String enums, String property, Class<E> clazz) {
        String[] values = enums.split(",");
        List<Specification<ExchangeLight>> specifications = new ArrayList<>();
        for (String value : values) {
            specifications.add(specificationBuilder.ofAggregate(ExchangeLight.class).property(property).equalTo(EnumUtils.getEnum(clazz, value)).build());

        }
        return new OrSpecification<>(specifications.toArray(new Specification[0]));
    }


}
