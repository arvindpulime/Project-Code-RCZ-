package com.inetpsa.rcz.rest.shared;

public enum SortOrder {
    ASCENDING,
    DESCENDING;

    public static SortOrder fromOrDefault(String sort) {
        if (sort != null && !"".equals(sort)) {
            try {
                return SortOrder.valueOf(sort.toUpperCase());
            } catch (IllegalArgumentException e) {
                throw new IllegalArgumentException("The sort order value can only be: ASCENDING or DESCENDING");
            }
        } else {
            return SortOrder.ASCENDING;
        }
    }
}
