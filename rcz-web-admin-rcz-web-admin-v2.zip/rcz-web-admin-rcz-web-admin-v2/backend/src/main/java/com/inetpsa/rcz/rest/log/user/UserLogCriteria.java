package com.inetpsa.rcz.rest.log.user;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import javax.ws.rs.QueryParam;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(NON_NULL)
public class UserLogCriteria {

    public static final String COL_USER_ID = "userId";
    public static final String COL_EMAIL = "email";
    public static final String COL_ENTRY_DATE= "entryDate";
    public static final String COL_RESOURCE = "resource";
    public static final String COL_LOG = "log";

    public static final String PARAM_USER_ID = "userId";
    public static final String PARAM_EMAIL = "email";
    public static final String PARAM_ENTRY_DATE_FROM = "entryDateFrom";
    public static final String PARAM_ENTRY_DATE_TO = "entryDateTo";
    public static final String PARAM_RESOURCES = "resources";
    public static final String PARAM_LOG = "log";

    @QueryParam(PARAM_USER_ID)
    private String userId;

    @QueryParam(PARAM_EMAIL)
    private String email;

    @QueryParam(PARAM_ENTRY_DATE_FROM)
    private Long entryDateFrom;

    @QueryParam(PARAM_ENTRY_DATE_TO)
    private Long entryDateTo;

    @QueryParam(PARAM_RESOURCES)
    private String resources;

    @QueryParam(PARAM_LOG)
    private String log;

}
