package com.inetpsa.rcz.infrastructure.jpa;

import com.inetpsa.rcz.domain.model.helper.Helper;
import com.inetpsa.rcz.rest.helper.HelperFinder;
import com.inetpsa.rcz.rest.helper.HelperRepresentation;
import org.seedstack.business.assembler.Assembler;
import org.seedstack.business.modelmapper.ModelMapper;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;

@JpaUnit("rcz")
@Transactional
public class HelperJpaFinder implements HelperFinder {

    @Inject
    private EntityManager entityManager;

    @Inject
    @ModelMapper
    private Assembler<Helper, HelperRepresentation> assembler;

    @Override
    public List<HelperRepresentation> findAll() {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Helper> q = cb.createQuery(Helper.class);
        Root<Helper> root = q.from(Helper.class);
        q.select(root);
        List<Helper> helpers = entityManager.createQuery(q).getResultList();
        List<HelperRepresentation> helperRepresentations = new ArrayList<>();
        helpers.stream().forEach(helper -> helperRepresentations.add(assembler.createDtoFromAggregate(helper)));
        return helperRepresentations;
    }
}
