package com.inetpsa.rcz.infrastructure.websocket.stomp.client;

import com.inetpsa.rcz.infrastructure.websocket.stomp.client.listener.StompConnectionListener;
import com.inetpsa.rcz.infrastructure.websocket.stomp.client.listener.StompMessageListener;
import com.inetpsa.rcz.infrastructure.websocket.stomp.client.spec.StompCommand;
import com.inetpsa.rcz.infrastructure.websocket.stomp.client.spec.StompFrame;
import com.inetpsa.rcz.infrastructure.websocket.stomp.client.spec.StompHeader;
import com.inetpsa.rcz.infrastructure.websocket.stomp.client.spec.StompSubscription;

import javax.websocket.Session;
import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * STOMP v1.2 client using `Java-WebSocket` WebSocket client implementation.
 */
public class WsStompClient {
    /**
     * Current STOMP implementation version.
     */
    private static final String STOMP_VERSION = "1.2";

    /**
     * STOMP topic subscription listeners.
     */
    private Map<Integer, StompSubscription> subscriptions = new HashMap<>();

    /**
     * STOMP connection status.
     */
    private boolean stompConnected;

    /**
     * STOMP connection listener.
     */
    private StompConnectionListener stompConnectionListener;

    private Session session;

    private WsStompConfig wsStompConfig;


    public WsStompClient(Session session, WsStompConfig wsStompConfig) {
        this.session = session;
        this.wsStompConfig = wsStompConfig;
    }

    public void onMessage(String message) {
        StompFrame stompFrame = StompFrame.fromString(message);

        switch (stompFrame.getCommand()) {
            case CONNECTED:
                stompConnected = true;
                if (stompConnectionListener != null) {
                    stompConnectionListener.onConnected();
                }
                break;
            case MESSAGE:
                Integer subscriptionId = Integer.valueOf(
                        stompFrame.getHeaders().get(StompHeader.SUBSCRIPTION.toString())
                );
                subscriptions.get(subscriptionId).getListener().onMessage(stompFrame);
                break;
            case DISCONNECT:
                stompConnected = false;
                if (stompConnectionListener != null) {
                    stompConnectionListener.onDisconnected();
                }
                break;
            default:
                onError(new WsStompException(MessageFormat.format("ORANGE error Frame exception : [{0}]", stompFrame.toString())));
                break;
        }
    }

    public void close() {
        stompConnected = false;
        if (stompConnectionListener != null) {
            stompConnectionListener.onDisconnected();
        }
        disconnectStomp();
    }

    public void onError(Exception ex) {
        close();
        throw new WsStompException(ex.getMessage(), ex);
    }

    /**
     * Create STOMP connection.
     */
    public void connect() {
        if (stompConnected) {
            return;
        }
        if (stompConnectionListener != null) {
            stompConnectionListener.onConnecting();
        }

        Map<String, String> headers = new HashMap<>();
        headers.put(StompHeader.ACCEPT_VERSION.toString(), STOMP_VERSION);
        //headers.put(StompHeader.HOST.toString(), wsStompConfig.getHost());
        headers.put(StompHeader.ACCEPT_VERSION.toString(), STOMP_VERSION);
        headers.put(StompHeader.HEART_BEAT.toString(), "1000,1000");
        headers.put(StompHeader.LOGIN.toString(), wsStompConfig.getLogin());
        headers.put(StompHeader.PASSCODE.toString(), wsStompConfig.getPassCode());
        headers.put(StompHeader.ACCEPT_VERSION.toString(), STOMP_VERSION);
        send(new StompFrame(StompCommand.CONNECT, headers).toString());
    }

    private void send(String text) {
        try {
            session.getBasicRemote().sendText(text);
        } catch (Exception e) {
            onError(new WsStompException(MessageFormat.format("ORANGE Sent Frame error : [{0}]", text), e));
        }
    }

    /**
     * Disconnect STOMP.
     */
    protected void disconnectStomp() {
        if (!stompConnected) {
            return;
        }

        send(new StompFrame(StompCommand.DISCONNECT).toString());
    }

    /**
     * Send text message to the server.
     *
     * @param destination destination
     * @param message     text message
     */
    public void send(String destination, String message) {
        send(destination, message, null);
    }

    /**
     * Send text message to the server.
     *
     * @param destination destination
     * @param message     text message
     * @param headers     (optional) additional headers
     */
    public void send(String destination, String message, Map<String, String> headers) {
        if (headers == null) {
            headers = new HashMap<>();
        }

        headers.put(StompHeader.DESTINATION.toString(), destination);
        StompFrame frame = new StompFrame(StompCommand.SEND, headers, message);

        send(frame.toString());
    }

    /**
     * Subscribe to a specific topic.
     *
     * @param destination topic destination
     * @param listener    listener
     * @return STOMP subscription data that can be used to unsubscribe
     */
    public StompSubscription subscribe(String destination, StompMessageListener listener) {
        StompSubscription subscription = new StompSubscription(UUID.randomUUID().hashCode(), destination, listener);

        Map<String, String> headers = new HashMap<>();
        headers.put(StompHeader.ID.toString(), String.valueOf(subscription.getId()));
        headers.put(StompHeader.DESTINATION.toString(), subscription.getDestination());

        StompFrame frame = new StompFrame(StompCommand.SUBSCRIBE, headers);
        send(frame.toString());

        subscriptions.put(subscription.getId(), subscription);

        return subscription;
    }

    /**
     * Remove a single subscription.
     *
     * @param subscription subscription
     */
    public void removeSubscription(StompSubscription subscription) {
        Map<String, String> headers = new HashMap<>();
        headers.put(StompHeader.ID.toString(), String.valueOf(subscription.getId()));

        StompFrame frame = new StompFrame(StompCommand.UNSUBSCRIBE, headers);
        send(frame.toString());

        subscriptions.remove(subscription.getId());
    }

    /**
     * Unsubscribe all from a single topic.
     *
     * @param destination topic
     */
    public void removeAllSubscriptions(String destination) {
        for (StompSubscription s : subscriptions.values()) {
            if (s.getDestination().equals(destination)) {
                removeSubscription(s);
            }
        }
    }

    /**
     * Check if STOMP is currently connected.
     *
     * @return STOMP connection status
     */
    public boolean isStompConnected() {
        return stompConnected;
    }

    /**
     * Register STOMP conection listener.
     *
     * @param stompConnectionListener listener
     */
    public void setStompConnectionListener(StompConnectionListener stompConnectionListener) {
        this.stompConnectionListener = stompConnectionListener;
    }
}
