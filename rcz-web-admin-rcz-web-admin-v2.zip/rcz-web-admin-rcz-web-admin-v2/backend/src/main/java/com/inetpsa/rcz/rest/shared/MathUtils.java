package com.inetpsa.rcz.rest.shared;

public final class MathUtils {

    public static int long2int(Long value) {
        try {
            return Math.toIntExact(value);
        } catch (ArithmeticException e) {
            return Integer.MAX_VALUE;
        }
    }
}
