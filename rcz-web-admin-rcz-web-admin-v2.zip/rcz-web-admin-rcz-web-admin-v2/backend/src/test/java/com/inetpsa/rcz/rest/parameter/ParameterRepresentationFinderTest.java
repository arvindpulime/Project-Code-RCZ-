package com.inetpsa.rcz.rest.parameter;

import com.inetpsa.rcz.domain.model.parameter.Parameter;
import org.assertj.core.api.Assertions;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.business.domain.Repository;
import org.seedstack.jpa.Jpa;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.testing.junit4.SeedITRunner;
import org.seedstack.seed.transaction.Transactional;
import org.seedstack.seed.undertow.LaunchWithUndertow;

import javax.inject.Inject;

/**
 * @author tuan.docao@ext.mpsa.com
 */
@LaunchWithUndertow
@RunWith(SeedITRunner.class)
public class ParameterRepresentationFinderTest {


    @Test
    public void findParameter() throws Exception {

    }

}