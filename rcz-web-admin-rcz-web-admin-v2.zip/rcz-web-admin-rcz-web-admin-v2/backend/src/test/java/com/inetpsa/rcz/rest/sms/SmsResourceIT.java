package com.inetpsa.rcz.rest.sms;

import com.inetpsa.rcz.domain.services.SmsService;
import com.inetpsa.rcz.rest.AbstractResourceIT;
import com.inetpsa.rcz.rest.shared.Rels;
import io.restassured.filter.log.ErrorLoggingFilter;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.response.Response;
import org.assertj.core.api.Assertions;
import org.junit.Test;

import javax.inject.Inject;
import java.util.Map;

import static io.restassured.RestAssured.expect;
import static io.restassured.path.json.JsonPath.from;

public class SmsResourceIT extends AbstractResourceIT {

    @Inject
    private SmsService smsService;


    @Test
    public void smsListTestNotFound() throws Exception {
        expect().statusCode(200).given()
                .filters(new RequestLoggingFilter(), new ResponseLoggingFilter(), new ErrorLoggingFilter()).auth().basic(LOGIN, PASSWORD).when().get(baseUrl + "/api/" + Rels.SMS + "?uin=000");
    }

    @Test
    public void smsListTest() throws Exception {
        smsService.create();
        Response response = expect()
                .statusCode(200)
                .given()
                .filters(new RequestLoggingFilter(), new ResponseLoggingFilter(), new ErrorLoggingFilter())
                .auth()
                .basic(LOGIN, PASSWORD)
                .when()
                .get(baseUrl + "/api/" + Rels.SMS);

        System.out.println(response.asString());
        Map<String, Object> links = from(response.asString()).get(LINKS);
        Map<String, Object> embedded = from(response.asString()).get(EMBEDDED);
        Assertions.assertThat(links).isNotEmpty();
        Assertions.assertThat(embedded).isNotEmpty();
    }

}