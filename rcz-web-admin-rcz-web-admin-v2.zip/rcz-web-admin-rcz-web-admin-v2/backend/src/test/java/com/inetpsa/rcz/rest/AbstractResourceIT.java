package com.inetpsa.rcz.rest;

import org.junit.runner.RunWith;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.testing.junit4.SeedITRunner;
import org.seedstack.seed.undertow.LaunchWithUndertow;

/**
 * @author tuan.docao@ext.mpsa.com
 */
@LaunchWithUndertow
@RunWith(SeedITRunner.class)
public abstract class AbstractResourceIT {

    protected static final String LOGIN = "dev";

    protected static final String PASSWORD = "dev";

    protected static final String LINKS = "_links";

    protected static final String EMBEDDED = "_embedded";

    protected static final String RESULT_SIZE = "resultSize";
    public static final String WEB_RUNTIME_BASE_URL = "runtime.web.baseUrl";

    @Configuration(WEB_RUNTIME_BASE_URL)
    protected String baseUrl;

}
