package com.inetpsa.rcz;

import com.inetpsa.rcz.rest.AbstractResourceIT;
import io.restassured.RestAssured;
import io.restassured.filter.log.ErrorLoggingFilter;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.testing.junit4.SeedITRunner;
import org.seedstack.seed.undertow.LaunchWithUndertow;

@RunWith(SeedITRunner.class)
@LaunchWithUndertow
public class PingWebIT extends AbstractResourceIT {

    @Test
    public void pingTest() {
        RestAssured.expect()
                .statusCode(200)
                .given()
                .filters(new RequestLoggingFilter(), new ResponseLoggingFilter(), new ErrorLoggingFilter())
                .auth()
                .basic(LOGIN, PASSWORD)
                .when()
                .get(baseUrl + "/api/ping");
    }
}