package com.inetpsa.rcz.rest.action;

import com.inetpsa.rcz.rest.AbstractResourceIT;
import io.restassured.filter.log.ErrorLoggingFilter;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.response.Response;
import org.assertj.core.api.Assertions;
import org.junit.Test;

import java.util.List;
import java.util.Map;

import static io.restassured.RestAssured.expect;
import static io.restassured.path.json.JsonPath.from;

/**
 * @author tuan.docao@ext.mpsa.com
 */
public class ActionResourceIT extends AbstractResourceIT {

    @Test
    public void testGetActions() throws Exception {
        Response response = expect()
                .statusCode(200)
                .given()
                .filters(new RequestLoggingFilter(), new ResponseLoggingFilter(), new ErrorLoggingFilter())
                .auth()
                .basic(LOGIN, PASSWORD)
                .when()
                .get(baseUrl + "/api/actions");
        Map<String, List<String>> actions = from(response.asString()).get();
        Assertions.assertThat(actions).hasSize(2);
    }

}
