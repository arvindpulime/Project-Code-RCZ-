package com.inetpsa.rcz.rest;

import com.inetpsa.rcz.domain.model.action.Action;
import com.inetpsa.rcz.domain.model.enums.CallerType;
import com.inetpsa.rcz.domain.model.enums.EventMessage;
import com.inetpsa.rcz.domain.model.enums.LogLevel;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.helper.Helper;
import com.inetpsa.rcz.domain.model.log.Log;
import com.inetpsa.rcz.domain.model.log.LogFactory;
import com.inetpsa.rcz.domain.model.log.LogMessage;
import com.inetpsa.rcz.domain.model.service.ServiceFeature;
import com.inetpsa.rcz.domain.repository.ExchangeRepository;
import com.inetpsa.rcz.domain.repository.LogRepository;
import com.inetpsa.rcz.rest.helper.HelperRepresentation;
import com.inetpsa.rcz.rest.log.detail.LogDetail;
import org.seedstack.business.assembler.Assembler;
import org.seedstack.business.domain.Factory;
import org.seedstack.business.domain.Repository;
import org.seedstack.business.modelmapper.ModelMapper;
import org.seedstack.jpa.Jpa;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.Bind;
import org.seedstack.seed.transaction.Transactional;

import javax.inject.Inject;
import java.util.Date;

/**
 * Enable SEED transactions within unit tests run with Arquillian.
 *
 * @author tuan.docao@ext.mpsa.com
 */
@Bind
@JpaUnit("rcz")
@Transactional
public class TestDataHandler {

    // FACTORIES
    @Inject
    private Factory<ServiceFeature> elementaryServiceFactory;

    @Inject
    private Factory<Exchange> exchangeFactory;

    @Inject
    private Factory<Helper> helperFactory;

    @Inject
    private LogFactory logFactory;

    // REPOSITORIES
    @Inject
    private ExchangeRepository exchangeRepository;

    @Inject
    @Jpa
    private Repository<Helper, Long> helperRepository;

    @Inject
    private LogRepository logRepository;

    // MAPPERS
    @Inject
    @ModelMapper
    private Assembler<Helper, HelperRepresentation> helperAssembler;

    @Inject
    private Assembler<Log, LogDetail> logDetailAssembler;

    // ENTITIES
    private Exchange exchange;

    private Helper helper;

    private Log log;

    @Inject
    @Jpa
    private Repository<ServiceFeature, String> elementaryServiceRepository;

    public void persistElementaryService(String id) {
        ServiceFeature service = elementaryServiceFactory.create(id);
        elementaryServiceRepository.add(service);
    }

    public void deleteElementaryService(String id) {
        elementaryServiceRepository.remove(id);
    }

    public void persistExchange() {
        exchange = exchangeFactory.create();
        exchange.setCallerType(CallerType.CLIENT);
        exchange.setCallerId("callerId");
        exchange.setAction(Action.DOORS);
        exchangeRepository.add(exchange);
    }

    public void deleteExchange() {
        exchangeRepository.remove(exchange.getId());
    }

    public void persistHelper() {
        helper = helperFactory.create();
        helperRepository.addOrUpdate(helper);
    }

    public void deleteHelper() {
        helperRepository.remove(helper.getId());
    }

    public HelperRepresentation getHelperRepresentation() {
        return helperAssembler.createDtoFromAggregate(helper);
    }

    public void persistLog() {
        log = logFactory.create(LogLevel.INFO, new Date(), LogMessage.create(EventMessage.ALARM_DELETE_RESPONSE_RECEIVED), "exchangeId");
        logRepository.add(log);
    }

    public void deleteLog() {
        logRepository.remove(log.getId());
    }

    public LogDetail getLogRepresentation() {
        return logDetailAssembler.createDtoFromAggregate(log);
    }
}
