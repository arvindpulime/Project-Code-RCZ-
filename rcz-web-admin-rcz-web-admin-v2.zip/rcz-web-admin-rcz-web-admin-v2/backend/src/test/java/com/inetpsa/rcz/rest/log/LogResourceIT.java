package com.inetpsa.rcz.rest.log;

import com.inetpsa.rcz.rest.AbstractResourceIT;
import com.inetpsa.rcz.rest.TestDataHandler;
import com.inetpsa.rcz.rest.log.detail.LogDetail;
import io.restassured.filter.log.ErrorLoggingFilter;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.response.Response;
import org.assertj.core.api.Assertions;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import javax.inject.Inject;
import java.util.Map;

import static io.restassured.RestAssured.expect;
import static io.restassured.path.json.JsonPath.from;

/**
 * @author tuan.docao@ext.mpsa.com
 */
public class LogResourceIT extends AbstractResourceIT {

    @Inject
    private TestDataHandler testDataHandler;

    @Before
    public void setUp() throws Exception {
        testDataHandler.persistLog();
    }

    @After
    public void tearDown() throws Exception {
        testDataHandler.deleteLog();
    }

    @Test
    public void testList() throws Exception {
        Response response = expect().statusCode(200).given()
                .filters(new RequestLoggingFilter(), new ResponseLoggingFilter(), new ErrorLoggingFilter()).auth().basic(LOGIN, PASSWORD).when().get(baseUrl + "/api/logs");
        int resultSize = from(response.asString()).get("page.totalElements");
        Assertions.assertThat(resultSize).isEqualTo(1);
    }

    @Test
    public void testGetDetail() throws Exception {
        LogDetail logRepresentation = testDataHandler.getLogRepresentation();
        String logId = null;
        if (logRepresentation != null) {
            logId = logRepresentation.getId();
        }

        Response response = expect().statusCode(200).given()
                .filters(new RequestLoggingFilter(), new ResponseLoggingFilter(), new ErrorLoggingFilter()).pathParam("logId", logId).auth().basic(LOGIN, PASSWORD).when().get(baseUrl + "/api/logs/{logId}");
        Map<String, Object> log = from(response.asString()).get();
        Assertions.assertThat(log).isNotNull();
        Assertions.assertThat(log.get("id")).isEqualTo(logId);
    }

}
