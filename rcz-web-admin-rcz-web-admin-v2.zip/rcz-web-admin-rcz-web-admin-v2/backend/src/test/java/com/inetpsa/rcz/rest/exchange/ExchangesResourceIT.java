package com.inetpsa.rcz.rest.exchange;

import com.inetpsa.rcz.rest.AbstractResourceIT;
import com.inetpsa.rcz.rest.TestDataHandler;
import com.inetpsa.rcz.rest.shared.Rels;
import io.restassured.filter.log.ErrorLoggingFilter;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.response.Response;
import org.assertj.core.api.Assertions;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import javax.inject.Inject;
import java.util.Map;

import static io.restassured.RestAssured.expect;
import static io.restassured.path.json.JsonPath.from;

/**
 * @author tuan.docao@ext.mpsa.com
 */
public class ExchangesResourceIT extends AbstractResourceIT {

    @Inject
    private TestDataHandler testDataHandler;

    @Before
    public void setUp() throws Exception {
        testDataHandler.persistExchange();
    }

    @After
    public void tearDown() throws Exception {
        testDataHandler.deleteExchange();
    }

    @Test
    public void testList() throws Exception {
        Response response = expect().statusCode(200).given()
                .filters(new RequestLoggingFilter(), new ResponseLoggingFilter(), new ErrorLoggingFilter()).auth().basic(LOGIN, PASSWORD).when().get(baseUrl + "/api/" + Rels.EXCHANGES);
        Map<String, Object> links = from(response.asString()).get(LINKS);
        Map<String, Object> embedded = from(response.asString()).get(EMBEDDED);
        Assertions.assertThat(links).isNotEmpty();
        Assertions.assertThat(embedded).isNotEmpty();
    }

    @Test
    public void testResources() throws Exception {
        Response response = expect().statusCode(200).given()
                .filters(new RequestLoggingFilter(), new ResponseLoggingFilter(), new ErrorLoggingFilter()).auth().basic(LOGIN, PASSWORD).when().get(baseUrl + "/api/" + Rels.EXCHANGES_ENUMS);
        Map<String, Object> m = from(response.asString()).get();
        Assertions.assertThat(m).isNotEmpty();
    }

    @Test
    public void testAlerts() throws Exception {
        Response response = expect().statusCode(200).given()
                .filters(new RequestLoggingFilter(), new ResponseLoggingFilter(), new ErrorLoggingFilter()).auth().basic(LOGIN, PASSWORD).when().get(baseUrl + "/api/" + Rels.EXCHANGES_ALERT);
        Map<String, Object> m = from(response.asString()).get(EMBEDDED);
        Assertions.assertThat(m).isNotEmpty();
    }
}
