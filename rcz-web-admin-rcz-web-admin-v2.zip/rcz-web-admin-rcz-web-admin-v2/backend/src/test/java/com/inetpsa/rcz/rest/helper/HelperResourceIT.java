package com.inetpsa.rcz.rest.helper;

import com.inetpsa.rcz.rest.AbstractResourceIT;
import com.inetpsa.rcz.rest.TestDataHandler;
import io.restassured.filter.log.ErrorLoggingFilter;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.assertj.core.api.Assertions;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import javax.inject.Inject;
import java.util.Map;

import static io.restassured.RestAssured.expect;
import static io.restassured.path.json.JsonPath.from;

/**
 * @author tuan.docao@ext.mpsa.com
 */
public class HelperResourceIT extends AbstractResourceIT {

    @Inject
    private TestDataHandler testDataHandler;

    @Before
    public void setUp() throws Exception {
        testDataHandler.persistHelper();
    }

    @After
    public void tearDown() throws Exception {
        testDataHandler.deleteHelper();
    }

    @Test
    public void testGet() throws Exception {
        Response response = expect().statusCode(200).given()
                .filters(new RequestLoggingFilter(), new ResponseLoggingFilter(), new ErrorLoggingFilter()).auth().basic(LOGIN, PASSWORD).when().get(baseUrl + "/api/helper");
        Map<String, Object> helper = from(response.asString()).get();
        Assertions.assertThat(helper).isNotEmpty();
    }

    @Test
    public void testUpdateActions() throws Exception {
        HelperRepresentation helperRepresentation = testDataHandler.getHelperRepresentation();
        helperRepresentation.setContent("toto");
        expect().statusCode(200)
                .given()
                .filters(new RequestLoggingFilter(), new ResponseLoggingFilter(), new ErrorLoggingFilter())
                .contentType(ContentType.JSON)
                .auth().basic(LOGIN, PASSWORD)
                .body(helperRepresentation)
                .when().put(baseUrl + "/api/helper");
    }
}
