package com.inetpsa.rcz.rest.log;

import com.inetpsa.rcz.domain.model.enums.LogLevel;
import com.inetpsa.rcz.domain.model.log.Log;
import com.inetpsa.rcz.domain.model.log.LogMessage;
import com.inetpsa.rcz.rest.log.list.LogFinder;
import com.inetpsa.rcz.rest.log.list.LogRepresentation;
import com.inetpsa.rcz.rest.log.list.SortType;
import com.inetpsa.rcz.rest.shared.SortOrder;
import org.assertj.core.api.Assertions;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.business.domain.Factory;
import org.seedstack.business.domain.Repository;
import com.inetpsa.rcz.rest.shared.Range;
import com.inetpsa.rcz.rest.shared.Result;
import org.seedstack.jpa.Jpa;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.testing.junit4.SeedITRunner;
import org.seedstack.seed.transaction.Transactional;

import javax.inject.Inject;
import java.util.Date;
import java.util.List;
import java.util.Set;

/**
 * @author tuan.docao@ext.mpsa.com
 */
@JpaUnit("rcz")
@RunWith(SeedITRunner.class)
@Ignore
public class LogFinderTest {

    @Inject
    @Jpa
    private Repository<Log, String> repository;

    @Inject
    private Factory<Log> factory;

    @Inject
    private LogFinder finder;

    private Log l1, l2, l3;

    @Before
    @Transactional
    public void setUp() throws Exception {
        createLogs();
    }

    @After
    @Transactional
    public void tearDown() throws Exception {
        deleteLogs();
    }

    @Test
    @Transactional
    public void testFindPaginatedLogs() throws Exception {
        Result<LogRepresentation> result = finder.findLogRepresentations(Range.rangeFromPageInfo(0, 2), SortType.ID, SortOrder.DESCENDING, new SearchQuery());
        List<LogRepresentation> logs = result.getResult();
        Assertions.assertThat(logs).hasSize(2);

        result = finder.findLogRepresentations(Range.rangeFromPageInfo(1, 2), SortType.ID, SortOrder.DESCENDING, new SearchQuery());
        logs = result.getResult();
        Assertions.assertThat(logs).hasSize(1);
    }

    @Test
    @Transactional
    public void testFindAvailableLevels() throws Exception {
        List<String> availableLevels = finder.findAvailableLevels();
        Assertions.assertThat(availableLevels).hasSize(2);
    }

    @Test
    @Transactional
    public void testFindAvailableServersInst() throws Exception {
        Set<String> availableLevels = finder.findAvailableInstances();
        Assertions.assertThat(availableLevels).hasSize(2);
    }

    private void createLogs() {
        l1 = factory.create(LogLevel.INFO, new Date(), LogMessage.create("toto"), "0000", "01");
        l2 = factory.create(LogLevel.INFO, new Date(), LogMessage.create("tutu"), "1111", "01");
        l3 = factory.create(LogLevel.ERROR, new Date(), LogMessage.create("tata"), "2222", "02");

        repository.add(l1);
        repository.add(l2);
        repository.add(l3);
    }

    private void deleteLogs() {
        repository.get(l1.getId()).ifPresent(log -> repository.remove(log));
        repository.get(l2.getId()).ifPresent(log -> repository.remove(log));
        repository.get(l3.getId()).ifPresent(log -> repository.remove(log));
    }

}