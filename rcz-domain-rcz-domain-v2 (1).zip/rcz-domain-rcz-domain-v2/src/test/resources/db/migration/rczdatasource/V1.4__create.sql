alter table RCZQTSMS add messageId varchar(80);
