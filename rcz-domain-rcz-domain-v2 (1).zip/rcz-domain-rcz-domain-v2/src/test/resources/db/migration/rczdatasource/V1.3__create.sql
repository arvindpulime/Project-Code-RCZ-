alter table "RCZQTVEHICLE" add serviceInfoDate timestamp;
alter table "RCZQTVEHICLE" add serviceInfoPayload text;
alter table "RCZQTVEHICLE" add serviceInfoSentDate timestamp;