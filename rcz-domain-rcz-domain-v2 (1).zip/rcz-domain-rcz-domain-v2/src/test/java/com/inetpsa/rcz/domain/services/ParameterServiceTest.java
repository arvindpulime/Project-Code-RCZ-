package com.inetpsa.rcz.domain.services;

import com.inetpsa.rcz.domain.model.parameter.Parameter;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.testing.junit4.SeedITRunner;
import org.seedstack.seed.transaction.Transactional;

import javax.inject.Inject;

/**
 * @author tuan.docao@ext.mpsa.com
 */
@JpaUnit("rcz")
@RunWith(SeedITRunner.class)
public class ParameterServiceTest {

    @Inject
    private ParameterService service;


    @Test
    @Transactional
    public void testGetParameterValue() throws Exception {

        int expectedValue = 5;
        Parameter parameter = service.get();
        parameter.getSms().setNbRetry(expectedValue);
        parameter.getSms().getByTel();
        service.update(parameter);
        int val = service.get().getSms().getNbRetry();
        Assertions.assertThat(val).isEqualTo(expectedValue);
    }

}