package com.inetpsa.rcz.domain.services;

import com.inetpsa.rcz.domain.model.action.Action;
import com.inetpsa.rcz.domain.model.enums.CallerType;
import com.inetpsa.rcz.domain.model.enums.LogLevel;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.log.Log;
import com.inetpsa.rcz.domain.model.log.LogMessage;
import com.inetpsa.rcz.domain.model.payload.data.Charging;
import com.inetpsa.rcz.domain.model.payload.data.Horn;
import com.inetpsa.rcz.domain.model.payload.data.Preconditioning;
import com.inetpsa.rcz.domain.model.payload.topic.BtaTopicsResolver;
import com.inetpsa.rcz.domain.model.shared.Payload;
import com.inetpsa.rcz.domain.repository.ExchangeRepository;
import com.inetpsa.rcz.domain.repository.LogRepository;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.business.domain.Factory;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.testing.junit4.SeedITRunner;
import org.seedstack.seed.transaction.Transactional;

import javax.inject.Inject;
import java.util.List;

/**
 * @author tuan.docao@ext.mpsa.com
 */
@JpaUnit("rcz")
@RunWith(SeedITRunner.class)
public class LogServiceTest {

    @Inject
    private Factory<Exchange> exchangeFactory;

    @Inject
    private ExchangeRepository exchangeRepository;

    @Inject
    private LogService logService;

    @Inject
    private BtaTopicsResolver<Preconditioning> btaTopicsResolver;

    @Inject
    private LogRepository logRepository;

    @Test
    public void injectLogService() {
        Assertions.assertThat(logService).isNotNull();
    }

    @Test
    public void resolvePlaceholders() {
        final String resolved = logService.resolvePlaceholders("log {0} message", "debug");
        Assertions.assertThat(resolved).isEqualTo("log debug message");
        //System.out.println(btaTopicsResolver.resolve(Action.HORN, null));
    }

    @Test
    public void debug() {
        Exchange exchange = createExchange();
        logService.debug(LogMessage.create("log debug message").data("{json}"), exchange);
        List<Log> logs = getLogsByExchange(exchange);
        Assertions.assertThat(logs.get(0).getLogLevel()).isEqualTo(LogLevel.DEBUG);
    }

    @Test
    public void info() {
        Exchange exchange = createExchange();
        logService.info(LogMessage.create("log info message").data("{json}"), exchange);
        List<Log> logs = getLogsByExchange(exchange);
        Assertions.assertThat(logs.get(0).getLogLevel()).isEqualTo(LogLevel.INFO);
    }

    @Test
    public void warn() {
        Exchange exchange = createExchange();
        logService.warn(LogMessage.create("log warn message").data("{json}"), exchange);
        List<Log> logs = getLogsByExchange(exchange);
        Assertions.assertThat(logs.get(0).getLogLevel()).isEqualTo(LogLevel.WARN);
    }

    @Test
    public void error() {
        Exchange exchange = createExchange();
        logService.error(LogMessage.create("log error message").data("{json}"), exchange);
        List<Log> logs = getLogsByExchange(exchange);
        Assertions.assertThat(logs.get(0).getLogLevel()).isEqualTo(LogLevel.ERROR);
    }

    @Transactional
    Exchange createExchange() {
        Exchange exchange = exchangeFactory.create();
        exchange.setCallerType(CallerType.CLIENT);
        exchange.setCallerId("123456789");
        exchange.setAction(Action.HORN);
        exchange.setRequest(new Payload());
        exchangeRepository.add(exchange);
        return exchange;
    }

    @Transactional
    List<Log> getLogsByExchange(Exchange exchange) {
        return logRepository.findByExchangeId(exchange.getId());
    }
}