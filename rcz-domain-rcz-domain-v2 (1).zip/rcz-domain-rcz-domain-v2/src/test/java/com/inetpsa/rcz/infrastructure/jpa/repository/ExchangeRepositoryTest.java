/*
 * Creation : 6 juin 2016
 */
package com.inetpsa.rcz.infrastructure.jpa.repository;

import com.inetpsa.rcz.domain.model.action.Action;
import com.inetpsa.rcz.domain.model.enums.CallerType;
import com.inetpsa.rcz.domain.model.enums.ExchangeStatus;
import com.inetpsa.rcz.domain.model.enums.ProcessStatus;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.shared.Payload;
import com.inetpsa.rcz.domain.repository.ExchangeRepository;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.business.domain.Factory;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.testing.junit4.SeedITRunner;
import org.seedstack.seed.transaction.Transactional;

import javax.inject.Inject;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@RunWith(SeedITRunner.class)
@JpaUnit("rcz")
public class ExchangeRepositoryTest {

    @Inject
    private ExchangeRepository exchangeRepository;

    @Inject
    private Factory<Exchange> exchangeFactory;

    @Test
    @Transactional
    public void repositoryInjectionTest() {
        Assertions.assertThat(exchangeRepository).isNotNull();
        Assertions.assertThat(exchangeFactory).isNotNull();
        Exchange exchange = newExchange(CallerType.CLIENT, "1", Action.REQUEST_STATE, new Date(), "123456789", ExchangeStatus.INITIAL, ProcessStatus.REQUEST_SENT_TO_BTA);
        Assertions.assertThat(exchange.getId()).isNotNull();
        exchangeRepository.add(exchange);
        Optional<Exchange> exchangePersisted = exchangeRepository.get(exchange.getId());
        Assertions.assertThat(exchangePersisted.isPresent()).isTrue();
        Assertions.assertThat(exchange.getId()).isEqualTo(exchangePersisted.get().getId());
    }

    @Test
    @Transactional
    public void nbRequestForClient() {
        Exchange exchange1 = newExchange(CallerType.CLIENT, "1", Action.DOORS, new Date(), null, ExchangeStatus.PENDING, ProcessStatus.REQUEST_SENT_TO_BTA);
        Exchange exchange2 = newExchange(CallerType.CLIENT, "1", Action.DOORS, new Date(), null, ExchangeStatus.PENDING, ProcessStatus.REQUEST_SENT_TO_BTA);
        Date date = new Date();
        Exchange exchange3 = newExchange(CallerType.CLIENT, "1", Action.DOORS, date, null, ExchangeStatus.PENDING, ProcessStatus.REQUEST_SENT_TO_BTA);
        exchangeRepository.add(exchange1);
        exchangeRepository.add(exchange2);
        exchangeRepository.add(exchange3);
        Assertions.assertThat(exchangeRepository.checkQuotaByCallerAndSentToBta("1", date, 10, 1)).isFalse();
    }

    @Test
    @Transactional
    public void callerHasDuplicateTrue() {
        Exchange exchange1 = newExchange(CallerType.CLIENT, "1", Action.DOORS, new Date(), "exchange1", ExchangeStatus.PENDING, null);
        Exchange exchange2 = newExchange(CallerType.CLIENT, "1", Action.DOORS, new Date(), "exchange2", ExchangeStatus.PENDING, null);
        Exchange exchange3 = newExchange(CallerType.CLIENT, "1", Action.DOORS, new Date(), "exchange3", ExchangeStatus.PENDING, null);
        exchangeRepository.add(exchange1);
        exchangeRepository.add(exchange2);
        exchangeRepository.add(exchange3);
        boolean hasDuplicate = exchangeRepository.callerHasDuplicate(exchange3);
        Assertions.assertThat(hasDuplicate).isTrue();
    }

    @Test
    @Transactional
    public void callerHasDuplicateFalse() {
        Exchange exchange1 = newExchange(CallerType.CLIENT, "2", Action.DOORS, new Date(), "exchange1", ExchangeStatus.FINISHED, ProcessStatus.REQUEST_SENT_TO_BTA);
        Exchange exchange2 = newExchange(CallerType.CLIENT, "2", Action.DOORS, new Date(), "exchange2", ExchangeStatus.ERROR, ProcessStatus.REQUEST_SENT_TO_BTA);
        Exchange exchange3 = newExchange(CallerType.CLIENT, "2", Action.DOORS, new Date(), "exchange3", ExchangeStatus.INITIAL, ProcessStatus.REQUEST_SENT_TO_BTA);
        exchangeRepository.add(exchange1);
        exchangeRepository.add(exchange2);
        exchangeRepository.add(exchange3);
        boolean hasDuplicate = exchangeRepository.callerHasDuplicate(exchange3);
        Assertions.assertThat(hasDuplicate).isFalse();
    }

    @Test
    @Transactional
    public void findByCorrelationId() {
        final String correlationId = "ac8d1c2ccd8311e4341a1681e6b88ec1";
        Exchange toPersist = newExchange(CallerType.CLIENT, "1", Action.REQUEST_STATE, new Date(), correlationId, ExchangeStatus.INITIAL, ProcessStatus.REQUEST_SENT_TO_BTA);
        exchangeRepository.add(toPersist);
        Optional<Exchange> found = exchangeRepository.findByCorrelationId(correlationId);
        Assertions.assertThat(found.isPresent()).isTrue();
        Assertions.assertThat(found.get().getId()).isEqualTo(toPersist.getId());
    }

    private Exchange newExchange(CallerType callerType, String callerId, Action action, Date requestDate, String correlationId, ExchangeStatus status, ProcessStatus processStatus) {
        Exchange exchange = exchangeFactory.create();
        exchange.setCallerType(callerType);
        exchange.setCallerId(callerId);
        exchange.setAction(action);
        Payload request = new Payload();
        request.setReceivedDate(requestDate);
        request.setSentDate(requestDate);
        exchange.setRequest(request);
        exchange.setCorrelationId(correlationId);
        exchange.setStatus(status);
        exchange.setProcessStatus(processStatus);
        exchange.setVin("VF3CA5FV8CW100632");
        return exchange;
    }

    @Test
    @Transactional
    public void getAllTimeoutExchanges() {
        Calendar now = Calendar.getInstance();
        now.setTime(new Date());
        now.add(Calendar.MINUTE, -16);

        Exchange exchange1 = newExchange(CallerType.CLIENT, "2", Action.DOORS, now.getTime(), "exchange1", ExchangeStatus.PENDING, ProcessStatus.REQUEST_SENT_TO_BTA); // ok
        exchangeRepository.add(exchange1);
        Exchange exchange2 = newExchange(CallerType.CLIENT, "2", Action.DOORS, now.getTime(), "exchange2", ExchangeStatus.INITIAL, ProcessStatus.REQUEST_SENT_TO_BTA); // ok
        exchangeRepository.add(exchange2);
        Exchange exchange3 = newExchange(CallerType.CLIENT, "2", Action.DOORS, now.getTime(), "exchange3", ExchangeStatus.FINISHED, ProcessStatus.REQUEST_SENT_TO_BTA); // ko : finished
        exchangeRepository.add(exchange3);
        Exchange exchange4 = newExchange(CallerType.CLIENT, "2", Action.LIGHTS, new Date(), "exchange4", ExchangeStatus.PENDING, ProcessStatus.REQUEST_SENT_TO_BTA); // ko : not timed out
        exchangeRepository.add(exchange4);
        Exchange exchange5 = newExchange(CallerType.PARTNER, "1", Action.IMMOBILIZATION, now.getTime(), "exchange5", ExchangeStatus.PENDING, ProcessStatus.REQUEST_SENT_TO_BTA); // ko : immo
        exchangeRepository.add(exchange5);
        List<Exchange> list = exchangeRepository.findAllInTimeout(15);
        Assertions.assertThat(list).isNotNull();
        Assertions.assertThat(list).hasSize(3);
    }

}
