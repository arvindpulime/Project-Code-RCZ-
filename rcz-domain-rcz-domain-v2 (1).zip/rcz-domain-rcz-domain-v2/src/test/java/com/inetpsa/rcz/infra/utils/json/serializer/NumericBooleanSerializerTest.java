package com.inetpsa.rcz.infra.utils.json.serializer;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.inetpsa.rcz.domain.model.enums.SevState;
import com.inetpsa.rcz.domain.model.payload.data.Horn;
import com.inetpsa.rcz.domain.model.payload.data.VehicleStateResult;
import com.inetpsa.rcz.domain.model.payload.request.RequestPayload;
import com.inetpsa.rcz.domain.model.shared.Payload;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;
import org.assertj.core.api.Assertions;
import org.junit.Test;

import java.util.Date;

public class NumericBooleanSerializerTest {

    @Test
    public void serializeBooleanToNumeric() throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        Horn hornBTA = new Horn(5, true);
        String jsonInString = mapper.writeValueAsString(hornBTA);
        hornBTA = mapper.readValue(jsonInString, Horn.class);
        Assertions.assertThat(hornBTA.getActivated()).isTrue();
        String test = "{\"privacy_state\":0,\"sev_state\":0,\"alarm_activation\":0,\"doors_opening_state\":[0,0,0,0,0,0],\"doors_locking_state\":1,\"stolen_state\":0,\"signal_quality\":2,\"sev_stop_date\":\"2016-09-28T14:28:101Z\",\"immo_state\":0,\"location\":{\"dop\":{\"valid_p\":\"false\",\"valid_h\":\"false\",\"valid_v\":\"false\",\"p\":99.99,\"h\":99.99,\"v\":99.99},\"satellites\":{\"valid_usd\":\"false\",\"valid_trk\":\"false\",\"valid_vis\":\"false\",\"used\":0,\"tracked\":0,\"visible\":0},\"gnss\":{\"fix_status\":0,\"valid_lat\":\"false\",\"valid_lng\":\"false\",\"valid_alt\":\"false\",\"valid_hdg\":\"false\",\"valid_spd\":\"false\",\"valid_err_hps\":\"false\",\"valid_err_alt\":\"false\",\"valid_err_spd\":\"false\",\"latitude\":0,\"longitude\":0,\"altitude\":0,\"heading\":0,\"speed\":0,\"error_h_position\":0,\"error_altitude\":-1,\"error_v_speed\":-1},\"dr\":{\"valid_lat\":\"false\",\"valid_lng\":\"false\",\"valid_hdg\":\"false\",\"valid_spd\":\"false\",\"latitude\":0.8471959999999999,\"longitude\":0.0436,\"heading\":2997,\"speed\":0}}}\n";
        VehicleStateResult vehicleStateResult = JsonConverter.convert(test, new TypeReference<VehicleStateResult>() {
        });
        Assertions.assertThat(vehicleStateResult).isNotNull();
    }

}