package com.inetpsa.rcz.infrastructure.jpa.repository;

import com.inetpsa.rcz.domain.model.shared.Payload;
import com.inetpsa.rcz.domain.model.vehicle.State;
import com.inetpsa.rcz.domain.model.vehicle.Vehicle;
import com.inetpsa.rcz.domain.repository.VehicleRepository;
import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.business.domain.Factory;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.testing.junit4.SeedITRunner;
import org.seedstack.seed.transaction.Transactional;

import javax.inject.Inject;
import java.util.Date;
import java.util.Optional;

/**
 * @author tuan.docao@ext.mpsa.com
 */
@RunWith(SeedITRunner.class)
@JpaUnit("rcz")
public class VehicleRepositoryTest {

    @Inject
    private Factory<Vehicle> vehicleFactory;

    @Inject
    private VehicleRepository vehicleRepository;

    private static final String uin = "uin";

    private static final String req = "{\n" +
            "\t\"req_date\": \"2016-12-14T15:07:51Z\",\n" +
            "\t\"vin\": \"VF123456789876543\",\n" +
            "\t\"client_code\": \"ap-mdemym00\",\n" +
            "\t\"req_parameters\": {\n" +
            "\t\t\"action\": \"activate\",\n" +
            "\t\t\"nb_horn\": 5\n" +
            "\t},\n" +
            "\t\"correlation_id\": \"20161214T150751ZIFA1\"\n" +
            "}";

    @Before
    @Transactional
    public void setUp() {
        Optional<Vehicle> result = vehicleRepository.get(uin);
        if (!result.isPresent()) {
            Vehicle vehicle = vehicleFactory.create(uin);

            State state = new State(false, new Date());
            vehicle.setVehicleState(state);

            Payload payload = new Payload(new Date(), req);
            vehicle.setVehicleInfo(payload);

            vehicleRepository.add(vehicle);
        } 
    }

    @Test
    @Transactional
    public void testIsConnected() throws Exception {
        Boolean connected = vehicleRepository.isConnected(uin);
        Assertions.assertThat(connected).isFalse();
    }

    @Test
    @Transactional
    public void testGetVehicleInfo() throws Exception {
        Payload res = vehicleRepository.getVehicleInfo(uin);
        Assertions.assertThat(res).isNotNull();
        Assertions.assertThat(res.getRawJson()).isEqualTo(req);
    }
}