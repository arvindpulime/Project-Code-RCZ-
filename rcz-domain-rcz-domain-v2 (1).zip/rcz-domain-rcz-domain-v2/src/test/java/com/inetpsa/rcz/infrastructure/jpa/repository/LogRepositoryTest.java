package com.inetpsa.rcz.infrastructure.jpa.repository;

import com.inetpsa.rcz.domain.model.action.Action;
import com.inetpsa.rcz.domain.model.action.ActionType;
import com.inetpsa.rcz.domain.model.enums.CallerType;
import com.inetpsa.rcz.domain.model.enums.LogLevel;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.log.EventLog;
import com.inetpsa.rcz.domain.model.log.Log;
import com.inetpsa.rcz.domain.model.log.LogFactory;
import com.inetpsa.rcz.domain.repository.ExchangeRepository;
import com.inetpsa.rcz.domain.repository.LogRepository;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.business.assembler.Assembler;
import org.seedstack.business.domain.Factory;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.testing.junit4.SeedITRunner;
import org.seedstack.seed.transaction.Transactional;

import javax.inject.Inject;
import java.util.Date;
import java.util.List;
import java.util.Optional;

/**
 * @author tuan.docao@ext.mpsa.com
 */
@RunWith(SeedITRunner.class)
@JpaUnit("rcz")
public class LogRepositoryTest {

    @Inject
    private Assembler<Log, EventLog> eventLogAssembler;

    @Inject
    private LogFactory logFactory;

    @Inject
    private LogRepository logRepository;

    @Inject
    private Factory<Exchange> exchangeFactory;

    @Inject
    private ExchangeRepository exchangeRepository;

    @Test
    @Transactional
    public void persistExchangeLog() throws Exception {
        Exchange exchange = createExchange();
        exchangeRepository.update(exchange);
        EventLog eventLog = createEventLog(exchange);

        Log log = logFactory.create();
        Assertions.assertThat(log.getInstanceId()).isNotNull();
        eventLogAssembler.mergeDtoIntoAggregate(eventLog, log);
        logRepository.add(log);
        Optional<Log> loaded = logRepository.get(log.getId());
        Assertions.assertThat(loaded.isPresent()).isTrue();
        Assertions.assertThat(loaded.get().getExchangeId()).isEqualTo(exchange.getId());
    }

    @Test
    @Transactional
    public void findByExchangeId() throws Exception {
        final String callerId = "012345678";

        Exchange exchange = createExchange();
        exchange.setCallerType(CallerType.CLIENT);
        exchange.setCallerId(callerId);
        exchange.setAction(Action.HORN);
        exchangeRepository.update(exchange);
        EventLog eventLog = createEventLog(exchange);

        Log log = logFactory.create();
        eventLogAssembler.mergeDtoIntoAggregate(eventLog, log);
        logRepository.add(log);
        List<Log> foundLogs = logRepository.findByExchangeId(exchange.getId());
        Assertions.assertThat(foundLogs).hasSize(1);

        log = foundLogs.get(0);
        eventLog = eventLogAssembler.createDtoFromAggregate(log);
        Assertions.assertThat(eventLog.getContext().getCallerType()).isEqualTo(CallerType.CLIENT);
        Assertions.assertThat(eventLog.getContext().getCallerId()).isEqualTo(callerId);
        Assertions.assertThat(eventLog.getContext().getAction()).isEqualTo(ActionType.HORN);
    }

    private EventLog createEventLog(Exchange exchange) {
        EventLog eventLog = new EventLog();
        eventLog.setMessage("log message");
        eventLog.setData("{json}");
        eventLog.setTopic("topic");
        eventLog.setLogDate(new Date());
        eventLog.setLogLevel(LogLevel.ERROR);
        eventLog.getContext().setExchangeId(exchange.getId());
        return eventLog;
    }

    private Exchange createExchange() {
        Exchange exchange = exchangeFactory.create();
        exchange.setCallerType(CallerType.CLIENT);
        exchange.setCallerId("012345678");
        exchange.setAction(Action.HORN);
        exchangeRepository.add(exchange);
        return exchange;
    }
}
