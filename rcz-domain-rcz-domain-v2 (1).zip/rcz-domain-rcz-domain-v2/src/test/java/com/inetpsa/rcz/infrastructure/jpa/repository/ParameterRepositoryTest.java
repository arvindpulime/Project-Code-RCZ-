package com.inetpsa.rcz.infrastructure.jpa.repository;


import com.inetpsa.rcz.domain.model.parameter.Parameter;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.business.domain.Factory;
import org.seedstack.business.domain.Repository;
import org.seedstack.jpa.Jpa;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.testing.junit4.SeedITRunner;
import org.seedstack.seed.transaction.Transactional;

import javax.inject.Inject;
import java.util.UUID;

/**
 * @author tuan.docao@ext.mpsa.com
 */
@RunWith(SeedITRunner.class)
@JpaUnit("rcz")
public class ParameterRepositoryTest {

    @Inject
    @Jpa
    private Repository<Parameter,String> parameterRepository;

    @Inject
    private Factory<Parameter> parameterFactory;

    @Test
    @Transactional
    public void testFindAll() throws Exception {
        final boolean val = true;
        Parameter parameter = parameterFactory.create();
        String id = parameter.getId();
        parameter.getRcz().setAutomaticVehicleState(val);
        parameterRepository.add(parameter);
        Assertions.assertThat(parameterRepository.get(id).get().getRcz().getAutomaticVehicleState()).isEqualTo(val);
    }
}