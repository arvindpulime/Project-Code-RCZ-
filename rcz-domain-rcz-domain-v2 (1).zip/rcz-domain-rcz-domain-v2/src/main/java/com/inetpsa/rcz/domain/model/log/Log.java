package com.inetpsa.rcz.domain.model.log;

import com.inetpsa.rcz.domain.model.enums.LogLevel;
import com.inetpsa.rcz.infrastructure.data.CustomUUIDGenerator;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;

import javax.persistence.*;
import java.util.Date;

/**
 * Entity for an applciation log.
 *
 * @author tuan.docao@ext.mpsa.com
 */
@Entity
@Table(name = "RCZQTLOG")
public class Log extends BaseAggregateRoot<String> {

    @Id
    @Identity(generator = CustomUUIDGenerator.class)
    private String id;

    private String instanceId;

    @Enumerated(EnumType.STRING)
    private LogLevel logLevel;

    private Date logDate;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(column = @Column(nullable = false), name = "message")
    })
    private LogMessage message;

    private String exchangeId;

    Log() {
    }

    Log(String instanceId) {
        this.instanceId = instanceId;
    }

    Log(LogLevel logLevel, Date logDate, LogMessage message, String exchangeId, String instanceId) {
        this.logLevel = logLevel;
        this.logDate = logDate;
        this.message = message;
        this.exchangeId = exchangeId;
        this.instanceId = instanceId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getInstanceId() {
        return instanceId;
    }

    public void setInstanceId(String instanceId) {
        this.instanceId = instanceId;
    }

    public LogLevel getLogLevel() {
        return logLevel;
    }

    public void setLogLevel(LogLevel logLevel) {
        this.logLevel = logLevel;
    }

    public Date getLogDate() {
        return logDate;
    }

    public void setLogDate(Date logDate) {
        this.logDate = logDate;
    }

    public LogMessage getMessage() {
        return message;
    }

    public void setMessage(LogMessage message) {
        this.message = message;
    }

    public String getExchangeId() {
        return exchangeId;
    }

    public void setExchangeId(String exchangeId) {
        this.exchangeId = exchangeId;
    }

}
