package com.inetpsa.rcz.domain.model.payload.topic;

import com.inetpsa.rcz.domain.model.payload.data.Doors;

public class DoorsBtaTopicsResolver implements BtaTopicsResolver<Doors> {
}
