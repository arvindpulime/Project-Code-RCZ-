package com.inetpsa.rcz.domain.model.event;

import org.seedstack.business.domain.BaseDomainEvent;

public abstract class AbstractVehicleEvent extends BaseDomainEvent {
}
