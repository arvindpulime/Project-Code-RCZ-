package com.inetpsa.rcz.domain.model.event;

import com.inetpsa.rcz.domain.model.exchange.Exchange;

public class BatteryAvailability extends AbstractExchangeEvent  {
    public BatteryAvailability(Exchange exchange) {
        super(exchange);
    }
}
