package com.inetpsa.rcz.domain.model.log;

import com.inetpsa.rcz.domain.model.enums.LogLevel;
import org.seedstack.business.domain.Factory;

import java.util.Date;

public interface LogFactory extends Factory<Log> {

    Log create(LogLevel logLevel, Date logDate, LogMessage message, String exchangeId);

    Log create();
}
