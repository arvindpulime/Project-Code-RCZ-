package com.inetpsa.rcz.domain.model.payload.data;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Date;

import static com.inetpsa.rcz.domain.model.payload.ValidationPattern.PATTERN_DATE;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Acknowledgement {


    public Acknowledgement() {
    }

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = PATTERN_DATE)
    @JsonProperty("ack_date")
    private Date date;

    @JsonProperty("req_id")
    private String requestId;

    public Date getDate() {
        return date;
    }

    public Acknowledgement setDate(Date date) {
        this.date = date;
        return this;
    }

    public String getRequestId() {
        return requestId;
    }

    public Acknowledgement setRequestId(String requestId) {
        this.requestId = requestId;
        return this;
    }
}
