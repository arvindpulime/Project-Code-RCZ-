package com.inetpsa.rcz.domain.model.event;

import com.inetpsa.rcz.domain.model.exchange.Exchange;

public class AuthorizationReceivedEvent extends AbstractExchangeEvent {

    private String authorizations;

    public AuthorizationReceivedEvent(Exchange exchange, String authorizations) {
        super(exchange);
        this.authorizations = authorizations;
    }

    public String getAuthorizations() {
        return authorizations;
    }
}
