package com.inetpsa.rcz.domain.model.monitoring;

public class ApplicationInfoWrapper {
}
