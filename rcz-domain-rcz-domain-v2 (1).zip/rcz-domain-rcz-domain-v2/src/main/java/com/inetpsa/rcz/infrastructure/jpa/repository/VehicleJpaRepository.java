package com.inetpsa.rcz.infrastructure.jpa.repository;

import com.inetpsa.rcz.domain.model.shared.Payload;
import com.inetpsa.rcz.domain.model.sms.Sms;
import com.inetpsa.rcz.domain.model.vehicle.Vehicle;
import com.inetpsa.rcz.domain.repository.VehicleRepository;
import org.seedstack.business.domain.AggregateNotFoundException;
import org.seedstack.jpa.BaseJpaRepository;

import javax.persistence.NoResultException;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

public class VehicleJpaRepository extends BaseJpaRepository<Vehicle, String> implements VehicleRepository {

    private static final String STATE_VALUE = "connected";

    private static final String ID = "id";

    private static final String VEHICLE_INFO = "vehicleInfo";

    private static final String SERVICE_STATE = "serviceState";

    @Override
    public Boolean isConnected(String uin) {
        CriteriaBuilder criteriaBuilder = getEntityManager().getCriteriaBuilder();
        CriteriaQuery<Boolean> criteriaQuery = criteriaBuilder.createQuery(Boolean.class);
        Root<Vehicle> root = criteriaQuery.from(Vehicle.class);
        criteriaQuery.select(root.get(SERVICE_STATE).get(STATE_VALUE));
        criteriaQuery.where(criteriaBuilder.equal(root.get(ID), uin));
        try {
            return getEntityManager().createQuery(criteriaQuery).getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @Override
    public Payload getVehicleInfo(String uin) {
        CriteriaBuilder criteriaBuilder = getEntityManager().getCriteriaBuilder();
        CriteriaQuery<Payload> criteriaQuery = criteriaBuilder.createQuery(Payload.class);
        Root<Vehicle> root = criteriaQuery.from(Vehicle.class);
        criteriaQuery.select(root.get(VEHICLE_INFO));
        criteriaQuery.where(criteriaBuilder.equal(root.get(ID), uin));
        try {
            return getEntityManager().createQuery(criteriaQuery).getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @Override
    public Vehicle merge(Vehicle aggregate) throws AggregateNotFoundException {
        return getEntityManager().merge(aggregate);
    }
}
