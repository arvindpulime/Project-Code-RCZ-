package com.inetpsa.rcz.domain.model.payload.data;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.inetpsa.rcz.domain.model.enums.ElectricalNetworkStatus;
import com.inetpsa.rcz.domain.model.enums.PrivacyState;
import com.inetpsa.rcz.domain.model.enums.SevState;
import com.inetpsa.rcz.infrastructure.jackson.deserializer.DataJsonDeserializer;
import com.inetpsa.rcz.infrastructure.jackson.serializer.DataJsonSerializer;
import com.inetpsa.rcz.infrastructure.jackson.serializer.NumericBooleanSerializer;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.util.Date;

import static com.inetpsa.rcz.domain.model.payload.ValidationPattern.PATTERN_DATE;
import static com.inetpsa.rcz.domain.model.payload.ValidationPattern.PATTERN_VIN;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class VehicleInfos {

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = PATTERN_DATE)
    @JsonProperty("date")
    private Date date;

    @Min(0)
    @Max(2)
    @JsonProperty("privacy_state")
    private Integer privacyStateValue;

    @Min(0)
    @Max(7)
    @JsonProperty("etat_res_elec")
    private Integer electricalNetworkState;

    @JsonSerialize(using = NumericBooleanSerializer.class)
    @JsonProperty("alarm_activation")
    private Boolean alarmActivated;

    @JsonProperty("precond_state")
    private PreconditioningState preconditioningState;

    @JsonProperty("charging_state")
    private ChargingState chargingState;

    @JsonProperty("stolen_state")
    @JsonSerialize(using = NumericBooleanSerializer.class)
    private Boolean stolen;

    @NotNull
    @Pattern(regexp = PATTERN_VIN)
    @JsonProperty("vin")
    private String vin;

    @Min(0)
    @Max(7)
    @JsonProperty("reason")
    private Integer reason;

    @Min(0)
    @Max(1000)
    @JsonProperty("signal_quality")
    private Integer signalQuality;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = PATTERN_DATE)
    @JsonProperty("sev_stop_date")
    private Date sevStopDate;

    @JsonSerialize(using = NumericBooleanSerializer.class)
    @JsonProperty("immo_state")
    private Boolean immobilized;

    @JsonSerialize(using = DataJsonSerializer.class)
    @JsonDeserialize(using = DataJsonDeserializer.class)
    @JsonProperty("location")
    private Data location;

    @JsonSerialize(using = DataJsonSerializer.class)
    @JsonDeserialize(using = DataJsonDeserializer.class)
    @JsonProperty("fds")
    private Data fds;

    @NotNull
    @Min(0) @Max(3)
    @JsonProperty("sev_state")
    private Integer sevStateValue;

    @JsonProperty("timestamp_gnss")
    private Integer timestampGnss;

    @JsonProperty("obj_counter")
    private Integer objCounter;

    @NotNull
    @Min(0)
    @Max(2)
    @JsonProperty("privacy_customer")
    private Integer privacyCustomer;

    @NotNull
    @Min(0)
    @Max(2)
    @JsonProperty("privacy_applicable")
    private Integer privacyApplicable;

    @NotNull
    @Min(0)
    @Max(3)
    @JsonProperty("privacy_applicable_max")
    private Integer privacyApplicableMax;


    /**
     * 0 The ATB is not superlocked
     * 1 The ATB is superlocked
     */
    @JsonProperty("superlock_state")
    @Min(0) @Max(1)
    private Integer superlockState;

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Integer getSevStateValue() {
        return sevStateValue;
    }

    public void setSevStateValue(Integer sevStateValue) {
        this.sevStateValue = sevStateValue;
    }

    @JsonIgnore
    public SevState getSevState() {
        return SevState.fromIntValue(sevStateValue);
    }

    @JsonIgnore
    public PrivacyState getPrivacyState() {
        return PrivacyState.fromIntValue(privacyApplicable);
    }

    @JsonIgnore
    public ElectricalNetworkStatus getElectricalNetworkStatus() {
        return ElectricalNetworkStatus.fromIntValue(electricalNetworkState);
    }


    public VehicleInfos() {
    }

    public Integer getPrivacyStateValue() {
        return privacyStateValue;
    }

    public void setPrivacyStateValue(Integer privacyStateValue) {
        this.privacyStateValue = privacyStateValue;
    }

    public Boolean getAlarmActivated() {
        return alarmActivated;
    }

    public void setAlarmActivated(Boolean alarmActivated) {
        this.alarmActivated = alarmActivated;
    }

    public Boolean getStolen() {
        return stolen;
    }

    public void setStolen(Boolean stolen) {
        this.stolen = stolen;
    }

    public Integer getSignalQuality() {
        return signalQuality;
    }

    public void setSignalQuality(Integer signalQuality) {
        this.signalQuality = signalQuality;
    }

    public Date getSevStopDate() {
        return sevStopDate;
    }

    public void setSevStopDate(Date sevStopDate) {
        this.sevStopDate = sevStopDate;
    }

    public Boolean getImmobilized() {
        return immobilized;
    }

    public void setImmobilized(Boolean immobilized) {
        this.immobilized = immobilized;
    }

    public Data getLocation() {
        return location;
    }

    public void setLocation(Data location) {
        this.location = location;
    }

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    public Integer getElectricalNetworkState() {
        return electricalNetworkState;
    }

    public Integer getReason() {
        return reason;
    }

    public VehicleInfos setReason(Integer reason) {
        this.reason = reason;
        return this;
    }

    public Data getFds() {
        return fds;
    }

    public VehicleInfos setFds(Data fds) {
        this.fds = fds;
        return this;
    }

    public void setElectricalNetworkState(Integer electricalNetworkState) {
        this.electricalNetworkState = electricalNetworkState;
    }

    public PreconditioningState getPreconditioningState() {
        return preconditioningState;
    }

    public void setPreconditioningState(PreconditioningState preconditioningState) {
        this.preconditioningState = preconditioningState;
    }

    public ChargingState getChargingState() {
        return chargingState;
    }

    public void setChargingState(ChargingState chargingState) {
        this.chargingState = chargingState;
    }

    public Integer getTimestampGnss() {
        return timestampGnss;
    }

    public VehicleInfos setTimestampGnss(Integer timestampGnss) {
        this.timestampGnss = timestampGnss;
        return this;
    }

    public Integer getObjCounter() {
        return objCounter;
    }

    public VehicleInfos setObjCounter(Integer objCounter) {
        this.objCounter = objCounter;
        return this;
    }

    public Integer getPrivacyCustomer() {
        return privacyCustomer;
    }

    public VehicleInfos setPrivacyCustomer(Integer privacyCustomer) {
        this.privacyCustomer = privacyCustomer;
        return this;
    }

    public Integer getPrivacyApplicable() {
        return privacyApplicable;
    }

    public VehicleInfos setPrivacyApplicable(Integer privacyApplicable) {
        this.privacyApplicable = privacyApplicable;
        return this;
    }

    public Integer getPrivacyApplicableMax() {
        return privacyApplicableMax;
    }

    public VehicleInfos setPrivacyApplicableMax(Integer privacyApplicableMax) {
        this.privacyApplicableMax = privacyApplicableMax;
        return this;
    }

    public Integer getSuperlockState() {
        return superlockState;
    }

    public VehicleInfos setSuperlockState(Integer superlockState) {
        this.superlockState = superlockState;
        return this;
    }
}
