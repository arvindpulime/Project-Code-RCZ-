package com.inetpsa.rcz.domain.model.event;

import com.inetpsa.rcz.domain.model.payload.topic.Topic;
import org.seedstack.business.domain.BaseDomainEvent;

public abstract class AbstractRequestReceivedEvent extends BaseDomainEvent {

    private Topic topic;

    private String message;

    public AbstractRequestReceivedEvent(Topic topic, String message) {
        this.topic = topic;
        this.message = message;
    }

    public Topic getTopic() {
        return topic;
    }

    public void setTopic(Topic topic) {
        this.topic = topic;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
