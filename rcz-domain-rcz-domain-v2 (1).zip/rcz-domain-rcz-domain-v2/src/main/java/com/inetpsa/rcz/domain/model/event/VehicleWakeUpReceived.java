package com.inetpsa.rcz.domain.model.event;

import com.inetpsa.rcz.domain.model.exchange.Exchange;

public class VehicleWakeUpReceived extends AbstractExchangeEvent {
    public VehicleWakeUpReceived(Exchange exchange) {
        super(exchange);
    }
}
