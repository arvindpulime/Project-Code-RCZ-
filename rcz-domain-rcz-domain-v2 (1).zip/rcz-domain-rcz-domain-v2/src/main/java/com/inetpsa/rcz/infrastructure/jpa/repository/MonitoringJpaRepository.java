package com.inetpsa.rcz.infrastructure.jpa.repository;

import com.inetpsa.rcz.domain.model.monitoring.MonitoringInfo;
import com.inetpsa.rcz.domain.model.monitoring.MonitoringInfoId;
import com.inetpsa.rcz.domain.repository.MonitoringRepository;
import org.seedstack.jpa.BaseJpaRepository;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaDelete;

/**
 * @author tuan.docao@ext.mpsa.com
 */
public class MonitoringJpaRepository extends BaseJpaRepository<MonitoringInfo, MonitoringInfoId> implements MonitoringRepository {


    @Override
    public void removeAll() {
        CriteriaBuilder builder = getEntityManager().getCriteriaBuilder();
        CriteriaDelete<MonitoringInfo> query = builder.createCriteriaDelete(MonitoringInfo.class);
        query.from(MonitoringInfo.class);
        getEntityManager().createQuery(query).executeUpdate();
    }
}
