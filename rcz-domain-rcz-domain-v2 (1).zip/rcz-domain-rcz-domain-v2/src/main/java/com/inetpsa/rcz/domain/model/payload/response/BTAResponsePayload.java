package com.inetpsa.rcz.domain.model.payload.response;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.inetpsa.rcz.domain.model.enums.ResponseStatus;
import com.inetpsa.rcz.domain.model.payload.ResponseStatusResolver;
import com.inetpsa.rcz.domain.model.payload.data.Data;
import com.inetpsa.rcz.infrastructure.jackson.deserializer.DataJsonDeserializer;

import javax.validation.constraints.NotNull;
import java.util.Date;

import static com.inetpsa.rcz.domain.model.payload.ValidationPattern.PATTERN_DATE;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BTAResponsePayload {

    @NotNull
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = PATTERN_DATE)
    @JsonProperty("resp_date")
    private Date responseDate;

    @NotNull
    @JsonProperty("req_id")
    private String requestId;

    @NotNull
    @JsonProperty("status")
    private Integer status;

    @NotNull
    @JsonDeserialize(using = DataJsonDeserializer.class)
    @JsonProperty("data")
    private Data data;

    @NotNull
    @JsonDeserialize(using = DataJsonDeserializer.class)
    @JsonProperty("location")
    private Data location;

    @JsonProperty("reason")
    private String reason;



    @JsonIgnore
    public ResponseStatus getResponseStatus() {
        return ResponseStatusResolver.BTA_RESPONSE_STATUS_RESOLVER.get(this.getStatus());
    }

    public Date getResponseDate() {
        return responseDate;
    }

    public void setResponseDate(Date responseDate) {
        this.responseDate = responseDate;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Data getData() {
        return data;
    }

    public void setData(Data data) {
        this.data = data;
    }

    public Data getLocation() {
        return location;
    }

    public void setLocation(Data location) {
        this.location = location;
    }

    public String getReason() {
        return reason;
    }

    public BTAResponsePayload setReason(String reason) {
        this.reason = reason;
        return this;
    }
}
