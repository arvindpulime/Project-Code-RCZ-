package com.inetpsa.rcz.domain.services.impl;

import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.repository.ExchangeRepository;
import com.inetpsa.rcz.domain.services.ExchangeService;
import com.inetpsa.rcz.domain.services.ParameterService;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.Logging;
import org.seedstack.seed.transaction.Propagation;
import org.seedstack.seed.transaction.Transactional;
import org.slf4j.Logger;

import javax.inject.Inject;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

@JpaUnit("rcz")
public class ExchangeServiceImpl implements ExchangeService {

    @Inject
    private ExchangeRepository exchangeRepository;

    @Inject
    private ParameterService parameterService;

    @Logging
    private Logger logger;

    @Override
    @Transactional
    public void add(Exchange exchange) {
        logger.debug("Creating new Exchange: " + exchange.getId());
        exchangeRepository.add(exchange);
    }

    @Override
    @Transactional
    public void update(Exchange exchange) {
        logger.debug("Updating new Exchange: " + exchange.getId());
        exchangeRepository.merge(exchange);
    }

    @Override
    @Transactional
    public String getRequestStateStatus(String correlationId) {
        Optional<Exchange> exchange = exchangeRepository.findByCorrelationId(correlationId);
        String requestStateStatus = null;
        if (exchange.isPresent()) {
            if (exchange.get().getResponseStatus() != null) {
                requestStateStatus = exchange.get().getResponseStatus().code();
            } else if (exchange.get().getProcessStatus() != null) {
                requestStateStatus = exchange.get().getProcessStatus().code();
            }
        }
        return requestStateStatus;
    }

    @Override
    @Transactional
    public Optional<Exchange> findById(String id) {
        return exchangeRepository.get(id);
    }

    @Override
    @Transactional
    public List<Exchange> findAllInTimeout(int timeout) {
        return exchangeRepository.findAllInTimeout(timeout);
    }

    @Override
    @Transactional
    public Optional<Exchange> findPendingByCorrelationId(String correlationId) {
        return exchangeRepository.findPendingByCorrelationId(correlationId);
    }

    @Override
    @Transactional
    public Collection<Exchange> findPendingAsleep(String uin) {
        return exchangeRepository.findPendingAsleep(uin);
    }

    @Override
    @Transactional
    public List<Exchange> findStolenInTimeout(int timeout) {
        return exchangeRepository.findStolenInTimeout(timeout);
    }

    @Override
    @Transactional
    public boolean correlationIdExist(String correlationId, String callerId) {
        return exchangeRepository.correlationIdExist(correlationId, callerId);
    }

}
