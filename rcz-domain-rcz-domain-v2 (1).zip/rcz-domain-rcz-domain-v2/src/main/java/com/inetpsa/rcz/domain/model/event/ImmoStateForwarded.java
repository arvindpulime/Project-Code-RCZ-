package com.inetpsa.rcz.domain.model.event;

import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.payload.request.ImmoStateRequestPayload;
import com.inetpsa.rcz.domain.model.payload.topic.Topic;

public class ImmoStateForwarded extends AbstractExchangeEvent {

    private Topic topic;

    private ImmoStateRequestPayload immoStateRequestPayload;

    public ImmoStateForwarded(Exchange exchange, ImmoStateRequestPayload immoStateRequestPayload, Topic topic) {
        super(exchange);
        this.topic = topic;
        this.immoStateRequestPayload = immoStateRequestPayload;
    }

    public Topic getTopic() {
        return topic;
    }

    public ImmoStateRequestPayload getImmoStateRequestPayload() {
        return immoStateRequestPayload;
    }

    public ImmoStateForwarded setTopic(Topic topic) {
        this.topic = topic;
        return this;
    }
}
