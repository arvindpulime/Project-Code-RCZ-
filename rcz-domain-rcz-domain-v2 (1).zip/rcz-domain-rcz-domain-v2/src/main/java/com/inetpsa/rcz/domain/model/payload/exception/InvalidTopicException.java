package com.inetpsa.rcz.domain.model.payload.exception;

public class InvalidTopicException extends RuntimeException {
    public InvalidTopicException() {
    }

    public InvalidTopicException(String message) {
        super(message);
    }

    public InvalidTopicException(String message, Throwable cause) {
        super(message, cause);
    }

    public InvalidTopicException(Throwable cause) {
        super(cause);
    }

    public InvalidTopicException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
