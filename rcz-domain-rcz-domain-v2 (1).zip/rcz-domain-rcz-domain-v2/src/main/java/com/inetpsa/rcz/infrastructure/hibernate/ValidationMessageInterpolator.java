package com.inetpsa.rcz.infrastructure.hibernate;

import javax.validation.MessageInterpolator;
import java.util.Locale;

/**
 * Custom message interpolator enabling ability to specify the locale for validation messages.
 *
 * @author tuan.docao@ext.mpsa.com
 */
public class ValidationMessageInterpolator implements MessageInterpolator {

    private final MessageInterpolator defaultInterpolator;

    private final Locale defaultLocale;

    public ValidationMessageInterpolator(MessageInterpolator interpolator, Locale locale) {
        this.defaultLocale = locale;
        this.defaultInterpolator = interpolator;
    }

    @Override
    public String interpolate(String messageTemplate, Context context) {
        return defaultInterpolator.interpolate(messageTemplate, context, this.defaultLocale);
    }

    @Override
    public String interpolate(String messageTemplate, Context context, Locale locale) {
        return defaultInterpolator.interpolate(messageTemplate, context, locale);
    }
}
