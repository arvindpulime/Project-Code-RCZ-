package com.inetpsa.rcz.infrastructure.jpa.repository;

import com.inetpsa.rcz.domain.model.vehicle.VehicleServiceInfo;
import com.inetpsa.rcz.domain.repository.VehicleServiceInfoRepository;
import org.seedstack.business.domain.AggregateNotFoundException;
import org.seedstack.jpa.BaseJpaRepository;

public class VehicleServiceInfoJpaRepository extends BaseJpaRepository<VehicleServiceInfo, String> implements VehicleServiceInfoRepository {
    @Override
    public VehicleServiceInfo merge(VehicleServiceInfo aggregate) throws AggregateNotFoundException {
        return getEntityManager().merge(aggregate);
    }
}
