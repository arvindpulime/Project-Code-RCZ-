package com.inetpsa.rcz.domain.services.impl;

import com.inetpsa.rcz.domain.model.sms.Sms;
import com.inetpsa.rcz.domain.repository.SmsRepository;
import com.inetpsa.rcz.domain.services.SmsService;
import org.seedstack.business.domain.Factory;
import org.seedstack.business.specification.Specification;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import javax.inject.Inject;
import java.util.List;
import java.util.Optional;

@JpaUnit("rcz")
public class SmsServiceImpl implements SmsService {

    public static final String UIN = "uin";
    public static final String MESSAGE_ID = "messageId";

    @Inject
    private SmsRepository smsRepository;

    @Inject
    private Factory<Sms> smsFactory;

    @Override
    @Transactional
    public Sms create() {
        Sms sms = smsFactory.create();
        return sms;
    }

    @Override
    @Transactional
    public void save(Sms sms) {
        smsRepository.add(sms);
    }

    @Transactional
    @Override
    public Sms update(Sms sms) {
        return smsRepository.merge(sms);
    }

    @Transactional
    @Override
    public int updateAll(List<Sms> smsList) {
        int updated = 0;
        for (Sms sms : smsList) {
            smsRepository.merge(sms);
            updated++;
        }
        return updated;
    }

    @Transactional
    @Override
    public Optional<Sms> findById(String id) {
        return smsRepository.get(id);
    }

    @Transactional
    @Override
    public Optional<Sms> findByMessageIdAndUin(String messageId, String uin) {
        Specification<Sms> specification = smsRepository.getSpecificationBuilder().ofAggregate(Sms.class)
                .property(UIN).equalTo(uin)
                .and()
                .property(MESSAGE_ID).equalTo(messageId).build();
        return smsRepository.get(specification).findFirst();
    }

    @Override
    @Transactional
    public Optional<Sms> findByMessageId(String messageId) {
        Specification<Sms> specification = smsRepository.getSpecificationBuilder().ofAggregate(Sms.class)
                .property(MESSAGE_ID).equalTo(messageId).build();
        return smsRepository.get(specification).findFirst();
    }

    @Transactional
    @Override
    public Optional<Sms> findByUin(String uin) {
        Specification<Sms> specification = smsRepository.getSpecificationBuilder().ofAggregate(Sms.class).property("uin").equalTo(uin).build();
        return smsRepository.get(specification).findFirst();
    }
}
