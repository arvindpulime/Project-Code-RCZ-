package com.inetpsa.rcz.domain.model.payload.data;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class PreconditioningState {

    @Min(0)
    @Max(1)
    @JsonProperty("available")
    private Integer available;

    @JsonProperty("programs")
    private Programs programs;

    @Min(0)
    @Max(1)
    @JsonProperty("asap")
    private Integer asap;

    @Min(0)
    @Max(8)
    @JsonProperty("status")
    private Integer status;

    @Min(0)
    @Max(1)
    @JsonProperty("aff")
    private Integer aff;

    public Integer getAvailable() {
        return available;
    }

    public void setAvailable(Integer available) {
        this.available = available;
    }

    public Programs getPrograms() {
        return programs;
    }

    public void setPrograms(Programs programs) {
        this.programs = programs;
    }

    public Integer getAsap() {
        return asap;
    }

    public void setAsap(Integer asap) {
        this.asap = asap;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getAff() {
        return aff;
    }

    public void setAff(Integer aff) {
        this.aff = aff;
    }
}
