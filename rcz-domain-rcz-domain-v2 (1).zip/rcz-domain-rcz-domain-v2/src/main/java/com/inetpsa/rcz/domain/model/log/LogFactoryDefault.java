package com.inetpsa.rcz.domain.model.log;

import com.inetpsa.rcz.domain.model.enums.LogLevel;
import org.seedstack.business.domain.BaseFactory;
import org.seedstack.business.domain.Create;
import org.seedstack.seed.Configuration;

import java.util.Date;

public class LogFactoryDefault extends BaseFactory<Log> implements LogFactory {

    @Configuration("rcz.application.instance")
    private String instanceId;

    @Create
    @Override
    public Log create(LogLevel logLevel, Date logDate, LogMessage message, String exchangeId) {
        return new Log(logLevel, logDate, message, exchangeId, instanceId);
    }

    @Create
    @Override
    public Log create() {
        return new Log(instanceId);
    }


}
