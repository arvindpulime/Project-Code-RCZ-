package com.inetpsa.rcz.domain.services;

import com.inetpsa.rcz.domain.model.payload.data.VehicleStateResult;
import com.inetpsa.rcz.domain.model.vehicle.*;
import org.seedstack.business.Service;
import org.seedstack.seed.transaction.Transactional;

import java.util.Optional;

@Service
public interface VehicleService {

    Boolean isConnected(String uin);

    VehicleStateResult getVehicleInfo(String uin);

    Vehicle save(Vehicle vehicle);

    @Transactional
    void saveServiceState(VehicleServiceState vehicle);

    @Transactional
    void saveConnect(VehicleConnect vehicle);

    @Transactional
    void saveVehicleLowPowerInfo(VehicleLowPowerInfo vehicle);

    @Transactional
    void saveVehicleVehicleInfo(VehicleVehicleInfo vehicle);


    @Transactional
    void saveVehicleServiceInfo(VehicleServiceInfo vehicle);

    Optional<Vehicle> find(String uin);

    @Transactional
    Optional<VehicleServiceState> findVehicleServiceState(String uin);

    @Transactional
    Optional<VehicleConnect> findVehicleConnect(String uin);

    @Transactional
    Optional<VehicleLowPowerInfo> findVehicleLowPowerInfo(String uin);

    @Transactional
    Optional<VehicleVehicleInfo> findVehicleVehicleInfo(String uin);

    @Transactional
    Optional<VehicleServiceInfo> findVehicleServiceInfo(String uin);

    @Transactional
    Optional<Vehicle> findByVin(String vin);

    @Transactional
    Optional<Vehicle> findByMsisdn(String msisdn);
}
