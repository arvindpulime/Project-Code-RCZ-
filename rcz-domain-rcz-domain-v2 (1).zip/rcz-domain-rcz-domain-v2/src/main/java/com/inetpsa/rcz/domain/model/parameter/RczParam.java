package com.inetpsa.rcz.domain.model.parameter;

import lombok.Data;
import lombok.experimental.Accessors;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Data
@Embeddable
@Accessors(chain = true)
public class RczParam implements Serializable {
    private Boolean automaticVehicleState = true;

    private Boolean callerDailyQuotaEnabled = false;

    private Boolean clientResponseDebug = false;

    private Boolean openBar = false;

    private Boolean proxy = false;

    private Integer callerDailyQuotaDurationMin = 1440;

    private Integer callerDailyQuota = 50;

    private Integer callerQuotaDurationMin = 1;

    private Integer callerQuota = 3;

    private Integer callerQuotaWarningDurationMin = 1440;

    private Integer callerQuotaWarning = 30;

    private Integer exchangeTimeoutMin = 1;

    private Integer hornQuotaDurationMin = 60;

    private Integer hornQuota = 3;

    private Integer lightsQuotaDurationMin = 60;

    private Integer lightsQuota = 6;

    private String remoteAlarmId = "mdercz00";
}