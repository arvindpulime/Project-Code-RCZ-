package com.inetpsa.rcz.domain.model.payload.data;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.inetpsa.rcz.infrastructure.jackson.serializer.NumericBooleanSerializer;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.util.Date;

import static com.inetpsa.rcz.domain.model.payload.ValidationPattern.PATTERN_DATE;
import static com.inetpsa.rcz.domain.model.payload.ValidationPattern.PATTERN_VIN;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LowPowerInfo {

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = PATTERN_DATE)
    @JsonProperty("date")
    private Date date;

    @NotNull
    @Min(0)
    @Max(9)
    @JsonProperty("currentState")
    private Integer currentState;

    @Min(0)
    @Max(9)
    @JsonProperty("nextState")
    private Integer nextState;

    @JsonProperty("isWmActive")
    @JsonSerialize(using = NumericBooleanSerializer.class)
    private Boolean isWmActive;

    @JsonProperty("remainingWMTime")
    private Integer[] remainingWMTime;

    @JsonProperty("dischargingRemainingTime")
    private Integer dischargingRemainingTime;

    @JsonProperty("dischargingMax")
    private Integer dischargingMax;

    @Min(0)
    @Max(4)
    @JsonProperty("powerOffReason")
    private Integer powerOffReason;

    @NotNull
    @Pattern(regexp = PATTERN_VIN)
    @JsonProperty("vin")
    private String vin;

    public Date getDate() {
        return date;
    }

    public LowPowerInfo setDate(Date date) {
        this.date = date;
        return this;
    }

    public Integer getCurrentState() {
        return currentState;
    }

    public LowPowerInfo setCurrentState(Integer currentState) {
        this.currentState = currentState;
        return this;
    }

    public Integer getNextState() {
        return nextState;
    }

    public LowPowerInfo setNextState(Integer nextState) {
        this.nextState = nextState;
        return this;
    }

    public Boolean getIsWmActive() {
        return isWmActive;
    }

    public LowPowerInfo setIsWmActive(Boolean wmActive) {
        isWmActive = wmActive;
        return this;
    }

    public Integer[] getRemainingWMTime() {
        return remainingWMTime;
    }

    public LowPowerInfo setRemainingWMTime(Integer[] remainingWMTime) {
        this.remainingWMTime = remainingWMTime;
        return this;
    }

    public Integer getDischargingRemainingTime() {
        return dischargingRemainingTime;
    }

    public LowPowerInfo setDischargingRemainingTime(Integer dischargingRemainingTime) {
        this.dischargingRemainingTime = dischargingRemainingTime;
        return this;
    }

    public Integer getDischargingMax() {
        return dischargingMax;
    }

    public LowPowerInfo setDischargingMax(Integer dischargingMax) {
        this.dischargingMax = dischargingMax;
        return this;
    }

    public Integer getPowerOffReason() {
        return powerOffReason;
    }

    public LowPowerInfo setPowerOffReason(Integer powerOffReason) {
        this.powerOffReason = powerOffReason;
        return this;
    }

    public String getVin() {
        return vin;
    }

    public LowPowerInfo setVin(String vin) {
        this.vin = vin;
        return this;
    }
}
