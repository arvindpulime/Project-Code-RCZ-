package com.inetpsa.rcz.domain.model.payload.topic;

import com.inetpsa.rcz.domain.model.payload.data.RequestState;

public class RequestStateBtaTopicsResolver implements BtaTopicsResolver<RequestState> {
}
