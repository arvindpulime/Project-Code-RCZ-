package com.inetpsa.rcz.domain.repository;

import com.inetpsa.rcz.domain.model.log.Log;
import org.seedstack.business.domain.Repository;

import java.util.List;

/**
 * @author tuan.docao@ext.mpsa.com
 */
public interface LogRepository extends Repository<Log, String> {

    List<Log> findByExchangeId(String exchangeId);
}
