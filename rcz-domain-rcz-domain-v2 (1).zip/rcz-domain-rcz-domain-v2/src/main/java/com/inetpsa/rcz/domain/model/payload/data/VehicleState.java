package com.inetpsa.rcz.domain.model.payload.data;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import static com.inetpsa.rcz.domain.model.payload.ValidationPattern.PATTERN_REQUEST_STATE_ACTION;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class VehicleState {

    @NotNull
    @Pattern(regexp = PATTERN_REQUEST_STATE_ACTION)
    @JsonProperty("action")
    private String action;

    public VehicleState() {
    }

    public String getAction() {
        return action;
    }

    public VehicleState setAction(String action) {
        this.action = action;
        return this;
    }
}
