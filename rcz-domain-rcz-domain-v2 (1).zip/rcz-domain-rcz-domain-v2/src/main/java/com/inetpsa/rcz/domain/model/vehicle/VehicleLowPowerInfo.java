package com.inetpsa.rcz.domain.model.vehicle;

import com.inetpsa.rcz.domain.model.shared.Payload;
import org.seedstack.business.domain.BaseAggregateRoot;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "RCZQTVEHICLE")
public class VehicleLowPowerInfo extends BaseAggregateRoot<String> {

    @Id
    @Column(name = "uin")
    private String id;


    @Embedded
    @AttributeOverrides({
            @AttributeOverride(column = @Column(name = "lowPowerInfoPayload"), name = "rawJson"),
            @AttributeOverride(column = @Column(name = "lowPowerInfoDate"), name = "receivedDate"),
            @AttributeOverride(column = @Column(name = "lowPowerInfoSentDate"), name = "sentDate")
    })
    private Payload lowPowerInfo;


    private Date updateDate = new Date();

    VehicleLowPowerInfo() {
    }

    VehicleLowPowerInfo(String id) {
        this.id = id;
    }

    public void setId(String id) {
        this.id = id;
    }


    public Payload getLowPowerInfo() {
        return lowPowerInfo;
    }

    public VehicleLowPowerInfo setLowPowerInfo(Payload lowPowerInfo) {
        this.lowPowerInfo = lowPowerInfo;
        return this;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public VehicleLowPowerInfo setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
        return this;
    }

    @Override
    public String getId() {
        return id;
    }

}