package com.inetpsa.rcz.domain.model.payload.data;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import static com.inetpsa.rcz.domain.model.payload.ValidationPattern.PATTERN_DOORS_ACTION;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DoorsRequest {

    public DoorsRequest() {
    }

    @NotNull
    @Pattern(regexp = PATTERN_DOORS_ACTION)
    @JsonProperty("action")
    private String action;

    @JsonProperty("forced")
    private boolean forced = false;

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public boolean isForced() {
        return forced;
    }

    public DoorsRequest setForced(boolean forced) {
        this.forced = forced;
        return this;
    }
}
