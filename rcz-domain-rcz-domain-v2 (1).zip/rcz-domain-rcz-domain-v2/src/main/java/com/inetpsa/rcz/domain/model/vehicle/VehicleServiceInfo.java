package com.inetpsa.rcz.domain.model.vehicle;

import com.inetpsa.rcz.domain.model.shared.Payload;
import org.seedstack.business.domain.BaseAggregateRoot;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "RCZQTVEHICLE")
public class VehicleServiceInfo extends BaseAggregateRoot<String> {

    @Id
    @Column(name = "uin")
    private String id;


    @Embedded
    @AttributeOverrides({
            @AttributeOverride(column = @Column(name = "serviceInfoPayload"), name = "rawJson"),
            @AttributeOverride(column = @Column(name = "serviceInfoDate"), name = "receivedDate"),
            @AttributeOverride(column = @Column(name = "serviceInfoSentDate"), name = "sentDate")
    })
    private Payload serviceInfo;


    private Date updateDate = new Date();

    VehicleServiceInfo() {
    }

    VehicleServiceInfo(String id) {
        this.id = id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Payload getServiceInfo() {
        return serviceInfo;
    }

    public VehicleServiceInfo setServiceInfo(Payload serviceInfo) {
        this.serviceInfo = serviceInfo;
        return this;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public VehicleServiceInfo setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
        return this;
    }

    @Override
    public String getId() {
        return id;
    }

}