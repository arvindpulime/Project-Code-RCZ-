package com.inetpsa.rcz.domain.services;

import com.inetpsa.rcz.domain.model.exchange.Exchange;
import org.seedstack.business.Service;
import org.seedstack.seed.transaction.Transactional;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

@Service
public interface ExchangeService {

    Optional<Exchange> findById(String id);

    void add(Exchange exchange);

    void update(Exchange exchange);

    String getRequestStateStatus(String correlationId);

    Optional<Exchange> findPendingByCorrelationId(String correlationId);

    Collection<Exchange> findPendingAsleep(String uin);

    List<Exchange> findStolenInTimeout(int timeout);

    List<Exchange> findAllInTimeout(int timeout);

    boolean correlationIdExist(String correlationId, String callerId);

}
