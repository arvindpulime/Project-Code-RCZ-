package com.inetpsa.rcz.domain.services;

import com.inetpsa.rcz.domain.model.enums.LogLevel;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.log.LogMessage;
import org.seedstack.business.Service;

import static com.inetpsa.rcz.domain.services.LogService.AppLog;

/**
 * @author tuan.docao@ext.mpsa.com
 */
@Service
public interface AppLogger {

    AppLog key();

    void log(LogLevel logLevel, LogMessage message, Exchange exchange);
}
