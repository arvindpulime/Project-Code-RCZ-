package com.inetpsa.rcz.infrastructure.jpa.repository;

import com.inetpsa.rcz.domain.model.vehicle.VehicleLowPowerInfo;
import com.inetpsa.rcz.domain.repository.VehicleLowPowerInfoRepository;
import org.seedstack.business.domain.AggregateNotFoundException;
import org.seedstack.jpa.BaseJpaRepository;

public class VehicleLowPowerInfoJpaRepository extends BaseJpaRepository<VehicleLowPowerInfo, String> implements VehicleLowPowerInfoRepository {
    @Override
    public VehicleLowPowerInfo merge(VehicleLowPowerInfo aggregate) throws AggregateNotFoundException {
        return getEntityManager().merge(aggregate);
    }
}
