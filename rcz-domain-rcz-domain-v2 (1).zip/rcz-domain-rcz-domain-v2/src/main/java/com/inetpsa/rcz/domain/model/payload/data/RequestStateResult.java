package com.inetpsa.rcz.domain.model.payload.data;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import static com.inetpsa.rcz.domain.model.payload.ValidationPattern.PATTERN_RETURN_CODE;

/**
 * @author tuan.docao@ext.mpsa.com
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RequestStateResult {

    @NotNull
    @Pattern(regexp = PATTERN_RETURN_CODE)
    @JsonProperty("status_code")
    private String statusCode;

    public RequestStateResult() {
    }

    public RequestStateResult(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }
}
