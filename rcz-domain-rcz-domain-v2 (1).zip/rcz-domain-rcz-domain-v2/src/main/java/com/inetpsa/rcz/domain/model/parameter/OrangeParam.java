package com.inetpsa.rcz.domain.model.parameter;

import lombok.Data;
import lombok.experimental.Accessors;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Data
@Embeddable
@Accessors(chain = true)
public class OrangeParam implements Serializable {

    @Column(name = "orangeSmsHost")
    private String host;

    @Column(name = "orangeSmsPath")
    private String path;

    @Column(name = "orangeSmsUsername")
    private String username;

    @Column(name = "orangeSmsPassword")
    private String password;

    @Column(name = "orangeSmsSenderAddress")
    private String senderAddress;

    @Column(name = "orangeSmsHeaderHost")
    private String headerHost;

    @Column(name = "orangeSmsRequestTimeout")
    private Integer requestTimeout;

    @Column(name = "orangeSmsConnectionTimeout")
    private Integer connectionTimeout;

    @Column(name = "headerVersion")
    private String headerVersion;

    @Column(name = "ecuType")
    private String ecuType;

    @Column(name = "orangeServiceType")
    private String serviceType;

    @Column(name = "objectType")
    private String objectType;

    @Column(name = "objectVersion")
    private String objectVersion;

    @Column(name = "objectId")
    private String objectId;

    @Column(name = "messageBinary")
    private Boolean messageBinary = true;


}
