package com.inetpsa.rcz.domain.model.payload.data;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ServiceInfo {

    public static String THERMAL_PRECOND = "ThermalPrecond";
    public static String Vehicle_Charge = "VehicleCharge";
    public static String DOORS_LOCK = "DoorsLock";
    public static String DOORS_LOCK_CONFIRMED = "DoorsLockConfirmed";
    public static String DOORS_LOCK_SELECTIVITY = "DoorsLockSelectivity";
    public static String HORN = "Horn";
    public static String TS_LIGHTS = "TSLights";

    @JsonProperty("version")
    private String version;

    @JsonProperty("build")
    private String build;

    @JsonProperty("mqtt_api_version")
    private String mqttApiVersion;

    @JsonProperty("capabilities")
    private List<String> capabilities;

    public ServiceInfo() {
    }

    public String getVersion() {
        return version;
    }

    public ServiceInfo setVersion(String version) {
        this.version = version;
        return this;
    }

    @JsonIgnore
    public boolean isBlackListed() {
        if (capabilities != null && !capabilities.isEmpty()) {
            return capabilities.contains(DOORS_LOCK_CONFIRMED);
        }
        return false;
    }

    public String getBuild() {
        return build;
    }

    public ServiceInfo setBuild(String build) {
        this.build = build;
        return this;
    }

    public String getMqttApiVersion() {
        return mqttApiVersion;
    }

    public ServiceInfo setMqttApiVersion(String mqttApiVersion) {
        this.mqttApiVersion = mqttApiVersion;
        return this;
    }

    public List<String> getCapabilities() {
        return capabilities;
    }

    public ServiceInfo setCapabilities(List<String> capabilities) {
        this.capabilities = capabilities;
        return this;
    }
}
