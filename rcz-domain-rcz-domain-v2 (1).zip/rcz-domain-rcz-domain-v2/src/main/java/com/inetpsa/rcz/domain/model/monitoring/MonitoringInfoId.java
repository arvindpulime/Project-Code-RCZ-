package com.inetpsa.rcz.domain.model.monitoring;

import org.seedstack.business.domain.BaseValueObject;

import javax.persistence.Embeddable;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;

@Embeddable
public class MonitoringInfoId extends BaseValueObject {
    private String instance;
    @Enumerated(EnumType.STRING)
    private MonitoringType type;

    public MonitoringInfoId() {
    }

    public MonitoringInfoId(String instance, MonitoringType type) {
        this.instance = instance;
        this.type = type;
    }

    public String getInstance() {
        return instance;
    }

    public MonitoringInfoId setInstance(String instance) {
        this.instance = instance;
        return this;
    }

    public MonitoringType getType() {
        return type;
    }

    public MonitoringInfoId setType(MonitoringType type) {
        this.type = type;
        return this;
    }
}
