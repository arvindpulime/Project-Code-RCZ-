package com.inetpsa.rcz.domain.services;

import com.inetpsa.rcz.domain.model.monitoring.AppInfo;
import com.inetpsa.rcz.domain.model.monitoring.MqttClient;
import org.seedstack.business.Service;

import java.util.List;
import java.util.Map;

@Service
public interface MonitoringService {

    void updateMqttMonitoringData(String instance, List<MqttClient> mqttClients);

    void updateApplicationMonitoringData(String instance, AppInfo appInfo);

    Map<String, List<MqttClient>> getAllMqttMonitoringData();

    List<AppInfo> getAllApplicationMonitoringData();

    void deleteAll();
}
