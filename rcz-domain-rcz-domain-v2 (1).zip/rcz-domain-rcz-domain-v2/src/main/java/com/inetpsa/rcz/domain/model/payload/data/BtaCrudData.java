package com.inetpsa.rcz.domain.model.payload.data;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BtaCrudData {

    @JsonProperty("req_id")
    private String requestId;

    public BtaCrudData(String requestId) {
        this.requestId = requestId;
    }

    public BtaCrudData() {
    }

    public String getRequestId() {
        return requestId;
    }

    public BtaCrudData setRequestId(String requestId) {
        this.requestId = requestId;
        return this;
    }
}
