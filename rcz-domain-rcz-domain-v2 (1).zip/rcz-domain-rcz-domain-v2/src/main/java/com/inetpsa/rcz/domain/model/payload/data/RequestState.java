package com.inetpsa.rcz.domain.model.payload.data;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import static com.inetpsa.rcz.domain.model.payload.ValidationPattern.PATTERN_CORRELATION_ID;
import static com.inetpsa.rcz.domain.model.payload.ValidationPattern.PATTERN_REQUEST_STATE_ACTION;

/**
 * @author tuan.docao@ext.mpsa.com
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class RequestState {

    @NotNull
    @Pattern(regexp = PATTERN_CORRELATION_ID)
    @JsonProperty("correlation_id")
    private String correlationId;

    @NotNull
    @Pattern(regexp = PATTERN_REQUEST_STATE_ACTION)
    @JsonProperty("action")
    private String action;

    public RequestState() {

    }

    public RequestState(String correlationId) {
        this.correlationId = correlationId;
    }

    public String getCorrelationId() {
        return correlationId;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }
}
