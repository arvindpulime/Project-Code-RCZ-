package com.inetpsa.rcz.domain.model.monitoring;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.google.common.collect.Lists;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.Collections;
import java.util.Date;
import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Accessors(chain = true)
public class MqttClient {

    private String clientId;

    private boolean connected;

    private List<String> serverURIs;

    private List<String> topics;

    private String reconnectionMode;

    private Integer reconnectionInterval;

    private Integer keepAliveInterval;

    private Boolean cleanSession;

    private Integer mqttVersion;

    private Integer connectionTimeout;

    private Integer poolCoreSize;

    private Integer poolMaxSize;

    private Integer poolQueueSize;

    private Integer poolKeepAlive;

    private Date upDate = new Date();

    public boolean isConnected() {
        Date now = new Date();
        if (now.getTime() - upDate.getTime() > 61000) {
            return false;
        }
        return connected;
    }
    public MqttClient serverURIs(String... serverURIs) {
        if (this.serverURIs == null) {
            this.serverURIs = Lists.newArrayList();
        }
        Collections.addAll(this.serverURIs, serverURIs);
        return this;
    }

    public MqttClient topics(String... topics) {
        if (this.topics == null) {
            this.topics = Lists.newArrayList();
        }
        Collections.addAll(this.topics, topics);
        return this;
    }


}
