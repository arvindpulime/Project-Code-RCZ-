package com.inetpsa.rcz.domain.model.payload.data;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.inetpsa.rcz.infrastructure.jackson.serializer.NumericBooleanSerializer;

import javax.validation.constraints.Pattern;

import static com.inetpsa.rcz.domain.model.payload.ValidationPattern.PATTERN_TRACKING_ACTION;

/**
 * @author tuan.docao@ext.mpsa.com
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Immobilization extends Error{

    @JsonProperty("action")
    @Pattern(regexp = PATTERN_TRACKING_ACTION)
    private String action;

    @JsonSerialize(using = NumericBooleanSerializer.class)
    @JsonProperty("state")
    private Boolean state;

    @JsonProperty("password")
    private String password;

    public Immobilization() {
    }

    public Immobilization(Boolean state) {
        this.state = state;
    }


    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public Boolean getState() {
        return state;
    }

    public void setState(Boolean state) {
        this.state = state;
    }

    public String getPassword() {
        return password;
    }

    public Immobilization setPassword(String password) {
        this.password = password;
        return this;
    }
}
