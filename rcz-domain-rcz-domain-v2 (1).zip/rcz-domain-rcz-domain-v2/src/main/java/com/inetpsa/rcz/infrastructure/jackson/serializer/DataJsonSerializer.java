package com.inetpsa.rcz.infrastructure.jackson.serializer;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.inetpsa.rcz.domain.model.payload.data.Data;

import java.io.IOException;

public class DataJsonSerializer extends JsonSerializer<Data> {

    @Override
    public void serialize(Data value, JsonGenerator gen, SerializerProvider serializers) throws IOException {
        if (value != null) {
            gen.writeRawValue(value.getValue());
        }
    }
}
