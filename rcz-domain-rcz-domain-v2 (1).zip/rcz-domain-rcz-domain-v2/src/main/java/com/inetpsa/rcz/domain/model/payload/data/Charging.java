package com.inetpsa.rcz.domain.model.payload.data;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import static com.inetpsa.rcz.domain.model.payload.ValidationPattern.PATTERN_CHARGING_TYPE;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Charging {

    public static final String DELAYED = "delayed";
    public static final String IMMEDIATE = "immediate";

    @NotNull
    @JsonProperty("program")
    private Program program;

    @NotNull
    @JsonProperty("type")
    @Pattern(regexp = PATTERN_CHARGING_TYPE)
    private String type;

    public Charging(Program program, String type) {
        this.program = program;
        this.type = type;
    }

    public Charging() {
    }

    public Program getProgram() {
        return program;
    }

    public void setProgram(Program program) {
        this.program = program;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
