package com.inetpsa.rcz.domain.repository;

import com.inetpsa.rcz.domain.model.vehicle.VehicleLowPowerInfo;
import org.seedstack.business.domain.AggregateNotFoundException;
import org.seedstack.business.domain.Repository;

public interface VehicleLowPowerInfoRepository extends Repository<VehicleLowPowerInfo, String> {
    VehicleLowPowerInfo merge(VehicleLowPowerInfo aggregate) throws AggregateNotFoundException;

}
