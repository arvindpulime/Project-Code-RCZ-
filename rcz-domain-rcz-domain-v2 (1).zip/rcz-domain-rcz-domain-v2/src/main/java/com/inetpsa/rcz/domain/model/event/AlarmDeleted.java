package com.inetpsa.rcz.domain.model.event;

import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.payload.response.BTAResponsePayload;

public class AlarmDeleted extends AbstractVehicleResponseEvent {
    public AlarmDeleted(Exchange exchange, BTAResponsePayload btaResponsePayload) {
        super(exchange, btaResponsePayload);
    }
}
