package com.inetpsa.rcz.domain.repository;

import com.inetpsa.rcz.domain.model.action.Action;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import org.seedstack.business.domain.AggregateNotFoundException;
import org.seedstack.business.domain.Repository;

import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Optional;

/**
 * Exchange repository
 */
public interface ExchangeRepository extends Repository<Exchange, String> {

    Exchange merge(Exchange aggregate) throws AggregateNotFoundException;

    /**
     * Count the number of request by caller for a period of time
     *
     * @param callerId caller id
     * @param date     received date of the concerned exchange
     * @param duration duration in millisecond during which the quota will be considered
     * @param quota    number of authorized iterations
     * @return boolean
     */
    boolean checkQuotaByCallerAndSentToBta(String callerId, Date date, int duration, int quota);


    boolean checkQuotaByCallerAndWakeUpCall(String callerId, Date date, int duration, int quota);

    boolean checkQuotaByCaller(String callerId, Date date, int duration, int quota);

    /**
     * Return true if the concerned exchange has a duplicate
     *
     * @param exchange Exchange
     * @return Boolean
     */
    Boolean callerHasDuplicate(Exchange exchange);

    /**
     * get an exchange by correlation ID (client id)
     *
     * @param correlationId
     * @return Exchange
     */
    Optional<Exchange> findByCorrelationId(String correlationId);

    /**
     * Find all exchange in timeout
     *
     * @param timeout during which the exchange is considered in timeout
     * @return list of exchange
     */
    List<Exchange> findAllInTimeout(int timeout);

    /**
     * get a PENDING exchange by correlation ID (client id)
     *
     * @param correlationId
     * @return Exchange
     */
    Optional<Exchange> findPendingByCorrelationId(String correlationId);

    /**
     * get pending exchange with asleep BTA
     *
     * @param uin vehicle id
     * @return list of exchange
     */
    Collection<Exchange> findPendingAsleep(String uin);

    /**
     * Find All Stolen Exchange in timeout
     *
     * @param timeout during which the exchange is considered in timeout
     * @return list of exchange
     */
    List<Exchange> findStolenInTimeout(int timeout);

    /**
     * return true if an exchange already has the same correlationId for the caller
     *
     * @param correlationId
     * @return boolean
     */
    boolean correlationIdExist(String correlationId, String callerId);

    /**
     * Check quota by vehicle/caller for a given action
     *
     * @param action   Action
     * @param callerId caller id
     * @param vin      Vin
     * @param duration duration in millisecond during which the quota will be considered
     * @param quota    number of authorized iterations
     * @return boolean
     */
    boolean checkQuotaForAction(Action action, String callerId, String vin, int duration, int quota);

    /**
     * Find by caller Id
     *
     * @param callerId caller id
     * @return list of exchange
     */
    List<Exchange> findByCallerId(String callerId);
}
