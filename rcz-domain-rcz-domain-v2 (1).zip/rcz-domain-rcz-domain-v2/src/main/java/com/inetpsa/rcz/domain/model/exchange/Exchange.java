/*
 * Creation : 6 juin 2016
 */
package com.inetpsa.rcz.domain.model.exchange;

import com.inetpsa.rcz.domain.model.action.Action;
import com.inetpsa.rcz.domain.model.enums.CallerType;
import com.inetpsa.rcz.domain.model.enums.ExchangeStatus;
import com.inetpsa.rcz.domain.model.enums.ProcessStatus;
import com.inetpsa.rcz.domain.model.enums.ResponseStatus;
import com.inetpsa.rcz.domain.model.shared.Payload;
import com.inetpsa.rcz.infrastructure.data.CustomUUIDGenerator;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;

import javax.persistence.*;

@Entity
@Table(name = "RCZQTEXCHANGE")
public class Exchange extends BaseAggregateRoot<String> {

    @Id
    @Identity(generator = CustomUUIDGenerator.class)
    private String id;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(column = @Column(nullable = false), name = "actionService"),
            @AttributeOverride(column = @Column(nullable = false), name = "actionType")
    })
    private Action action;

    @Embedded
    @AttributeOverride(column = @Column(name = "request"), name = "rawJson")
    private Payload request;

    @Enumerated(EnumType.STRING)
    private ExchangeStatus status = ExchangeStatus.INITIAL;

    private String topic;

    private String uin;

    @Column(nullable = false)
    private String callerId;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private CallerType callerType;

    private String correlationId;

    private String vin;

    @Enumerated(EnumType.STRING)
    private ProcessStatus processStatus;

    @Enumerated(EnumType.STRING)
    private ResponseStatus responseStatus;

    Exchange() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Action getAction() {
        return action;
    }

    public void setAction(Action action) {
        this.action = action;
    }

    public Payload getRequest() {
        return request;
    }

    public void setRequest(Payload request) {
        this.request = request;
    }

    public ExchangeStatus getStatus() {
        return status;
    }

    public void setStatus(ExchangeStatus status) {
        this.status = status;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public String getUin() {
        return uin;
    }

    public void setUin(String uin) {
        this.uin = uin;
    }

    public String getCallerId() {
        return callerId;
    }

    public void setCallerId(String callerId) {
        this.callerId = callerId;
    }

    public CallerType getCallerType() {
        return callerType;
    }

    public void setCallerType(CallerType callerType) {
        this.callerType = callerType;
    }

    public String getCorrelationId() {
        return correlationId;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    public ProcessStatus getProcessStatus() {
        return processStatus;
    }

    public void setProcessStatus(ProcessStatus processStatus) {
        this.processStatus = processStatus;
    }

    public ResponseStatus getResponseStatus() {
        return responseStatus;
    }

    public void setResponseStatus(ResponseStatus responseStatus) {
        this.responseStatus = responseStatus;
    }

    @Override
    public String toString() {
        return "Exchange{" +
                "id='" + id + '\'' +
                ", action=" + action +
                //", request=" + request +
                ", status=" + status +
                ", topic='" + topic + '\'' +
                ", uin='" + uin + '\'' +
                ", callerId='" + callerId + '\'' +
                ", callerType=" + callerType +
                ", correlationId='" + correlationId + '\'' +
                ", vin='" + vin + '\'' +
                ", processStatus=" + processStatus +
                ", responseStatus=" + responseStatus +
                '}';
    }
}
