package com.inetpsa.rcz.domain.services.impl;

import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.log.EventLog;
import com.inetpsa.rcz.domain.model.log.LogMessage;
import com.inetpsa.rcz.domain.services.AppLogger;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

/**
 * @author tuan.docao@ext.mpsa.com
 */
public abstract class AbstractAppLogger implements AppLogger {

    private static final String TAB = "\t";

    private static final String NEW_LINE = "\n";

    private static final String BULLET = "- ";

    private static final String COLON = " : ";

    private static final String EQUAL = "=";

    private static final String COMMA = ",";

    private static final String BRACKET_OPEN = "[";

    private static final String BRACKET_CLOSE = "]";

    private static final String NA = "n/a";

    protected String toPlainText(LogMessage message, Exchange exchange) {
        return toPlainText(message, exchange, false);
    }

    protected String toPlainText(LogMessage message, Exchange exchange, boolean multiline) {
        if (!multiline) {
            return toSingleLine(message, exchange);
        }
        return toMultipleLines(message, exchange);
    }

    protected EventLog toJson(LogMessage message, Exchange exchange) {
        EventLog eventLog = new EventLog(message.getMessage());
        eventLog.setData(message.getData());
        if (exchange != null) {
            eventLog.getContext().setExchangeId(exchange.getId());
            eventLog.getContext().setCallerType(exchange.getCallerType());
            eventLog.getContext().setCallerId(exchange.getCallerId());
            eventLog.getContext().setCorrelationId(exchange.getCorrelationId());
            eventLog.getContext().setService(exchange.getAction().getActionService());
            eventLog.getContext().setAction(exchange.getAction().getActionType());
            eventLog.getContext().setProcessStatus(exchange.getProcessStatus());
            eventLog.getContext().setResponseStatus(exchange.getResponseStatus());
        }
        return eventLog;
    }

    private static Object defaultIfNull(Object obj) {
        return (obj != null) ? obj : NA;
    }

    private String toMultipleLines(LogMessage message, Exchange exchange) {
        String receivedDate = null;
        String sentDate = null;
        if (exchange.getRequest() != null) {
            receivedDate = getDateString(exchange.getRequest().getReceivedDate());
            sentDate = getDateString(exchange.getRequest().getSentDate());
        }
        return NEW_LINE +
                "MESSAGE" + COLON + NEW_LINE +
                TAB + message.getMessage() + NEW_LINE +
                "CONTEXT" + COLON + NEW_LINE +
                TAB + BULLET + "exchange" + COLON + exchange.getId() + NEW_LINE +
                TAB + BULLET + "received_date" + COLON + receivedDate + NEW_LINE +
                TAB + BULLET + "sent_date" + COLON + sentDate + NEW_LINE +
                TAB + BULLET + "correlation_id" + COLON + defaultIfNull(exchange.getCorrelationId()) + NEW_LINE +
                TAB + BULLET + "caller_type" + COLON + exchange.getCallerType() + NEW_LINE +
                TAB + BULLET + "caller" + COLON + exchange.getCallerId() + NEW_LINE +
                TAB + BULLET + "uin" + COLON + defaultIfNull(exchange.getUin()) + NEW_LINE +
                TAB + BULLET + "service" + COLON + exchange.getAction().getActionService() + NEW_LINE +
                TAB + BULLET + "action" + COLON + exchange.getAction().getActionType() + NEW_LINE +
                TAB + BULLET + "process_status" + COLON + defaultIfNull(exchange.getProcessStatus()) + NEW_LINE +
                TAB + BULLET + "response_status" + COLON + defaultIfNull(exchange.getResponseStatus()) + NEW_LINE +
                TAB + BULLET + "status" + COLON + defaultIfNull(exchange.getStatus()) + NEW_LINE +

                "DATA" + COLON + NEW_LINE +
                TAB + message.getData();
    }

    private String getDateString(Date value) {
        if (value != null) {
            final String ISO_FORMAT = "yyyy-MM-dd'T'HH:mm:ss'Z'";
            final SimpleDateFormat sdf = new SimpleDateFormat(ISO_FORMAT);
            final TimeZone utc = TimeZone.getTimeZone("UTC");
            sdf.setTimeZone(utc);
            return sdf.format(value);
        } else {
            return null;
        }
    }

    private String toSingleLine(LogMessage message, Exchange exchange) {
        String receivedDate = null;
        String sentDate = null;
        if (exchange.getRequest() != null) {
            receivedDate = getDateString(exchange.getRequest().getReceivedDate());
            sentDate = getDateString(exchange.getRequest().getSentDate());
        }
        return message.getMessage() + " " +
                BRACKET_OPEN +
                "exchange" + EQUAL + exchange.getId() + COMMA +
                "correlation_id" + EQUAL + defaultIfNull(exchange.getCorrelationId()) + COMMA +
                "received_date" + EQUAL + receivedDate + COMMA +
                "sent_date" + EQUAL + sentDate + COMMA +
                "caller_type" + EQUAL + exchange.getCallerType() + COMMA +
                "caller" + EQUAL + exchange.getCallerId() + COMMA +
                "uin" + EQUAL + defaultIfNull(exchange.getUin()) + COMMA +
                "service" + EQUAL + exchange.getAction().getActionService() + COMMA +
                "action" + EQUAL + exchange.getAction().getActionType() + COMMA +
                "process_status" + EQUAL + defaultIfNull(exchange.getProcessStatus()) + COMMA +
                "response_status" + EQUAL + defaultIfNull(exchange.getResponseStatus()) + COMMA +
                "status" + EQUAL + defaultIfNull(exchange.getStatus()) +
                BRACKET_CLOSE;
    }
}
