package com.inetpsa.rcz.infrastructure.jackson.serializer;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.inetpsa.rcz.domain.model.payload.data.DoorsOpeningState;

import java.io.IOException;

/**
 * Serializer used to convert Boolean to numeric 0/1
 */
public class DoorsOpeningStateSerializer extends JsonSerializer<Boolean[]> {

    @Override
    public void serialize(Boolean[] value, JsonGenerator gen, SerializerProvider serializers) throws IOException {
        if (value != null) {
            gen.writeObject(new DoorsOpeningState(value));
        }
    }
}