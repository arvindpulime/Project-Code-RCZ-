package com.inetpsa.rcz.domain.model.enums;

public enum ProcessStatus {
    REQUEST_ACCEPTED("900"),
    BTA_ASLEEP("901"),
    PSA_VEH_STATE_REQUEST("902"),
    REQUEST_SENT_TO_BTA("903"),
    QUOTA_EXCEEDED_WARNING("904"),
    BATTERY_AVAILABILITY("905");


    private String code;

    ProcessStatus(String code) {
        this.code = code;
    }

    public String code() {
        return code;
    }

    public static ProcessStatus fromValue(String v) {
        for (ProcessStatus c : ProcessStatus.values()) {
            if (c.code.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }
}
