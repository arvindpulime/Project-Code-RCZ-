package com.inetpsa.rcz.domain.model.enums;

/**
 * @author tuan.docao@ext.mpsa.com
 */
public enum LogLevel {

    ALL, TRACE, DEBUG, INFO, WARN, ERROR, FATAL, OFF
}
