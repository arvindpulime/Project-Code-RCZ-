package com.inetpsa.rcz.domain.model.vehicle;

import com.inetpsa.rcz.domain.model.shared.Payload;
import org.seedstack.business.domain.BaseAggregateRoot;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static javax.persistence.EnumType.STRING;

@Entity
@Table(name = "RCZQTVEHICLE")
public class Vehicle extends BaseAggregateRoot<String> {

    public static final String ID_NAME = "uin";
    public static final String VIN = "vin";
    public static final String MSISDN = "msisdn";


    public static final int VIN_SIZE = 17;
    public static final String BSRF = "BSRF";

    @Id
    @Column(name = "uin")
    private String id;

    private Long lastSession;

    private String lastSource;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(column = @Column(name = "vehicleStateDate"), name = "receivedDate"),
            @AttributeOverride(column = @Column(name = "vehicleState"), name = "connected")
    })
    private State vehicleState = new State(false, new Date());

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(column = @Column(name = "serviceStateDate"), name = "receivedDate"),
            @AttributeOverride(column = @Column(name = "serviceState"), name = "connected")
    })
    private State serviceState = new State(false, new Date());

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(column = @Column(name = "vehicleInfosPayload"), name = "rawJson"),
            @AttributeOverride(column = @Column(name = "vehicleInfosDate"), name = "receivedDate"),
            @AttributeOverride(column = @Column(name = "vehicleInfosSentDate"), name = "sentDate")
    })
    private Payload vehicleInfo;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(column = @Column(name = "lowPowerInfoPayload"), name = "rawJson"),
            @AttributeOverride(column = @Column(name = "lowPowerInfoDate"), name = "receivedDate"),
            @AttributeOverride(column = @Column(name = "lowPowerInfoSentDate"), name = "sentDate")
    })
    private Payload lowPowerInfo;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(column = @Column(name = "serviceInfoPayload"), name = "rawJson"),
            @AttributeOverride(column = @Column(name = "serviceInfoDate"), name = "receivedDate"),
            @AttributeOverride(column = @Column(name = "serviceInfoSentDate"), name = "sentDate")
    })
    private Payload serviceInfo;

    private String msisdn;

    private String btaType;

    private String vin;

    private Date updateDate = new Date();

    @Enumerated(STRING)
    private Provider provider;

    Vehicle() {
    }

    Vehicle(String id) {
        this.id = id;
    }

    Vehicle(String id, String vin) {
        this.id = id;
        this.vin = vin;
    }

    public void setId(String id) {
        this.id = id;
    }

    public State getVehicleState() {
        return vehicleState;
    }

    public void setVehicleState(State vehicleState) {
        this.vehicleState = vehicleState;
    }

    public Payload getVehicleInfo() {
        return vehicleInfo;
    }

    public void setVehicleInfo(Payload vehicleInfo) {
        this.vehicleInfo = vehicleInfo;
    }

    public String getMsisdn() {
        return msisdn;
    }

    public void setMsisdn(String msisdn) {
        this.msisdn = msisdn;
    }

    public String getBtaType() {
        return btaType;
    }

    public void setBtaType(String btaType) {
        this.btaType = btaType;
    }

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }


    public String getShortVin() {
        if (this.vin != null && VIN_SIZE == this.vin.length()) {
            return vin.substring(3, 5) + vin.substring(9, VIN_SIZE);
        }
        return null;
    }

    public State getServiceState() {
        return serviceState;
    }

    public void setServiceState(State serviceState) {
        this.serviceState = serviceState;
    }

    public Payload getLowPowerInfo() {
        return lowPowerInfo;
    }

    public Vehicle setLowPowerInfo(Payload lowPowerInfo) {
        this.lowPowerInfo = lowPowerInfo;
        return this;
    }

    public Payload getServiceInfo() {
        return serviceInfo;
    }

    public Vehicle setServiceInfo(Payload serviceInfo) {
        this.serviceInfo = serviceInfo;
        return this;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public Vehicle setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
        return this;
    }

    @Override
    public String getId() {
        return id;
    }

    @Transient
    public boolean isConnected() {
        if (serviceState != null
                && vehicleState != null
                && serviceState.isConnected()
                && vehicleState.isConnected()) {
            return true;
        }
        return false;
    }

    public Long getLastSession() {
        return lastSession;
    }

    public Vehicle setLastSession(Long lastSession) {
        this.lastSession = lastSession;
        return this;
    }

    public String getLastSource() {
        return lastSource;
    }

    public Vehicle setLastSource(String lastSource) {
        this.lastSource = lastSource;
        return this;
    }

    public Provider getProvider() {
        return provider;
    }

    public void setProvider(Provider provider) {
        this.provider = provider;
    }

    @Override
    public String toString() {
        String sb = "Vehicle{" + "uin='" + id + '\'' +
                ", msisdn='" + msisdn + '\'' +
                ", lastSession='" + lastSession + '\'' +
                ", btaType='" + btaType + '\'' +
                ", vin='" + vin + '\'' +
                '}';
        return sb;
    }
}