package com.inetpsa.rcz.domain.model.monitoring;

public enum MonitoringType {
    APPLICATION,
    MQTT
}
