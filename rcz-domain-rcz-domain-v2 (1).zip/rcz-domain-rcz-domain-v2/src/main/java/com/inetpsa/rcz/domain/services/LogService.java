package com.inetpsa.rcz.domain.services;

import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.log.LogMessage;
import org.seedstack.business.Service;

/**
 * @author tuan.docao@ext.mpsa.com
 */
@Service
public interface LogService {

    enum AppLog {
        NONE, SLF4J, DATABASE
    }

    String resolvePlaceholders(String format, Object... arg);

    /**
     * Log DEBUG in all application loggers.
     *
     * @param message  the message to log
     * @param exchange the exchange concerned by the log
     */
    void debug(LogMessage message, Exchange exchange);

    /**
     * Log INFO in all application loggers.
     *
     * @param message  the message to log
     * @param exchange the exchange concerned by the log
     */
    void info(LogMessage message, Exchange exchange);

    /**
     * Log WARN in all application loggers.
     *
     * @param message  the message to log
     * @param exchange the exchange concerned by the log
     */
    void warn(LogMessage message, Exchange exchange);

    /**
     * Log ERROR in all application loggers.
     *
     * @param message  the message to log
     * @param exchange the exchange concerned by the log
     */
    void error(LogMessage message, Exchange exchange);

    /**
     * Log DEBUG in all application loggers but the ones passed as arguments.
     *
     * @param message     the message to log
     * @param exchange    the exchange concerned by the log
     * @param deactivated an array of loggers to disable for this log {@link AppLog}
     */
    void debug(LogMessage message, Exchange exchange, AppLog... deactivated);

    /**
     * Log INFO in all application loggers but the ones passed as arguments.
     *
     * @param message     the message to log
     * @param exchange    the exchange concerned by the log
     * @param deactivated an array of loggers to disable for this log {@link AppLog}
     */
    void info(LogMessage message, Exchange exchange, AppLog... deactivated);

    /**
     * Log WARN in all application loggers but the ones passed as arguments.
     *
     * @param message     the message to log
     * @param exchange    the exchange concerned by the log
     * @param deactivated an array of loggers to disable for this log {@link AppLog}
     */
    void warn(LogMessage message, Exchange exchange, AppLog... deactivated);

    /**
     * Log ERROR in all application loggers but the ones passed as arguments.
     *
     * @param message     the message to log
     * @param exchange    the exchange concerned by the log
     * @param deactivated an array of loggers to disable for this log {@link AppLog}
     */
    void error(LogMessage message, Exchange exchange, AppLog... deactivated);
}
