package com.inetpsa.rcz.domain.model.payload;

public final class ValidationPattern {

    public static final String PATTERN_VIN = "^([a-zA-Z0-9]{17})$";
    public static final String PATTERN_CUSTOMER_ID = "(^([a-zA-Z]{2}-[^\\?;<>=\\|]{1,256})$)";
    public static final String PATTERN_ID_PARTNER = "(^([a-zA-Z0-9]{1,50})$)";
    public static final String PATTERN_ID_PARTNER_CUSTOMER = "(" + PATTERN_CUSTOMER_ID + "|" + PATTERN_ID_PARTNER + ")";
    public static final String PATTERN_CLIENT_CODE = "^([^\\?;<>=\\|]{1,256})$";
    public static final String PATTERN_CORRELATION_ID = "((^([a-zA-Z0-9]{1,50})$)|(^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$))";
    public static final String PATTERN_ACTION = "^([a-z]{1,50})$";
    public static final String PATTERN_RETURN_CODE = "^([0-9]{3})$";
    public static final String PATTERN_RETURN_MESSAGE = "^([a-zA-Z0-9]{1,50})$";
    public static final String PATTERN_DATE = "yyyy-MM-dd'T'HH:mm:ss'Z'";
    public static final String PATTERN_DATE_FRONT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
    public static final String PATTERN_DOORS_ACTION = "^(lock|unlock)$";
    public static final String PATTERN_TRACKING_ACTION = "^(activate|deactivate)$";
    public static final String PATTERN_HORN_ACTION = "^(activate|deactivate)$";
    public static final String PATTERN_LIGHT_ACTION = "^(activate|deactivate)$";
    public static final String PATTERN_PRECONDITIONING = "^(activate|deactivate)$";
    public static final String PATTERN_CHARGING_TYPE = "^(immediate|delayed)$";
    public static final String PATTERN_REQUEST_STATE_ACTION = "^(state)$";
    public static final String PATTERN_IMMOBILIZATION_ACTION = "^(activate|deactivate)$";
    public static final String PATTERN_ACCESS_TOKEN = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$";

}
