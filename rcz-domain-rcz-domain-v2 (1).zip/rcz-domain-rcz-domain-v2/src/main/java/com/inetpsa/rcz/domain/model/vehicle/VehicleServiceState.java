package com.inetpsa.rcz.domain.model.vehicle;

import org.seedstack.business.domain.BaseAggregateRoot;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "RCZQTVEHICLE")
public class VehicleServiceState extends BaseAggregateRoot<String> {


    @Id
    @Column(name = "uin")
    private String id;


    @Embedded
    @AttributeOverrides({
            @AttributeOverride(column = @Column(name = "serviceStateDate"), name = "receivedDate"),
            @AttributeOverride(column = @Column(name = "serviceState"), name = "connected")
    })
    private State serviceState = new State(false, new Date());


    private Date updateDate = new Date();

    VehicleServiceState() {
    }

    VehicleServiceState(String id) {
        this.id = id;
    }

    public void setId(String id) {
        this.id = id;
    }


    public State getServiceState() {
        return serviceState;
    }

    public void setServiceState(State serviceState) {
        this.serviceState = serviceState;
    }


    public Date getUpdateDate() {
        return updateDate;
    }

    public VehicleServiceState setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
        return this;
    }

    @Override
    public String getId() {
        return id;
    }


}