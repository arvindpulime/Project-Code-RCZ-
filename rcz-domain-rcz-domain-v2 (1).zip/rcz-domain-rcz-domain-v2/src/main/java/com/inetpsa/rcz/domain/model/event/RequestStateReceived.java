package com.inetpsa.rcz.domain.model.event;

import com.inetpsa.rcz.domain.model.payload.topic.Topic;

/**
 * @author tuan.docao@ext.mpsa.com
 */
public class RequestStateReceived extends AbstractRequestReceivedEvent {

    public RequestStateReceived(Topic topic, String message) {
        super(topic, message);
    }
}
