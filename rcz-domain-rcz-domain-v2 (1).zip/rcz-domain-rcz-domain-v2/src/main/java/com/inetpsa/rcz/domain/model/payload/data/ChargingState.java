package com.inetpsa.rcz.domain.model.payload.data;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ChargingState {

    @JsonProperty("program")
    private Program program;

    @JsonProperty("available")
    private Integer available;

    @JsonProperty("remaining_time")
    private Integer remainingTime;

    @JsonProperty("rate")
    private Integer rate;

    @Min(0)
    @Max(2)
    @JsonProperty("cable_detected")
    private Integer cableDetected;

    @JsonProperty("soc_batt")
    private Integer socBatt;

    @JsonProperty("autonomy_zev")
    private Integer autonomyZev;

    @Min(0)
    @Max(1)
    @JsonProperty("type")
    private Integer type;

    @Min(0)
    @Max(1)
    @JsonProperty("aff")
    private Integer aff;

    @Min(0)
    @Max(4)
    @JsonProperty("hmi_state")
    private Integer hmiState;

    @Min(0)
    @Max(2)
    @JsonProperty("mode")
    private Integer mode;

    @JsonProperty("autonomy")
    private Integer autonomy;

    @JsonProperty("fuel_level")
    private Integer fuelLevel;

    public Program getProgram() {
        return program;
    }

    public void setProgram(Program program) {
        this.program = program;
    }

    public Integer getAvailable() {
        return available;
    }

    public void setAvailable(Integer available) {
        this.available = available;
    }

    public Integer getRemainingTime() {
        return remainingTime;
    }

    public void setRemainingTime(Integer remainingTime) {
        this.remainingTime = remainingTime;
    }

    public Integer getRate() {
        return rate;
    }

    public void setRate(Integer rate) {
        this.rate = rate;
    }

    public Integer getCableDetected() {
        return cableDetected;
    }

    public void setCableDetected(Integer cableDetected) {
        this.cableDetected = cableDetected;
    }

    public Integer getSocBatt() {
        return socBatt;
    }

    public void setSocBatt(Integer socBatt) {
        this.socBatt = socBatt;
    }

    public Integer getAutonomyZev() {
        return autonomyZev;
    }

    public void setAutonomyZev(Integer autonomyZev) {
        this.autonomyZev = autonomyZev;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getAff() {
        return aff;
    }

    public void setAff(Integer aff) {
        this.aff = aff;
    }

    public Integer getHmiState() {
        return hmiState;
    }

    public void setHmiState(Integer hmiState) {
        this.hmiState = hmiState;
    }

    public Integer getMode() {
        return mode;
    }

    public void setMode(Integer mode) {
        this.mode = mode;
    }

    public Integer getAutonomy() {
        return autonomy;
    }

    public ChargingState setAutonomy(Integer autonomy) {
        this.autonomy = autonomy;
        return this;
    }

    public Integer getFuelLevel() {
        return fuelLevel;
    }

    public ChargingState setFuelLevel(Integer fuelLevel) {
        this.fuelLevel = fuelLevel;
        return this;
    }
}
