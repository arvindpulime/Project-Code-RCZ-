package com.inetpsa.rcz.domain.model.payload.topic;

import com.inetpsa.rcz.domain.model.action.Action;
import com.inetpsa.rcz.domain.model.action.ActionService;
import com.inetpsa.rcz.domain.model.action.ActionType;
import com.inetpsa.rcz.domain.model.payload.exception.AckTopicException;
import com.inetpsa.rcz.domain.model.payload.exception.InvalidTopicException;
import org.apache.commons.lang3.StringUtils;
import org.seedstack.business.domain.BaseValueObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class Topic extends BaseValueObject {

    public static final String PROCESS_MANAGEMENT = "ProcessManagement";

    public static final String TOPIC_SEP = "/";

    public static final String ORGANIZATION = "psa";

    public static final String BTA_UPDATE = "update";

    public static final String BTA_DATA = "data";

    public static final String BTA_DELETE = "delete";

    public static final String BTA_READ = "read";

    public static final String BTA_START = "start";
    public static final String BTA_START_STOP = "start_stop";

    public static final String BTA_PROGRAM = "program";


    public static final String DOORS_LOCK = "DoorsLock";

    public static final Map<Action, String> BTA_TOPICS_RESOLVER = intBTATopicsResolver();

    public static final String TS_LIGHTS = "TSLights";

    public static final String VEH_INFO = "VehInfo";

    public static final String STOLEN_STATE = "StolenState";

    public static final String TOPIC_MUST_HAVE_AT_LEAST_6_LAYERS = "Topic must have at least 6 layers";
    public static final String SEPARATOR = "/";
    public static final String TOPIC_ACK = "Ack";

    private static Map<Action, String> intBTATopicsResolver() {
        Map<Action, String> topicsResolver = new HashMap<>();
        topicsResolver.put(Action.HORN, Action.HORN.getActionType().literal() + TOPIC_SEP + BTA_UPDATE);
        topicsResolver.put(Action.DOORS, DOORS_LOCK + TOPIC_SEP + BTA_UPDATE);
        topicsResolver.put(Action.LIGHTS, TS_LIGHTS + TOPIC_SEP + BTA_UPDATE);
        topicsResolver.put(Action.VEHICLE_STATE, VEH_INFO + TOPIC_SEP + BTA_READ);
        topicsResolver.put(Action.VEHICLE_STATE_STOLEN, VEH_INFO + TOPIC_SEP + BTA_READ);
        topicsResolver.put(Action.REMOTE_ALARM, Action.REMOTE_ALARM.getActionType().literal() + TOPIC_SEP + BTA_DELETE);
        topicsResolver.put(Action.MOTION_ALERT, Action.MOTION_ALERT.getActionType().literal() + TOPIC_SEP + BTA_DELETE);
        topicsResolver.put(Action.STOLEN_VIN, STOLEN_STATE + TOPIC_SEP + BTA_UPDATE);
        topicsResolver.put(Action.TRACKING, Action.TRACKING.getActionType().literal() + TOPIC_SEP + BTA_UPDATE);
        topicsResolver.put(Action.IMMOBILIZATION, Action.IMMOBILIZATION.getActionType().literal() + TOPIC_SEP + BTA_UPDATE);
        topicsResolver.put(Action.IMMOBILIZATION_STOLEN, Action.IMMOBILIZATION.getActionType().literal() + TOPIC_SEP + BTA_UPDATE);

        topicsResolver.put(Action.IMMO_DATA, Action.IMMO_DATA.getActionType().literal() + TOPIC_SEP + BTA_DELETE);
        topicsResolver.put(Action.IMMO_DATA_STOLEN, Action.IMMO_DATA.getActionType().literal() + TOPIC_SEP + BTA_DELETE);
        topicsResolver.put(Action.CHARGING, Action.CHARGING.getActionType().literal() + TOPIC_SEP + BTA_START + TOPIC_SEP + BTA_UPDATE);
        topicsResolver.put(Action.CHARGING_STATE, Action.CHARGING.getActionType().literal() + TOPIC_SEP + BTA_DATA + TOPIC_SEP + BTA_UPDATE);
        topicsResolver.put(Action.BTA_DELAYED_CHARGE, Action.CHARGING.getActionType().literal() + TOPIC_SEP + BTA_PROGRAM + TOPIC_SEP + BTA_UPDATE);
        topicsResolver.put(Action.THERMAL_PRECONDITIONING, Action.THERMAL_PRECONDITIONING.getActionType().literal() + TOPIC_SEP + BTA_START_STOP + TOPIC_SEP + BTA_UPDATE);
        topicsResolver.put(Action.THERMAL_PRECONDITIONING_PROGRAMED, Action.THERMAL_PRECONDITIONING.getActionType().literal() + TOPIC_SEP + BTA_PROGRAM + TOPIC_SEP + BTA_UPDATE);
        topicsResolver.put(Action.LOW_POWER_INFO, Action.LOW_POWER_INFO.getActionType().literal() + TOPIC_SEP + BTA_READ);
        topicsResolver.put(Action.LOW_POWER_INFO_STOLEN, Action.LOW_POWER_INFO.getActionType().literal() + TOPIC_SEP + BTA_READ);
        topicsResolver.put(Action.SERVICE_STATE, Action.SERVICE_STATE.getActionType().literal() + TOPIC_SEP + BTA_DELETE);

        return topicsResolver;
    }

    private static final Logger logger = LoggerFactory.getLogger(Topic.class);

    public Topic(String topic) {
        String[] topicData = topic.split("/");
        if (topicData.length < 6) {
            InvalidTopicException exception = new InvalidTopicException(TOPIC_MUST_HAVE_AT_LEAST_6_LAYERS);
            logger.error(exception.getMessage(), exception);
            throw exception;
        }
        if(topicData[topicData.length - 1].contentEquals(TOPIC_ACK)){
            throw new AckTopicException();
        }
        try {
            ActionService actionService = ActionService.fromValue(topicData[1]);
            Direction direction = Direction.fromValue(topicData[2]);
            Tag tag = Tag.fromValue(topicData[3]);
            this.actionType = ActionType.fromValue(
                    StringUtils.join(
                            Arrays.copyOfRange(topicData, 5, topicData.length), SEPARATOR));
            this.organization = topicData[0];
            this.actionService = actionService;
            this.direction = direction;
            this.tag = tag;
            this.id = topicData[4];
        } catch (AckTopicException e){
            throw e;
        } catch (Exception e) {//NOSONAR
            throw new InvalidTopicException(e.getMessage(), e);
        }
    }

    public Topic(String organization, ActionService actionService, Direction direction, Tag tag, String id, ActionType actionType) {
        this.organization = organization;
        this.actionService = actionService;
        this.direction = direction;
        this.tag = tag;
        this.id = id;
        this.actionType = actionType;
    }

    public Topic() {
    }

    public enum Direction {
        TO("to"),
        FROM("from");

        private String literal;

        Direction(String literal) {
            this.literal = literal;
        }

        public String literal() {
            return literal;
        }

        public static Direction fromValue(String v) {
            for (Direction c : Direction.values()) {
                if (c.literal.equals(v)) {
                    return c;
                }
            }
            throw new IllegalArgumentException(v);
        }
    }

    public enum Tag {
        UID("uid"),
        CID("cid"),
        UIN("uin");

        private String literal;

        Tag(String literal) {
            this.literal = literal;
        }

        public String literal() {
            return literal;
        }

        public static Tag fromValue(String v) {
            for (Tag c : Tag.values()) {
                if (c.literal.equals(v)) {
                    return c;
                }
            }
            throw new IllegalArgumentException(v);
        }
    }

    private String organization;

    private ActionService actionService;

    private Direction direction;

    private Tag tag;

    private String id;

    private ActionType actionType;

    public String getOrganization() {
        return organization;
    }

    public void setOrganization(String organization) {
        this.organization = organization;
    }

    public ActionService getActionService() {
        return actionService;
    }

    public void setActionService(ActionService actionService) {
        this.actionService = actionService;
    }

    public Direction getDirection() {
        return direction;
    }

    public void setDirection(Direction direction) {
        this.direction = direction;
    }

    public Tag getTag() {
        return tag;
    }

    public void setTag(Tag tag) {
        this.tag = tag;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public ActionType getActionType() {
        return actionType;
    }

    public void setActionType(ActionType actionType) {
        this.actionType = actionType;
    }

    @Override
    public String toString() {
        return toTarget(this.direction, this.tag, this.id).toString();
    }

    private StringBuilder toTarget(Direction direction, Tag tag, String id) {
        StringBuilder sb = new StringBuilder(ORGANIZATION).append(TOPIC_SEP)
                .append(this.actionService.literal()).append(TOPIC_SEP)
                .append(direction.literal()).append(TOPIC_SEP)
                .append(tag.literal()).append(TOPIC_SEP)
                .append(id).append(TOPIC_SEP);
        sb.append(this.actionType.literal());
        return sb;
    }

    static StringBuilder toBTATarget(String id, Action action) {
        StringBuilder sb = new StringBuilder(ORGANIZATION).append(TOPIC_SEP)
                .append(action.getActionService().literal()).append(TOPIC_SEP)
                .append(Direction.TO.literal()).append(TOPIC_SEP)
                .append(Tag.UIN.literal()).append(TOPIC_SEP)
                .append(id).append(TOPIC_SEP);
        return sb;
    }

    StringBuilder appendProcess(StringBuilder topicBuilder, boolean process) {
        if (process) {
            return topicBuilder.append(TOPIC_SEP).append(PROCESS_MANAGEMENT);
        }
        return topicBuilder;
    }

    public static String toRemoteAlarm(String uid) {
        StringBuilder sb = new StringBuilder(ORGANIZATION).append(TOPIC_SEP)
                .append(ActionService.REMOTE.literal()).append(TOPIC_SEP)
                .append(Direction.FROM.literal()).append(TOPIC_SEP)
                .append(Tag.UID.literal()).append(TOPIC_SEP)
                .append(uid).append(TOPIC_SEP);
        sb.append(ActionType.ALARM.literal());
        return sb.toString();
    }

    public String toBTAVehicleState(String id) {
        return toBTATarget(id, Action.VEHICLE_STATE).append(BTA_TOPICS_RESOLVER.get(Action.VEHICLE_STATE)).toString();
    }

    public String toBTA(String id) {
        Action action = Action.create(this.actionService, this.actionType);
        return toBTATarget(id, action).append(BTA_TOPICS_RESOLVER.get(action)).toString();
    }

    public String toPartner(boolean process) {
        return appendProcess(toTarget(Direction.TO, Tag.UID, this.id), process).toString();
    }

    public String toClient(boolean process) {
        return appendProcess(toTarget(Direction.TO, Tag.CID, this.id), process).toString();
    }

    public String toTarget(boolean process) {
        if (Tag.CID.equals(this.tag)) {
            return toClient(process);
        }
        return toPartner(process);
    }
}
