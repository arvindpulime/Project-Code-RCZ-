package com.inetpsa.rcz.domain.model.payload.data;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.inetpsa.rcz.infrastructure.jackson.serializer.NumericBooleanSerializer;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import static com.inetpsa.rcz.domain.model.payload.ValidationPattern.PATTERN_HORN_ACTION;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Horn extends Error{

    @Min(1)
    @Max(5)
    @JsonProperty("nb_horn")
    private Integer nbHorn;

    @NotNull
    @Pattern(regexp = PATTERN_HORN_ACTION)
    @JsonProperty("action")
    private String action;

    @JsonSerialize(using = NumericBooleanSerializer.class)
    @JsonProperty("activation")
    private Boolean activated;

    public Horn(Integer nbHorn, Boolean activated) {
        this.nbHorn = nbHorn;
        this.activated = activated;
    }

    public Horn() {
    }

    public Integer getNbHorn() {
        return nbHorn;
    }

    public void setNbHorn(Integer nbHorn) {
        this.nbHorn = nbHorn;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public Boolean getActivated() {
        return activated;
    }

    public void setActivated(Boolean activated) {
        this.activated = activated;
    }
}
