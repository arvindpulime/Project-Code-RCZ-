package com.inetpsa.rcz.infrastructure.jpa.repository;

import com.inetpsa.rcz.domain.model.vehicle.VehicleServiceState;
import com.inetpsa.rcz.domain.repository.VehicleServiceStateRepository;
import org.seedstack.business.domain.AggregateNotFoundException;
import org.seedstack.jpa.BaseJpaRepository;

public class VehicleServiceStateJpaRepository extends BaseJpaRepository<VehicleServiceState, String> implements VehicleServiceStateRepository {
    @Override
    public VehicleServiceState merge(VehicleServiceState aggregate) throws AggregateNotFoundException {
        return getEntityManager().merge(aggregate);
    }
}
