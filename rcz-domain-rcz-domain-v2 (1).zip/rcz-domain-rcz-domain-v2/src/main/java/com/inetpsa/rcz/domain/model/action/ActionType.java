package com.inetpsa.rcz.domain.model.action;

public enum ActionType {

    HORN(Constants.HORN),
    DOORS(Constants.DOORS),
    LIGHTS(Constants.LIGHTS),
    VEHICLE_STATE(Constants.VEHICLE_STATE),
    SERVICE_STATE(Constants.SERVICE_STATE),
    REQUEST_STATE(Constants.REQUEST_STATE),
    RESPONSE(Constants.RESPONSE),
    ALARM(Constants.REMOTE_ALARM),
    MOTION_ALERT(Constants.MOTION_ALERT),
    STOLEN_VIN(Constants.STOLEN_VIN),
    TRACKING(Constants.TRACKING),
    IMMO_DATA(Constants.IMMO_DATA),
    IMMOBILIZATION(Constants.IMMOBILIZATION),
    VEHICLE_INFO(Constants.VEH_INFO),
    SERVICE_INFO(Constants.SERVICE_INFO),
    STATE(Constants.STATE),
    CHARGING(Constants.CHARGING),
    CHARGING_STATE(Constants.CHARGING_STATE),
    DELAYED_CHARGING(Constants.DELAYED_CHARGING),
    THERMAL_PRECONDITIONING(Constants.THERMAL_PRECONDITIONING),
    THERMAL_PRECONDITIONING_PROGRAMED(Constants.THERMAL_PRECONDITIONING_PROGRAMED),
    LOW_POWER_INFO(Constants.LOW_POWER_INFO);


    private String literal;

    ActionType(String literal) {
        this.literal = literal;
    }

    public String literal() {
        return literal;
    }

    public static ActionType fromValue(String v) {
        for (ActionType c : ActionType.values()) {
            if (c.literal.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

    public static class Constants {
        public static final String HORN = "Horn";
        public static final String DOORS = "Doors";
        public static final String LIGHTS = "Lights";
        public static final String VEHICLE_STATE = "VehicleState";
        public static final String REQUEST_STATE = "RequestState";
        public static final String RESPONSE = "Response";
        public static final String REMOTE_ALARM = "VehAlarm";
        public static final String MOTION_ALERT = "MotionAlert";
        public static final String STOLEN_VIN = "StolenVIN";
        public static final String TRACKING = "Tracking";
        public static final String IMMO_DATA = "ImmoData";
        public static final String IMMOBILIZATION = "Immobilization";
        public static final String VEH_INFO = "VehInfo";
        public static final String SERVICE_INFO = "ServiceInfo";
        public static final String STATE = "state";
        public static final String CHARGING = "VehCharge";
        public static final String CHARGING_STATE = "VehCharge/state";
        public static final String THERMAL_PRECONDITIONING = "ThermalPrecond";
        public static final String DELAYED_CHARGING = "delayedCharging";
        public static final String THERMAL_PRECONDITIONING_PROGRAMED = "thermalPreconditioningProgramed";
        public static final String SERVICE_STATE = "ServiceState";
        public static final String LOW_POWER_INFO = "LowPowerInfo";

    }
}
