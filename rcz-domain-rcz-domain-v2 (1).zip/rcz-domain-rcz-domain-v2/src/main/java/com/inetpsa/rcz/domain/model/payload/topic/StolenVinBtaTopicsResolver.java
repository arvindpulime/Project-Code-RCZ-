package com.inetpsa.rcz.domain.model.payload.topic;

import com.inetpsa.rcz.domain.model.payload.data.StolenVin;

public class StolenVinBtaTopicsResolver implements BtaTopicsResolver<StolenVin> {
}
