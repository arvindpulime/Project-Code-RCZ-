package com.inetpsa.rcz.domain.model.payload.data;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.inetpsa.rcz.domain.model.payload.ValidationPattern;
import com.inetpsa.rcz.infrastructure.jackson.deserializer.DataJsonDeserializer;
import com.inetpsa.rcz.infrastructure.jackson.serializer.DataJsonSerializer;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TrackingData {

    @JsonProperty("id")
    @Min(0)
    private Integer id;

    @JsonProperty("obj_date")
    private String date;

    @JsonSerialize(using = DataJsonSerializer.class)
    @JsonDeserialize(using = DataJsonDeserializer.class)
    @JsonProperty("location")
    private Data location;

    @Min(0)
    @Max(3)
    @JsonProperty("sev_state")
    private Boolean sevState;

    @Pattern(regexp = ValidationPattern.PATTERN_VIN)
    @JsonProperty("vin")
    private String vin;

    @Min(0)
    @JsonProperty("wheels_speed")
    private Integer wheelsSpeed;

    public Integer getId() {
        return id;
    }

    public TrackingData setId(Integer id) {
        this.id = id;
        return this;
    }

    public String getDate() {
        return date;
    }

    public TrackingData setDate(String date) {
        this.date = date;
        return this;
    }

    public Data getLocation() {
        return location;
    }

    public TrackingData setLocation(Data location) {
        this.location = location;
        return this;
    }

    public Boolean getSevState() {
        return sevState;
    }

    public TrackingData setSevState(Boolean sevState) {
        this.sevState = sevState;
        return this;
    }

    public String getVin() {
        return vin;
    }

    public TrackingData setVin(String vin) {
        this.vin = vin;
        return this;
    }

    public Integer getWheelsSpeed() {
        return wheelsSpeed;
    }

    public TrackingData setWheelsSpeed(Integer wheelsSpeed) {
        this.wheelsSpeed = wheelsSpeed;
        return this;
    }
}
