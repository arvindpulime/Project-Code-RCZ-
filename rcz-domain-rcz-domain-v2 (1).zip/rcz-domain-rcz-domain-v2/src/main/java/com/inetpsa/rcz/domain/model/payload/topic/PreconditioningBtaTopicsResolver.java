package com.inetpsa.rcz.domain.model.payload.topic;

import com.inetpsa.rcz.domain.model.action.Action;
import com.inetpsa.rcz.domain.model.payload.data.AdvancedProgram;
import com.inetpsa.rcz.domain.model.payload.data.Preconditioning;
import com.inetpsa.rcz.domain.model.payload.request.RequestPayload;

public class PreconditioningBtaTopicsResolver implements BtaTopicsResolver<Preconditioning> {

    @Override
    public String resolve(String uin, Topic topic, RequestPayload<Preconditioning> payload) {
        Action action = Action.create(topic.getActionService(), topic.getActionType());
        StringBuilder sb = Topic.toBTATarget(uin, action);
        if (PreconditioningBtaTopicsResolver.IsPrecondProgramed(payload)) {
            return sb.append(Topic.BTA_TOPICS_RESOLVER.get(Action.THERMAL_PRECONDITIONING_PROGRAMED)).toString();
        }
        return sb.append(Topic.BTA_TOPICS_RESOLVER.get(Action.THERMAL_PRECONDITIONING)).toString();
    }

    public static boolean IsPrecondProgramed(RequestPayload<Preconditioning> preconditioningRequestPayload) {
        if (preconditioningRequestPayload != null
                && preconditioningRequestPayload.getRequestParameters() != null
                && Preconditioning.DEACTIVATE.contentEquals(preconditioningRequestPayload.getRequestParameters().getAsap())) {
            return true;
        }
        return false;
    }
}
