package com.inetpsa.rcz.domain.model.enums;

/**
 * @author tuan.docao@ext.mpsa.com
 */
public enum IntrusionType {

    NO_BREAKIN, // 0
    BREAKIN_RIGHT_FRONT_DOOR,
    BREAKIN_LEFT_FRONT_DOOR, // 2
    BREAKIN_RIGHT_REAR_DOOR,
    BREAKIN_LEFT_REAR_DOOR, // 4
    BREAKIN_HOOD,
    BREAKIN_TRUNK, // 6
    BREAKIN_BACKLITE,
    BREAKIN_OPENING_ROOF, // 8
    VOLUMETRIC_BREAKIN,
    LIFTING_VEHICLE, // 10
    BREAKIN_VEHICLE_ELECTRICAL_SYSTEM;

    public static IntrusionType fromIntValue(int value) {
        for (IntrusionType intrusionType : IntrusionType.values()) {
            if (intrusionType.ordinal() == value) {
                return intrusionType;
            }
        }
        throw new IllegalArgumentException("IntrusionType must be between 0 and 11 : " + value);
    }
}
