package com.inetpsa.rcz.domain.services.impl;

import com.fasterxml.jackson.core.type.TypeReference;
import com.inetpsa.rcz.domain.model.monitoring.*;
import com.inetpsa.rcz.domain.repository.MonitoringRepository;
import com.inetpsa.rcz.domain.services.MonitoringService;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;
import org.seedstack.business.domain.Factory;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@JpaUnit("rcz")
@Transactional
public class MonitoringServiceImpl implements MonitoringService {

    public static final String MONITORING_TYPE = "id.type";
    public static final String MONITORING_ID = "id";

    @Inject
    public MonitoringRepository monitoringRepository;

    @Inject
    public Factory<MonitoringInfo> factory;

    @Inject
    private EntityManager entityManager;

    @Override
    public void updateMqttMonitoringData(String instance, List<MqttClient> mqttClients) {
        MonitoringInfo monitoringInfo = monitoringRepository.get(monitoringRepository.getSpecificationBuilder().of(MonitoringInfo.class)
                .property(MONITORING_ID).equalTo(new MonitoringInfoId(instance, MonitoringType.MQTT))
                .build()).findFirst().orElse(factory.create(new MonitoringInfoId(instance, MonitoringType.MQTT)));
        monitoringInfo.setData(JsonConverter.convert(mqttClients));
        monitoringInfo.setUpdateDate(new Date());
        monitoringRepository.addOrUpdate(monitoringInfo);

    }

    @Override
    public void updateApplicationMonitoringData(String instance, AppInfo appInfo) {
        MonitoringInfo monitoringInfo = monitoringRepository.get(monitoringRepository.getSpecificationBuilder().of(MonitoringInfo.class)
                .property(MONITORING_ID).equalTo(new MonitoringInfoId(instance, MonitoringType.APPLICATION))
                .build()).findFirst().orElse(factory.create(new MonitoringInfoId(instance, MonitoringType.APPLICATION)));
        monitoringInfo.setData(JsonConverter.convert(appInfo));
        monitoringInfo.setUpdateDate(new Date());
        monitoringRepository.addOrUpdate(monitoringInfo);
    }

    @Override
    public Map<String, List<MqttClient>> getAllMqttMonitoringData() {
        Map<String, List<MqttClient>> monitoring = monitoringRepository.get(monitoringRepository.getSpecificationBuilder().of(MonitoringInfo.class)
                .property(MONITORING_TYPE).equalTo(MonitoringType.MQTT)
                .build()).collect(Collectors.toMap(monitoringInfo -> monitoringInfo.getId().getInstance(), monitoringInfo -> JsonConverter.convert(monitoringInfo.getData(), new TypeReference<List<MqttClient>>() {
        })));
        return monitoring;
    }

    @Override
    public List<AppInfo> getAllApplicationMonitoringData() {
        List<AppInfo> monitoring = monitoringRepository.get(monitoringRepository.getSpecificationBuilder().of(MonitoringInfo.class)
                .property(MONITORING_TYPE).equalTo(MonitoringType.APPLICATION)
                .build()).map(monitoringInfo -> JsonConverter.convert(monitoringInfo.getData(), new TypeReference<AppInfo>() {
        })).collect(Collectors.toList());
        return monitoring;
    }

    @Override
    public void deleteAll() {
        monitoringRepository.removeAll();
    }

}
