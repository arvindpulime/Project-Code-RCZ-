package com.inetpsa.rcz.infrastructure.jackson.deserializer;

import com.fasterxml.jackson.core.JsonLocation;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.inetpsa.rcz.domain.model.payload.data.Data;

import java.io.IOException;

public class DataJsonDeserializer extends JsonDeserializer<Data> {
    @Override
    public Data deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
        JsonLocation startLocation = p.getCurrentLocation();
        long charOffsetStart = startLocation.getCharOffset();
        JsonLocation endLocation = p.skipChildren().getCurrentLocation();
        long charOffsetEnd = endLocation.getCharOffset();
        if (charOffsetStart < charOffsetEnd) {
            return new Data(endLocation.getSourceRef().toString().substring((int) charOffsetStart - 1, (int) charOffsetEnd));
        }
        return null;
    }
}
