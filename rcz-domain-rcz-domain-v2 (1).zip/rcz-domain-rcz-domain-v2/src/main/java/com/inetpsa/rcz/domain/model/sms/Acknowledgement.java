package com.inetpsa.rcz.domain.model.sms;

import javax.persistence.Embeddable;
import java.util.Date;

@Embeddable
public class Acknowledgement {

    private Date ackDate;

    private String ackCode;

    private String reason;

    public Acknowledgement() {
    }

    public Acknowledgement(String ackCode, String reason) {
        this.ackCode = ackCode;
        this.reason = reason;
        this.ackDate = new Date();
    }

    public String getAckCode() {
        return ackCode;
    }

    public void setAckCode(String ackCode) {
        this.ackCode = ackCode;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public Date getAckDate() {
        return ackDate;
    }

    public void setAckDate(Date ackDate) {
        this.ackDate = ackDate;
    }
}
