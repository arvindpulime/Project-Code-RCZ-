package com.inetpsa.rcz.domain.services;

import com.inetpsa.rcz.domain.model.parameter.Parameter;
import org.seedstack.business.Service;

/**
 * @author tuan.docao@ext.mpsa.com
 */
@Service
public interface ParameterService {

    Parameter get();

    Parameter getAll();

    void update(Parameter parameter);

}
