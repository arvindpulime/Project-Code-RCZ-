package com.inetpsa.rcz.domain.model.payload.topic;

import com.inetpsa.rcz.domain.model.action.Action;
import com.inetpsa.rcz.domain.model.payload.data.Charging;
import com.inetpsa.rcz.domain.model.payload.request.RequestPayload;

public class ChargingBtaTopicsResolver implements BtaTopicsResolver<Charging> {

    @Override
    public String resolve(String uin, Topic topic, RequestPayload<Charging> payload) {
        Action action = Action.create(topic.getActionService(), topic.getActionType());
        StringBuilder sb = Topic.toBTATarget(uin, action);
        if (Charging.IMMEDIATE.contentEquals(payload.getRequestParameters().getType())) {
            return sb.append(Topic.BTA_TOPICS_RESOLVER.get(Action.CHARGING)).toString();
        }
        return sb.append(Topic.BTA_TOPICS_RESOLVER.get(Action.BTA_DELAYED_CHARGE)).toString();
    }
}
