package com.inetpsa.rcz.domain.repository;

import com.inetpsa.rcz.domain.model.monitoring.MonitoringInfo;
import com.inetpsa.rcz.domain.model.monitoring.MonitoringInfoId;
import org.seedstack.business.domain.Repository;

public interface MonitoringRepository  extends Repository<MonitoringInfo, MonitoringInfoId> {
    void removeAll();
}
