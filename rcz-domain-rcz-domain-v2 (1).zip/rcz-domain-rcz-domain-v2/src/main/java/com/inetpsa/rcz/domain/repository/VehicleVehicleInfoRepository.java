package com.inetpsa.rcz.domain.repository;

import com.inetpsa.rcz.domain.model.vehicle.VehicleVehicleInfo;
import org.seedstack.business.domain.AggregateNotFoundException;
import org.seedstack.business.domain.Repository;

public interface VehicleVehicleInfoRepository extends Repository<VehicleVehicleInfo, String> {
    VehicleVehicleInfo merge(VehicleVehicleInfo aggregate) throws AggregateNotFoundException;

}
