package com.inetpsa.rcz.domain.services.impl;

import com.inetpsa.rcz.domain.model.parameter.Parameter;
import com.inetpsa.rcz.domain.services.ParameterService;
import org.seedstack.business.domain.Repository;
import org.seedstack.jpa.Jpa;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import javax.cache.annotation.CacheResult;
import javax.inject.Inject;

/**
 * @author tuan.docao@ext.mpsa.com
 */
@JpaUnit("rcz")
@Transactional
public class ParameterServiceImpl implements ParameterService {


    @Inject
    @Jpa
    private Repository<Parameter, String> parameterRepository;


    @Override
    @CacheResult(cacheName = "parameters")
    public Parameter get() {
        return getAll();
    }

    @Override
    public Parameter getAll() {
        return parameterRepository.get("1").orElse(new Parameter());
    }

    @Override
    public void update(Parameter parameter) {
        parameterRepository.update(parameter);
    }

}
