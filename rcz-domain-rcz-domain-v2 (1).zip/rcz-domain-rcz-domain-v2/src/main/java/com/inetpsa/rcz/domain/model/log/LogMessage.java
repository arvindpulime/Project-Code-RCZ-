package com.inetpsa.rcz.domain.model.log;

import com.inetpsa.rcz.domain.model.enums.EventMessage;
import org.apache.commons.lang3.StringUtils;
import org.seedstack.business.domain.BaseValueObject;

import javax.persistence.Lob;

/**
 * Object containing a log message and the associated data (optional).
 *
 * @author tuan.docao@ext.mpsa.com
 */
public class LogMessage extends BaseValueObject {

    private String message;

    @Lob
    private String data;

    private String topic;

    /**
     * Create a log message from plain text
     *
     * @param message the string message
     * @return a new instance of LogMessage
     */
    public static LogMessage create(String message) {
        return new LogMessage(message);
    }

    /**
     * Create a log message from {@link EventMessage}
     *
     * @param message the message enum
     * @return a new instance of LogMessage
     */
    public static LogMessage create(EventMessage message) {
        return new LogMessage(message.name());
    }

    private LogMessage() {
    }

    private LogMessage(String message) {
        this.message = message;
    }

    public LogMessage data(String data) {
        if (StringUtils.isNotBlank(data)) {
            this.data = data.replaceAll("\u0000", "");
        }
        return this;
    }

    public LogMessage topic(String topic) {
        this.topic = topic;
        return this;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        if (StringUtils.isNotBlank(data)) {
            this.data = data.replaceAll("\u0000", "");
        } else {
            this.data = data;
        }
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }
}
