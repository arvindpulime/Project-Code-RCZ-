package com.inetpsa.rcz.domain.model.parameter;

import lombok.Data;

import javax.persistence.Embeddable;
import javax.persistence.Embedded;
import java.io.Serializable;

@Data
@Embeddable
public class SmsParam implements Serializable {

    private Integer nbRetry = 3;
    private Integer retryDelay = 1000;
    private Integer messageLength = 48;
    private Integer dataLength = 48;
    private Integer dspt = 0;
    private Integer messageId = 1;
    private Integer messageVersion = 1;
    private Integer messageType = 63;
    private Integer serviceType = 5;

    @Embedded
    private ByTelParam byTel = new ByTelParam();

    @Embedded
    private OrangeParam orange = new OrangeParam();
}
