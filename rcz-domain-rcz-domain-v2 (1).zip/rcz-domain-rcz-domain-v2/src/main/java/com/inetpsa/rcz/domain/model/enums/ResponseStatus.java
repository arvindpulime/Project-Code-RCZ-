package com.inetpsa.rcz.domain.model.enums;

public enum ResponseStatus {
    STATUS_OK("0"),
    STATUS_OK_WARNING("1"),
    PARTNER_NOT_FOUND("100"),
    PARTNER_INACTIVE("101"),
    SERVICE_NOT_FOUND("102"),
    SERVICE_INACTIVE("103"),
    RESOURCE_NOT_FOUND("104"),
    RESOURCE_SERVICE_NOT_FOUND("105"),
    BAD_REQUEST("110"),
    FORMAT_ERROR("111"),
    MISSING_CORRELATION_ID("112"),
    REQUEST_ERROR("113"),
    VEHICLE_CONNECTION_TIMEOUT("300"),
    VEHICLE_NOT_FOUND("301"),
    VEHICLE_VALIDATION_ERROR("302"),
    VEHICLE_REQUEST_ERROR("303"),
    AUTHORIZATION_DENIED("400"),
    RIGHTS_ERRORS("404"),
    RIGHTS_ERROR_VES("420"),
    RIGHTS_ERROR_STOLEN("421"),
    RIGHTS_ERROR_PRIVACY("422"),
    RIGHTS_ERROR_BATTERY("423"),
    RIGHTS_ERROR_BATTERY_WARNING("424"),
    TECHNICAL_ERROR("500"),
    REQUESTS_QUOTA_EXCEEDED("501"),
    DUPLICATE("502"),
    HORN_QUOTA_EXCEEDED("503"),
    LIGHTS_QUOTA_EXCEEDED("504"),
    REQUESTS_QUOTA_WARNING("505");



    private String code;

    ResponseStatus(String code) {
        this.code = code;
    }

    public String code() {
        return code;
    }

    public static ResponseStatus fromValue(String v) {
        for (ResponseStatus c : ResponseStatus.values()) {
            if (c.code.equals(v)) {
                return c;
            }
        }
       return null;
    }



}
