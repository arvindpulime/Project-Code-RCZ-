package com.inetpsa.rcz.domain.repository;

import com.inetpsa.rcz.domain.model.vehicle.VehicleServiceState;
import org.seedstack.business.domain.AggregateNotFoundException;
import org.seedstack.business.domain.Repository;

public interface VehicleServiceStateRepository extends Repository<VehicleServiceState, String> {
    VehicleServiceState merge(VehicleServiceState aggregate) throws AggregateNotFoundException;

}
