package com.inetpsa.rcz.domain.services;

import com.inetpsa.rcz.domain.model.sms.Sms;
import org.seedstack.business.Service;
import org.seedstack.seed.transaction.Transactional;

import java.util.List;
import java.util.Optional;

@Service
public interface SmsService {

    Sms create();

    void save(Sms sms);

    Sms update(Sms sms);

    int updateAll(List<Sms> smsList);

    Optional<Sms> findById(String id);

    Optional<Sms> findByMessageIdAndUin(String messageId, String uin);
    Optional<Sms> findByMessageId(String messageId);
    Optional<Sms> findByUin(String uin);
}
