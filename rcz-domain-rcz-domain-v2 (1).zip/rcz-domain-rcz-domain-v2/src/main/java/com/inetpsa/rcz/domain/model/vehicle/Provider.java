package com.inetpsa.rcz.domain.model.vehicle;

public enum Provider {
    OFR,
    BYT,
    PTL
}
