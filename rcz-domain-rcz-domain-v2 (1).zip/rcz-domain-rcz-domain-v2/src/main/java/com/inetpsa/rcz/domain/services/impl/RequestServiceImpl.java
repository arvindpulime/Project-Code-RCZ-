package com.inetpsa.rcz.domain.services.impl;

import com.inetpsa.rcz.domain.model.api.request.Request;
import com.inetpsa.rcz.domain.services.RequestService;
import org.seedstack.business.domain.Repository;
import org.seedstack.business.specification.Specification;
import org.seedstack.jpa.Jpa;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import javax.inject.Inject;
import java.util.Optional;
import java.util.stream.Stream;

@JpaUnit("rcz")
@Transactional
public class RequestServiceImpl implements RequestService {

    @Inject
    @Jpa
    private Repository<Request, String> requestRepository;

    @Override
    public Optional<Request> get(String id) {
        return requestRepository.get(id);
    }

    @Override
    public Stream<Request> get(Specification<Request> specification) {
        return requestRepository.get(specification);
    }

    @Override
    public void save(Request request) {
        requestRepository.addOrUpdate(request);
    }
}
