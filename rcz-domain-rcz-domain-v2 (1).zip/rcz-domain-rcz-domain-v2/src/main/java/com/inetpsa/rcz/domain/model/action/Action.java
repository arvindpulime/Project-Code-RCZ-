package com.inetpsa.rcz.domain.model.action;

import com.google.common.collect.Sets;
import org.seedstack.business.domain.BaseValueObject;

import javax.persistence.Embeddable;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import java.util.Set;

@Embeddable
public class Action extends BaseValueObject {

    public static final Set<Action> ACTION_SET = Sets.newHashSet();

    public static final Action DOORS = createRemote(ActionType.DOORS);

    public static final Action HORN = createRemote(ActionType.HORN);

    public static final Action IMMOBILIZATION = createRemote(ActionType.IMMOBILIZATION);

    public static final Action IMMOBILIZATION_STOLEN = createStolen(ActionType.IMMOBILIZATION);

    public static final Action IMMO_DATA = createRemote(ActionType.IMMO_DATA);

    public static final Action IMMO_DATA_STOLEN = createRemote(ActionType.IMMO_DATA);

    public static final Action LIGHTS = createRemote(ActionType.LIGHTS);

    public static final Action REQUEST_STATE = create(ActionService.REMOTE, ActionType.REQUEST_STATE);

    public static final Action SERVICE_STATE = create(ActionService.REMOTE, ActionType.SERVICE_STATE);

    public static final Action REQUEST_STATE_STOLEN = create(ActionService.STOLEN, ActionType.REQUEST_STATE);

    public static final Action REMOTE_ALARM = createRemote(ActionType.ALARM);

    public static final Action MOTION_ALERT = createRemote(ActionType.MOTION_ALERT);

    public static final Action STOLEN_VIN = createStolen(ActionType.STOLEN_VIN);

    public static final Action TRACKING = createStolen(ActionType.TRACKING);

    public static final Action VEHICLE_STATE = create(ActionService.REMOTE, ActionType.VEHICLE_STATE);

    public static final Action VEHICLE_STATE_STOLEN = create(ActionService.STOLEN, ActionType.VEHICLE_STATE);

    public static final Action VEHICLE_INFO = create(ActionService.REMOTE, ActionType.VEHICLE_INFO);

    public static final Action VEHICLE_STATE_MANAGEMENT = createDeviceManagement(ActionType.STATE);

    public static final Action CHARGING = createRemote(ActionType.CHARGING);

    public static final Action CHARGING_STATE = createRemote(ActionType.CHARGING_STATE);

    public static final Action LOW_POWER_INFO = createRemote(ActionType.LOW_POWER_INFO);

    public static final Action LOW_POWER_INFO_STOLEN = createStolen(ActionType.LOW_POWER_INFO);

    public static final Action THERMAL_PRECONDITIONING = createRemote(ActionType.THERMAL_PRECONDITIONING);
    /** Used only for BTA response redirection **/
    public static final Action BTA_DELAYED_CHARGE = new Action(ActionService.REMOTE, ActionType.DELAYED_CHARGING);
    public static final Action THERMAL_PRECONDITIONING_PROGRAMED = new Action(ActionService.REMOTE, ActionType.THERMAL_PRECONDITIONING_PROGRAMED);


    @Enumerated(EnumType.STRING)
    private ActionService actionService;

    @Enumerated(EnumType.STRING)
    private ActionType actionType;

    private Action(final ActionService actionService, ActionType actionType) {
        this.actionService = actionService;
        this.actionType = actionType;
    }

    private Action() {
    }

    private static Action createStolen(ActionType actionType) {
        Action action;
        addAction(action = new Action(ActionService.STOLEN, actionType));
        return action;
    }

    private static Action createRemote(ActionType actionType) {
        Action action;
        addAction(action = new Action(ActionService.REMOTE, actionType));
        return action;
    }

    private static Action createDeviceManagement(ActionType actionType) {
        Action action;
        addAction(action = new Action(ActionService.DEVICE_MANAGEMENT, actionType));
        return action;
    }

    private static void addAction(Action action) {
        ACTION_SET.add(action);
    }

    public static Action create(ActionService actionService, ActionType actionType) {
        return new Action(actionService, actionType);
    }

    public ActionService getActionService() {
        return actionService;
    }

    public ActionType getActionType() {
        return actionType;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;

        Action action = (Action) o;

        if (actionService != action.actionService) return false;
        return actionType == action.actionType;

    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + actionService.hashCode();
        result = 31 * result + actionType.hashCode();
        return result;
    }
}
