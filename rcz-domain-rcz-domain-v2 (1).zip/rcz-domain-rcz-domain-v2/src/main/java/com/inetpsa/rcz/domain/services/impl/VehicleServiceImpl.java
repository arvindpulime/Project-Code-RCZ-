package com.inetpsa.rcz.domain.services.impl;


import com.fasterxml.jackson.core.type.TypeReference;
import com.inetpsa.rcz.domain.model.payload.data.VehicleStateResult;
import com.inetpsa.rcz.domain.model.shared.Payload;
import com.inetpsa.rcz.domain.model.vehicle.*;
import com.inetpsa.rcz.domain.repository.*;
import com.inetpsa.rcz.domain.services.VehicleService;
import com.inetpsa.rcz.infrastructure.json.JsonConverter;
import org.apache.commons.lang3.StringUtils;
import org.seedstack.business.domain.AggregateNotFoundException;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Transactional;

import javax.inject.Inject;
import java.util.Date;
import java.util.Optional;

@JpaUnit("rcz")
public class VehicleServiceImpl implements VehicleService {

    @Inject
    private VehicleRepository vehicleRepository;

    @Inject
    private VehicleServiceStateRepository vehicleServiceStateRepository;

    @Inject
    private VehicleConnectRepository vehicleConnectRepository;

    @Inject
    private VehicleVehicleInfoRepository vehicleVehicleInfoRepository;

    @Inject
    private VehicleLowPowerInfoRepository vehicleLowPowerInfoRepository;

    @Inject
    private VehicleServiceInfoRepository vehicleServiceInfoRepository;

    @Transactional
    public Boolean isConnected(String uin) {
        return vehicleRepository.isConnected(uin);
    }

    @Transactional
    public VehicleStateResult getVehicleInfo(String uin) {
        Payload payload = vehicleRepository.getVehicleInfo(uin);
        if (payload != null && StringUtils.isNotBlank(payload.getRawJson())) {
            return JsonConverter.convert(payload.getRawJson(), new TypeReference<VehicleStateResult>() {
            });
        }
        return null;
    }

    @Transactional
    public Vehicle save(Vehicle vehicle) {
        vehicle.setUpdateDate(new Date());
        Vehicle merge = vehicleRepository.addOrUpdate(vehicle);
        return merge;
    }


    @Transactional
    @Override
    public void saveServiceState(VehicleServiceState vehicle) {
        vehicle.setUpdateDate(new Date());
        try {
            vehicleServiceStateRepository.merge(vehicle);
        } catch (AggregateNotFoundException e) {
            vehicleServiceStateRepository.add(vehicle);
        }

    }

    @Transactional
    @Override
    public void saveConnect(VehicleConnect vehicle) {
        vehicle.setUpdateDate(new Date());
        try {

            vehicleConnectRepository.merge(vehicle);
        } catch (AggregateNotFoundException e) {
            vehicleConnectRepository.add(vehicle);
        }
    }

    @Transactional
    @Override
    public void saveVehicleLowPowerInfo(VehicleLowPowerInfo vehicle) {
        vehicle.setUpdateDate(new Date());
        try {
            vehicleLowPowerInfoRepository.merge(vehicle);
        } catch (AggregateNotFoundException e) {
            vehicleLowPowerInfoRepository.add(vehicle);
        }
    }

    @Transactional
    @Override
    public void saveVehicleVehicleInfo(VehicleVehicleInfo vehicle) {
        vehicle.setUpdateDate(new Date());
        try {
            vehicleVehicleInfoRepository.merge(vehicle);
        } catch (AggregateNotFoundException e) {
            vehicleVehicleInfoRepository.add(vehicle);
        }
    }

    @Transactional
    @Override
    public void saveVehicleServiceInfo(VehicleServiceInfo vehicle) {
        vehicle.setUpdateDate(new Date());
        try {
            vehicleServiceInfoRepository.merge(vehicle);
        } catch (AggregateNotFoundException e) {
            vehicleServiceInfoRepository.add(vehicle);
        }
    }

    @Transactional
    public Optional<Vehicle> find(String uin) {
        return vehicleRepository.get(uin);
    }

    @Transactional
    @Override
    public Optional<VehicleServiceState> findVehicleServiceState(String uin) {
        return vehicleServiceStateRepository.get(uin);
    }

    @Transactional
    @Override
    public Optional<VehicleConnect> findVehicleConnect(String uin) {
        return vehicleConnectRepository.get(uin);
    }

    @Transactional
    @Override
    public Optional<VehicleLowPowerInfo> findVehicleLowPowerInfo(String uin) {
        return vehicleLowPowerInfoRepository.get(uin);
    }

    @Transactional
    @Override
    public Optional<VehicleVehicleInfo> findVehicleVehicleInfo(String uin) {
        return vehicleVehicleInfoRepository.get(uin);
    }

    @Transactional
    @Override
    public Optional<VehicleServiceInfo> findVehicleServiceInfo(String uin) {
        return vehicleServiceInfoRepository.get(uin);
    }

    @Override
    @Transactional
    public Optional<Vehicle> findByVin(String vin) {
        return vehicleRepository.get(vehicleRepository.getSpecificationBuilder().ofAggregate(Vehicle.class).property(Vehicle.VIN).equalTo(vin).build()).findFirst();
    }

    @Override
    @Transactional
    public Optional<Vehicle> findByMsisdn(String msisdn) {
        return vehicleRepository.get(vehicleRepository.getSpecificationBuilder().ofAggregate(Vehicle.class).property(Vehicle.MSISDN).equalTo(msisdn).build()).findFirst();
    }


}
