package com.inetpsa.rcz.domain.services.impl;

import com.inetpsa.rcz.domain.model.enums.LogLevel;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.log.Log;
import com.inetpsa.rcz.domain.model.log.LogFactory;
import com.inetpsa.rcz.domain.model.log.LogMessage;
import org.seedstack.business.domain.Repository;
import org.seedstack.jpa.Jpa;
import org.seedstack.jpa.JpaUnit;
import org.seedstack.seed.transaction.Propagation;
import org.seedstack.seed.transaction.Transactional;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.Date;

import static com.inetpsa.rcz.domain.services.LogService.AppLog;

/**
 * @author tuan.docao@ext.mpsa.com
 */
@JpaUnit("rcz")
@Named("database-logger")
public class DatabaseLogger extends AbstractAppLogger {

    @Inject
    private LogFactory logFactory;

    @Inject
    @Jpa
    private Repository<Log, String> logRepository;

    public AppLog key() {
        return AppLog.DATABASE;
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void log(LogLevel logLevel, LogMessage message, Exchange exchange) {
        Log log = logFactory.create(logLevel, new Date(), message, exchange.getId());
        logRepository.add(log);
    }

}
