package com.inetpsa.rcz.domain.model.event;

import org.seedstack.business.domain.BaseDomainEvent;

public class AcknowledgmentReceived extends BaseDomainEvent {

    private final String topic;
    private final String message;

    public AcknowledgmentReceived(String topic, String message) {
        this.topic = topic;
        this.message = message;
    }

    public String getTopic() {
        return topic;
    }

    public String getMessage() {
        return message;
    }
}
