package com.inetpsa.rcz.domain.model.payload.data;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.inetpsa.rcz.infrastructure.jackson.serializer.NumericBooleanSerializer;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DoorsOpeningState {

    public DoorsOpeningState(Boolean[] openingState) {
        if (openingState != null && openingState.length > 3) {
            this.driver = openingState[0];
            passenger = openingState[1];
            rearLeft = openingState[2];
            rearRight = openingState[3];
            if (openingState.length > 5) {
                trunk = openingState[4];
                rearWindow = openingState[5];
            }
        }
    }

    @JsonSerialize(using = NumericBooleanSerializer.class)
    @JsonProperty("driver_door")
    private Boolean driver;

    @JsonSerialize(using = NumericBooleanSerializer.class)
    @JsonProperty("passenger_door")
    private Boolean passenger;

    @JsonSerialize(using = NumericBooleanSerializer.class)
    @JsonProperty("rear_left_door")
    private Boolean rearLeft;

    @JsonSerialize(using = NumericBooleanSerializer.class)
    @JsonProperty("rear_right_door")
    private Boolean rearRight;

    @JsonSerialize(using = NumericBooleanSerializer.class)
    @JsonProperty("trunk")
    private Boolean trunk;

    @JsonSerialize(using = NumericBooleanSerializer.class)
    @JsonProperty("rear_window")
    private Boolean rearWindow;

    public Boolean getDriver() {
        return driver;
    }

    public void setDriver(Boolean driver) {
        this.driver = driver;
    }

    public Boolean getPassenger() {
        return passenger;
    }

    public void setPassenger(Boolean passenger) {
        this.passenger = passenger;
    }

    public Boolean getRearLeft() {
        return rearLeft;
    }

    public void setRearLeft(Boolean rearLeft) {
        this.rearLeft = rearLeft;
    }

    public Boolean getRearRight() {
        return rearRight;
    }

    public void setRearRight(Boolean rearRight) {
        this.rearRight = rearRight;
    }

    public Boolean getTrunk() {
        return trunk;
    }

    public void setTrunk(Boolean trunk) {
        this.trunk = trunk;
    }

    public Boolean getRearWindow() {
        return rearWindow;
    }

    public void setRearWindow(Boolean rearWindow) {
        this.rearWindow = rearWindow;
    }
}