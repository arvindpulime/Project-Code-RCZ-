package com.inetpsa.rcz.domain.model.event;

import com.inetpsa.rcz.domain.model.payload.topic.Topic;

public class VehicleInfoReceived extends AbstractVehicleInfoReceived {

    public VehicleInfoReceived(Topic topic, String message, String uin) {
        super(topic, message, uin);
    }
}
