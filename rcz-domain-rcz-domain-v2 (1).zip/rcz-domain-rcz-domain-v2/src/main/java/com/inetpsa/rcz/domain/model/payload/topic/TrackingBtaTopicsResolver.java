package com.inetpsa.rcz.domain.model.payload.topic;

import com.inetpsa.rcz.domain.model.payload.data.Tracking;

public class TrackingBtaTopicsResolver implements BtaTopicsResolver<Tracking> {
}
