package com.inetpsa.rcz.domain.model.vehicle;

import org.seedstack.business.domain.BaseAggregateRoot;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "RCZQTVEHICLE")
public class VehicleConnect extends BaseAggregateRoot<String> {

    @Id
    @Column(name = "uin")
    private String id;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(column = @Column(name = "vehicleStateDate"), name = "receivedDate"),
            @AttributeOverride(column = @Column(name = "vehicleState"), name = "connected")
    })
    private State vehicleState = new State(false, new Date());


    private Date updateDate = new Date();

    private Long lastSession;

    private String lastSource;

    VehicleConnect() {
    }

    VehicleConnect(String id) {
        this.id = id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public State getVehicleState() {
        return vehicleState;
    }

    public void setVehicleState(State vehicleState) {
        this.vehicleState = vehicleState;
    }


    public Date getUpdateDate() {
        return updateDate;
    }

    public VehicleConnect setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
        return this;
    }

    @Override
    public String getId() {
        return id;
    }

    public Long getLastSession() {
        return lastSession;
    }

    public VehicleConnect setLastSession(Long lastSession) {
        this.lastSession = lastSession;
        return this;
    }

    public String getLastSource() {
        return lastSource;
    }

    public VehicleConnect setLastSource(String lastSource) {
        this.lastSource = lastSource;
        return this;
    }
}