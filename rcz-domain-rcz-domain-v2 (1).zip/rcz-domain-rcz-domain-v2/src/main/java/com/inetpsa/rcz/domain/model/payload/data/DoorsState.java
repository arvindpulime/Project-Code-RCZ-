package com.inetpsa.rcz.domain.model.payload.data;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.inetpsa.rcz.domain.model.enums.DoorsLockingState;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DoorsState {

    /**
     * <ul>
     * <li>Driver</li>
     * <li>Passenger</li>
     * <li>Rear left</li>
     * <li>Rear right</li>
     * <li>Trunk</li>
     * <li>Rear window</li>
     * </ul>
     */
    private static final int NB_OPENING_STATE = 6;

    @NotNull
    @JsonProperty("doors_opening_state")
    @Size(min = 4, max = 6)
    private Integer[] doorsOpeningState;

    @NotNull
    @Min(0)
    @Max(8)
    @JsonProperty("doors_locking_state")
    private Integer doorsLockingStateValue;

    @Min(0)
    @Max(1)
    @JsonProperty("driver_sel_state")
    private Integer doorSelState;

    public Integer[] getDoorsOpeningState() {
        return doorsOpeningState;
    }

    public void setDoorsOpeningState(Integer[] doorsOpeningState) {
        this.doorsOpeningState = doorsOpeningState;
    }

    public Integer getDoorsLockingStateValue() {
        return doorsLockingStateValue;
    }

    public void setDoorsLockingStateValue(Integer doorsLockingStateValue) {
        this.doorsLockingStateValue = doorsLockingStateValue;
    }

    public static int getNbOpeningState() {
        return NB_OPENING_STATE;
    }


    @JsonIgnore
    public DoorsLockingState getDoorsLockingState() {
        return DoorsLockingState.fromIntValue(doorsLockingStateValue);
    }

    public Integer getDoorSelState() {
        return doorSelState;
    }

    public DoorsState setDoorSelState(Integer doorSelState) {
        this.doorSelState = doorSelState;
        return this;
    }
}
