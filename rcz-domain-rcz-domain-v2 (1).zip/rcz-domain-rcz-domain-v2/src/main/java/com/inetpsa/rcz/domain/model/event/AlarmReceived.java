package com.inetpsa.rcz.domain.model.event;

import com.inetpsa.rcz.domain.model.payload.topic.Topic;

public class AlarmReceived extends AbstractRequestReceivedEvent {
    public AlarmReceived(Topic topic, String message) {
        super(topic, message);
    }
}
