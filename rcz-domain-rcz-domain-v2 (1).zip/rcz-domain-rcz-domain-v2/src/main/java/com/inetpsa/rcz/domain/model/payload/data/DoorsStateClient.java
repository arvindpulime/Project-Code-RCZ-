package com.inetpsa.rcz.domain.model.payload.data;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.inetpsa.rcz.domain.model.enums.DoorsLockingState;
import com.inetpsa.rcz.infrastructure.jackson.serializer.DoorsOpeningStateSerializer;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DoorsStateClient {

    /**
     * <ul>
     * <li>Driver</li>
     * <li>Passenger</li>
     * <li>Rear left</li>
     * <li>Rear right</li>
     * <li>Trunk</li>
     * <li>Rear window</li>
     * </ul>
     */
    private static final int NB_OPENING_STATE = 6;

    @JsonSerialize(using = DoorsOpeningStateSerializer.class)
    @NotNull
    @JsonProperty("doors_opening_state")
    @Size(min = 4, max = 6)
    private Boolean[] doorsOpeningState;

    @NotNull @Min(0) @Max(6)
    @JsonProperty("doors_locking_state")
    private Integer doorsLockingStateValue;


    public Boolean[] getDoorsOpeningState() {
        return doorsOpeningState;
    }

    public void setDoorsOpeningState(Boolean[] doorsOpeningState) {
        this.doorsOpeningState = doorsOpeningState;
    }

    public Integer getDoorsLockingStateValue() {
        return doorsLockingStateValue;
    }

    public void setDoorsLockingStateValue(Integer doorsLockingStateValue) {
        this.doorsLockingStateValue = doorsLockingStateValue;
    }

    @JsonIgnore
    public static int getNbOpeningState() {
        return NB_OPENING_STATE;
    }



    @JsonIgnore
    public DoorsLockingState getDoorsLockingState() {
        return DoorsLockingState.fromIntValue(doorsLockingStateValue);
    }
}
