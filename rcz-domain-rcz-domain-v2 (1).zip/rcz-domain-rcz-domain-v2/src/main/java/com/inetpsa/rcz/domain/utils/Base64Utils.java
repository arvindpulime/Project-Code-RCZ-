package com.inetpsa.rcz.domain.utils;

import java.util.Base64;

public class Base64Utils {

    public static String encode(String string2Encode) {
        return Base64.getEncoder().encodeToString(string2Encode.getBytes());
    }

    public static String decode(String string2Decode) {
        return new String(Base64.getDecoder().decode(string2Decode));
    }
}
