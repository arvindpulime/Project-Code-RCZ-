package com.inetpsa.rcz.domain.model.payload.topic;

import com.inetpsa.rcz.domain.model.action.Action;
import com.inetpsa.rcz.domain.model.payload.request.RequestPayload;
import org.seedstack.business.Service;

@Service
public interface BtaTopicsResolver<T> {

    default String resolve(String uin, Topic topic, RequestPayload<T> payload) {
        Action action = Action.create(topic.getActionService(), topic.getActionType());
        return Topic.toBTATarget(uin, action).append(Topic.BTA_TOPICS_RESOLVER.get(action)).toString();
    }
}
