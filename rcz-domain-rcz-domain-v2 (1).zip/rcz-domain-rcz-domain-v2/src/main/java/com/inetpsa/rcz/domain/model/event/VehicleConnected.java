package com.inetpsa.rcz.domain.model.event;

public class VehicleConnected extends AbstractVehicleEvent {
}
