package com.inetpsa.rcz.domain.model.event;

import com.inetpsa.rcz.domain.model.enums.ResponseStatus;
import com.inetpsa.rcz.domain.model.exchange.Exchange;

public class ErrorOccurred extends AbstractExchangeEvent {

    private ResponseStatus responseStatus;

    private String message;

    public ErrorOccurred(Exchange exchange, ResponseStatus responseStatus, String message) {
        super(exchange);
        this.responseStatus = responseStatus;
        this.message = message;
    }

    public ErrorOccurred(Exchange exchange, ResponseStatus responseStatus) {
        super(exchange);
        this.responseStatus = responseStatus;
    }

    public ResponseStatus getResponseStatus() {
        return responseStatus;
    }

    public void setResponseStatus(ResponseStatus responseStatus) {
        this.responseStatus = responseStatus;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
