package com.inetpsa.rcz.domain.model.payload.data;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.validation.constraints.NotNull;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class VehicleStateClient extends VehicleInfos {

    @NotNull
    @JsonProperty("doors_state")
    private DoorsStateClient doorsState;

    public DoorsStateClient getDoorsState() {
        return doorsState;
    }

    public void setDoorsState(DoorsStateClient doorsState) {
        this.doorsState = doorsState;
    }
}
