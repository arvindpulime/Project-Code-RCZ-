package com.inetpsa.rcz.domain.model.parameter;


import lombok.Data;
import lombok.experimental.Accessors;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Data
@Accessors(chain = true)
@Embeddable
public class CvsParam implements Serializable {

    private Boolean cvsAuthAccess;

    private Boolean cvsMock = true;

    private String cvsEndpointUrl;

    private String cvsOauthEndpointUrl;

}




