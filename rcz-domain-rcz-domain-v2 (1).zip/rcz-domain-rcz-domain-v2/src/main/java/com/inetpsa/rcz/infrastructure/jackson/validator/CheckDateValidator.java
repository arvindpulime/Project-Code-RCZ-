package com.inetpsa.rcz.infrastructure.jackson.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CheckDateValidator implements ConstraintValidator<CheckDateFormat, String> {

    private String pattern;

    @Override
    public void initialize(CheckDateFormat constraintAnnotation) {
        this.pattern = constraintAnnotation.pattern();
    }

    @Override
    public boolean isValid(String object, ConstraintValidatorContext constraintContext) {
        if ( object == null ) {
            return true;
        }

        try {
            SimpleDateFormat format = new SimpleDateFormat(pattern);
            Date date = format.parse(object);
            return format.format(date).contentEquals(object);
        } catch (Exception e) {
            return false;
        }
    }
}