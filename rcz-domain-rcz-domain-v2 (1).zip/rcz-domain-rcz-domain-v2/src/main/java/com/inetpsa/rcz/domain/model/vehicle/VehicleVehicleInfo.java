package com.inetpsa.rcz.domain.model.vehicle;

import com.inetpsa.rcz.domain.model.shared.Payload;
import org.seedstack.business.domain.BaseAggregateRoot;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "RCZQTVEHICLE")
public class VehicleVehicleInfo extends BaseAggregateRoot<String> {

    @Id
    @Column(name = "uin")
    private String id;

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(column = @Column(name = "vehicleInfosPayload"), name = "rawJson"),
            @AttributeOverride(column = @Column(name = "vehicleInfosDate"), name = "receivedDate"),
            @AttributeOverride(column = @Column(name = "vehicleInfosSentDate"), name = "sentDate")
    })
    private Payload vehicleInfo;


    private Date updateDate = new Date();

    private String vin;

    VehicleVehicleInfo() {
    }

    VehicleVehicleInfo(String id) {
        this.id = id;
    }

    public void setId(String id) {
        this.id = id;
    }


    public Date getUpdateDate() {
        return updateDate;
    }

    public VehicleVehicleInfo setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
        return this;
    }

    @Override
    public String getId() {
        return id;
    }

    public Payload getVehicleInfo() {
        return vehicleInfo;
    }

    public VehicleVehicleInfo setVehicleInfo(Payload vehicleInfo) {
        this.vehicleInfo = vehicleInfo;
        return this;
    }

    public String getVin() {
        return vin;
    }

    public VehicleVehicleInfo setVin(String vin) {
        this.vin = vin;
        return this;
    }
}