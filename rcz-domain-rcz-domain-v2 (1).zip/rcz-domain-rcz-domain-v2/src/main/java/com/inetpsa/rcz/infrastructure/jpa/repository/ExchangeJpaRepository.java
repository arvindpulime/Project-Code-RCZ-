package com.inetpsa.rcz.infrastructure.jpa.repository;

import com.inetpsa.rcz.domain.model.action.Action;
import com.inetpsa.rcz.domain.model.enums.CallerType;
import com.inetpsa.rcz.domain.model.enums.ExchangeStatus;
import com.inetpsa.rcz.domain.model.enums.ProcessStatus;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.repository.ExchangeRepository;
import com.inetpsa.rcz.domain.services.ParameterService;
import org.seedstack.business.domain.AggregateExistsException;
import org.seedstack.jpa.BaseJpaRepository;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.util.*;

public class ExchangeJpaRepository extends BaseJpaRepository<Exchange, String> implements ExchangeRepository {

    private static final String REQUEST = "request";

    private static final String RECEIVED_DATE = "receivedDate";

    private static final String SENT_DATE = "sentDate";

    private static final String ID = "id";

    private static final String CALLER_ID = "callerId";

    private static final String ACTION = "action";

    private static final String ACTION_TYPE = "actionType";

    private static final String CORRELATION_ID = "correlationId";

    private static final String STATUS = "status";

    private static final String CALLER_TYPE = "callerType";

    private static final String UIN = "uin";

    private static final String PROCESS_STATUS = "processStatus";
    public static final String VIN = "vin";
    public static final String RCZ_EXCHANGE_TIMEOUT_PERIOD = "rcz.exchange.timeout.period";
    @Configuration(RCZ_EXCHANGE_TIMEOUT_PERIOD)
    private int exchangeTimeoutPeriod = 24;

    @Logging
    private Logger logger;

    @Inject
    private ParameterService parameterService;

    @Override
    public void add(Exchange aggregate) throws AggregateExistsException {
        super.add(aggregate);
    }

    @Override
    public Exchange merge(Exchange aggregate) throws AggregateExistsException {
        try {
            aggregate = getEntityManager().merge(aggregate);
            return aggregate;
        } catch (Exception e) {
            throw new AggregateExistsException(e);
        }
    }

    @Override
    public boolean checkQuotaByCallerAndSentToBta(String callerId, Date date, int duration, int quota) {
        Calendar calendar = getDateAndAddBy(-duration, Calendar.SECOND);
        CriteriaBuilder criteriaBuilder = getEntityManager().getCriteriaBuilder();
        CriteriaQuery<Long> criteriaQuery = criteriaBuilder.createQuery(Long.class);
        Root<Exchange> root = criteriaQuery.from(Exchange.class);
        criteriaQuery.select(criteriaBuilder.count(root));
        criteriaQuery.where(
                criteriaBuilder.and(
                        criteriaBuilder.between(
                                root.get(REQUEST).get(RECEIVED_DATE),
                                criteriaBuilder.literal(calendar.getTime()),
                                criteriaBuilder.literal(date)),
                        criteriaBuilder.equal(root.get(CALLER_ID), callerId),
                        criteriaBuilder.equal(root.get(PROCESS_STATUS), ProcessStatus.REQUEST_SENT_TO_BTA)
                )
        );
        return getEntityManager().createQuery(criteriaQuery).getSingleResult().intValue() <= quota;
    }

    @Override
    public boolean checkQuotaByCallerAndWakeUpCall(String callerId, Date date, int duration, int quota) {
        Calendar calendar = getDateAndAddBy(-duration, Calendar.SECOND);
        CriteriaBuilder criteriaBuilder = getEntityManager().getCriteriaBuilder();
        CriteriaQuery<Long> criteriaQuery = criteriaBuilder.createQuery(Long.class);
        Root<Exchange> root = criteriaQuery.from(Exchange.class);
        criteriaQuery.select(criteriaBuilder.count(root));
        criteriaQuery.where(
                criteriaBuilder.and(
                        criteriaBuilder.between(
                                root.get(REQUEST).get(RECEIVED_DATE),
                                criteriaBuilder.literal(calendar.getTime()),
                                criteriaBuilder.literal(date)),
                        criteriaBuilder.equal(root.get(CALLER_ID), callerId),
                        criteriaBuilder.equal(root.get(PROCESS_STATUS), ProcessStatus.BTA_ASLEEP)
                )
        );
        return getEntityManager().createQuery(criteriaQuery).getSingleResult().intValue() <= quota;
    }

    @Override
    public boolean checkQuotaByCaller(String callerId, Date date, int duration, int quota) {
        Calendar calendar = getDateAndAddBy(-duration, Calendar.SECOND);
        CriteriaBuilder criteriaBuilder = getEntityManager().getCriteriaBuilder();
        CriteriaQuery<Long> criteriaQuery = criteriaBuilder.createQuery(Long.class);
        Root<Exchange> root = criteriaQuery.from(Exchange.class);
        criteriaQuery.select(criteriaBuilder.count(root));
        criteriaQuery.where(
                criteriaBuilder.and(
                        criteriaBuilder.between(
                                root.get(REQUEST).get(RECEIVED_DATE),
                                criteriaBuilder.literal(calendar.getTime()),
                                criteriaBuilder.literal(date)),
                        criteriaBuilder.equal(root.get(CALLER_ID), callerId)
                )
        );
        return getEntityManager().createQuery(criteriaQuery).getSingleResult().intValue() <= quota;
    }

    @Override
    public Boolean callerHasDuplicate(Exchange exchange) {
        Calendar calendar = getDateAndAddBy(-(parameterService.get().getRcz().getExchangeTimeoutMin() + 1), Calendar.MINUTE);
        CriteriaBuilder criteriaBuilder = getEntityManager().getCriteriaBuilder();
        CriteriaQuery<Long> criteriaQuery = criteriaBuilder.createQuery(Long.class);
        Root<Exchange> root = criteriaQuery.from(Exchange.class);
        criteriaQuery.select(criteriaBuilder.count(root));
        criteriaQuery.where(
                criteriaBuilder.and(
                        criteriaBuilder.greaterThan(root.get(REQUEST).get(RECEIVED_DATE), calendar.getTime()),
                        criteriaBuilder.not(criteriaBuilder.equal(root.get(ID), exchange.getId())),
                        criteriaBuilder.equal(root.get(CALLER_ID), exchange.getCallerId()),
                        criteriaBuilder.equal(root.get(VIN), exchange.getVin()),
                        criteriaBuilder.equal(root.get(ACTION), exchange.getAction()),
                        criteriaBuilder.or(criteriaBuilder.equal(root.get(STATUS), ExchangeStatus.PENDING),
                                criteriaBuilder.equal(root.get(STATUS), ExchangeStatus.INITIAL)))
        );
        Long nbDuplicate = getEntityManager().createQuery(criteriaQuery).getSingleResult();
        return nbDuplicate > 0;
    }

    @Override
    public List<Exchange> findByCallerId(String callerId) {
        CriteriaBuilder criteriaBuilder = getEntityManager().getCriteriaBuilder();
        CriteriaQuery<Exchange> criteriaQuery = criteriaBuilder.createQuery(Exchange.class);
        Root<Exchange> root = criteriaQuery.from(Exchange.class);
        criteriaQuery.select(root);
        criteriaQuery.where(
                criteriaBuilder.equal(root.get(CALLER_ID), callerId)
        );
        return getEntityManager().createQuery(criteriaQuery).getResultList();
    }

    @Override
    //TODO CORRELATION ID BUG REQUEST STATE
    public Optional<Exchange> findByCorrelationId(String correlationId) {
        CriteriaBuilder cb = getEntityManager().getCriteriaBuilder();
        CriteriaQuery<Exchange> q = cb.createQuery(Exchange.class);
        Root<Exchange> e = q.from(Exchange.class);
        q.select(e).where(cb.equal(e.get(CORRELATION_ID), correlationId));
        return Optional.ofNullable(getEntityManager().createQuery(q).getSingleResult());
    }

    @Override
    public Optional<Exchange> findPendingByCorrelationId(String correlationId) {
        CriteriaBuilder cb = getEntityManager().getCriteriaBuilder();
        CriteriaQuery<Exchange> q = cb.createQuery(Exchange.class);
        Root<Exchange> e = q.from(Exchange.class);
        q.select(e).where(cb.and(cb.equal(e.get(CORRELATION_ID), correlationId), cb.equal(e.get(STATUS), ExchangeStatus.PENDING)));
        return Optional.ofNullable(getEntityManager().createQuery(q).getSingleResult());
    }

    @Override
    public List<Exchange> findAllInTimeout(int timeout) {
        Date timeoutDate = getDateAndAddBy(-timeout, Calendar.MINUTE).getTime();
        Date periode = getDateAndAddBy(-exchangeTimeoutPeriod, Calendar.HOUR).getTime();
        CriteriaBuilder cb = getEntityManager().getCriteriaBuilder();
        CriteriaQuery<Exchange> q = cb.createQuery(Exchange.class);
        Root<Exchange> root = q.from(Exchange.class);
        q.select(root).where(
                cb.and(
                        cb.between(
                                root.get(REQUEST).get(RECEIVED_DATE),
                                cb.literal(periode),
                                cb.literal(timeoutDate)),
                        cb.in(root.get(CALLER_TYPE)).value(CallerType.CLIENT).value(CallerType.PARTNER),
                        cb.in(root.get(STATUS)).value(ExchangeStatus.PENDING).value(ExchangeStatus.INITIAL)
                )
        );
        return getEntityManager().createQuery(q).getResultList();
    }

    private Calendar getDateAndAddBy(int duration, int unit) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        calendar.add(unit, duration);
        return calendar;
    }

    @Override
    public List<Exchange> findStolenInTimeout(int timeout) {
        Calendar calendar = getDateAndAddBy(-timeout, Calendar.MINUTE);
        CriteriaBuilder cb = getEntityManager().getCriteriaBuilder();
        CriteriaQuery<Exchange> q = cb.createQuery(Exchange.class);
        Root<Exchange> root = q.from(Exchange.class);
        q.select(root).where(
                cb.and(cb.greaterThan(cb.literal(calendar.getTime()), root.get(REQUEST).get(RECEIVED_DATE))),
                cb.equal(root.get(ACTION), Action.STOLEN_VIN),
                cb.or(cb.equal(root.get(STATUS), ExchangeStatus.PENDING),
                        cb.equal(root.get(STATUS), ExchangeStatus.INITIAL))

        );
        return getEntityManager().createQuery(q).getResultList();
    }


    @Override
    public Collection<Exchange> findPendingAsleep(String uin) {
        Calendar calendar = getDateAndAddBy(-(parameterService.get().getRcz().getExchangeTimeoutMin() + 1), Calendar.MINUTE);
        CriteriaBuilder cb = getEntityManager().getCriteriaBuilder();
        CriteriaQuery<Exchange> q = cb.createQuery(Exchange.class);
        Root<Exchange> e = q.from(Exchange.class);
        q.select(e).where(cb.and(
                cb.greaterThan(e.get(REQUEST).get(RECEIVED_DATE), calendar.getTime()),
                cb.in(e.get(CALLER_TYPE)).value(CallerType.CLIENT).value(CallerType.PARTNER),
                cb.equal(e.get(UIN), uin),
                cb.equal(e.get(STATUS),
                        ExchangeStatus.PENDING),
                cb.equal(e.get(PROCESS_STATUS),
                        ProcessStatus.BTA_ASLEEP)));
        return getEntityManager().createQuery(q).getResultList();
    }


    @Override
    public boolean correlationIdExist(String correlationId, String callerId) {
        CriteriaBuilder cb = getEntityManager().getCriteriaBuilder();
        CriteriaQuery<Long> q = cb.createQuery(Long.class);
        Root<Exchange> root = q.from(Exchange.class);
        q.select(cb.count(root)).where(cb.and(cb.equal(root.get("callerId"), callerId), cb.equal(root.get(CORRELATION_ID), correlationId)));
        return getEntityManager().createQuery(q).getSingleResult() > 0;
    }

    @Override
    public boolean checkQuotaForAction(Action action, String callerId, String vin, int duration, int quota) {
        Date date = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.MINUTE, -duration);
        CriteriaBuilder criteriaBuilder = getEntityManager().getCriteriaBuilder();
        CriteriaQuery<Long> criteriaQuery = criteriaBuilder.createQuery(Long.class);
        Root<Exchange> root = criteriaQuery.from(Exchange.class);
        criteriaQuery.select(criteriaBuilder.count(root));
        criteriaQuery.where(
                criteriaBuilder.and(
                        criteriaBuilder.between(
                                root.get(REQUEST).get(RECEIVED_DATE),
                                criteriaBuilder.literal(calendar.getTime()),
                                criteriaBuilder.literal(date)),
                        criteriaBuilder.equal(root.get(ACTION), action),
                        criteriaBuilder.equal(root.get(CALLER_ID), callerId),
                        criteriaBuilder.equal(root.get(PROCESS_STATUS), ProcessStatus.REQUEST_SENT_TO_BTA),
                        criteriaBuilder.equal(root.get(VIN), vin)
                )
        );
        return getEntityManager().createQuery(criteriaQuery).getSingleResult().intValue() <= quota;
    }

}
