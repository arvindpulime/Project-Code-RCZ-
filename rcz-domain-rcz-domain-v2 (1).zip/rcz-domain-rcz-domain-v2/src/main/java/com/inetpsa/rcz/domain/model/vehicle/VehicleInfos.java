/*
 * Creation : 6 juin 2016
 */
package com.inetpsa.rcz.domain.model.vehicle;

import org.seedstack.business.domain.BaseValueObject;

import javax.persistence.Embeddable;
import java.util.Date;

@Embeddable
public class VehicleInfos extends BaseValueObject {

    private Date receivedDate;
    private String rawJson;

    public VehicleInfos(Date receivedDate, String request) {
        this.receivedDate = receivedDate;
        this.rawJson = request;
    }

    VehicleInfos() {
    }

    public Date getReceivedDate() {
        return receivedDate;
    }

    public void setReceivedDate(Date receivedDate) {
        this.receivedDate = receivedDate;
    }

    public String getRawJson() {
        return rawJson;
    }

    public void setRawJson(String rawJson) {
        this.rawJson = rawJson;
    }
}
