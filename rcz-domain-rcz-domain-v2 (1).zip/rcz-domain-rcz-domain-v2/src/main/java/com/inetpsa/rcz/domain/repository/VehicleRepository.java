package com.inetpsa.rcz.domain.repository;

import com.inetpsa.rcz.domain.model.shared.Payload;
import com.inetpsa.rcz.domain.model.vehicle.Vehicle;
import org.seedstack.business.domain.AggregateNotFoundException;
import org.seedstack.business.domain.Repository;

public interface VehicleRepository extends Repository<Vehicle, String> {

    Boolean isConnected(String uin);

    Payload getVehicleInfo(String uin);

    Vehicle merge(Vehicle aggregate) throws AggregateNotFoundException;
}
