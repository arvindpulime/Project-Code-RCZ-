package com.inetpsa.rcz.domain.model.payload.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.inetpsa.rcz.domain.model.payload.data.Data;
import com.inetpsa.rcz.infrastructure.jackson.deserializer.DataJsonDeserializer;
import com.inetpsa.rcz.infrastructure.jackson.serializer.DataJsonSerializer;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.util.Date;

import static com.inetpsa.rcz.domain.model.payload.ValidationPattern.PATTERN_DATE;
import static com.inetpsa.rcz.domain.model.payload.ValidationPattern.PATTERN_VIN;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RemoteAlarmRequestPayload {


    @JsonProperty("req_id")
    private String requestId;

    @NotNull
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = PATTERN_DATE)
    @JsonProperty("date")
    private Date alarmDate;

    @Min(0)
    @Max(11)
    @NotNull
    @JsonProperty("type")
    private Integer type;

    @NotNull
    @JsonDeserialize(using = DataJsonDeserializer.class)
    @JsonSerialize(using = DataJsonSerializer.class)
    @JsonProperty("location")
    private Data location;

    @NotNull
    @JsonProperty("vin")
    @Pattern(regexp = PATTERN_VIN)
    private String vin;

    @JsonProperty("alarm_type")
    String alarmType;

    public String getRequestId() {
        return requestId;
    }

    public RemoteAlarmRequestPayload setRequestId(String requestId) {
        this.requestId = requestId;
        return this;
    }

    public Date getAlarmDate() {
        return alarmDate;
    }

    public void setAlarmDate(Date alarmDate) {
        this.alarmDate = alarmDate;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Data getLocation() {
        return location;
    }

    public void setLocation(Data location) {
        this.location = location;
    }

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    public String getAlarmType() {
        return alarmType;
    }

    public AlarmType getAlarmEnum() {
        return AlarmType.valueOf(alarmType);
    }

    public RemoteAlarmRequestPayload setAlarmType(String alarmType) {
        this.alarmType = alarmType;
        return this;
    }
    public RemoteAlarmRequestPayload setAlarmType(AlarmType alarmType) {
        this.alarmType = alarmType.name();
        return this;
    }
    public enum AlarmType {
        MOTION_ALERT,
        VEHICLE_ALARM
    }
}
