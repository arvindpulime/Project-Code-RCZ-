package com.inetpsa.rcz.domain.model.payload.topic;

import com.inetpsa.rcz.domain.model.payload.data.VehicleState;

public class VehicleStateBtaTopicsResolver implements BtaTopicsResolver<VehicleState> {

}
