package com.inetpsa.rcz.infrastructure.jpa.repository;

import com.inetpsa.rcz.domain.model.vehicle.VehicleConnect;
import com.inetpsa.rcz.domain.repository.VehicleConnectRepository;
import org.seedstack.business.domain.AggregateNotFoundException;
import org.seedstack.business.domain.Repository;
import org.seedstack.jpa.BaseJpaRepository;

public class VehicleConnectJpaRepository extends BaseJpaRepository<VehicleConnect, String> implements VehicleConnectRepository {
    @Override
    public VehicleConnect merge(VehicleConnect aggregate) throws AggregateNotFoundException {
        return getEntityManager().merge(aggregate);
    }
}
