package com.inetpsa.rcz.domain.model.payload.topic;

import com.inetpsa.rcz.domain.model.payload.data.Immobilization;

public class ImmobilizationBtaTopicsResolver implements BtaTopicsResolver<Immobilization> {
}
