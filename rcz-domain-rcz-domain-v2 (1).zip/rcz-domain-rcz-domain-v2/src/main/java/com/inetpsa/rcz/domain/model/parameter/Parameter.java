package com.inetpsa.rcz.domain.model.parameter;


import com.inetpsa.rcz.infrastructure.data.CustomUUIDGenerator;
import lombok.Data;
import lombok.experimental.Accessors;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "RCZQTPARAMETER")
@Data
@Accessors(chain = true)
public class Parameter extends BaseAggregateRoot<String> implements Serializable {

    @Id
    @Identity(generator = CustomUUIDGenerator.class)
    private String id;

    @Embedded
    private RczParam rcz = new RczParam();

    @Embedded
    private CommodoreParam commodore = new CommodoreParam();

    @Embedded
    private SmsParam sms = new SmsParam();

    @Embedded
    private CvsParam cvs = new CvsParam();
}