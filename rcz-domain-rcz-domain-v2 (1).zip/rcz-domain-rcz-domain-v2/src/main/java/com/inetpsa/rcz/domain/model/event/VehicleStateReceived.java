package com.inetpsa.rcz.domain.model.event;

import org.seedstack.business.domain.BaseDomainEvent;

public class VehicleStateReceived extends BaseDomainEvent {

    private String topic;

    private String message;

    public String getTopic() {
        return topic;
    }

    public String getMessage() {
        return message;
    }

    public VehicleStateReceived(String topic, String message) {
        this.topic = topic;
        this.message = message;
    }
}
