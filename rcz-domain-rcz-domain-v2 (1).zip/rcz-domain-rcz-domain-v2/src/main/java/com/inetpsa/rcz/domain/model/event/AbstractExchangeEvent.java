package com.inetpsa.rcz.domain.model.event;

import com.inetpsa.rcz.domain.model.exchange.Exchange;
import org.seedstack.business.domain.BaseDomainEvent;

public class AbstractExchangeEvent extends BaseDomainEvent {

    private Exchange exchange;

    public AbstractExchangeEvent(Exchange exchange) {
        this.exchange = exchange;
    }

    public Exchange getExchange() {
        return exchange;
    }

    public void setExchange(Exchange exchange) {
        this.exchange = exchange;
    }
}
