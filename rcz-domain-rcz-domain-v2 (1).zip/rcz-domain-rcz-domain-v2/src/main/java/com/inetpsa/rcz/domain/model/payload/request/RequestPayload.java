package com.inetpsa.rcz.domain.model.payload.request;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.inetpsa.rcz.domain.model.event.VehicleInfoReceived;
import com.inetpsa.rcz.infrastructure.jackson.validator.CheckDateFormat;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import static com.inetpsa.rcz.domain.model.payload.ValidationPattern.*;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RequestPayload<R> {

    @NotNull
    @CheckDateFormat(pattern = PATTERN_DATE)
    @JsonProperty("req_date")
    private String requestDateValue;

    @NotNull
    @Pattern(regexp = PATTERN_VIN)
    @JsonProperty("vin")
    private String vin;

    @NotNull
    @Pattern(regexp = PATTERN_CLIENT_CODE)
    @JsonProperty("customer_id")
    private String customerId;

    @NotNull
    @Pattern(regexp = PATTERN_CORRELATION_ID)
    @JsonProperty("correlation_id")
    private String correlationId;


    @Pattern(regexp = PATTERN_ACCESS_TOKEN)
    @JsonProperty("access_token")
    private String accessToken;

    @NotNull
    @Valid
    @JsonProperty("req_parameters")
    private R requestParameters;

    public String getRequestDateValue() {
        return requestDateValue;
    }

    public void setRequestDateValue(String requestDateValue) {
        this.requestDateValue = requestDateValue;
    }

    @JsonIgnore
    public void setRequestDate(Date requestDateValue) {
        SimpleDateFormat formatter = new SimpleDateFormat(PATTERN_DATE);
        formatter.setTimeZone(TimeZone.getTimeZone("UTC"));
        this.requestDateValue = formatter.format(requestDateValue);
    }

    @JsonIgnore
    public Date getRequestDate() {
        SimpleDateFormat formatter = new SimpleDateFormat(PATTERN_DATE);
        formatter.setTimeZone(TimeZone.getTimeZone("UTC"));
        try {
            return formatter.parse(requestDateValue);
        } catch (ParseException e) {
            return null;
        }
    }

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getCorrelationId() {
        return correlationId;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public R getRequestParameters() {
        return requestParameters;
    }

    public void setRequestParameters(R requestParameters) {
        this.requestParameters = requestParameters;
    }

}


