/*
 * Creation : 16 août 2016
 */
package com.inetpsa.rcz.domain.model.payload.data;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import static com.inetpsa.rcz.domain.model.payload.ValidationPattern.PATTERN_ID_PARTNER;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class StolenVin extends Error {

    @NotNull
    @JsonProperty("partner_id")
    @Pattern(regexp = PATTERN_ID_PARTNER)
    private String partnerId;

    @NotNull
    @Min(0)
    @Max(1)
    @JsonProperty("stolen_state")
    private Integer stolenState;

    public StolenVin(String partnerId) {
        super();
        this.partnerId = partnerId;
    }

    public StolenVin() {
    }

    public String getPartnerId() {
        return partnerId;
    }

    public void setPartnerId(String partnerId) {
        this.partnerId = partnerId;
    }

    @JsonIgnore
    public Boolean getStolen() {
        return Boolean.parseBoolean(stolenState.toString());
    }

    public StolenVin(String partnerId, Boolean stolen) {
        this.partnerId = partnerId;
        this.stolenState = Boolean.compare(stolen, false);
    }

    public StolenVin(String partnerId, int stolen) {
        this.partnerId = partnerId;
        this.stolenState = stolen;
    }

    public Integer getStolenState() {
        return stolenState;
    }

    public StolenVin setStolenState(Integer stolenState) {
        this.stolenState = stolenState;
        return this;
    }
}
