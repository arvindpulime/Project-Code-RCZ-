package com.inetpsa.rcz.domain.model.api.request;

public enum RequestType {
    CHARGING,
    CHARGING_STATE,
    DOOR,
    HORN,
    IMMOBILIZATION,
    LIGHTS,
    LOW_POWER_INFO,
    REQUEST_STATE,
    STOLEN_VIN,
    THERMAL_PRECONDITIONING,
    TRACKING,
    VEHICLE_STATE
}