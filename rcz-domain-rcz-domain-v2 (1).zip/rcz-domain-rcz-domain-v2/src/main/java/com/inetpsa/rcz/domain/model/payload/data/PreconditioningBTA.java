package com.inetpsa.rcz.domain.model.payload.data;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.validation.constraints.NotNull;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PreconditioningBTA {

    public static final int DEACTIVATE = 0;
    public static final int ACTIVATE = 1;

    @NotNull
    @JsonProperty("programs")
    private Programs programs;

    @NotNull
    @JsonProperty("asap")
    private Integer asap;

    public PreconditioningBTA(Programs programs, Integer asap) {
        this.programs = programs;
        this.asap = asap;
    }

    public PreconditioningBTA() {
    }

    public Programs getPrograms() {
        return programs;
    }

    public void setPrograms(Programs programs) {
        this.programs = programs;
    }

    public Integer getAsap() {
        return asap;
    }

    public void setAsap(Integer asap) {
        this.asap = asap;
    }
}
