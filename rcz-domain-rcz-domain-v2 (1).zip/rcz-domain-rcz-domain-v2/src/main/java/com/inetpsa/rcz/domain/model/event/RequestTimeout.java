package com.inetpsa.rcz.domain.model.event;


import org.seedstack.business.domain.BaseDomainEvent;

public class RequestTimeout extends BaseDomainEvent {

}
