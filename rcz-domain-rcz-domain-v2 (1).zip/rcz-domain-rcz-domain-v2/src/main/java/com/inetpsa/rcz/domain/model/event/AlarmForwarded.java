package com.inetpsa.rcz.domain.model.event;

import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.payload.request.RemoteAlarmRequestPayload;

public class AlarmForwarded extends AbstractExchangeEvent {

    private RemoteAlarmRequestPayload remoteAlarmRequestPayload;

    public AlarmForwarded(Exchange exchange, RemoteAlarmRequestPayload remoteAlarmRequestPayload) {
        super(exchange);
        this.remoteAlarmRequestPayload = remoteAlarmRequestPayload;
    }

    public RemoteAlarmRequestPayload getRemoteAlarmRequestPayload() {
        return remoteAlarmRequestPayload;
    }
}
