package com.inetpsa.rcz.domain.model.log;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.inetpsa.rcz.domain.model.action.ActionService;
import com.inetpsa.rcz.domain.model.action.ActionType;
import com.inetpsa.rcz.domain.model.enums.CallerType;
import com.inetpsa.rcz.domain.model.enums.ProcessStatus;
import com.inetpsa.rcz.domain.model.enums.ResponseStatus;

/**
 * JSON representation holding an exchange data.
 *
 * @author tuan.docao@ext.mpsa.com
 */
public class EventLogContext {

    @JsonProperty("exchange")
    private String exchangeId;

    @JsonProperty("caller_type")
    private CallerType callerType;

    @JsonProperty("caller")
    private String callerId;

    @JsonProperty("vehicle")
    private String vehicleId;

    @JsonProperty("service")
    private ActionService service;

    @JsonProperty("action")
    private ActionType action;

    @JsonProperty("correlation_id")
    private String correlationId;

    @JsonProperty("process_status")
    private ProcessStatus processStatus;

    @JsonProperty("response_status")
    private ResponseStatus responseStatus;

    public String getExchangeId() {
        return exchangeId;
    }

    public void setExchangeId(String exchangeId) {
        this.exchangeId = exchangeId;
    }

    public CallerType getCallerType() {
        return callerType;
    }

    public void setCallerType(CallerType callerType) {
        this.callerType = callerType;
    }

    public String getCallerId() {
        return callerId;
    }

    public void setCallerId(String callerId) {
        this.callerId = callerId;
    }

    public String getVehicleId() {
        return vehicleId;
    }

    public void setVehicleId(String vehicleId) {
        this.vehicleId = vehicleId;
    }

    public ActionService getService() {
        return service;
    }

    public void setService(ActionService service) {
        this.service = service;
    }

    public ActionType getAction() {
        return action;
    }

    public void setAction(ActionType action) {
        this.action = action;
    }

    public String getCorrelationId() {
        return correlationId;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    public ProcessStatus getProcessStatus() {
        return processStatus;
    }

    public void setProcessStatus(ProcessStatus processStatus) {
        this.processStatus = processStatus;
    }

    public ResponseStatus getResponseStatus() {
        return responseStatus;
    }

    public void setResponseStatus(ResponseStatus responseStatus) {
        this.responseStatus = responseStatus;
    }
}
