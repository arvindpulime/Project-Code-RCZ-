package com.inetpsa.rcz.domain.model.payload.response;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.inetpsa.rcz.domain.model.enums.SevState;
import com.inetpsa.rcz.domain.model.payload.data.Data;
import com.inetpsa.rcz.infrastructure.jackson.deserializer.DataJsonDeserializer;
import com.inetpsa.rcz.infrastructure.jackson.serializer.DataJsonSerializer;
import com.inetpsa.rcz.infrastructure.jackson.serializer.NumericBooleanSerializer;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.util.Date;

import static com.inetpsa.rcz.domain.model.payload.ValidationPattern.PATTERN_DATE;

/**
 * @author tuan.docao@ext.mpsa.com
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ImmoStateResponsePayload {

    @NotNull
    @JsonProperty("vin")
    private String vin;

    @NotNull
    @JsonProperty("correlation_id")
    private String correlationId;

    @NotNull
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = PATTERN_DATE)
    @JsonProperty("date")
    private Date date;

    @JsonSerialize(using = NumericBooleanSerializer.class)
    @JsonProperty("immo_state")
    private Boolean immoState;

    @JsonSerialize(using = DataJsonSerializer.class)
    @JsonDeserialize(using = DataJsonDeserializer.class)
    @JsonProperty("location")
    private Data location;

    @Min(0) @Max(3)
    @JsonProperty("sev_state")
    private Integer sevStateValue;

    public Integer getSevStateValue() {
        return sevStateValue;
    }

    public void setSevStateValue(Integer sevStateValue) {
        this.sevStateValue = sevStateValue;
    }

    @JsonIgnore
    public SevState getSevState() {
        return SevState.fromIntValue(sevStateValue);
    }

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    public String getCorrelationId() {
        return correlationId;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Boolean getImmoState() {
        return immoState;
    }

    public void setImmoState(Boolean immoState) {
        this.immoState = immoState;
    }

    public Data getLocation() {
        return location;
    }

    public void setLocation(Data location) {
        this.location = location;
    }
}
