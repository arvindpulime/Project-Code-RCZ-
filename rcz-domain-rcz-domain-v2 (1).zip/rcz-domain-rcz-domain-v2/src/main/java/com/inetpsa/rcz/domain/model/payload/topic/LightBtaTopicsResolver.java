package com.inetpsa.rcz.domain.model.payload.topic;

import com.inetpsa.rcz.domain.model.payload.data.Lights;

public class LightBtaTopicsResolver implements  BtaTopicsResolver<Lights> {
}
