package com.inetpsa.rcz.domain.repository;

import com.inetpsa.rcz.domain.model.sms.Sms;
import org.seedstack.business.domain.AggregateNotFoundException;
import org.seedstack.business.domain.Repository;

public interface SmsRepository extends Repository<Sms, String> {
    Sms merge(Sms aggregate) throws AggregateNotFoundException;

}
