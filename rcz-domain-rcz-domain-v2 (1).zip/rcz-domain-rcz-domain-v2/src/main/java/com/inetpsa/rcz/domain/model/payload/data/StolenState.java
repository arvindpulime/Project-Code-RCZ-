/*
 * Creation : 16 août 2016
 */
package com.inetpsa.rcz.domain.model.payload.data;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.inetpsa.rcz.infrastructure.jackson.serializer.NumericBooleanSerializer;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class StolenState extends Error{

    @JsonSerialize(using = NumericBooleanSerializer.class)
    @JsonProperty("stolen_state_value")
    private Boolean stolenStateValue;

    public StolenState() {
    }

    public StolenState(Boolean stolenStateValue) {
        this.stolenStateValue = stolenStateValue;
    }

    public Boolean getStolenStateValue() {
        return stolenStateValue;
    }

    public void setStolenStateValue(Boolean stolenStateValue) {
        this.stolenStateValue = stolenStateValue;
    }

}
