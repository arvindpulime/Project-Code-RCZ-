package com.inetpsa.rcz.domain.model.monitoring;

public class MqttMonitoringWrapper {
    private String instance;
    private String updateDate;
    private MqttClient mqttClient;
}
