package com.inetpsa.rcz.domain.model.sms;

public enum UserType {

    MSISDN,
    GWALIAS,
    UID,
    WUID
}
