package com.inetpsa.rcz.infrastructure.data;

import org.seedstack.business.domain.Entity;
import org.seedstack.business.domain.IdentityGenerator;

import javax.inject.Named;
import java.util.UUID;

@Named("string-uuid")
public class CustomUUIDGenerator implements IdentityGenerator<String> {

    @Override
    public <E extends Entity<String>> String generate(Class<E> entityClass) {
        return UUID.randomUUID().toString();
    }
}