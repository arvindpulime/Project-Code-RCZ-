package com.inetpsa.rcz.domain.model.vehicle;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.seedstack.business.domain.BaseValueObject;

import javax.persistence.Embeddable;
import java.util.Date;

import static com.inetpsa.rcz.domain.model.payload.ValidationPattern.PATTERN_DATE_FRONT;

@Embeddable
public class State extends BaseValueObject {

    private boolean connected;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = PATTERN_DATE_FRONT)
    private Date receivedDate;

    public State(boolean connected, Date receivedDate) {
        this.connected = connected;
        this.receivedDate = receivedDate;
    }

    public State() {
    }

    public boolean isConnected() {
        return connected;
    }

    public void setConnected(boolean connected) {
        this.connected = connected;
    }

    public Date getReceivedDate() {
        return receivedDate;
    }

    public void setReceivedDate(Date receivedDate) {
        this.receivedDate = receivedDate;
    }
}
