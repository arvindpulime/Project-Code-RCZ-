package com.inetpsa.rcz.domain.model.log;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.inetpsa.rcz.domain.model.enums.LogLevel;

import javax.validation.Valid;
import java.util.Date;

/**
 * JSON representation of an event log.
 *
 * @author tuan.docao@ext.mpsa.com
 */
public class EventLog {

    @JsonProperty("id")
    private String id;

    @JsonProperty("level")
    private LogLevel logLevel;

    @JsonProperty("date")
    private Date logDate;

    @JsonProperty("message")
    private String message;

    @JsonProperty("topic")
    private String topic;

    @JsonProperty("data")
    private String data;

    @JsonProperty("context")
    @Valid
    private EventLogContext context;

    public EventLog() {
    }

    public EventLog(String message) {
        this.message = message;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public LogLevel getLogLevel() {
        return logLevel;
    }

    public void setLogLevel(LogLevel logLevel) {
        this.logLevel = logLevel;
    }

    public Date getLogDate() {
        return logDate;
    }

    public void setLogDate(Date logDate) {
        this.logDate = logDate;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public EventLogContext getContext() {
        if (context == null) {
            context = new EventLogContext();
        }
        return context;
    }

    public void setContext(EventLogContext context) {
        this.context = context;
    }
}
