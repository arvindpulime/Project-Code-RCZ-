package com.inetpsa.rcz.domain.model.payload.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.util.Date;

import static com.inetpsa.rcz.domain.model.payload.ValidationPattern.*;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RemoteAlarmResponsePayload {

    @NotNull
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern= PATTERN_DATE)
    @JsonProperty("resp_date")
    private Date responseDate;

    @NotNull
    @Pattern(regexp = PATTERN_CORRELATION_ID)
    @JsonProperty("correlation_id")
    private String correlationId;

    @NotNull
    @Pattern(regexp = PATTERN_RETURN_CODE)
    @JsonProperty("return_code")
    private String returnCode;

    @NotNull
    @Size(max = 50)
    @JsonProperty("return_message")
    private String returnMessage;

    public Date getResponseDate() {
        return responseDate;
    }

    public void setResponseDate(Date responseDate) {
        this.responseDate = responseDate;
    }

    public String getCorrelationId() {
        return correlationId;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    public String getReturnCode() {
        return returnCode;
    }

    public void setReturnCode(String returnCode) {
        this.returnCode = returnCode;
    }

    public String getReturnMessage() {
        return returnMessage;
    }

    public void setReturnMessage(String returnMessage) {
        this.returnMessage = returnMessage;
    }
}
