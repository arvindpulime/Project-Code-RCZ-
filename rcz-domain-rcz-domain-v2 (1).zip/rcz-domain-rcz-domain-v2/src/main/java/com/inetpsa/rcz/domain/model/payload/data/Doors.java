package com.inetpsa.rcz.domain.model.payload.data;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.inetpsa.rcz.domain.model.enums.DoorsLockingState;
import com.inetpsa.rcz.domain.model.enums.SevState;
import com.inetpsa.rcz.infrastructure.jackson.deserializer.DoorsOpeningStateDeserializer;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import static com.inetpsa.rcz.domain.model.payload.ValidationPattern.PATTERN_DOORS_ACTION;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Doors extends Error{

    public Doors() {
    }

    public Doors(Integer state) {
        this.state = state;
    }

    @Min(0)
    @Max(4)
    @JsonProperty("state")
    private Integer state;

    @JsonProperty("lock_resp_state")
    private Integer lockRespState;

    @JsonDeserialize(using = DoorsOpeningStateDeserializer.class)
    @JsonProperty("opening_state")
    private DoorsOpeningState openingState;

    @JsonProperty(value = "forced", defaultValue = "false")
    private Boolean forced;

    @Min(0)
    @Max(6)
    @JsonProperty("locking_state")
    private Integer lockingStateValue;

    @NotNull
    @Pattern(regexp = PATTERN_DOORS_ACTION)
    @JsonProperty("action")
    private String action;

    @Min(0)
    @Max(3)
    @JsonProperty("sev_state")
    private Integer sevStateValue;


    public Integer getSevStateValue() {
        return sevStateValue;
    }

    public void setSevStateValue(Integer sevStateValue) {
        this.sevStateValue = sevStateValue;
    }

    @JsonIgnore
    public SevState getSevState() {
        return SevState.fromIntValue(sevStateValue);
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public Integer getLockRespState() {
        return lockRespState;
    }

    public void setLockRespState(Integer lockRespState) {
        this.lockRespState = lockRespState;
    }


    public DoorsOpeningState getOpeningState() {
        return openingState;
    }

    public void setOpeningState(DoorsOpeningState openingState) {
        this.openingState = openingState;
    }


    public Boolean getForced() {
        return forced;
    }

    public Doors setForced(Boolean forced) {
        this.forced = forced;
        return this;
    }

    @JsonIgnore
    public DoorsLockingState getLockingState() {
        return DoorsLockingState.fromIntValue(lockingStateValue);
    }


    public Integer getLockingStateValue() {
        return lockingStateValue;
    }

    public void setLockingStateValue(Integer lockingStateValue) {
        this.lockingStateValue = lockingStateValue;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

}
