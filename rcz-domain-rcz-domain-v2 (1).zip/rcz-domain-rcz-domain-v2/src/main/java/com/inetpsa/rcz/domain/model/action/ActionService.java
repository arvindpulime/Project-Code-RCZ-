package com.inetpsa.rcz.domain.model.action;

public enum ActionService {
    REMOTE("RemoteServices"),
    STOLEN("Stolen"),
    DEVICE_MANAGEMENT("DeviceManagement");

    private String literal;

    ActionService(String literal) {
        this.literal = literal;
    }

    public String literal() {
        return literal;
    }

    public static ActionService fromValue(String v) {
        for (ActionService c : ActionService.values()) {
            if (c.literal.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }
}
