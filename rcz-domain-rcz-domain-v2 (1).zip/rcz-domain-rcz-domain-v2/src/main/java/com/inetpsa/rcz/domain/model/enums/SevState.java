package com.inetpsa.rcz.domain.model.enums;

/**
 * Position of Enum constants matters.
 *
 * @author tuan.docao@ext.mpsa.com
 */
public enum SevState {
    STOP,
    CONTACT,
    DEM,
    FREE;

    public static SevState fromIntValue(Integer value) {
        if(value == null){
            return null;
        }
        for (SevState sevState : SevState.values()) {
            if (sevState.ordinal() == value) {
                return sevState;
            }
        }
        throw new IllegalArgumentException("SevState must be between 0 and 3 : " + value);
    }

}
