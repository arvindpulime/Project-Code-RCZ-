package com.inetpsa.rcz.domain.model.event;

import com.inetpsa.rcz.domain.model.exchange.Exchange;

public class VehicleCommandSent extends AbstractExchangeEvent {
    public VehicleCommandSent(Exchange exchange) {
        super(exchange);
    }
}
