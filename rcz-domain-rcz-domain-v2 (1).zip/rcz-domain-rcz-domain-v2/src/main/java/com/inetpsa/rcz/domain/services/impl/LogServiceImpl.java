package com.inetpsa.rcz.domain.services.impl;

import com.inetpsa.rcz.domain.model.enums.LogLevel;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.log.LogMessage;
import com.inetpsa.rcz.domain.services.AppLogger;
import com.inetpsa.rcz.domain.services.LogService;
import org.seedstack.business.domain.DomainRegistry;
import org.seedstack.seed.Application;

import javax.inject.Inject;
import java.text.MessageFormat;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;

/**
 * @author tuan.docao@ext.mpsa.com
 */
public class LogServiceImpl implements LogService {

    private static final String PROP_KEY_LOGGERS = "rcz.applogger.implementations";

    private static final Map<AppLog, AppLogger> LOGGERS = new HashMap<>();

    @Inject
    public LogServiceImpl(DomainRegistry domainRegistry, Application application) {
        String[] impls = application.getConfiguration().getMandatory(String[].class, PROP_KEY_LOGGERS);
        for (String impl : impls) {
            AppLogger logger = domainRegistry.getService(AppLogger.class, impl);
            LOGGERS.put(logger.key(), logger);
        }
    }

    @Override
    public String resolvePlaceholders(String format, Object... arg) {
        MessageFormat form = new MessageFormat(format);
        return form.format(arg);
    }

    @Override
    public void debug(LogMessage message, Exchange exchange) {
        log(LogLevel.DEBUG, message, exchange, AppLog.NONE);
    }

    @Override
    public void info(LogMessage message, Exchange exchange) {
        log(LogLevel.INFO, message, exchange, AppLog.NONE);
    }

    @Override
    public void warn(LogMessage message, Exchange exchange) {
        log(LogLevel.WARN, message, exchange, AppLog.NONE);
    }

    @Override
    public void error(LogMessage message, Exchange exchange) {
        log(LogLevel.ERROR, message, exchange, AppLog.NONE);
    }

    @Override
    public void debug(LogMessage message, Exchange exchange, AppLog... deactivated) {
        log(LogLevel.DEBUG, message, exchange, deactivated);
    }

    @Override
    public void info(LogMessage message, Exchange exchange, AppLog... deactivated) {
        log(LogLevel.INFO, message, exchange, deactivated);
    }

    @Override
    public void warn(LogMessage message, Exchange exchange, AppLog... deactivated) {
        log(LogLevel.WARN, message, exchange, deactivated);
    }

    @Override
    public void error(LogMessage message, Exchange exchange, AppLog... deactivated) {
        log(LogLevel.ERROR, message, exchange, deactivated);
    }

    private void log(LogLevel logLevel, LogMessage message, Exchange exchange, AppLog... deactivated) {
        EnumSet<AppLog> loggersToRemove = toEnumSet(deactivated);
        Map<AppLog, AppLogger> activeLoggers = new HashMap<>(LOGGERS);
        activeLoggers.keySet().removeAll(loggersToRemove);
        for (AppLogger logger : activeLoggers.values()) {
            logger.log(logLevel, message, exchange);
        }
    }

    private EnumSet<AppLog> toEnumSet(AppLog... loggers) {
        EnumSet<AppLog> result = EnumSet.noneOf(AppLog.class);
        result.addAll(Arrays.asList(loggers));
        return result;
    }
}
