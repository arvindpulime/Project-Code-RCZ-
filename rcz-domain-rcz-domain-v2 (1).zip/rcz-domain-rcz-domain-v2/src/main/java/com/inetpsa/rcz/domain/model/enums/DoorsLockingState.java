package com.inetpsa.rcz.domain.model.enums;

/**
 * Position of Enum constants matters.
 *
 * @author tuan.docao@ext.mpsa.com
 */
public enum DoorsLockingState {
    INVALID_STATE, // 0
    DOORS_LOCKED,
    DOORS_SUPERLOCKED, // 2
    DOORS_UNLOCKED,
    DRIVER_DOOR_UNLOCKED, // 4
    CABIN_DOORS_UNLOCKED,
    CARGO_DOORS_UNLOCKED, // 6
    TRUNK_DOOR_UNLOCKED, //7
    TRUNK_AND_DRIVER_DOORS_UNLOCKED; //8

    public static DoorsLockingState fromIntValue(int value) {
        for (DoorsLockingState doorsLockingState : DoorsLockingState.values()) {
            if (doorsLockingState.ordinal() == value) {
                return doorsLockingState;
            }
        }
        throw new IllegalArgumentException("DoorsLockingState must be between 0 and 8 : " + value);
    }
}
