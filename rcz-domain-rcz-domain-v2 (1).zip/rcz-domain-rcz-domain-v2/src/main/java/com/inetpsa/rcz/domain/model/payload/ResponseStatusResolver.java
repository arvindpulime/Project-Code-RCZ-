package com.inetpsa.rcz.domain.model.payload;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.google.common.collect.ImmutableMap;
import com.inetpsa.rcz.domain.model.action.ActionService;
import com.inetpsa.rcz.domain.model.action.ActionType;
import com.inetpsa.rcz.domain.model.enums.ResponseStatus;

import java.util.Map;

public class ResponseStatusResolver {

    private static final int OK = 0;

    private static final int KO = 1;

    private static final int UNKNOWN_OBJECT = 2;

    private static final int OBJECT_ALREADY_EXISTS = 3;

    private static final int MALFORMED_OBJECT = 4;

    private static final int UNKNOWN_ATTRIBUTE = 5;

    private static final int BAD_VALUE = 6;

    private static final int UNSUPPORTED_OPERATION = 7;

    private static final int PERMISSION_DENIED = 8;

    private static final int BAD_STATE = 9;

    private static final int OUT_OF_MEMORY = 10;

    private static final int STATUS_OUTDATED = 11;

    private static final int STATUS_UNEXPECTED_PAYLOAD = 12;


    public static final Map<Integer, ResponseStatus> BTA_RESPONSE_STATUS_RESOLVER = initBtaResponseStatusResolver();

    public static final Map<ResponseStatus, ResponseStatus> CLIENT_RESPONSE_STATUS_RESOLVER = initClientResponseStatusResolver();

    private static Map<ResponseStatus, ResponseStatus> initClientResponseStatusResolver() {
        return ImmutableMap.<ResponseStatus, ResponseStatus>builder().put(ResponseStatus.STATUS_OK, ResponseStatus.STATUS_OK)
                .put(ResponseStatus.STATUS_OK_WARNING, ResponseStatus.STATUS_OK_WARNING)
                .put(ResponseStatus.PARTNER_NOT_FOUND, ResponseStatus.AUTHORIZATION_DENIED)
                .put(ResponseStatus.PARTNER_INACTIVE, ResponseStatus.AUTHORIZATION_DENIED)
                .put(ResponseStatus.SERVICE_NOT_FOUND, ResponseStatus.TECHNICAL_ERROR)
                .put(ResponseStatus.SERVICE_INACTIVE, ResponseStatus.TECHNICAL_ERROR)
                .put(ResponseStatus.RESOURCE_NOT_FOUND, ResponseStatus.TECHNICAL_ERROR)
                .put(ResponseStatus.RESOURCE_SERVICE_NOT_FOUND, ResponseStatus.TECHNICAL_ERROR)
                .put(ResponseStatus.BAD_REQUEST, ResponseStatus.TECHNICAL_ERROR)
                .put(ResponseStatus.FORMAT_ERROR, ResponseStatus.TECHNICAL_ERROR)
                .put(ResponseStatus.MISSING_CORRELATION_ID, ResponseStatus.TECHNICAL_ERROR)
                .put(ResponseStatus.REQUEST_ERROR, ResponseStatus.TECHNICAL_ERROR)
                .put(ResponseStatus.VEHICLE_CONNECTION_TIMEOUT, ResponseStatus.VEHICLE_CONNECTION_TIMEOUT)
                .put(ResponseStatus.VEHICLE_NOT_FOUND, ResponseStatus.TECHNICAL_ERROR)
                .put(ResponseStatus.VEHICLE_VALIDATION_ERROR, ResponseStatus.TECHNICAL_ERROR)
                .put(ResponseStatus.VEHICLE_REQUEST_ERROR, ResponseStatus.TECHNICAL_ERROR)
                .put(ResponseStatus.AUTHORIZATION_DENIED, ResponseStatus.AUTHORIZATION_DENIED)
                .put(ResponseStatus.RIGHTS_ERROR_VES, ResponseStatus.RIGHTS_ERROR_VES)
                .put(ResponseStatus.RIGHTS_ERROR_STOLEN, ResponseStatus.AUTHORIZATION_DENIED)
                .put(ResponseStatus.RIGHTS_ERROR_PRIVACY, ResponseStatus.RIGHTS_ERROR_PRIVACY)
                .put(ResponseStatus.RIGHTS_ERROR_BATTERY, ResponseStatus.RIGHTS_ERROR_BATTERY)
                .put(ResponseStatus.TECHNICAL_ERROR, ResponseStatus.TECHNICAL_ERROR)
                .put(ResponseStatus.REQUESTS_QUOTA_EXCEEDED, ResponseStatus.REQUESTS_QUOTA_EXCEEDED)
                .put(ResponseStatus.DUPLICATE, ResponseStatus.DUPLICATE)
                .put(ResponseStatus.HORN_QUOTA_EXCEEDED, ResponseStatus.HORN_QUOTA_EXCEEDED)
                .put(ResponseStatus.LIGHTS_QUOTA_EXCEEDED, ResponseStatus.LIGHTS_QUOTA_EXCEEDED)
                .build();
    }

    @JsonIgnore
    private static Map<Integer, ResponseStatus> initBtaResponseStatusResolver() {
        return ImmutableMap.<Integer, ResponseStatus>builder().put(OK, ResponseStatus.STATUS_OK)
                .put(KO, ResponseStatus.TECHNICAL_ERROR)
                .put(UNKNOWN_OBJECT, ResponseStatus.FORMAT_ERROR)
                .put(OBJECT_ALREADY_EXISTS, ResponseStatus.DUPLICATE)
                .put(MALFORMED_OBJECT, ResponseStatus.FORMAT_ERROR)
                .put(UNKNOWN_ATTRIBUTE, ResponseStatus.FORMAT_ERROR)
                .put(BAD_VALUE, ResponseStatus.FORMAT_ERROR)
                .put(UNSUPPORTED_OPERATION, ResponseStatus.SERVICE_NOT_FOUND)
                .put(PERMISSION_DENIED, ResponseStatus.AUTHORIZATION_DENIED)
                .put(BAD_STATE, ResponseStatus.RIGHTS_ERRORS)
                .put(OUT_OF_MEMORY, ResponseStatus.TECHNICAL_ERROR)
                .put(STATUS_OUTDATED, ResponseStatus.TECHNICAL_ERROR)
                .put(STATUS_UNEXPECTED_PAYLOAD, ResponseStatus.TECHNICAL_ERROR).build();
    }

    public static ResponseStatus getBTAResponseStatus(Integer btaReturnCode) {
        ResponseStatus responseStatus = BTA_RESPONSE_STATUS_RESOLVER.get(btaReturnCode);
        if (btaReturnCode == null || responseStatus == null) {
            return ResponseStatus.TECHNICAL_ERROR;
        }
        return responseStatus;

    }

    public static ResponseStatus getBTAResponseStatus(Integer btaReturnCode, ActionService actionService) {
        if(btaReturnCode == null){
            return ResponseStatus.TECHNICAL_ERROR;
        }
        if(BAD_STATE == btaReturnCode && ActionService.STOLEN.equals(actionService)){
            return ResponseStatus.RIGHTS_ERROR_STOLEN;
        }
        ResponseStatus responseStatus = BTA_RESPONSE_STATUS_RESOLVER.get(btaReturnCode);
        if (responseStatus == null) {
            responseStatus = getClientResponseStatus(ResponseStatus.fromValue(String.valueOf(btaReturnCode)));
        }
        return responseStatus;

    }
    public static ResponseStatus getClientResponseStatus(ResponseStatus responseStatus) {
        if(responseStatus == null){
            return ResponseStatus.TECHNICAL_ERROR;
        }
        ResponseStatus responseStatusClient = CLIENT_RESPONSE_STATUS_RESOLVER.get(responseStatus);
        if (responseStatusClient == null) {
            return ResponseStatus.TECHNICAL_ERROR;
        }
        return responseStatus;

    }
}
