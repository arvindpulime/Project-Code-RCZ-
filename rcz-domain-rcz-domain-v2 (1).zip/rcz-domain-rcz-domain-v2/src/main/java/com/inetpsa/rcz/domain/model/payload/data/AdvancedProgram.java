package com.inetpsa.rcz.domain.model.payload.data;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class AdvancedProgram extends Program {

    public static final int ENABLED = 1;
    public static final int DISABLED = 0;


    @JsonProperty("on")
    private Integer on;

    @JsonProperty("day")
    private Integer[] day;

    public Integer getOn() {
        return on;
    }

    public void setOn(Integer on) {
        this.on = on;
    }

    public Integer[] getDay() {
        return day;
    }

    public void setDay(Integer[] day) {
        this.day = day;
    }
}
