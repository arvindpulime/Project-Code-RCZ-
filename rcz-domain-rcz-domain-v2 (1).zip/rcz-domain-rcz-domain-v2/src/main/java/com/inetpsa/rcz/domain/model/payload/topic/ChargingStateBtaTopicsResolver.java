package com.inetpsa.rcz.domain.model.payload.topic;

import com.inetpsa.rcz.domain.model.payload.data.VehicleChargingState;

public class ChargingStateBtaTopicsResolver implements BtaTopicsResolver<VehicleChargingState> {
}
