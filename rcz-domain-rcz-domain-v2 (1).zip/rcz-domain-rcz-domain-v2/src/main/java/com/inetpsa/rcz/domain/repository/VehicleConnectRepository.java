package com.inetpsa.rcz.domain.repository;

import com.inetpsa.rcz.domain.model.vehicle.VehicleConnect;
import org.seedstack.business.domain.AggregateNotFoundException;
import org.seedstack.business.domain.Repository;

public interface VehicleConnectRepository extends Repository<VehicleConnect, String> {
    VehicleConnect merge(VehicleConnect aggregate) throws AggregateNotFoundException;
}
