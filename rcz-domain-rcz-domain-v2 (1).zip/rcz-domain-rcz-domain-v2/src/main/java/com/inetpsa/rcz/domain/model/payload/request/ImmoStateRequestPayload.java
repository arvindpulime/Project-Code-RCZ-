package com.inetpsa.rcz.domain.model.payload.request;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.inetpsa.rcz.domain.model.enums.SevState;
import com.inetpsa.rcz.domain.model.payload.data.Data;
import com.inetpsa.rcz.infrastructure.jackson.deserializer.DataJsonDeserializer;
import com.inetpsa.rcz.infrastructure.jackson.serializer.DataJsonSerializer;
import com.inetpsa.rcz.infrastructure.jackson.serializer.NumericBooleanSerializer;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.util.Date;

import static com.inetpsa.rcz.domain.model.payload.ValidationPattern.PATTERN_DATE;

/**
 * Object holding published data for an immobilization state from the vehicle.
 *
 * @author tuan.docao@ext.mpsa.com
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ImmoStateRequestPayload {

    @NotNull
    @JsonProperty("req_id")
    private String requestId;

    @NotNull
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = PATTERN_DATE)
    @JsonProperty("date")
    private Date date;

    @JsonSerialize(using = NumericBooleanSerializer.class)
    @JsonProperty("immo_state")
    private Boolean immoState;

    @JsonSerialize(using = DataJsonSerializer.class)
    @JsonDeserialize(using = DataJsonDeserializer.class)
    @JsonProperty("location")
    private Data location;

    @Min(0) @Max(3)
    @JsonProperty("sev_state")
    private Integer sevStateValue;

    public Integer getSevStateValue() {
        return sevStateValue;
    }

    public void setSevStateValue(Integer sevStateValue) {
        this.sevStateValue = sevStateValue;
    }

    @JsonIgnore
    public SevState getSevState() {
        return SevState.fromIntValue(sevStateValue);
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Boolean getImmoState() {
        return immoState;
    }

    public void setImmoState(Boolean immoState) {
        this.immoState = immoState;
    }

    public Data getLocation() {
        return location;
    }

    public void setLocation(Data location) {
        this.location = location;
    }

}
