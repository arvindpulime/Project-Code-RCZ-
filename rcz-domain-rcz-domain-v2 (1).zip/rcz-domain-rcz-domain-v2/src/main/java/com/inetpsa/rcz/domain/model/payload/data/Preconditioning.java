package com.inetpsa.rcz.domain.model.payload.data;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import static com.inetpsa.rcz.domain.model.payload.ValidationPattern.PATTERN_PRECONDITIONING;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Preconditioning {

    public static final String DEACTIVATE = "deactivate";
    public static final String ACTIVATE = "activate";
    @NotNull
    @JsonProperty("programs")
    private Programs programs;

    @NotNull
    @Pattern(regexp = PATTERN_PRECONDITIONING)
    @JsonProperty("asap")
    private String asap;

    public Preconditioning(Programs programs, String asap) {
        this.programs = programs;
        this.asap = asap;
    }

    public Preconditioning() {
    }

    public Programs getPrograms() {
        return programs;
    }

    public void setPrograms(Programs programs) {
        this.programs = programs;
    }

    public String getAsap() {
        return asap;
    }

    public void setAsap(String asap) {
        this.asap = asap;
    }
}
