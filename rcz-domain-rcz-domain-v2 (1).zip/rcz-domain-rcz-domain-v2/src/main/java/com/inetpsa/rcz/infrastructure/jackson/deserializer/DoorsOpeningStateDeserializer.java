package com.inetpsa.rcz.infrastructure.jackson.deserializer;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.inetpsa.rcz.domain.model.payload.data.DoorsOpeningState;

import java.io.IOException;

/**
 * Serializer used to convert Boolean to numeric 0/1
 */
public class DoorsOpeningStateDeserializer extends JsonDeserializer<DoorsOpeningState> {

    @Override
    public DoorsOpeningState deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
        Boolean[] openingStateArray = p.readValueAs(Boolean[].class);
        return new DoorsOpeningState(openingStateArray);
    }
}