package com.inetpsa.rcz.domain.model.enums;

public enum PrivacyState {

    NOT_PRIVATE,
    LOCALISATION_PRIVATE,
    FULL_PRIVATE;

    public static PrivacyState fromIntValue(Integer value) {
        if(value == null){
            return null;
        }
        for (PrivacyState privacy : PrivacyState.values()) {
            if (privacy.ordinal() == value) {
                return privacy;
            }
        }
        throw new IllegalArgumentException("Privacy must be between 0 and 2 : " + value);
    }
}
