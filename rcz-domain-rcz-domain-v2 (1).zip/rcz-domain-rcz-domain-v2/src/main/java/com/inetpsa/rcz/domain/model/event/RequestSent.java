package com.inetpsa.rcz.domain.model.event;

import com.inetpsa.rcz.domain.model.exchange.Exchange;

public class RequestSent extends AbstractExchangeEvent {

    public RequestSent(Exchange exchange) {
        super(exchange);
    }
}
