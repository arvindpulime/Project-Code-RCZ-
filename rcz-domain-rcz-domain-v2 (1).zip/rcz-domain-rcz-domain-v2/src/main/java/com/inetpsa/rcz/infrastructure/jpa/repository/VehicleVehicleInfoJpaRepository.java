package com.inetpsa.rcz.infrastructure.jpa.repository;

import com.inetpsa.rcz.domain.model.vehicle.VehicleVehicleInfo;
import com.inetpsa.rcz.domain.repository.VehicleVehicleInfoRepository;
import org.seedstack.business.domain.AggregateNotFoundException;
import org.seedstack.jpa.BaseJpaRepository;

public class VehicleVehicleInfoJpaRepository extends BaseJpaRepository<VehicleVehicleInfo, String> implements VehicleVehicleInfoRepository {
    @Override
    public VehicleVehicleInfo merge(VehicleVehicleInfo aggregate) throws AggregateNotFoundException {
        return getEntityManager().merge(aggregate);
    }
}
