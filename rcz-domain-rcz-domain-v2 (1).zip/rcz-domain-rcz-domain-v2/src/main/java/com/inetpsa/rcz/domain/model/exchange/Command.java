/*
 * Creation : 6 juin 2016
 */
package com.inetpsa.rcz.domain.model.exchange;

import org.seedstack.business.domain.BaseValueObject;

import javax.persistence.Embeddable;
import java.util.Date;

@Embeddable
public class Command extends BaseValueObject {

    private Date deliveryDate;
    private String rawJson;

    public Command(Date deliveryDate, String rawJson) {
        this.deliveryDate = deliveryDate;
        this.rawJson = rawJson;
    }

    public Command() {
    }

    public Date getDeliveryDate() {
        return deliveryDate;
    }

    public void setDeliveryDate(Date deliveryDate) {
        this.deliveryDate = deliveryDate;
    }

    public String getRawJson() {
        return rawJson;
    }

    public void setRawJson(String rawJson) {
        this.rawJson = rawJson;
    }
}
