package com.inetpsa.rcz.domain.model.enums;

/**
 * @author tuan.docao@ext.mpsa.com
 */
public enum CallerType {

    CLIENT, PARTNER, VEHICLE;

    public String code() {
        switch (this) {
            case CLIENT:
                return "cid";
            case PARTNER:
                return "uid";
            case VEHICLE:
                return "uin";
            default:
                return null;
        }
    }

}
