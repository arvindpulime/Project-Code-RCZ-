package com.inetpsa.rcz.domain.model.payload.exception;

public class AckTopicException extends RuntimeException {
    public AckTopicException() {
    }

    public AckTopicException(String message) {
        super(message);
    }

    public AckTopicException(String message, Throwable cause) {
        super(message, cause);
    }

    public AckTopicException(Throwable cause) {
        super(cause);
    }

    public AckTopicException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
