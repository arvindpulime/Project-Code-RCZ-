package com.inetpsa.rcz.domain.model.monitoring;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.experimental.Accessors;

import java.util.Date;

@Data
@Accessors(chain = true)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AppInfo {

    private String name;

    private String description;

    private String version;

    private String buildDate;

    private Status status = Status.UP;

    private String instance;

    private String baseURL;

    private Date upDate = new Date();

    public Status getStatus() {
        Date now = new Date();
        if (now.getTime() - upDate.getTime() > 61000) {
            return Status.DOWN;
        }
        return status;
    }
}