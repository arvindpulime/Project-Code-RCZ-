package com.inetpsa.rcz.domain.model.payload.data;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ServiceState {

    @Min(0)
    @Max(1)
    @NotNull
    @JsonProperty("state")
    private Integer state;
    @JsonProperty("req_id")
    private String requestId;

    public Integer getState() {
        return state;
    }

    public ServiceState(String requestId) {
        this.requestId = requestId;
    }

    public ServiceState() {
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public String getRequestId() {
        return requestId;
    }

    public ServiceState setRequestId(String requestId) {
        this.requestId = requestId;
        return this;
    }
}
