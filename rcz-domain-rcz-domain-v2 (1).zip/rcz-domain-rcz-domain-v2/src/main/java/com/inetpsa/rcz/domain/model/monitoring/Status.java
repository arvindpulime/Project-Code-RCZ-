package com.inetpsa.rcz.domain.model.monitoring;

enum Status {
    UP, DOWN
}