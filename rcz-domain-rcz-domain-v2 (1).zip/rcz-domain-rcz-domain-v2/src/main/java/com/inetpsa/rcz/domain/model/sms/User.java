package com.inetpsa.rcz.domain.model.sms;

import org.seedstack.business.domain.BaseValueObject;

import javax.persistence.Embeddable;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;

@Embeddable
public class User extends BaseValueObject {

    @Enumerated(EnumType.STRING)
    private UserType type;

    private String value;

    public User(UserType type, String value) {
        this.type = type;
        this.value = value;
    }

    User() {
    }

    public UserType getType() {
        return type;
    }

    public void setType(UserType type) {
        this.type = type;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
