/*
 * Creation : 6 juin 2016
 */
package com.inetpsa.rcz.domain.model.shared;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.lang3.StringUtils;
import org.seedstack.business.domain.BaseValueObject;

import javax.persistence.Basic;
import javax.persistence.Embeddable;
import javax.persistence.FetchType;
import javax.persistence.Lob;
import java.util.Date;

import static com.inetpsa.rcz.domain.model.payload.ValidationPattern.PATTERN_DATE_FRONT;

@Embeddable
public class Payload extends BaseValueObject {

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = PATTERN_DATE_FRONT)
    private Date receivedDate = new Date();

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = PATTERN_DATE_FRONT)
    private Date sentDate = new Date();

    @Basic(fetch = FetchType.LAZY)
    @Lob
    private String rawJson;

    public Payload(Date receivedDate, String request) {
        this.receivedDate = receivedDate;
        if (StringUtils.isNotBlank(request)) {
            this.rawJson = request.replaceAll("\u0000", "");
        } else {
            this.rawJson = request;
        }
    }

    public Payload(Date receivedDate, Date sentDate, String rawJson) {
        this.receivedDate = receivedDate;
        this.sentDate = sentDate;
        this.rawJson = rawJson.replaceAll("\u0000", "");
    }

    public Payload() {
    }

    public Date getReceivedDate() {
        return receivedDate;
    }

    public void setReceivedDate(Date receivedDate) {
        this.receivedDate = receivedDate;
    }

    public String getRawJson() {
        return rawJson;
    }

    public void setRawJson(String rawJson) {
        if (StringUtils.isNotBlank(rawJson)) {
            this.rawJson = rawJson.replaceAll("\u0000", "");
        } else {
            this.rawJson = rawJson;
        }
    }

    public Date getSentDate() {
        return sentDate;
    }

    public Payload setSentDate(Date sentDate) {
        this.sentDate = sentDate;
        return this;
    }

    @Override
    public String toString() {
        return "Payload{" +
                "receivedDate=" + receivedDate +
                ", sentDate=" + sentDate +
                ", rawJson='" + rawJson + '\'' +
                '}';
    }
}
