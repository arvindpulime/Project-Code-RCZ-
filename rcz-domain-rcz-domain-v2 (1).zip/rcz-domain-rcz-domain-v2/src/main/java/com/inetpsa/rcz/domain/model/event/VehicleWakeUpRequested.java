package com.inetpsa.rcz.domain.model.event;

import com.inetpsa.rcz.domain.model.exchange.Exchange;

public class VehicleWakeUpRequested extends AbstractExchangeEvent {
    public VehicleWakeUpRequested(Exchange exchange) {
        super(exchange);
    }
}
