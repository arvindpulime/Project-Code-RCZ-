package com.inetpsa.rcz.domain.services;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.inetpsa.rcz.infrastructure.hibernate.ValidationMessageInterpolator;
import org.apache.commons.lang3.StringUtils;
import org.seedstack.seed.Bind;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.validation.*;
import java.lang.reflect.Field;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Bind
public class PayloadValidationService {

    public static final String VALIDATION_PARSING_ERROR = "Validation parsing error";
    public static final String DEFAULT_LOCALE = "en";

    @Inject
    private ValidatorFactory validatorFactory;

    @Logging
    private Logger logger;

    private static final Pattern index = Pattern.compile(".*\\[(.*?)\\]");


    public <T> void validateRequest(T payload) throws ValidationException {
        validateRequest(payload, DEFAULT_LOCALE);
    }

    public <T> void validateRequest(T payload, String locale) throws ValidationException {
        Set<ConstraintViolation<T>> constraintViolations = getLocalizedValidator(new Locale(locale)).validate(payload);
        if (constraintViolations != null && !constraintViolations.isEmpty()) {
            throw new ValidationException(getMessage(constraintViolations));
        }
    }

    /**
     * Enforces the locale passed to the message interpolator
     *
     * @param locale the locale to use
     * @return a validator with localized messages
     */
    private Validator getLocalizedValidator(Locale locale) {
        MessageInterpolator interpolator = new ValidationMessageInterpolator(validatorFactory.getMessageInterpolator(), locale);
        return validatorFactory.usingContext().messageInterpolator(interpolator).getValidator();
    }

    protected <T> String getMessage(Collection<ConstraintViolation<T>> constraintViolations) {
        StringBuilder stringBuilder = new StringBuilder();
        for (ConstraintViolation<T> constraintViolation :
                constraintViolations) {
            String propertyPath = constraintViolation.getPropertyPath().toString();
            if (StringUtils.isBlank(propertyPath)) {
                stringBuilder.append("[").append(constraintViolation.getMessage()).append("] ");
            } else {
                stringBuilder.append("[").append(getParameterJsonName(propertyPath.split("\\."), constraintViolation.getRootBean()))
                        .append(" ").append(constraintViolation.getMessage())
                        .append(" : (")
                        .append(constraintViolation.getInvalidValue()).append(")").append("] ");
            }

        }
        return stringBuilder.toString();
    }

    private <T> String getParameterJsonName(String[] parametersName, T rootBean) {
        return getField(rootBean, parametersName);

    }

    // TODO : check with Redouane
    public Field findFieldInClassHierarchy(Class<?> clazz, String fieldName) {
        Class<?> current = clazz;
        do {
            try {
                return current.getDeclaredField(fieldName);
            } catch (Exception e) {
            }
        } while ((current = current.getSuperclass()) != null);
        return null;
    }

    private String getField(Object object, String[] parametersName) {
        try {
            Field field = findFieldInClassHierarchy(object.getClass(), parametersName[0].split("\\[")[0]);
            if (parametersName.length == 1) {
                return field.getAnnotation(JsonProperty.class).value();
            }

            field.setAccessible(true);
            if (object.getClass().isArray()) {
                object = Arrays.asList(object);
            }

            if (Collection.class.isAssignableFrom(field.get(object).getClass())) {

                return getField(((List) field.get(object)).get(getIndex(parametersName[0])), Arrays.copyOfRange(parametersName, 1, parametersName.length));
            }
            return getField(field.get(object), Arrays.copyOfRange(parametersName, 1, parametersName.length));

        } catch (IllegalAccessException e) {
            throw new ValidationException(VALIDATION_PARSING_ERROR, e);
        }

    }

    private int getIndex(String parametersName) {
        Matcher matcher = index.matcher(parametersName);
        if (matcher.find()) {
            return Integer.valueOf(matcher.group(1));
        } else {
            throw new ValidationException(VALIDATION_PARSING_ERROR);
        }
    }
}
