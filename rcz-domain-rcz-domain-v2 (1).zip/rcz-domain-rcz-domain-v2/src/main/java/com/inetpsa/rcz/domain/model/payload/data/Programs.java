package com.inetpsa.rcz.domain.model.payload.data;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.validation.constraints.NotNull;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Programs {


    @NotNull
    @JsonProperty("program1")
    private AdvancedProgram program1;

    @NotNull
    @JsonProperty("program2")
    private AdvancedProgram program2;

    @NotNull
    @JsonProperty("program3")
    private AdvancedProgram program3;

    @NotNull
    @JsonProperty("program4")
    private AdvancedProgram program4;

    public AdvancedProgram getProgram1() {
        return program1;
    }

    public void setProgram1(AdvancedProgram program1) {
        this.program1 = program1;
    }

    public AdvancedProgram getProgram2() {
        return program2;
    }

    public void setProgram2(AdvancedProgram program2) {
        this.program2 = program2;
    }

    public AdvancedProgram getProgram3() {
        return program3;
    }

    public void setProgram3(AdvancedProgram program3) {
        this.program3 = program3;
    }

    public AdvancedProgram getProgram4() {
        return program4;
    }

    public void setProgram4(AdvancedProgram program4) {
        this.program4 = program4;
    }
}
