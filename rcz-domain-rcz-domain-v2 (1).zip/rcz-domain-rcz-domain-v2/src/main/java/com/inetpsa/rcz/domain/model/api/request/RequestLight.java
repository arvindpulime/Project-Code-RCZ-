package com.inetpsa.rcz.domain.model.api.request;

import com.inetpsa.rcz.domain.model.action.Action;
import com.inetpsa.rcz.domain.model.enums.CallerType;
import com.inetpsa.rcz.domain.model.shared.PayloadDate;
import com.inetpsa.rcz.infrastructure.data.CustomUUIDGenerator;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;

import javax.persistence.*;

@Entity
@Table(name = "RCZQTREQUEST")
public class RequestLight extends BaseAggregateRoot<String> {

    public static final String ACTION_TYPE = "action.actionType";
    public static final String ACTION_SERVICE = "action.actionService";

    @Id
    @Identity(generator = CustomUUIDGenerator.class)
    private String id;
    @Enumerated(EnumType.STRING)
    private CallerType callerType;
    private String callerId;
    private String vin;
    @Embedded
    private Action action;
    @Embedded
    @AttributeOverride(column = @Column(name = "request"), name = "rawJson")
    private PayloadDate request;
    @Enumerated(EnumType.STRING)
    RequestStatus status = RequestStatus.PENDING;
    private String customerId;

    RequestLight() {
    }

    @Override
    public String getId() {
        return id;
    }

    public RequestLight setId(String id) {
        this.id = id;
        return this;
    }

    public CallerType getCallerType() {
        return callerType;
    }

    public RequestLight setCallerType(CallerType callerType) {
        this.callerType = callerType;
        return this;
    }

    public String getCallerId() {
        return callerId;
    }

    public RequestLight setCallerId(String callerId) {
        this.callerId = callerId;
        return this;
    }

    public String getVin() {
        return vin;
    }

    public RequestLight setVin(String vin) {
        this.vin = vin;
        return this;
    }

    public Action getAction() {
        return action;
    }

    public RequestLight setAction(Action action) {
        this.action = action;
        return this;
    }

    public PayloadDate getRequest() {
        return request;


    }

    public RequestLight setRequest(PayloadDate request) {
        this.request = request;
        return this;
    }

    public RequestStatus getStatus() {
        return status;
    }

    public RequestLight setStatus(RequestStatus status) {
        this.status = status;
        return this;
    }

    public String getCustomerId() {
        return customerId;
    }

    public RequestLight setCustomerId(String customerId) {
        this.customerId = customerId;
        return this;
    }
}