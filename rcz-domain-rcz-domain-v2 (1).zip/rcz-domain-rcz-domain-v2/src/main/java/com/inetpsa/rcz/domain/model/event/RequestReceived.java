package com.inetpsa.rcz.domain.model.event;

import com.inetpsa.rcz.domain.model.payload.topic.Topic;

public class RequestReceived extends AbstractRequestReceivedEvent {

    public RequestReceived(Topic topic, String message) {
        super(topic, message);
    }
}
