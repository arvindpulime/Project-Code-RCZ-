package com.inetpsa.rcz.domain.model.payload.data;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.validation.constraints.NotNull;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ChargingBTA {

    public static final int DELAYED = 1;
    public static final int IMMEDIATE = 0;

    @NotNull
    @JsonProperty("program")
    private Program program;

    @NotNull
    @JsonProperty("type")
    private Integer type;

    public ChargingBTA(Program program, Integer type) {
        this.program = program;
        this.type = type;
    }

    public ChargingBTA() {
    }

    public Program getProgram() {
        return program;
    }

    public void setProgram(Program program) {
        this.program = program;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }
}
