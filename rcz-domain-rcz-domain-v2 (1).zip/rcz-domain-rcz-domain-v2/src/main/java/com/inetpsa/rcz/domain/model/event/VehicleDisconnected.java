package com.inetpsa.rcz.domain.model.event;

public class VehicleDisconnected extends AbstractVehicleEvent {
}
