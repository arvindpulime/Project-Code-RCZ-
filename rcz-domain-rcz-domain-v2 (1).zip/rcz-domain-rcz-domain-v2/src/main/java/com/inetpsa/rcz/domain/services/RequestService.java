package com.inetpsa.rcz.domain.services;

import com.inetpsa.rcz.domain.model.api.request.Request;
import org.seedstack.business.Service;
import org.seedstack.business.specification.Specification;

import java.util.Optional;
import java.util.stream.Stream;

@Service
public interface RequestService {

    Optional<Request> get(String id);

    Stream<Request> get(Specification<Request> specification);

    void save(Request request);
}
