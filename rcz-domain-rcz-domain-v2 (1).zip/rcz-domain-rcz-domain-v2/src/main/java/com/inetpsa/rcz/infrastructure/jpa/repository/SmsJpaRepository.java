package com.inetpsa.rcz.infrastructure.jpa.repository;

import com.inetpsa.rcz.domain.model.sms.Sms;
import com.inetpsa.rcz.domain.repository.SmsRepository;
import org.seedstack.business.domain.AggregateExistsException;
import org.seedstack.business.domain.AggregateNotFoundException;
import org.seedstack.jpa.BaseJpaRepository;

public class SmsJpaRepository extends BaseJpaRepository<Sms, String> implements SmsRepository {
    @Override
    public Sms merge(Sms aggregate) throws AggregateNotFoundException {
        try {
            Sms merge = getEntityManager().merge(aggregate);
            return merge;
        } catch (Exception e) {
            throw new AggregateExistsException(e);
        }
    }

    @Override
    public void add(Sms aggregate) throws AggregateExistsException {
        super.add(aggregate);
    }
}
