package com.inetpsa.rcz.domain.model.enums;

public enum ElectricalNetworkStatus {

    INACTIVE_TRACTION_NOMINAL,
    INACTIVE_TRACTION_DEGRADED,
    INACTIVE_TRACTION_ONLY_START_AVAILABLE,
    STARTED,
    RESTARTED,
    ACTIVE_TRACTION_NOMINAL,
    ACTIVE_TRACTION_DEGRADED,
    ACTIVE_TRACTION_SECURED;

    public static ElectricalNetworkStatus fromIntValue(Integer value) {
        if(value == null){
            return null;
        }
        for (ElectricalNetworkStatus electricalNetworkStatus: ElectricalNetworkStatus.values()) {
            if (electricalNetworkStatus.ordinal() == value) {
                return electricalNetworkStatus;
            }
        }
        throw new IllegalArgumentException("Privacy must be between 0 and 7 : " + value);
    }
}
