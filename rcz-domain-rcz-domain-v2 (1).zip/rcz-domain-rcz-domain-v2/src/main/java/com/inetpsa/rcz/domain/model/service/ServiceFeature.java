package com.inetpsa.rcz.domain.model.service;

import com.inetpsa.rcz.domain.model.action.Action;
import org.hibernate.annotations.Type;
import org.seedstack.business.domain.BaseAggregateRoot;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "RCZQTSERVICEFEATURE")
public class ServiceFeature extends BaseAggregateRoot<String> implements Serializable {


    @Id
    private String code;

    private String shortLabel;

    private String label;

    private Date startDate;

    private Date endDate;

    @Type(type = "org.hibernate.type.NumericBooleanType")
    private Boolean suspended;

    @Type(type = "org.hibernate.type.NumericBooleanType")
    private Boolean deleted;

    @ElementCollection
    @CollectionTable(name = "RCZQTACTIONS", joinColumns = @JoinColumn(name = "code"))
    private Set<Action> actions;

    ServiceFeature() {
    }

    @Override
    public String getId() {
        return code;
    }

    ServiceFeature(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getShortLabel() {
        return shortLabel;
    }

    public void setShortLabel(String shortLabel) {
        this.shortLabel = shortLabel;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Boolean getSuspended() {
        return suspended;
    }

    public ServiceFeature setSuspended(Boolean suspended) {
        this.suspended = suspended;
        return this;
    }

    public Boolean getDeleted() {
        return deleted;
    }

    public ServiceFeature setDeleted(Boolean deleted) {
        this.deleted = deleted;
        return this;
    }

    public Set<Action> getActions() {
        return actions;
    }

    public void setActions(Set<Action> actions) {
        this.actions = actions;
    }

    public void addAction(Action action) {
        if (actions == null) {
            actions = new HashSet<>();
        }
        actions.add(action);
    }
}
