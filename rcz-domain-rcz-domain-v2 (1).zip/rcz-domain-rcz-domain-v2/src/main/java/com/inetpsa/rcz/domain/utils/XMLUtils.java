package com.inetpsa.rcz.domain.utils;

import javax.xml.bind.*;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;

/**
 * @author tuan.docao@ext.mpsa.com
 */
public final class XMLUtils {

    private XMLUtils() {
    }

    public static <R> String marshal(R xmlRoot) throws JAXBException {

        if (xmlRoot != null) {
            JAXBContext jaxbContext = JAXBContext.newInstance(xmlRoot.getClass());
            Marshaller marshaller = jaxbContext.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
            marshaller.setProperty(Marshaller.JAXB_ENCODING, StandardCharsets.UTF_8.displayName());
            StringWriter sw = new StringWriter();
            marshaller.marshal(xmlRoot, sw);
            return sw.toString();
        }

        return "";
    }

    @SuppressWarnings("unchecked")
    public static <R> R unmarshal(String str, Class<R> jaxbClass) throws JAXBException {
        R xmlRoot = null;

        if (str != null) {
            JAXBContext jaxbContext = JAXBContext.newInstance(jaxbClass);
            Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
            xmlRoot = (R) JAXBIntrospector.getValue(unmarshaller.unmarshal(new StringReader(str)));
        }

        return xmlRoot;
    }

}
