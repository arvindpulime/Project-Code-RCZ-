package com.inetpsa.rcz.domain.model.sms;

import org.seedstack.business.domain.BaseValueObject;

import javax.persistence.*;

@Embeddable
public class Message extends BaseValueObject {

    @Embedded
    @AttributeOverrides({
            @AttributeOverride(column = @Column(name = "toType"), name = "type"),
            @AttributeOverride(column = @Column(name = "toValue"), name = "value")
    })
    private User to;

    private String format;

    private String text;

    public Message(User to, String format, String text) {
        this.to = to;
        this.format = format;
        this.text = text;
    }

    public Message(User to, String text) {
        this.to = to;
        this.text = text;
    }

    public Message() {
    }

    public User getTo() {
        return to;
    }

    public void setTo(User to) {
        this.to = to;
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
