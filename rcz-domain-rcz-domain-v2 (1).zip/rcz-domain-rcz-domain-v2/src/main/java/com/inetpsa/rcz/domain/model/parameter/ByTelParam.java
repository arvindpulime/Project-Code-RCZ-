package com.inetpsa.rcz.domain.model.parameter;


import lombok.Data;
import lombok.experimental.Accessors;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Data
@Embeddable
@Accessors(chain = true)
public class ByTelParam implements Serializable {

    @Column(name = "bytelSmsProtocolVersion")
    private String protocolVersion = "1.00";

    @Column(name = "bytelSmsAdm")
    private String adm = "PSA-PH3_ADM";

    @Column(name = "bytelSmsIdOffer")
    private String idOffer = "EVSKCELSC22859";

    @Column(name = "bytelSmsMessageFormat")
    private String messageFormat = "B";

    @Column(name = "bytelSmsPath")
    private String path = "/";

    @Column(name = "bytelSmsTargetType")
    private String targetType = "MSISDN";

    @Column(name = "bytelSmsUri")
    private String uri = "http://localhost:8282";

    @Column(name = "bytelSmsIcp")
    private String icp = "PSA-PH3";
}