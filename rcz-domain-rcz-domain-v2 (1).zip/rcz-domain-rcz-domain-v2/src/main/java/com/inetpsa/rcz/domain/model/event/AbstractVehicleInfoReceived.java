package com.inetpsa.rcz.domain.model.event;

import com.inetpsa.rcz.domain.model.payload.topic.Topic;

public class AbstractVehicleInfoReceived extends AbstractRequestReceivedEvent {

    String uin;
    public AbstractVehicleInfoReceived(Topic topic, String message, String uin) {
        super(topic, message);
        this.uin = uin;
    }

    public String getUin() {
        return uin;
    }
}
