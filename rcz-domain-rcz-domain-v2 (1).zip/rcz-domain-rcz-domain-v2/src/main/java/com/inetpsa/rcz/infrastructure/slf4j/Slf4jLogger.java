package com.inetpsa.rcz.infrastructure.slf4j;

import com.inetpsa.rcz.domain.model.enums.LogLevel;
import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.model.log.LogMessage;
import com.inetpsa.rcz.domain.services.LogService.AppLog;
import com.inetpsa.rcz.domain.services.impl.AbstractAppLogger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Named;

/**
 * @author tuan.docao@ext.mpsa.com
 */
@Named("slf4j-logger")
public class Slf4jLogger extends AbstractAppLogger {

    private static final Logger LOGGER = LoggerFactory.getLogger(Slf4jLogger.class);

    public AppLog key() {
        return AppLog.SLF4J;
    }

    @Override
    public void log(LogLevel logLevel, LogMessage message, Exchange exchange) {
        final String msg = toPlainText(message, exchange, true);
        switch (logLevel) {
            case ALL:
                break;
            case TRACE:
                break;
            case DEBUG:
                LOGGER.debug(msg);
                break;
            case INFO:
                LOGGER.info(msg);
                break;
            case WARN:
                LOGGER.warn(msg);
                break;
            case ERROR:
                LOGGER.error(msg);
                break;
            case FATAL:
                break;
            case OFF:
                break;
        }
    }
}
