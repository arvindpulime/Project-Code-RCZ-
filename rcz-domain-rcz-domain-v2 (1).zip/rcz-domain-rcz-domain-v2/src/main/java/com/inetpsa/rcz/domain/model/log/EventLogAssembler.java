package com.inetpsa.rcz.domain.model.log;

import com.inetpsa.rcz.domain.model.exchange.Exchange;
import com.inetpsa.rcz.domain.repository.ExchangeRepository;
import org.seedstack.business.assembler.BaseAssembler;

import javax.inject.Inject;
import java.util.Optional;

/**
 * Assembler between JSON representation and entity for application logs.
 *
 * @author tuan.docao@ext.mpsa.com
 */

public class EventLogAssembler extends BaseAssembler<Log, EventLog> {

    @Inject
    private ExchangeRepository exchangeRepository;


    @Override
    public void mergeAggregateIntoDto(Log log, EventLog eventLog) {
        eventLog.setId(log.getId());
        eventLog.setLogLevel(log.getLogLevel());
        eventLog.setLogDate(log.getLogDate());
        if (log.getMessage() != null) {
            eventLog.setMessage(log.getMessage().getMessage());
            eventLog.setData(log.getMessage().getData());
            eventLog.setTopic(log.getMessage().getTopic());
        }
        Optional<Exchange> exchange = exchangeRepository.get(log.getExchangeId());
        if (exchange.isPresent()) {
            eventLog.getContext().setExchangeId(exchange.get().getId());
            eventLog.getContext().setCallerType(exchange.get().getCallerType());
            eventLog.getContext().setCallerId(exchange.get().getCallerId());
            eventLog.getContext().setCorrelationId(exchange.get().getCorrelationId());
            eventLog.getContext().setService(exchange.get().getAction().getActionService());
            eventLog.getContext().setAction(exchange.get().getAction().getActionType());
            eventLog.getContext().setProcessStatus(exchange.get().getProcessStatus());
            eventLog.getContext().setResponseStatus(exchange.get().getResponseStatus());
        }
    }

    @Override
    public void mergeDtoIntoAggregate(EventLog eventLog, Log log) {
        log.setLogLevel(eventLog.getLogLevel());
        log.setLogDate(eventLog.getLogDate());
        LogMessage message = LogMessage.create(eventLog.getMessage()).data(eventLog.getData()).topic(eventLog.getTopic());
        log.setMessage(message);
        EventLogContext context;
        if ((context = eventLog.getContext()) != null) {
            Optional<Exchange> exchange = exchangeRepository.get(context.getExchangeId());
            exchange.ifPresent(exchange1 -> log.setExchangeId(exchange1.getId()));
        }
    }

}
