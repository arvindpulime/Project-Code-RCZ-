package com.inetpsa.rcz.domain.model.payload.response;

import com.fasterxml.jackson.annotation.*;
import com.inetpsa.rcz.domain.model.enums.ProcessStatus;

import javax.validation.constraints.Max;
import javax.validation.constraints.Pattern;
import java.util.Date;

import static com.inetpsa.rcz.domain.model.payload.ValidationPattern.*;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProcessPayload {


    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = PATTERN_DATE)
    @JsonProperty("process_date")
    private Date date;

    @JsonProperty("vin")
    @Pattern(regexp = PATTERN_VIN)
    private String vin;

    @JsonProperty("correlation_id")
    @Pattern(regexp = PATTERN_CORRELATION_ID)
    private String correlationId;

    @JsonProperty("process_code")
    @Pattern(regexp = PATTERN_RETURN_CODE)
    private String code;

    @JsonProperty("process_message")
    @Max(50)
    private String message;

    @JsonIgnore
    public ProcessStatus getProcessCode() {
        return ProcessStatus.fromValue(code);
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    public String getCorrelationId() {
        return correlationId;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
