package com.inetpsa.rcz.domain.model.sms;

import com.inetpsa.rcz.domain.model.vehicle.Provider;
import com.inetpsa.rcz.infrastructure.data.CustomUUIDGenerator;
import org.seedstack.business.domain.BaseAggregateRoot;
import org.seedstack.business.domain.Identity;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static javax.persistence.EnumType.STRING;

@Entity
@Table(name = "RCZQTSMS")
public class Sms extends BaseAggregateRoot<String> {

    public static final String ID_NAME = "id";

    @Id
    @Identity(generator = CustomUUIDGenerator.class)
    private String id;

    private String messageId;

    private String uin;

    private String icp;

    private String adm;

    private String version;

    private String idOffer;

    private Date sendingDate;

    @Enumerated(STRING)
    private Provider provider;

    @ElementCollection
    @CollectionTable(name = "RCZQTSMSMESSAGES", joinColumns = @JoinColumn(name = ID_NAME))
    private List<Message> messages;

    private String answerStatus;

    @Embedded
    private Acknowledgement acknowledgement = new Acknowledgement();

    Sms() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getMessageId() {
        return messageId;
    }

    public Sms setMessageId(String messageId) {
        this.messageId = messageId;
        return this;
    }

    public String getUin() {
        return uin;
    }

    public void setUin(String uin) {
        this.uin = uin;
    }

    public String getIcp() {
        return icp;
    }

    public void setIcp(String icp) {
        this.icp = icp;
    }

    public String getAdm() {
        return adm;
    }

    public void setAdm(String adm) {
        this.adm = adm;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getIdOffer() {
        return idOffer;
    }

    public void setIdOffer(String idOffer) {
        this.idOffer = idOffer;
    }

    public Date getSendingDate() {
        return sendingDate;
    }

    public void setSendingDate(Date sendingDate) {
        this.sendingDate = sendingDate;
    }

    public List<Message> getMessages() {
        return messages;
    }

    public void setMessages(List<Message> messages) {
        this.messages = messages;
    }

    public String getAnswerStatus() {
        return answerStatus;
    }

    public void setAnswerStatus(String answerStatus) {
        this.answerStatus = answerStatus;
    }

    public Acknowledgement getAcknowledgement() {
        return acknowledgement;
    }

    public void setAcknowledgement(Acknowledgement acknowledgement) {
        this.acknowledgement = acknowledgement;
    }

    public Provider getProvider() {
        return provider;
    }

    public void setProvider(Provider provider) {
        this.provider = provider;
    }

    public void addMessage(Message message) {
        if (messages == null) {
            messages = new ArrayList<>();
        }
        messages.add(message);
    }

}
