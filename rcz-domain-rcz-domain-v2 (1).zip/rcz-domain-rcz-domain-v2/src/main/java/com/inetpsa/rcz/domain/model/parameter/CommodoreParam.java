package com.inetpsa.rcz.domain.model.parameter;

import lombok.Data;
import lombok.experimental.Accessors;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Data
@Embeddable
@Accessors(chain = true)
public class CommodoreParam implements Serializable {

    private Boolean vehicleRequestMock = false;

    private Integer vehicleRequestMaxDuration = 10000;

    private Integer vehicleRequestNbRetry = 1;

    private Integer vehicleRequestRetryDelay = 1000;

    private String vehicleRequestPath;

    private String vehicleRequestUri;
}