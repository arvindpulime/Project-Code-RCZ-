package com.inetpsa.rcz.domain.model.event;

import com.inetpsa.rcz.domain.model.event.AbstractExchangeEvent;
import com.inetpsa.rcz.domain.model.exchange.Exchange;

public class ExchangeClosed extends AbstractExchangeEvent {
    public ExchangeClosed(Exchange exchange) {
        super(exchange);
    }
}
