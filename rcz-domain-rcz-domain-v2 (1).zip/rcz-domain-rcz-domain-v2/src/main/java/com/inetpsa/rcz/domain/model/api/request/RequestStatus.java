package com.inetpsa.rcz.domain.model.api.request;

public enum RequestStatus {
    PENDING,
    FINISH
}