/*
 * Creation : 6 juin 2016
 */
package com.inetpsa.rcz.domain.model.enums;

/**
 * Different status for an exchange.
 */
public enum ExchangeStatus {
    INITIAL, PENDING, FINISHED, ERROR
}
