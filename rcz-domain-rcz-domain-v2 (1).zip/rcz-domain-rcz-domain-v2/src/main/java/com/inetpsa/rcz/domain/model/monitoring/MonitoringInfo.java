package com.inetpsa.rcz.domain.model.monitoring;

import org.seedstack.business.domain.AggregateRoot;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Lob;
import javax.persistence.Table;
import java.util.Date;

@Entity
@Table(name = "RCZQTMONITORINGINFO")
public class MonitoringInfo implements AggregateRoot<MonitoringInfoId> {

    @EmbeddedId
    private MonitoringInfoId id;
    private Date updateDate = new Date();
    @Lob
    private String data;

    MonitoringInfo(MonitoringInfoId id) {
        this.id = id;
    }

    MonitoringInfo() {
    }

    public MonitoringInfoId getId() {
        return id;
    }

    public Date getUpdateDate() {
        return updateDate;
    }

    public MonitoringInfo setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
        return this;
    }

    public String getData() {
        return data;
    }

    public MonitoringInfo setData(String data) {
        this.data = data;
        return this;
    }
}
