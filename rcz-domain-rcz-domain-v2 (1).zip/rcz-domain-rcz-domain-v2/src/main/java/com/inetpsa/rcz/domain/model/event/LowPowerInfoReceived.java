package com.inetpsa.rcz.domain.model.event;

import com.inetpsa.rcz.domain.model.payload.topic.Topic;

public class LowPowerInfoReceived extends AbstractVehicleInfoReceived {

    public LowPowerInfoReceived(Topic topic, String message, String uin) {
        super(topic, message, uin);
    }
}
