package com.inetpsa.rcz.domain.model.event;

import com.inetpsa.rcz.domain.model.exchange.Exchange;

public class RequestDenied extends AbstractExchangeEvent {


    public RequestDenied(Exchange exchange) {
        super(exchange);
    }
}
