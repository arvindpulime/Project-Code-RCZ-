/*
 * Creation : 6 juin 2016
 */
package com.inetpsa.rcz.domain.model.exchange;

import javax.persistence.Embeddable;

import org.seedstack.business.domain.BaseValueObject;

import java.util.Date;

@Embeddable
public class Response extends BaseValueObject {

    private Date publishedDate;
    private String rawJson;

    public Response(String rawJson, Date publishedDate) {
        this.rawJson = rawJson;
        this.publishedDate = publishedDate;
    }

    public Response() {
    }

    public Date getPublishedDate() {
        return publishedDate;
    }

    public void setPublishedDate(Date publishedDate) {
        this.publishedDate = publishedDate;
    }

    public String getRawJson() {
        return rawJson;
    }

    public void setRawJson(String rawJson) {
        this.rawJson = rawJson;
    }
}
