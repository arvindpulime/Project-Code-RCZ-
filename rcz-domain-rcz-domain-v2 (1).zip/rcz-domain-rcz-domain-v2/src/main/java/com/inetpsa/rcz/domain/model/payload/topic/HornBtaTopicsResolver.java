package com.inetpsa.rcz.domain.model.payload.topic;

import com.inetpsa.rcz.domain.model.payload.data.Horn;

public class HornBtaTopicsResolver implements  BtaTopicsResolver<Horn>{
}
