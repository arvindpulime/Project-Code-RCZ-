package com.inetpsa.rcz.infrastructure.jpa.repository;

import com.inetpsa.rcz.domain.model.log.Log;
import com.inetpsa.rcz.domain.repository.LogRepository;
import org.seedstack.jpa.BaseJpaRepository;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.util.List;

/**
 * @author tuan.docao@ext.mpsa.com
 */
public class LogJpaRepository extends BaseJpaRepository<Log, String> implements LogRepository {

    @Override
    public List<Log> findByExchangeId(String exchangeId) {
        CriteriaBuilder cb = getEntityManager().getCriteriaBuilder();
        CriteriaQuery<Log> q = cb.createQuery(Log.class);
        Root<Log> l = q.from(Log.class);
        q.select(l).where(cb.equal(l.get("exchangeId"), exchangeId));
        return getEntityManager().createQuery(q).getResultList();
    }
}
