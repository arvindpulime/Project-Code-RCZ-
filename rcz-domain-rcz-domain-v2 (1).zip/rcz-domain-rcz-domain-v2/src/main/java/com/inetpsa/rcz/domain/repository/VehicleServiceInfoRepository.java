package com.inetpsa.rcz.domain.repository;

import com.inetpsa.rcz.domain.model.vehicle.VehicleServiceInfo;
import org.seedstack.business.domain.AggregateNotFoundException;
import org.seedstack.business.domain.Repository;

public interface VehicleServiceInfoRepository extends Repository<VehicleServiceInfo, String> {
    VehicleServiceInfo merge(VehicleServiceInfo aggregate) throws AggregateNotFoundException;

}
