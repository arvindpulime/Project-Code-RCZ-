package com.inetpsa.rcz.domain.model.payload.response;

import com.fasterxml.jackson.annotation.*;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.inetpsa.rcz.domain.model.enums.ProcessStatus;
import com.inetpsa.rcz.domain.model.payload.data.Data;
import com.inetpsa.rcz.infrastructure.jackson.deserializer.DataJsonDeserializer;
import com.inetpsa.rcz.infrastructure.jackson.serializer.DataJsonSerializer;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.util.Date;

import static com.inetpsa.rcz.domain.model.payload.ValidationPattern.*;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ResponsePayload<R> {

    @NotNull
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = PATTERN_DATE)
    @JsonProperty("resp_date")
    private Date responseDate;

    @NotNull
    @Pattern(regexp = PATTERN_VIN)
    @JsonProperty("vin")
    private String vin;

    @NotNull
    @Pattern(regexp = PATTERN_CORRELATION_ID)
    @JsonProperty("correlation_id")
    private String correlationId;

    @NotNull
    @Pattern(regexp = PATTERN_RETURN_CODE)
    @JsonProperty("return_code")
    private String returnCode;

    @NotNull
    @Size(max = 50)
    @JsonProperty("return_message")
    private String returnMessage;

    @JsonProperty("reason")
    private String reason;

    @JsonSerialize(using = DataJsonSerializer.class)
    @JsonDeserialize(using = DataJsonDeserializer.class)
    @JsonProperty("location")
    private Data location;

    @JsonProperty("resp_data")
    private R responseData;


    @JsonIgnore
    public ProcessStatus getProcessCode() {
        return ProcessStatus.valueOf(returnCode);
    }

    public ResponsePayload() {
    }

    public Date getResponseDate() {
        return responseDate;
    }

    public void setResponseDate(Date responseDate) {
        this.responseDate = responseDate;
    }

    public String getVin() {
        return vin;
    }

    public void setVin(String vin) {
        this.vin = vin;
    }

    public String getCorrelationId() {
        return correlationId;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    public String getReturnCode() {
        return returnCode;
    }

    public void setReturnCode(String returnCode) {
        this.returnCode = returnCode;
    }

    public String getReturnMessage() {
        return returnMessage;
    }

    public void setReturnMessage(String returnMessage) {
        this.returnMessage = returnMessage;
    }

    public String getReason() {
        return reason;
    }

    public ResponsePayload setReason(String reason) {
        this.reason = reason;
        return this;
    }

    public Data getLocation() {
        return location;
    }

    public void setLocation(Data location) {
        this.location = location;
    }

    public R getResponseData() {
        return responseData;
    }

    public void setResponseData(R responseData) {
        this.responseData = responseData;
    }
}
