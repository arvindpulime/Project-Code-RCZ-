package com.inetpsa.rcz.domain.model.payload.data;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.inetpsa.rcz.infrastructure.jackson.serializer.NumericBooleanSerializer;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;

import static com.inetpsa.rcz.domain.model.payload.ValidationPattern.PATTERN_TRACKING_ACTION;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Tracking extends Error {

    @JsonProperty("action")
    @Pattern(regexp = PATTERN_TRACKING_ACTION)
    private String action;

    @Min(5)
    @Max(Integer.MAX_VALUE)
    @JsonProperty("period_run")
    private Integer periodRun;

    @Min(60)
    @Max(Integer.MAX_VALUE)
    @JsonProperty("period_shutdn")
    private Integer periodShutdown;

    @JsonSerialize(using = NumericBooleanSerializer.class)
    @JsonProperty("state")
    private Boolean state;

    public Tracking() {
    }

    public Tracking(Integer periodRun, Integer periodShutdown, Boolean state) {
        this.periodRun = periodRun;
        this.periodShutdown = periodShutdown;
        this.state = state;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public Integer getPeriodRun() {
        return periodRun;
    }

    public void setPeriodRun(Integer periodRun) {
        this.periodRun = periodRun;
    }

    public Integer getPeriodShutdown() {
        return periodShutdown;
    }

    public void setPeriodShutdown(Integer periodShutdown) {
        this.periodShutdown = periodShutdown;
    }

    public Boolean getState() {
        return state;
    }

    public void setState(Boolean state) {
        this.state = state;
    }
}
