package com.inetpsa.carbide.decoder.infrastructure.util;

import org.assertj.core.api.Assertions;
import org.junit.Test;

public class ByteUtilsTest {

    private static byte[] create(byte... bytes) {
        return bytes;
    }

    // UNSIGNED

    @Test
    public void testUnsignedInt8bits() {
        final byte[] bytes = create((byte) 0xAC);
        final int out = ByteUtils.asInt(bytes);
        Assertions.assertThat(out).isEqualTo(172);
    }

    @Test
    public void testUnsignedInt16bits() {
        final byte[] bytes = create((byte) 0xD6, (byte) 0xAC);
        final int out = ByteUtils.asInt(bytes);
        Assertions.assertThat(out).isEqualTo(54956);
    }

    @Test
    public void testUnsignedInt24bits() {
        final byte[] bytes = create((byte) 0x94, (byte) 0xAE, (byte) 0xF0);
        final int out = ByteUtils.asInt(bytes);
        Assertions.assertThat(out).isEqualTo(9744112);
    }

    @Test
    public void testUnsignedInt7bits() {
        final byte[] bytes = create((byte) 0x5A);
        final int out = ByteUtils.asInt(bytes);
        Assertions.assertThat(out).isEqualTo(90);
    }

    @Test
    public void testUnsignedInt15bits() {
        final byte[] bytes = create((byte) 0x48, (byte) 0xEA);
        final int out = ByteUtils.asInt(bytes);
        Assertions.assertThat(out).isEqualTo(18666);
    }

    // POSITIVES

    @Test
    public void testPositiveSignedInt8bits() {
        final byte[] bytes = create((byte) 0x64);
        final int out = ByteUtils.asSignedInt(bytes);
        Assertions.assertThat(out).isEqualTo(100);
    }

    @Test
    public void testPositiveSignedInt16bits() {
        final byte[] bytes = create((byte) 0x27, (byte) 0x10);
        final int out = ByteUtils.asSignedInt(bytes);
        Assertions.assertThat(out).isEqualTo(10000);
    }

    @Test
    public void testPositiveSignedInt7bits() {
        final byte[] bytes = create((byte) 0x32);
        final int out = ByteUtils.asSignedInt(bytes, 7);
        Assertions.assertThat(out).isEqualTo(50);
    }

    @Test
    public void testPositiveSignedInt15bits() {
        final byte[] bytes = create((byte) 0x27, (byte) 0x10);
        final int out = ByteUtils.asSignedInt(bytes, 15);
        Assertions.assertThat(out).isEqualTo(10000);
    }

    // NEGATIVES

    @Test
    public void testNegativeSignedInt8bits() {
        final byte[] bytes = create((byte) 0x9C);
        final int out = ByteUtils.asSignedInt(bytes);
        Assertions.assertThat(out).isEqualTo(-100);
    }

    @Test
    public void testNegativeSignedInt16bits() {
        final byte[] bytes = create((byte) 0xD8, (byte) 0xF0);
        final int out = ByteUtils.asSignedInt(bytes);
        Assertions.assertThat(out).isEqualTo(-10000);
    }

    @Test
    public void testNegativeSignedInt7bits() {
        final byte[] bytes = create((byte) 0x4E);
        final int out = ByteUtils.asSignedInt(bytes, 7);
        Assertions.assertThat(out).isEqualTo(-50);
    }

    @Test
    public void testNegativeSignedInt15bits() {
        final byte[] bytes = create((byte) 0x58, (byte) 0xF0);
        final int out = ByteUtils.asSignedInt(bytes, 15);
        Assertions.assertThat(out).isEqualTo(-10000);
    }

    @Test
    public void testNegativeSignedInt32bits() {
        final byte[] bytes = create((byte) 0xFF, (byte) 0xFF, (byte) 0xFC, (byte) 0x18);
        final int out = ByteUtils.asInt(bytes);
        Assertions.assertThat(out).isEqualTo(-1000);
    }

    @Test
    public void testPositiveSignedInt32bits() {
        final byte[] bytes = create((byte) 0x00, (byte) 0x00, (byte) 0x27, (byte) 0x10);
        final int out = ByteUtils.asInt(bytes);
        Assertions.assertThat(out).isEqualTo(10000);
    }
}