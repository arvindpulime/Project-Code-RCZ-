package com.inetpsa.carbide.decoder.application.services;

import com.inetpsa.carbide.decoder.application.util.Structure;
import com.inetpsa.carbide.domain.interfaces.data.Header;
import com.inetpsa.carbide.domain.interfaces.data.global.*;
import com.inetpsa.carbide.domain.interfaces.data.global.troubleshooting.JDA;
import com.inetpsa.carbide.domain.interfaces.data.global.troubleshooting.JDD;
import com.inetpsa.carbide.domain.interfaces.data.legacy.Event;
import com.inetpsa.carbide.domain.interfaces.data.legacy.Extension;
import com.inetpsa.carbide.domain.interfaces.data.legacy.LEV;
import com.inetpsa.carbide.domain.interfaces.data.legacy.Periodic;
import com.inetpsa.carbide.domain.interfaces.data.lev.Battery;
import com.inetpsa.carbide.domain.interfaces.data.lev.Ecoaching;
import com.inetpsa.carbide.domain.interfaces.data.lev.ThermalConditioning;
import com.inetpsa.carbide.domain.interfaces.data.lev.Trip;
import com.inetpsa.carbide.domain.interfaces.data.lev.monitoring.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.Logging;
import org.seedstack.seed.testing.junit4.SeedITRunner;
import org.slf4j.Logger;

import javax.inject.Inject;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SeedITRunner.class)
public class DecoderServiceTest {

    @Logging
    private Logger logger;

    @Inject
    private DecoderService underTest;

    @Test
    public void decodeHeader() throws Exception {
        Header header = (Header) underTest.decode(Structure.HEADER, StructureFixture.toByteArray(StructureFixture.HEADER));
        logger.info(header.toString());
        assertThat(header).isNotNull();
    }

    @Test
    public void decodeHeaderV2() throws Exception {
        Header header = (Header) underTest.decode(Structure.HEADER_V2, StructureFixture.toByteArray(StructureFixture.HEADER_V2));
        logger.info(header.toString());
        assertThat(header).isNotNull();
    }

    @Test
    public void decodeLocalization() throws Exception {
        Localization localization = (Localization) underTest.decode(Structure.LOCALIZATION, StructureFixture.toByteArray(StructureFixture.LOCALIZATION));
        logger.info(localization.toString());
        assertThat(localization).isNotNull();
    }

    @Test
    public void decodeBattery() throws Exception {
        Battery battery = (Battery) underTest.decode(Structure.BATTERY, StructureFixture.toByteArray(StructureFixture.BATTERY));
        logger.info(battery.toString());
        assertThat(battery).isNotNull();
    }

    @Test
    public void decodeBatteryStateOfHealth() throws Exception {
        BatteryStateOfHealth batteryStateOfHealth = (BatteryStateOfHealth) underTest.decode(Structure.BATTERY_SOH, StructureFixture.toByteArray(StructureFixture.BATTERY_SOH));
        logger.info(batteryStateOfHealth.toString());
        assertThat(batteryStateOfHealth).isNotNull();
    }

    @Test
    public void decodeBatteryStatusSummary() throws Exception {
        BatteryStatusSummary batteryStatusSummary = (BatteryStatusSummary) underTest.decode(Structure.BATTERY_STATUS_SUMMARY, StructureFixture.toByteArray(StructureFixture.BATTERY_STATUS_SUMMARY));
        logger.info(batteryStatusSummary.toString());
        assertThat(batteryStatusSummary).isNotNull();
    }

    @Test
    public void decodeBatteryStatusDetails() throws Exception {
        BatteryStatusDetails batteryStatusDetails = (BatteryStatusDetails) underTest.decode(Structure.BATTERY_STATUS_DETAILS, StructureFixture.toByteArray(StructureFixture.BATTERY_STATUS_DETAILS));
        logger.info(batteryStatusDetails.toString());
        assertThat(batteryStatusDetails).isNotNull();
    }

    @Test
    public void decodeBatteryVoltageSummary() throws Exception {
        BatteryVoltageSummary batteryVoltageSummary = (BatteryVoltageSummary) underTest.decode(Structure.BATTERY_VOLTAGE_SUMMARY, StructureFixture.toByteArray(StructureFixture.BATTERY_VOLTAGE_SUMMARY));
        logger.info(batteryVoltageSummary.toString());
        assertThat(batteryVoltageSummary).isNotNull();
    }

    @Test
    public void decodeBatteryVoltageDetails() throws Exception {
        BatteryVoltageDetails batteryVoltageDetails = (BatteryVoltageDetails) underTest.decode(Structure.BATTERY_VOLTAGE_DETAILS, StructureFixture.toByteArray(StructureFixture.BATTERY_VOLTAGE_DETAILS));
        logger.info(batteryVoltageDetails.toString());
        assertThat(batteryVoltageDetails).isNotNull();
    }

    @Test
    public void decodeEcoaching() throws Exception {
        Ecoaching ecoaching = (Ecoaching) underTest.decode(Structure.ECOACHING, StructureFixture.toByteArray(StructureFixture.ECOACHING));
        logger.info(ecoaching.toString());
        assertThat(ecoaching).isNotNull();
    }

    @Test
    public void decodeTrip() throws Exception {
        Trip trip = (Trip) underTest.decode(Structure.TRIP, StructureFixture.toByteArray(StructureFixture.TRIP));
        logger.info(trip.toString());
        assertThat(trip).isNotNull();
    }

    @Test
    public void decodeJDA() throws Exception {
        JDA jda = (JDA) underTest.decode(Structure.JDA, StructureFixture.toByteArray(StructureFixture.JDA));
        logger.info(jda.toString());
        assertThat(jda).isNotNull();
    }

    @Test
    public void decodeJDD() throws Exception {
        JDD jdd = (JDD) underTest.decode(Structure.JDD, StructureFixture.toByteArray(StructureFixture.JDD));
        logger.info(jdd.toString());
        assertThat(jdd).isNotNull();
    }

    @Test
    public void decodeThermalConditioning() throws Exception {
        ThermalConditioning thermalConditioning = (ThermalConditioning) underTest.decode(Structure.THERMAL_CONDITIONING, StructureFixture.toByteArray(StructureFixture.THERMAL_CONDITIONING));
        logger.info(thermalConditioning.toString());
        assertThat(thermalConditioning).isNotNull();
    }

    @Test
    public void decodePeriodic() throws Exception {
        Periodic periodic = (Periodic) underTest.decode(Structure.PERIODIC, StructureFixture.toByteArray(StructureFixture.PERIODIC));
        logger.info(periodic.toString());
        assertThat(periodic).isNotNull();
    }

    @Test
    public void decodeEventPrivacy() throws Exception {
        Event event = (Event) underTest.decode(Structure.EVENT, StructureFixture.toByteArray(StructureFixture.EVENT_PRIVACY));
        logger.info(event.toString());
        assertThat(event).isNotNull();
    }

    @Test
    public void decodeEventStop() throws Exception {
        Event event = (Event) underTest.decode(Structure.EVENT, StructureFixture.toByteArray(StructureFixture.EVENT_STOP));
        logger.info(event.toString());
        assertThat(event).isNotNull();
    }

    @Test
    public void decodeEventStart() throws Exception {
        Event event = (Event) underTest.decode(Structure.EVENT, StructureFixture.toByteArray(StructureFixture.EVENT_START));
        logger.info(event.toString());
        assertThat(event).isNotNull();
    }

    @Test
    public void decodeEventCrash() throws Exception {
        Event event = (Event) underTest.decode(Structure.EVENT, StructureFixture.toByteArray(StructureFixture.EVENT_CRASH));
        logger.info(event.toString());
        assertThat(event).isNotNull();
    }

    @Test
    public void decodeExtension() throws Exception {
        Extension extension = (Extension) underTest.decode(Structure.EXTENSION, StructureFixture.toByteArray(StructureFixture.EXTENSION));
        logger.info(extension.toString());
        assertThat(extension).isNotNull();
    }

    @Test
    public void decodePrivacy() throws Exception {
        Privacy privacy = (Privacy) underTest.decode(Structure.PRIVACY, StructureFixture.toByteArray(StructureFixture.PRIVACY));
        logger.info(privacy.toString());
        assertThat(privacy).isNotNull();
    }

    @Test
    public void decodeVehicleStatus() throws Exception {
        VehicleStatus vehicleStatus = (VehicleStatus) underTest.decode(Structure.VEHICLE_STATUS, StructureFixture.toByteArray(StructureFixture.VEHICLE_STATUS));
        logger.info(vehicleStatus.toString());
        assertThat(vehicleStatus).isNotNull();
    }

    @Test
    public void decodeVehicleStatusV2() throws Exception {
        VehicleStatus vehicleStatus = (VehicleStatus) underTest.decode(Structure.VEHICLE_STATUS_V2, StructureFixture.toByteArray(StructureFixture.VEHICLE_STATUS_V2));
        logger.info(vehicleStatus.toString());
        assertThat(vehicleStatus).isNotNull();
    }

    @Test
    public void decodeMaintenanceStatus() throws Exception {
        MaintenanceStatus maintenanceStatus = (MaintenanceStatus) underTest.decode(Structure.MAINTENANCE_STATUS, StructureFixture.toByteArray(StructureFixture.MAINTENANCE_STATUS));
        logger.info(maintenanceStatus.toString());
        assertThat(maintenanceStatus).isNotNull();
    }

    @Test
    public void decodeDoorsStatus() throws Exception {
        DoorsStatus doorsStatus = (DoorsStatus) underTest.decode(Structure.DOORS_STATUS, StructureFixture.toByteArray(StructureFixture.DOORS_STATUS));
        logger.info(doorsStatus.toString());
        assertThat(doorsStatus).isNotNull();
    }

    @Test
    public void decodeCfmLev() throws Exception {
        LEV lev = (LEV) underTest.decode(Structure.CFM_LEV, StructureFixture.toByteArray(StructureFixture.CFM_LEV));
        logger.info(lev.toString());
        assertThat(lev).isNotNull();
    }

    @Test
    public void decodeAdas() throws Exception {
        Adas adas = (Adas) underTest.decode(Structure.ADAS, StructureFixture.toByteArray(StructureFixture.ADAS));
        logger.info(adas.toString());
        assertThat(adas).isNotNull();
    }

    @Test
    public void decodeCrash() throws Exception {
        Crash crash = (Crash) underTest.decode(Structure.CRASH, StructureFixture.toByteArray(StructureFixture.CRASH));
        logger.info(crash.toString());
        assertThat(crash).isNotNull();
    }

    @Test
    public void decodeUsageStatus() throws Exception {
        UsageStatus usageStatus = (UsageStatus) underTest.decode(Structure.USAGE_STATUS, StructureFixture.toByteArray(StructureFixture.USAGE_STATUS));
        logger.info(usageStatus.toString());
        assertThat(usageStatus).isNotNull();
    }

    @Test
    public void decodeUsageStatusV2() throws Exception {
        UsageStatus usageStatus = (UsageStatus) underTest.decode(Structure.USAGE_STATUS_V2, StructureFixture.toByteArray(StructureFixture.USAGE_STATUS_V2));
        logger.info(usageStatus.toString());
        assertThat(usageStatus).isNotNull();
    }
}
