package com.inetpsa.carbide.decoder.infrastructure.jbbp.struct;

import com.igormaznitsa.jbbp.io.JBBPBitOrder;
import com.igormaznitsa.jbbp.mapper.Bin;
import com.igormaznitsa.jbbp.mapper.BinType;
import lombok.Setter;

@Setter
public final class JBBPHeaderV2 extends JBBPHeader {

    @Bin(order = 18, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int triggerType;

    public int getTriggerType() {
        return triggerType;
    }
}
