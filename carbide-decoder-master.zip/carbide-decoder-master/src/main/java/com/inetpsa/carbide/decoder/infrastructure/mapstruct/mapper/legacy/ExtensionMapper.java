package com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.legacy;

import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.legacy.JBBPExtension;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.DataMapper;
import com.inetpsa.carbide.domain.interfaces.data.legacy.Extension;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface ExtensionMapper extends DataMapper<Extension, JBBPExtension> {

    ExtensionMapper INSTANCE = Mappers.getMapper(ExtensionMapper.class);
}
