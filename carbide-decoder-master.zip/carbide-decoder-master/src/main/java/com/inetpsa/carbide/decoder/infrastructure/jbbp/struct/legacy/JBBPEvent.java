package com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.legacy;

import com.igormaznitsa.jbbp.io.JBBPBitNumber;
import com.igormaznitsa.jbbp.io.JBBPBitOrder;
import com.igormaznitsa.jbbp.mapper.Bin;
import com.igormaznitsa.jbbp.mapper.BinType;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.JBBPData;
import com.inetpsa.carbide.decoder.infrastructure.util.ByteUtils;
import com.inetpsa.carbide.decoder.infrastructure.util.CollectionUtils;
import com.inetpsa.carbide.decoder.infrastructure.util.DateUtils;
import com.inetpsa.carbide.decoder.infrastructure.util.Formula;
import lombok.Setter;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.List;

import static com.inetpsa.carbide.decoder.infrastructure.util.Constant.STARTING_YEAR;
import static com.inetpsa.carbide.decoder.infrastructure.util.Factor.*;
import static com.inetpsa.carbide.decoder.infrastructure.util.Offset.TEMPERATURE_OFFSET;

@Setter
public class JBBPEvent implements JBBPData {

    //<editor-fold desc="HOUR_DATE_FIRST_DATA_COLLECT">
    @Bin(order = 1, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_6, bitOrder = JBBPBitOrder.MSB0)
    private int yearOfCollection;

    @Bin(order = 2, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int monthOfCollection;

    @Bin(order = 3, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int dayOfCollection;

    @Bin(order = 4, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int hourOfCollection;

    @Bin(order = 5, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_6, bitOrder = JBBPBitOrder.MSB0)
    private int minuteOfCollection;

    @Bin(order = 6, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_6, bitOrder = JBBPBitOrder.MSB0)
    private int secondOfCollection;
    //</editor-fold>

    //<editor-fold desc="HOUR_DATE_UPSTREAM">
    @Bin(order = 7, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_6, bitOrder = JBBPBitOrder.MSB0)
    private int yearOfTransmission;

    @Bin(order = 8, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int monthOfTransmission;

    @Bin(order = 9, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int dayOfTransmission;

    @Bin(order = 10, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int hourOfTransmission;

    @Bin(order = 11, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_6, bitOrder = JBBPBitOrder.MSB0)
    private int minuteOfTransmission;

    @Bin(order = 12, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_6, bitOrder = JBBPBitOrder.MSB0)
    private int secondOfTransmission;
    //</editor-fold>

    @Bin(order = 13, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] idTrip;

    //<editor-fold desc="ID_FRAME">
    @Bin(order = 14, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] idFrame;
    //</editor-fold>

    //<editor-fold desc="PRIVACY_MODE_STATE">
    @Bin(order = 15, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int privacyMode;
    //</editor-fold>

    //<editor-fold desc="HOUR_DATE_EVENT">
    @Bin(order = 16, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_6, bitOrder = JBBPBitOrder.MSB0)
    private int yearOfEvent;

    @Bin(order = 17, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int monthOfEvent;

    @Bin(order = 18, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int dayOfEvent;

    @Bin(order = 19, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int hourOfEvent;

    @Bin(order = 20, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_6, bitOrder = JBBPBitOrder.MSB0)
    private int minuteOfEvent;

    @Bin(order = 21, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_6, bitOrder = JBBPBitOrder.MSB0)
    private int secondOfEvent;
    //</editor-fold>

    //<editor-fold desc="TRIGGER_TYPE">
    @Bin(order = 22, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int triggerType;
    //</editor-fold>

    //<editor-fold desc="VIN_VEHICLE">
    @Bin(order = 23, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] vin;
    //</editor-fold>

    //<editor-fold desc="PREVIOUS_EVENT_FRAME_DATA">
    @Bin(order = 24, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] previousLifetimeMileage;

    @Bin(order = 25, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int previousFuelLevel;

    @Bin(order = 26, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int previousPrivacyMode;

    @Bin(order = 27, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int previousTriggerType;

    @Bin(order = 28, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_6, bitOrder = JBBPBitOrder.MSB0)
    private int previousYearOfEvent;

    @Bin(order = 29, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int previousMonthOfEvent;

    @Bin(order = 30, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int previousDayOfEvent;

    @Bin(order = 31, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int previousHourOfEvent;

    @Bin(order = 32, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_6, bitOrder = JBBPBitOrder.MSB0)
    private int previousMinuteOfEvent;

    @Bin(order = 33, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_6, bitOrder = JBBPBitOrder.MSB0)
    private int previousSecondOfEvent;

    @Bin(order = 34, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] previousIdFrame;

    @Bin(order = 35, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] previousAltitude;

    @Bin(order = 36, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] previousHeading;

    @Bin(order = 37, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] previousLongitude;

    @Bin(order = 38, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] previousLatitude;

    @Bin(order = 39, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int previousGPSSignalQuality;

    @Bin(order = 40, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int previousVehicleLocationType;
    //</editor-fold>

    //<editor-fold desc="GPS_LOCATION">
    @Bin(order = 101, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude01;

    @Bin(order = 102, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude02;

    @Bin(order = 103, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude03;

    @Bin(order = 104, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude04;

    @Bin(order = 105, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude05;

    @Bin(order = 106, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude06;

    @Bin(order = 107, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude07;

    @Bin(order = 108, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude08;

    @Bin(order = 109, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude09;

    @Bin(order = 110, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude10;

    @Bin(order = 111, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude11;

    @Bin(order = 112, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude12;

    @Bin(order = 113, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude13;

    @Bin(order = 114, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude14;

    @Bin(order = 115, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude15;

    @Bin(order = 116, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude16;

    @Bin(order = 117, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude17;

    @Bin(order = 118, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude18;

    @Bin(order = 119, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude19;

    @Bin(order = 120, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude20;

    @Bin(order = 121, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude21;

    @Bin(order = 122, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude22;

    @Bin(order = 123, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude23;

    @Bin(order = 124, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude24;

    @Bin(order = 125, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude25;

    @Bin(order = 126, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude26;

    @Bin(order = 127, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude27;

    @Bin(order = 128, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude28;

    @Bin(order = 129, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude29;

    @Bin(order = 130, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude30;

    @Bin(order = 131, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude31;

    @Bin(order = 132, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude32;

    @Bin(order = 133, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude33;

    @Bin(order = 134, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude34;

    @Bin(order = 135, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude35;

    @Bin(order = 136, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude36;

    @Bin(order = 137, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude37;

    @Bin(order = 138, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude38;

    @Bin(order = 139, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude39;

    @Bin(order = 140, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude40;

    @Bin(order = 141, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude41;

    @Bin(order = 142, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude42;

    @Bin(order = 143, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude43;

    @Bin(order = 144, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude44;

    @Bin(order = 145, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude45;

    @Bin(order = 146, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude46;

    @Bin(order = 147, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude47;

    @Bin(order = 148, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude48;

    @Bin(order = 149, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude49;

    @Bin(order = 150, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude50;

    @Bin(order = 151, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude51;

    @Bin(order = 152, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude52;

    @Bin(order = 153, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude53;

    @Bin(order = 154, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude54;

    @Bin(order = 155, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude55;

    @Bin(order = 156, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude56;

    @Bin(order = 157, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude57;

    @Bin(order = 158, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude58;

    @Bin(order = 159, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude59;

    @Bin(order = 160, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude60;

    @Bin(order = 201, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading01;

    @Bin(order = 202, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading02;

    @Bin(order = 203, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading03;

    @Bin(order = 204, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading04;

    @Bin(order = 205, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading05;

    @Bin(order = 206, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading06;

    @Bin(order = 207, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading07;

    @Bin(order = 208, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading08;

    @Bin(order = 209, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading09;

    @Bin(order = 210, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading10;

    @Bin(order = 211, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading11;

    @Bin(order = 212, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading12;

    @Bin(order = 213, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading13;

    @Bin(order = 214, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading14;

    @Bin(order = 215, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading15;

    @Bin(order = 216, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading16;

    @Bin(order = 217, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading17;

    @Bin(order = 218, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading18;

    @Bin(order = 219, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading19;

    @Bin(order = 220, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading20;

    @Bin(order = 221, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading21;

    @Bin(order = 222, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading22;

    @Bin(order = 223, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading23;

    @Bin(order = 224, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading24;

    @Bin(order = 225, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading25;

    @Bin(order = 226, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading26;

    @Bin(order = 227, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading27;

    @Bin(order = 228, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading28;

    @Bin(order = 229, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading29;

    @Bin(order = 230, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading30;

    @Bin(order = 231, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading31;

    @Bin(order = 232, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading32;

    @Bin(order = 233, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading33;

    @Bin(order = 234, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading34;

    @Bin(order = 235, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading35;

    @Bin(order = 236, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading36;

    @Bin(order = 237, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading37;

    @Bin(order = 238, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading38;

    @Bin(order = 239, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading39;

    @Bin(order = 240, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading40;

    @Bin(order = 241, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading41;

    @Bin(order = 242, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading42;

    @Bin(order = 243, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading43;

    @Bin(order = 244, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading44;

    @Bin(order = 245, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading45;

    @Bin(order = 246, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading46;

    @Bin(order = 247, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading47;

    @Bin(order = 248, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading48;

    @Bin(order = 249, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading49;

    @Bin(order = 250, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading50;

    @Bin(order = 251, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading51;

    @Bin(order = 252, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading52;

    @Bin(order = 253, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading53;

    @Bin(order = 254, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading54;

    @Bin(order = 255, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading55;

    @Bin(order = 256, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading56;

    @Bin(order = 257, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading57;

    @Bin(order = 258, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading58;

    @Bin(order = 259, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading59;

    @Bin(order = 260, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading60;

    @Bin(order = 301, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude01;

    @Bin(order = 302, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude01;

    @Bin(order = 303, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude02;

    @Bin(order = 304, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude02;

    @Bin(order = 305, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude03;

    @Bin(order = 306, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude03;

    @Bin(order = 307, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude04;

    @Bin(order = 308, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude04;

    @Bin(order = 309, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude05;

    @Bin(order = 310, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude05;

    @Bin(order = 311, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude06;

    @Bin(order = 312, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude06;

    @Bin(order = 313, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude07;

    @Bin(order = 314, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude07;

    @Bin(order = 315, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude08;

    @Bin(order = 316, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude08;

    @Bin(order = 317, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude09;

    @Bin(order = 318, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude09;

    @Bin(order = 319, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude10;

    @Bin(order = 320, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude10;

    @Bin(order = 321, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude11;

    @Bin(order = 322, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude11;

    @Bin(order = 323, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude12;

    @Bin(order = 324, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude12;

    @Bin(order = 325, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude13;

    @Bin(order = 326, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude13;

    @Bin(order = 327, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude14;

    @Bin(order = 328, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude14;

    @Bin(order = 329, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude15;

    @Bin(order = 330, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude15;

    @Bin(order = 330, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude16;

    @Bin(order = 332, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude16;

    @Bin(order = 333, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude17;

    @Bin(order = 334, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude17;

    @Bin(order = 335, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude18;

    @Bin(order = 336, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude18;

    @Bin(order = 337, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude19;

    @Bin(order = 338, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude19;

    @Bin(order = 339, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude20;

    @Bin(order = 340, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude20;

    @Bin(order = 341, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude21;

    @Bin(order = 342, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude21;

    @Bin(order = 343, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude22;

    @Bin(order = 344, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude22;

    @Bin(order = 345, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude23;

    @Bin(order = 346, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude23;

    @Bin(order = 347, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude24;

    @Bin(order = 348, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude24;

    @Bin(order = 349, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude25;

    @Bin(order = 350, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude25;

    @Bin(order = 351, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude26;

    @Bin(order = 352, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude26;

    @Bin(order = 353, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude27;

    @Bin(order = 354, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude27;

    @Bin(order = 355, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude28;

    @Bin(order = 356, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude28;

    @Bin(order = 357, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude29;

    @Bin(order = 358, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude29;

    @Bin(order = 359, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude30;

    @Bin(order = 360, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude30;

    @Bin(order = 361, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude31;

    @Bin(order = 362, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude31;

    @Bin(order = 363, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude32;

    @Bin(order = 364, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude32;

    @Bin(order = 365, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude33;

    @Bin(order = 366, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude33;

    @Bin(order = 367, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude34;

    @Bin(order = 368, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude34;

    @Bin(order = 369, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude35;

    @Bin(order = 370, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude35;

    @Bin(order = 371, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude36;

    @Bin(order = 372, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude36;

    @Bin(order = 373, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude37;

    @Bin(order = 374, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude37;

    @Bin(order = 375, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude38;

    @Bin(order = 376, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude38;

    @Bin(order = 377, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude39;

    @Bin(order = 378, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude39;

    @Bin(order = 379, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude40;

    @Bin(order = 380, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude40;

    @Bin(order = 381, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude41;

    @Bin(order = 382, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude41;

    @Bin(order = 383, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude42;

    @Bin(order = 384, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude42;

    @Bin(order = 385, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude43;

    @Bin(order = 386, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude43;

    @Bin(order = 387, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude44;

    @Bin(order = 388, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude44;

    @Bin(order = 389, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude45;

    @Bin(order = 390, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude45;

    @Bin(order = 391, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude46;

    @Bin(order = 392, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude46;

    @Bin(order = 393, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude47;

    @Bin(order = 394, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude47;

    @Bin(order = 395, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude48;

    @Bin(order = 396, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude48;

    @Bin(order = 397, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude49;

    @Bin(order = 398, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude49;

    @Bin(order = 399, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude50;

    @Bin(order = 400, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude50;

    @Bin(order = 401, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude51;

    @Bin(order = 402, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude51;

    @Bin(order = 403, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude52;

    @Bin(order = 404, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude52;

    @Bin(order = 405, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude53;

    @Bin(order = 406, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude53;

    @Bin(order = 407, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude54;

    @Bin(order = 408, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude54;

    @Bin(order = 409, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude55;

    @Bin(order = 410, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude55;

    @Bin(order = 411, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude56;

    @Bin(order = 412, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude56;

    @Bin(order = 413, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude57;

    @Bin(order = 414, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude57;

    @Bin(order = 415, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude58;

    @Bin(order = 416, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude58;

    @Bin(order = 417, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude59;

    @Bin(order = 418, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude59;

    @Bin(order = 419, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude60;

    @Bin(order = 420, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude60;

    @Bin(order = 501, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality01;

    @Bin(order = 502, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality02;

    @Bin(order = 503, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality03;

    @Bin(order = 504, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality04;

    @Bin(order = 505, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality05;

    @Bin(order = 506, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality06;

    @Bin(order = 507, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality07;

    @Bin(order = 508, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality08;

    @Bin(order = 509, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality09;

    @Bin(order = 510, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality10;

    @Bin(order = 511, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality11;

    @Bin(order = 512, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality12;

    @Bin(order = 513, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality13;

    @Bin(order = 514, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality14;

    @Bin(order = 515, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality15;

    @Bin(order = 516, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality16;

    @Bin(order = 517, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality17;

    @Bin(order = 518, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality18;

    @Bin(order = 519, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality19;

    @Bin(order = 520, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality20;

    @Bin(order = 521, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality21;

    @Bin(order = 522, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality22;

    @Bin(order = 523, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality23;

    @Bin(order = 524, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality24;

    @Bin(order = 525, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality25;

    @Bin(order = 526, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality26;

    @Bin(order = 527, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality27;

    @Bin(order = 528, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality28;

    @Bin(order = 529, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality29;

    @Bin(order = 530, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality30;

    @Bin(order = 531, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality31;

    @Bin(order = 532, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality32;

    @Bin(order = 533, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality33;

    @Bin(order = 534, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality34;

    @Bin(order = 535, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality35;

    @Bin(order = 536, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality36;

    @Bin(order = 537, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality37;

    @Bin(order = 538, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality38;

    @Bin(order = 539, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality39;

    @Bin(order = 540, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality40;

    @Bin(order = 541, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality41;

    @Bin(order = 542, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality42;

    @Bin(order = 543, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality43;

    @Bin(order = 544, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality44;

    @Bin(order = 545, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality45;

    @Bin(order = 546, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality46;

    @Bin(order = 547, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality47;

    @Bin(order = 548, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality48;

    @Bin(order = 549, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality49;

    @Bin(order = 550, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality50;

    @Bin(order = 551, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality51;

    @Bin(order = 552, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality52;

    @Bin(order = 553, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality53;

    @Bin(order = 554, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality54;

    @Bin(order = 555, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality55;

    @Bin(order = 556, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality56;

    @Bin(order = 557, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality57;

    @Bin(order = 558, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality58;

    @Bin(order = 559, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality59;

    @Bin(order = 560, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality60;

    @Bin(order = 601, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType01;

    @Bin(order = 602, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType02;

    @Bin(order = 603, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType03;

    @Bin(order = 604, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType04;

    @Bin(order = 605, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType05;

    @Bin(order = 606, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType06;

    @Bin(order = 607, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType07;

    @Bin(order = 608, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType08;

    @Bin(order = 609, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType09;

    @Bin(order = 610, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType10;

    @Bin(order = 611, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType11;

    @Bin(order = 612, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType12;

    @Bin(order = 613, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType13;

    @Bin(order = 614, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType14;

    @Bin(order = 615, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType15;

    @Bin(order = 616, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType16;

    @Bin(order = 617, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType17;

    @Bin(order = 618, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType18;

    @Bin(order = 619, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType19;

    @Bin(order = 620, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType20;

    @Bin(order = 621, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType21;

    @Bin(order = 622, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType22;

    @Bin(order = 623, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType23;

    @Bin(order = 624, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType24;

    @Bin(order = 625, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType25;

    @Bin(order = 626, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType26;

    @Bin(order = 627, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType27;

    @Bin(order = 628, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType28;

    @Bin(order = 629, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType29;

    @Bin(order = 630, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType30;

    @Bin(order = 631, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType31;

    @Bin(order = 632, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType32;

    @Bin(order = 633, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType33;

    @Bin(order = 634, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType34;

    @Bin(order = 635, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType35;

    @Bin(order = 636, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType36;

    @Bin(order = 637, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType37;

    @Bin(order = 638, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType38;

    @Bin(order = 639, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType39;

    @Bin(order = 640, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType40;

    @Bin(order = 641, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType41;

    @Bin(order = 642, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType42;

    @Bin(order = 643, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType43;

    @Bin(order = 644, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType44;

    @Bin(order = 645, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType45;

    @Bin(order = 646, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType46;

    @Bin(order = 647, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType47;

    @Bin(order = 648, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType48;

    @Bin(order = 649, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType49;

    @Bin(order = 650, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType50;

    @Bin(order = 651, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType51;

    @Bin(order = 652, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType52;

    @Bin(order = 653, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType53;

    @Bin(order = 654, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType54;

    @Bin(order = 655, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType55;

    @Bin(order = 656, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType56;

    @Bin(order = 657, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType57;

    @Bin(order = 658, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType58;

    @Bin(order = 659, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType59;

    @Bin(order = 660, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType60;
    //</editor-fold>

    //<editor-fold desc="CRASH_DATA">
    @Bin(order = 700, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rearHighSpeedCrashInfo;

    @Bin(order = 701, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rearMediumSpeedCrashInfo;

    @Bin(order = 702, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rearSlowSpeedCrashInfo;

    @Bin(order = 703, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rearReparabilitySpeedCrashInfo;

    @Bin(order = 704, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int pedestrianCrashInfo;

    @Bin(order = 705, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int highSpeedFrontCrashInfo;

    @Bin(order = 706, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int mediumSpeedN1FrontCrashInfo;

    @Bin(order = 707, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int mediumSpeedN2FrontCrashInfo;

    @Bin(order = 708, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int lowSpeedFrontCrashInfo;

    @Bin(order = 709, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int frontReparabilityCrashInfo;

    @Bin(order = 710, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rearHighSpeedLateralCrashInfo;

    @Bin(order = 711, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rearMediumSpeedLateralCrashInfo;

    @Bin(order = 712, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rearLowSpeedLateralCrashInfo;

    @Bin(order = 713, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rearRepairabilityCrashInfo;

    @Bin(order = 714, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int tippedOver;
    //</editor-fold>

    //<editor-fold desc="ADAS_DATA">
    @Bin(order = 801, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking01;

    @Bin(order = 802, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking02;

    @Bin(order = 803, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking03;

    @Bin(order = 804, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking04;

    @Bin(order = 805, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking05;

    @Bin(order = 806, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking06;

    @Bin(order = 807, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking07;

    @Bin(order = 808, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking08;

    @Bin(order = 809, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking09;

    @Bin(order = 810, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking10;

    @Bin(order = 811, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking11;

    @Bin(order = 812, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking12;

    @Bin(order = 813, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking13;

    @Bin(order = 814, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking14;

    @Bin(order = 815, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking15;

    @Bin(order = 816, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking16;

    @Bin(order = 817, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking17;

    @Bin(order = 818, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking18;

    @Bin(order = 819, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking19;

    @Bin(order = 820, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking20;

    @Bin(order = 821, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking21;

    @Bin(order = 822, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking22;

    @Bin(order = 823, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking23;

    @Bin(order = 824, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking24;

    @Bin(order = 825, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking25;

    @Bin(order = 826, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking26;

    @Bin(order = 827, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking27;

    @Bin(order = 828, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking28;

    @Bin(order = 829, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking29;

    @Bin(order = 830, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking30;

    @Bin(order = 831, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking31;

    @Bin(order = 832, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking32;

    @Bin(order = 833, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking33;

    @Bin(order = 834, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking34;

    @Bin(order = 835, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking35;

    @Bin(order = 836, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking36;

    @Bin(order = 837, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking37;

    @Bin(order = 838, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking38;

    @Bin(order = 839, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking39;

    @Bin(order = 840, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking40;

    @Bin(order = 841, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking41;

    @Bin(order = 842, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking42;

    @Bin(order = 843, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking43;

    @Bin(order = 844, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking44;

    @Bin(order = 845, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking45;

    @Bin(order = 846, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking46;

    @Bin(order = 847, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking47;

    @Bin(order = 848, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking48;

    @Bin(order = 849, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking49;

    @Bin(order = 850, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking50;

    @Bin(order = 851, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking51;

    @Bin(order = 852, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking52;

    @Bin(order = 853, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking53;

    @Bin(order = 854, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking54;

    @Bin(order = 855, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking55;

    @Bin(order = 856, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking56;

    @Bin(order = 857, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking57;

    @Bin(order = 858, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking58;

    @Bin(order = 859, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking59;

    @Bin(order = 860, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int rearParking60;

    @Bin(order = 901, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking01;

    @Bin(order = 902, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking02;

    @Bin(order = 903, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking03;

    @Bin(order = 904, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking04;

    @Bin(order = 905, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking05;

    @Bin(order = 906, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking06;

    @Bin(order = 907, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking07;

    @Bin(order = 908, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking08;

    @Bin(order = 909, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking09;

    @Bin(order = 910, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking10;

    @Bin(order = 911, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking11;

    @Bin(order = 912, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking12;

    @Bin(order = 913, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking13;

    @Bin(order = 914, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking14;

    @Bin(order = 915, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking15;

    @Bin(order = 916, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking16;

    @Bin(order = 917, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking17;

    @Bin(order = 918, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking18;

    @Bin(order = 919, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking19;

    @Bin(order = 920, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking20;

    @Bin(order = 921, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking21;

    @Bin(order = 922, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking22;

    @Bin(order = 923, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking23;

    @Bin(order = 924, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking24;

    @Bin(order = 925, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking25;

    @Bin(order = 926, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking26;

    @Bin(order = 927, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking27;

    @Bin(order = 928, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking28;

    @Bin(order = 929, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking29;

    @Bin(order = 930, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking30;

    @Bin(order = 931, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking31;

    @Bin(order = 932, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking32;

    @Bin(order = 933, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking33;

    @Bin(order = 934, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking34;

    @Bin(order = 935, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking35;

    @Bin(order = 936, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking36;

    @Bin(order = 937, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking37;

    @Bin(order = 938, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking38;

    @Bin(order = 939, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking39;

    @Bin(order = 940, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking40;

    @Bin(order = 941, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking41;

    @Bin(order = 942, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking42;

    @Bin(order = 943, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking43;

    @Bin(order = 944, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking44;

    @Bin(order = 945, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking45;

    @Bin(order = 946, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking46;

    @Bin(order = 947, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking47;

    @Bin(order = 948, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking48;

    @Bin(order = 949, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking49;

    @Bin(order = 950, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking50;

    @Bin(order = 951, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking51;

    @Bin(order = 952, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking52;

    @Bin(order = 953, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking53;

    @Bin(order = 954, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking54;

    @Bin(order = 955, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking55;

    @Bin(order = 956, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking56;

    @Bin(order = 957, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking57;

    @Bin(order = 958, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking58;

    @Bin(order = 959, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking59;

    @Bin(order = 960, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int frontParking60;

    @Bin(order = 1001, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation01;

    @Bin(order = 1002, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation02;

    @Bin(order = 1003, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation03;

    @Bin(order = 1004, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation04;

    @Bin(order = 1005, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation05;

    @Bin(order = 1006, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation06;

    @Bin(order = 1007, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation07;

    @Bin(order = 1008, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation08;

    @Bin(order = 1009, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation09;

    @Bin(order = 1010, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation10;

    @Bin(order = 1011, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation11;

    @Bin(order = 1012, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation12;

    @Bin(order = 1013, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation13;

    @Bin(order = 1014, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation14;

    @Bin(order = 1015, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation15;

    @Bin(order = 1016, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation16;

    @Bin(order = 1017, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation17;

    @Bin(order = 1018, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation18;

    @Bin(order = 1019, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation19;

    @Bin(order = 1020, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation20;

    @Bin(order = 1021, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation21;

    @Bin(order = 1022, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation22;

    @Bin(order = 1023, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation23;

    @Bin(order = 1024, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation24;

    @Bin(order = 1025, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation25;

    @Bin(order = 1026, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation26;

    @Bin(order = 1027, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation27;

    @Bin(order = 1028, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation28;

    @Bin(order = 1029, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation29;

    @Bin(order = 1030, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation30;

    @Bin(order = 1031, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation31;

    @Bin(order = 1032, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation32;

    @Bin(order = 1033, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation33;

    @Bin(order = 1034, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation34;

    @Bin(order = 1035, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation35;

    @Bin(order = 1036, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation36;

    @Bin(order = 1037, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation37;

    @Bin(order = 1038, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation38;

    @Bin(order = 1039, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation39;

    @Bin(order = 1040, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation40;

    @Bin(order = 1041, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation41;

    @Bin(order = 1042, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation42;

    @Bin(order = 1043, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation43;

    @Bin(order = 1044, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation44;

    @Bin(order = 1045, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation45;

    @Bin(order = 1046, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation46;

    @Bin(order = 1047, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation47;

    @Bin(order = 1048, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation48;

    @Bin(order = 1049, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation49;

    @Bin(order = 1050, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation50;

    @Bin(order = 1051, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation51;

    @Bin(order = 1052, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation52;

    @Bin(order = 1053, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation53;

    @Bin(order = 1054, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation54;

    @Bin(order = 1055, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation55;

    @Bin(order = 1056, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation56;

    @Bin(order = 1057, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation57;

    @Bin(order = 1058, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation58;

    @Bin(order = 1059, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation59;

    @Bin(order = 1060, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControlRegulation60;

    @Bin(order = 1101, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem01;

    @Bin(order = 1102, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem02;

    @Bin(order = 1103, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem03;

    @Bin(order = 1104, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem04;

    @Bin(order = 1105, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem05;

    @Bin(order = 1106, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem06;

    @Bin(order = 1107, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem07;

    @Bin(order = 1108, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem08;

    @Bin(order = 1109, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem09;

    @Bin(order = 1110, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem10;

    @Bin(order = 1111, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem11;

    @Bin(order = 1112, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem12;

    @Bin(order = 1113, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem13;

    @Bin(order = 1114, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem14;

    @Bin(order = 1115, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem15;

    @Bin(order = 1116, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem16;

    @Bin(order = 1117, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem17;

    @Bin(order = 1118, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem18;

    @Bin(order = 1119, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem19;

    @Bin(order = 1120, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem20;

    @Bin(order = 1121, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem21;

    @Bin(order = 1122, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem22;

    @Bin(order = 1123, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem23;

    @Bin(order = 1124, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem24;

    @Bin(order = 1125, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem25;

    @Bin(order = 1126, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem26;

    @Bin(order = 1127, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem27;

    @Bin(order = 1128, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem28;

    @Bin(order = 1129, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem29;

    @Bin(order = 1130, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem30;

    @Bin(order = 1131, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem31;

    @Bin(order = 1132, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem32;

    @Bin(order = 1133, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem33;

    @Bin(order = 1134, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem34;

    @Bin(order = 1135, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem35;

    @Bin(order = 1136, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem36;

    @Bin(order = 1137, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem37;

    @Bin(order = 1138, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem38;

    @Bin(order = 1139, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem39;

    @Bin(order = 1140, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem40;

    @Bin(order = 1141, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem41;

    @Bin(order = 1142, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem42;

    @Bin(order = 1143, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem43;

    @Bin(order = 1144, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem44;

    @Bin(order = 1145, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem45;

    @Bin(order = 1146, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem46;

    @Bin(order = 1147, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem47;

    @Bin(order = 1148, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem48;

    @Bin(order = 1149, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem49;

    @Bin(order = 1150, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem50;

    @Bin(order = 1151, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem51;

    @Bin(order = 1152, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem52;

    @Bin(order = 1153, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem53;

    @Bin(order = 1154, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem54;

    @Bin(order = 1155, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem55;

    @Bin(order = 1156, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem56;

    @Bin(order = 1157, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem57;

    @Bin(order = 1158, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem58;

    @Bin(order = 1159, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem59;

    @Bin(order = 1160, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem60;

    @Bin(order = 1201, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning01;

    @Bin(order = 1202, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning02;

    @Bin(order = 1203, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning03;

    @Bin(order = 1204, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning04;

    @Bin(order = 1205, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning05;

    @Bin(order = 1206, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning06;

    @Bin(order = 1207, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning07;

    @Bin(order = 1208, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning08;

    @Bin(order = 1209, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning09;

    @Bin(order = 1210, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning10;

    @Bin(order = 1211, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning11;

    @Bin(order = 1212, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning12;

    @Bin(order = 1213, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning13;

    @Bin(order = 1214, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning14;

    @Bin(order = 1215, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning15;

    @Bin(order = 1216, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning16;

    @Bin(order = 1217, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning17;

    @Bin(order = 1218, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning18;

    @Bin(order = 1219, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning19;

    @Bin(order = 1220, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning20;

    @Bin(order = 1221, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning21;

    @Bin(order = 1222, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning22;

    @Bin(order = 1223, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning23;

    @Bin(order = 1224, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning24;

    @Bin(order = 1225, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning25;

    @Bin(order = 1226, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning26;

    @Bin(order = 1227, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning27;

    @Bin(order = 1228, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning28;

    @Bin(order = 1229, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning29;

    @Bin(order = 1230, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning30;

    @Bin(order = 1231, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning31;

    @Bin(order = 1232, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning32;

    @Bin(order = 1233, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning33;

    @Bin(order = 1234, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning34;

    @Bin(order = 1235, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning35;

    @Bin(order = 1236, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning36;

    @Bin(order = 1237, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning37;

    @Bin(order = 1238, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning38;

    @Bin(order = 1239, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning39;

    @Bin(order = 1240, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning40;

    @Bin(order = 1241, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning41;

    @Bin(order = 1242, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning42;

    @Bin(order = 1243, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning43;

    @Bin(order = 1244, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning44;

    @Bin(order = 1245, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning45;

    @Bin(order = 1246, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning46;

    @Bin(order = 1247, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning47;

    @Bin(order = 1248, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning48;

    @Bin(order = 1249, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning49;

    @Bin(order = 1250, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning50;

    @Bin(order = 1251, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning51;

    @Bin(order = 1252, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning52;

    @Bin(order = 1253, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning53;

    @Bin(order = 1254, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning54;

    @Bin(order = 1255, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning55;

    @Bin(order = 1256, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning56;

    @Bin(order = 1257, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning57;

    @Bin(order = 1258, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning58;

    @Bin(order = 1259, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning59;

    @Bin(order = 1260, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning60;

    @Bin(order = 1301, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist01;

    @Bin(order = 1302, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist02;

    @Bin(order = 1303, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist03;

    @Bin(order = 1304, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist04;

    @Bin(order = 1305, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist05;

    @Bin(order = 1306, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist06;

    @Bin(order = 1307, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist07;

    @Bin(order = 1308, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist08;

    @Bin(order = 1309, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist09;

    @Bin(order = 1310, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist10;

    @Bin(order = 1311, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist11;

    @Bin(order = 1312, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist12;

    @Bin(order = 1313, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist13;

    @Bin(order = 1314, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist14;

    @Bin(order = 1315, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist15;

    @Bin(order = 1316, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist16;

    @Bin(order = 1317, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist17;

    @Bin(order = 1318, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist18;

    @Bin(order = 1319, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist19;

    @Bin(order = 1320, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist20;

    @Bin(order = 1321, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist21;

    @Bin(order = 1322, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist22;

    @Bin(order = 1323, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist23;

    @Bin(order = 1324, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist24;

    @Bin(order = 1325, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist25;

    @Bin(order = 1326, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist26;

    @Bin(order = 1327, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist27;

    @Bin(order = 1328, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist28;

    @Bin(order = 1329, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist29;

    @Bin(order = 1330, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist30;

    @Bin(order = 1331, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist31;

    @Bin(order = 1332, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist32;

    @Bin(order = 1333, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist33;

    @Bin(order = 1334, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist34;

    @Bin(order = 1335, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist35;

    @Bin(order = 1336, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist36;

    @Bin(order = 1337, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist37;

    @Bin(order = 1338, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist38;

    @Bin(order = 1339, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist39;

    @Bin(order = 1340, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist40;

    @Bin(order = 1341, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist41;

    @Bin(order = 1342, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist42;

    @Bin(order = 1343, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist43;

    @Bin(order = 1344, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist44;

    @Bin(order = 1345, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist45;

    @Bin(order = 1346, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist46;

    @Bin(order = 1347, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist47;

    @Bin(order = 1348, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist48;

    @Bin(order = 1349, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist49;

    @Bin(order = 1350, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist50;

    @Bin(order = 1351, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist51;

    @Bin(order = 1352, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist52;

    @Bin(order = 1353, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist53;

    @Bin(order = 1354, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist54;

    @Bin(order = 1355, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist55;

    @Bin(order = 1356, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist56;

    @Bin(order = 1357, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist57;

    @Bin(order = 1358, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist58;

    @Bin(order = 1359, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist59;

    @Bin(order = 1360, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist60;

    @Bin(order = 1401, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP01;

    @Bin(order = 1402, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP02;

    @Bin(order = 1403, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP03;

    @Bin(order = 1404, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP04;

    @Bin(order = 1405, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP05;

    @Bin(order = 1406, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP06;

    @Bin(order = 1407, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP07;

    @Bin(order = 1408, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP08;

    @Bin(order = 1409, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP09;

    @Bin(order = 1410, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP10;

    @Bin(order = 1411, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP11;

    @Bin(order = 1412, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP12;

    @Bin(order = 1413, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP13;

    @Bin(order = 1414, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP14;

    @Bin(order = 1415, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP15;

    @Bin(order = 1416, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP16;

    @Bin(order = 1417, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP17;

    @Bin(order = 1418, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP18;

    @Bin(order = 1419, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP19;

    @Bin(order = 1420, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP20;

    @Bin(order = 1421, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP21;

    @Bin(order = 1422, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP22;

    @Bin(order = 1423, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP23;

    @Bin(order = 1424, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP24;

    @Bin(order = 1425, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP25;

    @Bin(order = 1426, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP26;

    @Bin(order = 1427, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP27;

    @Bin(order = 1428, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP28;

    @Bin(order = 1429, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP29;

    @Bin(order = 1430, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP30;

    @Bin(order = 1431, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP31;

    @Bin(order = 1432, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP32;

    @Bin(order = 1433, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP33;

    @Bin(order = 1434, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP34;

    @Bin(order = 1435, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP35;

    @Bin(order = 1436, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP36;

    @Bin(order = 1437, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP37;

    @Bin(order = 1438, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP38;

    @Bin(order = 1439, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP39;

    @Bin(order = 1440, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP40;

    @Bin(order = 1441, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP41;

    @Bin(order = 1442, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP42;

    @Bin(order = 1443, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP43;

    @Bin(order = 1444, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP44;

    @Bin(order = 1445, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP45;

    @Bin(order = 1446, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP46;

    @Bin(order = 1447, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP47;

    @Bin(order = 1448, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP48;

    @Bin(order = 1449, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP49;

    @Bin(order = 1450, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP50;

    @Bin(order = 1451, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP51;

    @Bin(order = 1452, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP52;

    @Bin(order = 1453, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP53;

    @Bin(order = 1454, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP54;

    @Bin(order = 1455, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP55;

    @Bin(order = 1456, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP56;

    @Bin(order = 1457, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP57;

    @Bin(order = 1458, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP58;

    @Bin(order = 1459, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP59;

    @Bin(order = 1460, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP60;

    @Bin(order = 1501, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS01;

    @Bin(order = 1502, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS02;

    @Bin(order = 1503, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS03;

    @Bin(order = 1504, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS04;

    @Bin(order = 1505, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS05;

    @Bin(order = 1506, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS06;

    @Bin(order = 1507, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS07;

    @Bin(order = 1508, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS08;

    @Bin(order = 1509, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS09;

    @Bin(order = 1510, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS10;

    @Bin(order = 1511, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS11;

    @Bin(order = 1512, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS12;

    @Bin(order = 1513, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS13;

    @Bin(order = 1514, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS14;

    @Bin(order = 1515, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS15;

    @Bin(order = 1516, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS16;

    @Bin(order = 1517, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS17;

    @Bin(order = 1518, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS18;

    @Bin(order = 1519, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS19;

    @Bin(order = 1520, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS20;

    @Bin(order = 1521, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS21;

    @Bin(order = 1522, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS22;

    @Bin(order = 1523, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS23;

    @Bin(order = 1524, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS24;

    @Bin(order = 1525, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS25;

    @Bin(order = 1526, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS26;

    @Bin(order = 1527, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS27;

    @Bin(order = 1528, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS28;

    @Bin(order = 1529, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS29;

    @Bin(order = 1530, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS30;

    @Bin(order = 1531, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS31;

    @Bin(order = 1532, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS32;

    @Bin(order = 1533, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS33;

    @Bin(order = 1534, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS34;

    @Bin(order = 1535, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS35;

    @Bin(order = 1536, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS36;

    @Bin(order = 1537, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS37;

    @Bin(order = 1538, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS38;

    @Bin(order = 1539, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS39;

    @Bin(order = 1540, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS40;

    @Bin(order = 1541, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS41;

    @Bin(order = 1542, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS42;

    @Bin(order = 1543, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS43;

    @Bin(order = 1544, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS44;

    @Bin(order = 1545, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS45;

    @Bin(order = 1546, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS46;

    @Bin(order = 1547, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS47;

    @Bin(order = 1548, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS48;

    @Bin(order = 1549, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS49;

    @Bin(order = 1550, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS50;

    @Bin(order = 1551, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS51;

    @Bin(order = 1552, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS52;

    @Bin(order = 1553, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS53;

    @Bin(order = 1554, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS54;

    @Bin(order = 1555, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS55;

    @Bin(order = 1556, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS56;

    @Bin(order = 1557, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS57;

    @Bin(order = 1558, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS58;

    @Bin(order = 1559, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS59;

    @Bin(order = 1560, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS60;

    @Bin(order = 1601, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService01;

    @Bin(order = 1602, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService02;

    @Bin(order = 1603, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService03;

    @Bin(order = 1604, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService04;

    @Bin(order = 1605, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService05;

    @Bin(order = 1606, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService06;

    @Bin(order = 1607, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService07;

    @Bin(order = 1608, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService08;

    @Bin(order = 1609, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService09;

    @Bin(order = 1610, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService10;

    @Bin(order = 1611, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService11;

    @Bin(order = 1612, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService12;

    @Bin(order = 1613, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService13;

    @Bin(order = 1614, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService14;

    @Bin(order = 1615, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService15;

    @Bin(order = 1616, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService16;

    @Bin(order = 1617, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService17;

    @Bin(order = 1618, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService18;

    @Bin(order = 1619, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService19;

    @Bin(order = 1620, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService20;

    @Bin(order = 1621, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService21;

    @Bin(order = 1622, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService22;

    @Bin(order = 1623, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService23;

    @Bin(order = 1624, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService24;

    @Bin(order = 1625, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService25;

    @Bin(order = 1626, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService26;

    @Bin(order = 1627, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService27;

    @Bin(order = 1628, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService28;

    @Bin(order = 1629, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService29;

    @Bin(order = 1630, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService30;

    @Bin(order = 1631, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService31;

    @Bin(order = 1632, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService32;

    @Bin(order = 1633, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService33;

    @Bin(order = 1634, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService34;

    @Bin(order = 1635, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService35;

    @Bin(order = 1636, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService36;

    @Bin(order = 1637, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService37;

    @Bin(order = 1638, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService38;

    @Bin(order = 1639, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService39;

    @Bin(order = 1640, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService40;

    @Bin(order = 1641, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService41;

    @Bin(order = 1642, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService42;

    @Bin(order = 1643, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService43;

    @Bin(order = 1644, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService44;

    @Bin(order = 1645, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService45;

    @Bin(order = 1646, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService46;

    @Bin(order = 1647, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService47;

    @Bin(order = 1648, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService48;

    @Bin(order = 1649, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService49;

    @Bin(order = 1650, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService50;

    @Bin(order = 1651, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService51;

    @Bin(order = 1652, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService52;

    @Bin(order = 1653, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService53;

    @Bin(order = 1654, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService54;

    @Bin(order = 1655, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService55;

    @Bin(order = 1656, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService56;

    @Bin(order = 1657, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService57;

    @Bin(order = 1658, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService58;

    @Bin(order = 1659, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService59;

    @Bin(order = 1660, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService60;

    @Bin(order = 1701, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit01;

    @Bin(order = 1702, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit02;

    @Bin(order = 1703, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit03;

    @Bin(order = 1704, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit04;

    @Bin(order = 1705, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit05;

    @Bin(order = 1706, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit06;

    @Bin(order = 1707, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit07;

    @Bin(order = 1708, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit08;

    @Bin(order = 1709, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit09;

    @Bin(order = 1710, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit10;

    @Bin(order = 1711, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit11;

    @Bin(order = 1712, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit12;

    @Bin(order = 1713, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit13;

    @Bin(order = 1714, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit14;

    @Bin(order = 1715, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit15;

    @Bin(order = 1716, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit16;

    @Bin(order = 1717, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit17;

    @Bin(order = 1718, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit18;

    @Bin(order = 1719, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit19;

    @Bin(order = 1720, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit20;

    @Bin(order = 1721, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit21;

    @Bin(order = 1722, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit22;

    @Bin(order = 1723, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit23;

    @Bin(order = 1724, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit24;

    @Bin(order = 1725, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit25;

    @Bin(order = 1726, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit26;

    @Bin(order = 1727, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit27;

    @Bin(order = 1728, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit28;

    @Bin(order = 1729, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit29;

    @Bin(order = 1730, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit30;

    @Bin(order = 1731, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit31;

    @Bin(order = 1732, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit32;

    @Bin(order = 1733, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit33;

    @Bin(order = 1734, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit34;

    @Bin(order = 1735, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit35;

    @Bin(order = 1736, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit36;

    @Bin(order = 1737, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit37;

    @Bin(order = 1738, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit38;

    @Bin(order = 1739, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit39;

    @Bin(order = 1740, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit40;

    @Bin(order = 1741, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit41;

    @Bin(order = 1742, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit42;

    @Bin(order = 1743, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit43;

    @Bin(order = 1744, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit44;

    @Bin(order = 1745, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit45;

    @Bin(order = 1746, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit46;

    @Bin(order = 1747, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit47;

    @Bin(order = 1748, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit48;

    @Bin(order = 1749, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit49;

    @Bin(order = 1750, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit50;

    @Bin(order = 1751, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit51;

    @Bin(order = 1752, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit52;

    @Bin(order = 1753, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit53;

    @Bin(order = 1754, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit54;

    @Bin(order = 1755, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit55;

    @Bin(order = 1756, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit56;

    @Bin(order = 1757, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit57;

    @Bin(order = 1758, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit58;

    @Bin(order = 1759, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit59;

    @Bin(order = 1760, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit60;

    @Bin(order = 1801, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist01;

    @Bin(order = 1802, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist02;

    @Bin(order = 1803, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist03;

    @Bin(order = 1804, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist04;

    @Bin(order = 1805, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist05;

    @Bin(order = 1806, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist06;

    @Bin(order = 1807, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist07;

    @Bin(order = 1808, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist08;

    @Bin(order = 1809, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist09;

    @Bin(order = 1810, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist10;

    @Bin(order = 1811, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist11;

    @Bin(order = 1812, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist12;

    @Bin(order = 1813, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist13;

    @Bin(order = 1814, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist14;

    @Bin(order = 1815, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist15;

    @Bin(order = 1816, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist16;

    @Bin(order = 1817, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist17;

    @Bin(order = 1818, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist18;

    @Bin(order = 1819, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist19;

    @Bin(order = 1820, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist20;

    @Bin(order = 1821, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist21;

    @Bin(order = 1822, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist22;

    @Bin(order = 1823, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist23;

    @Bin(order = 1824, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist24;

    @Bin(order = 1825, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist25;

    @Bin(order = 1826, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist26;

    @Bin(order = 1827, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist27;

    @Bin(order = 1828, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist28;

    @Bin(order = 1829, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist29;

    @Bin(order = 1830, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist30;

    @Bin(order = 1831, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist31;

    @Bin(order = 1832, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist32;

    @Bin(order = 1833, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist33;

    @Bin(order = 1834, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist34;

    @Bin(order = 1835, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist35;

    @Bin(order = 1836, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist36;

    @Bin(order = 1837, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist37;

    @Bin(order = 1838, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist38;

    @Bin(order = 1839, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist39;

    @Bin(order = 1840, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist40;

    @Bin(order = 1841, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist41;

    @Bin(order = 1842, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist42;

    @Bin(order = 1843, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist43;

    @Bin(order = 1844, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist44;

    @Bin(order = 1845, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist45;

    @Bin(order = 1846, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist46;

    @Bin(order = 1847, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist47;

    @Bin(order = 1848, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist48;

    @Bin(order = 1849, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist49;

    @Bin(order = 1850, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist50;

    @Bin(order = 1851, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist51;

    @Bin(order = 1852, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist52;

    @Bin(order = 1853, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist53;

    @Bin(order = 1854, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist54;

    @Bin(order = 1855, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist55;

    @Bin(order = 1856, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist56;

    @Bin(order = 1857, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist57;

    @Bin(order = 1858, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist58;

    @Bin(order = 1859, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist59;

    @Bin(order = 1860, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist60;

    @Bin(order = 1901, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist01;

    @Bin(order = 1902, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist02;

    @Bin(order = 1903, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist03;

    @Bin(order = 1904, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist04;

    @Bin(order = 1905, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist05;

    @Bin(order = 1906, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist06;

    @Bin(order = 1907, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist07;

    @Bin(order = 1908, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist08;

    @Bin(order = 1909, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist09;

    @Bin(order = 1910, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist10;

    @Bin(order = 1911, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist11;

    @Bin(order = 1912, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist12;

    @Bin(order = 1913, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist13;

    @Bin(order = 1914, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist14;

    @Bin(order = 1915, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist15;

    @Bin(order = 1916, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist16;

    @Bin(order = 1917, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist17;

    @Bin(order = 1918, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist18;

    @Bin(order = 1919, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist19;

    @Bin(order = 1920, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist20;

    @Bin(order = 1921, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist21;

    @Bin(order = 1922, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist22;

    @Bin(order = 1923, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist23;

    @Bin(order = 1924, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist24;

    @Bin(order = 1925, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist25;

    @Bin(order = 1926, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist26;

    @Bin(order = 1927, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist27;

    @Bin(order = 1928, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist28;

    @Bin(order = 1929, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist29;

    @Bin(order = 1930, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist30;

    @Bin(order = 1931, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist31;

    @Bin(order = 1932, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist32;

    @Bin(order = 1933, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist33;

    @Bin(order = 1934, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist34;

    @Bin(order = 1935, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist35;

    @Bin(order = 1936, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist36;

    @Bin(order = 1937, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist37;

    @Bin(order = 1938, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist38;

    @Bin(order = 1939, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist39;

    @Bin(order = 1940, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist40;

    @Bin(order = 1941, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist41;

    @Bin(order = 1942, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist42;

    @Bin(order = 1943, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist43;

    @Bin(order = 1944, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist44;

    @Bin(order = 1945, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist45;

    @Bin(order = 1946, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist46;

    @Bin(order = 1947, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist47;

    @Bin(order = 1948, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist48;

    @Bin(order = 1949, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist49;

    @Bin(order = 1950, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist50;

    @Bin(order = 1951, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist51;

    @Bin(order = 1952, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist52;

    @Bin(order = 1953, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist53;

    @Bin(order = 1954, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist54;

    @Bin(order = 1955, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist55;

    @Bin(order = 1956, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist56;

    @Bin(order = 1957, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist57;

    @Bin(order = 1958, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist58;

    @Bin(order = 1959, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist59;

    @Bin(order = 1960, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist60;

    @Bin(order = 2001, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator01;

    @Bin(order = 2002, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator02;

    @Bin(order = 2003, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator03;

    @Bin(order = 2004, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator04;

    @Bin(order = 2005, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator05;

    @Bin(order = 2006, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator06;

    @Bin(order = 2007, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator07;

    @Bin(order = 2008, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator08;

    @Bin(order = 2009, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator09;

    @Bin(order = 2010, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator10;

    @Bin(order = 2011, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator11;

    @Bin(order = 2012, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator12;

    @Bin(order = 2013, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator13;

    @Bin(order = 2014, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator14;

    @Bin(order = 2015, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator15;

    @Bin(order = 2016, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator16;

    @Bin(order = 2017, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator17;

    @Bin(order = 2018, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator18;

    @Bin(order = 2019, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator19;

    @Bin(order = 2020, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator20;

    @Bin(order = 2021, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator21;

    @Bin(order = 2022, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator22;

    @Bin(order = 2023, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator23;

    @Bin(order = 2024, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator24;

    @Bin(order = 2025, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator25;

    @Bin(order = 2026, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator26;

    @Bin(order = 2027, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator27;

    @Bin(order = 2028, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator28;

    @Bin(order = 2029, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator29;

    @Bin(order = 2030, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator30;

    @Bin(order = 2031, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator31;

    @Bin(order = 2032, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator32;

    @Bin(order = 2033, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator33;

    @Bin(order = 2034, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator34;

    @Bin(order = 2035, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator35;

    @Bin(order = 2036, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator36;

    @Bin(order = 2037, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator37;

    @Bin(order = 2038, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator38;

    @Bin(order = 2039, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator39;

    @Bin(order = 2040, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator40;

    @Bin(order = 2041, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator41;

    @Bin(order = 2042, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator42;

    @Bin(order = 2043, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator43;

    @Bin(order = 2044, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator44;

    @Bin(order = 2045, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator45;

    @Bin(order = 2046, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator46;

    @Bin(order = 2047, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator47;

    @Bin(order = 2048, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator48;

    @Bin(order = 2049, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator49;

    @Bin(order = 2050, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator50;

    @Bin(order = 2051, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator51;

    @Bin(order = 2052, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator52;

    @Bin(order = 2053, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator53;

    @Bin(order = 2054, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator54;

    @Bin(order = 2055, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator55;

    @Bin(order = 2056, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator56;

    @Bin(order = 2057, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator57;

    @Bin(order = 2058, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator58;

    @Bin(order = 2059, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator59;

    @Bin(order = 2060, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator60;

    @Bin(order = 2101, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring01;

    @Bin(order = 2102, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring02;

    @Bin(order = 2103, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring03;

    @Bin(order = 2104, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring04;

    @Bin(order = 2105, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring05;

    @Bin(order = 2106, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring06;

    @Bin(order = 2107, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring07;

    @Bin(order = 2108, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring08;

    @Bin(order = 2109, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring09;

    @Bin(order = 2110, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring10;

    @Bin(order = 2111, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring11;

    @Bin(order = 2112, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring12;

    @Bin(order = 2113, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring13;

    @Bin(order = 2114, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring14;

    @Bin(order = 2115, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring15;

    @Bin(order = 2116, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring16;

    @Bin(order = 2117, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring17;

    @Bin(order = 2118, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring18;

    @Bin(order = 2119, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring19;

    @Bin(order = 2120, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring20;

    @Bin(order = 2121, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring21;

    @Bin(order = 2122, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring22;

    @Bin(order = 2123, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring23;

    @Bin(order = 2124, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring24;

    @Bin(order = 2125, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring25;

    @Bin(order = 2126, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring26;

    @Bin(order = 2127, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring27;

    @Bin(order = 2128, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring28;

    @Bin(order = 2129, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring29;

    @Bin(order = 2130, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring30;

    @Bin(order = 2131, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring31;

    @Bin(order = 2132, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring32;

    @Bin(order = 2133, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring33;

    @Bin(order = 2134, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring34;

    @Bin(order = 2135, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring35;

    @Bin(order = 2136, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring36;

    @Bin(order = 2137, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring37;

    @Bin(order = 2138, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring38;

    @Bin(order = 2139, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring39;

    @Bin(order = 2140, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring40;

    @Bin(order = 2141, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring41;

    @Bin(order = 2142, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring42;

    @Bin(order = 2143, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring43;

    @Bin(order = 2144, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring44;

    @Bin(order = 2145, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring45;

    @Bin(order = 2146, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring46;

    @Bin(order = 2147, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring47;

    @Bin(order = 2148, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring48;

    @Bin(order = 2149, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring49;

    @Bin(order = 2150, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring50;

    @Bin(order = 2151, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring51;

    @Bin(order = 2152, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring52;

    @Bin(order = 2153, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring53;

    @Bin(order = 2154, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring54;

    @Bin(order = 2155, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring55;

    @Bin(order = 2156, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring56;

    @Bin(order = 2157, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring57;

    @Bin(order = 2158, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring58;

    @Bin(order = 2159, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring59;

    @Bin(order = 2160, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring60;

    @Bin(order = 2201, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation01;

    @Bin(order = 2202, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation02;

    @Bin(order = 2203, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation03;

    @Bin(order = 2204, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation04;

    @Bin(order = 2205, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation05;

    @Bin(order = 2206, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation06;

    @Bin(order = 2207, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation07;

    @Bin(order = 2208, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation08;

    @Bin(order = 2209, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation09;

    @Bin(order = 2210, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation10;

    @Bin(order = 2211, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation11;

    @Bin(order = 2212, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation12;

    @Bin(order = 2213, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation13;

    @Bin(order = 2214, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation14;

    @Bin(order = 2215, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation15;

    @Bin(order = 2216, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation16;

    @Bin(order = 2217, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation17;

    @Bin(order = 2218, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation18;

    @Bin(order = 2219, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation19;

    @Bin(order = 2220, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation20;

    @Bin(order = 2221, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation21;

    @Bin(order = 2222, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation22;

    @Bin(order = 2223, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation23;

    @Bin(order = 2224, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation24;

    @Bin(order = 2225, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation25;

    @Bin(order = 2226, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation26;

    @Bin(order = 2227, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation27;

    @Bin(order = 2228, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation28;

    @Bin(order = 2229, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation29;

    @Bin(order = 2230, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation30;

    @Bin(order = 2231, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation31;

    @Bin(order = 2232, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation32;

    @Bin(order = 2233, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation33;

    @Bin(order = 2234, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation34;

    @Bin(order = 2235, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation35;

    @Bin(order = 2236, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation36;

    @Bin(order = 2237, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation37;

    @Bin(order = 2238, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation38;

    @Bin(order = 2239, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation39;

    @Bin(order = 2240, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation40;

    @Bin(order = 2241, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation41;

    @Bin(order = 2242, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation42;

    @Bin(order = 2243, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation43;

    @Bin(order = 2244, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation44;

    @Bin(order = 2245, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation45;

    @Bin(order = 2246, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation46;

    @Bin(order = 2247, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation47;

    @Bin(order = 2248, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation48;

    @Bin(order = 2249, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation49;

    @Bin(order = 2250, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation50;

    @Bin(order = 2251, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation51;

    @Bin(order = 2252, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation52;

    @Bin(order = 2253, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation53;

    @Bin(order = 2254, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation54;

    @Bin(order = 2255, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation55;

    @Bin(order = 2256, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation56;

    @Bin(order = 2257, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation57;

    @Bin(order = 2258, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation58;

    @Bin(order = 2259, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation59;

    @Bin(order = 2260, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation60;
    //</editor-fold>

    //<editor-fold desc="VEHICLE_DATA">
    @Bin(order = 2301, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rearFogLampsStatement;

    @Bin(order = 2302, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int frontFogLampsStatement;

    @Bin(order = 2401, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning01;

    @Bin(order = 2402, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning02;

    @Bin(order = 2403, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning03;

    @Bin(order = 2404, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning04;

    @Bin(order = 2405, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning05;

    @Bin(order = 2406, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning06;

    @Bin(order = 2407, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning07;

    @Bin(order = 2408, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning08;

    @Bin(order = 2409, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning09;

    @Bin(order = 2410, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning10;

    @Bin(order = 2411, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning11;

    @Bin(order = 2412, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning12;

    @Bin(order = 2413, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning13;

    @Bin(order = 2414, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning14;

    @Bin(order = 2415, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning15;

    @Bin(order = 2416, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning16;

    @Bin(order = 2417, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning17;

    @Bin(order = 2418, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning18;

    @Bin(order = 2419, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning19;

    @Bin(order = 2420, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning20;

    @Bin(order = 2421, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning21;

    @Bin(order = 2422, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning22;

    @Bin(order = 2423, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning23;

    @Bin(order = 2424, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning24;

    @Bin(order = 2425, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning25;

    @Bin(order = 2426, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning26;

    @Bin(order = 2427, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning27;

    @Bin(order = 2428, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning28;

    @Bin(order = 2429, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning29;

    @Bin(order = 2430, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning30;

    @Bin(order = 2431, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning31;

    @Bin(order = 2432, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning32;

    @Bin(order = 2433, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning33;

    @Bin(order = 2434, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning34;

    @Bin(order = 2435, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning35;

    @Bin(order = 2436, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning36;

    @Bin(order = 2437, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning37;

    @Bin(order = 2438, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning38;

    @Bin(order = 2439, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning39;

    @Bin(order = 2440, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning40;

    @Bin(order = 2441, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning41;

    @Bin(order = 2442, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning42;

    @Bin(order = 2443, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning43;

    @Bin(order = 2444, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning44;

    @Bin(order = 2445, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning45;

    @Bin(order = 2446, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning46;

    @Bin(order = 2447, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning47;

    @Bin(order = 2448, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning48;

    @Bin(order = 2449, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning49;

    @Bin(order = 2450, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning50;

    @Bin(order = 2451, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning51;

    @Bin(order = 2452, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning52;

    @Bin(order = 2453, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning53;

    @Bin(order = 2454, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning54;

    @Bin(order = 2455, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning55;

    @Bin(order = 2456, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning56;

    @Bin(order = 2457, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning57;

    @Bin(order = 2458, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning58;

    @Bin(order = 2459, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning59;

    @Bin(order = 2460, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning60;

    @Bin(order = 2501, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int outsideTemperature;

    @Bin(order = 2502, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] fuelInstantConsumption;

    @Bin(order = 2503, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] fuelTotalConsumption;

    @Bin(order = 2504, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int ignition;

    @Bin(order = 2601, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed01;

    @Bin(order = 2602, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed02;

    @Bin(order = 2603, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed03;

    @Bin(order = 2604, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed04;

    @Bin(order = 2605, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed05;

    @Bin(order = 2606, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed06;

    @Bin(order = 2607, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed07;

    @Bin(order = 2608, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed08;

    @Bin(order = 2609, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed09;

    @Bin(order = 2610, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed10;

    @Bin(order = 2611, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed11;

    @Bin(order = 2612, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed12;

    @Bin(order = 2613, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed13;

    @Bin(order = 2614, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed14;

    @Bin(order = 2615, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed15;

    @Bin(order = 2616, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed16;

    @Bin(order = 2617, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed17;

    @Bin(order = 2618, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed18;

    @Bin(order = 2619, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed19;

    @Bin(order = 2620, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed20;

    @Bin(order = 2621, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed21;

    @Bin(order = 2622, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed22;

    @Bin(order = 2623, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed23;

    @Bin(order = 2624, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed24;

    @Bin(order = 2625, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed25;

    @Bin(order = 2626, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed26;

    @Bin(order = 2627, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed27;

    @Bin(order = 2628, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed28;

    @Bin(order = 2629, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed29;

    @Bin(order = 2630, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed30;

    @Bin(order = 2631, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed31;

    @Bin(order = 2632, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed32;

    @Bin(order = 2633, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed33;

    @Bin(order = 2634, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed34;

    @Bin(order = 2635, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed35;

    @Bin(order = 2636, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed36;

    @Bin(order = 2637, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed37;

    @Bin(order = 2638, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed38;

    @Bin(order = 2639, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed39;

    @Bin(order = 2640, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed40;

    @Bin(order = 2641, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed41;

    @Bin(order = 2642, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed42;

    @Bin(order = 2643, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed43;

    @Bin(order = 2644, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed44;

    @Bin(order = 2645, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed45;

    @Bin(order = 2646, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed46;

    @Bin(order = 2647, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed47;

    @Bin(order = 2648, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed48;

    @Bin(order = 2649, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed49;

    @Bin(order = 2650, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed50;

    @Bin(order = 2651, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed51;

    @Bin(order = 2652, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed52;

    @Bin(order = 2653, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed53;

    @Bin(order = 2654, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed54;

    @Bin(order = 2655, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed55;

    @Bin(order = 2656, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed56;

    @Bin(order = 2657, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed57;

    @Bin(order = 2658, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed58;

    @Bin(order = 2659, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed59;

    @Bin(order = 2660, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed60;

    @Bin(order = 2701, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity01;

    @Bin(order = 2702, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity02;

    @Bin(order = 2703, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity03;

    @Bin(order = 2704, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity04;

    @Bin(order = 2705, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity05;

    @Bin(order = 2706, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity06;

    @Bin(order = 2707, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity07;

    @Bin(order = 2708, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity08;

    @Bin(order = 2709, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity09;

    @Bin(order = 2710, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity10;

    @Bin(order = 2711, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity11;

    @Bin(order = 2712, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity12;

    @Bin(order = 2713, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity13;

    @Bin(order = 2714, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity14;

    @Bin(order = 2715, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity15;

    @Bin(order = 2716, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity16;

    @Bin(order = 2717, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity17;

    @Bin(order = 2718, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity18;

    @Bin(order = 2719, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity19;

    @Bin(order = 2720, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity20;

    @Bin(order = 2721, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity21;

    @Bin(order = 2722, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity22;

    @Bin(order = 2723, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity23;

    @Bin(order = 2724, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity24;

    @Bin(order = 2725, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity25;

    @Bin(order = 2726, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity26;

    @Bin(order = 2727, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity27;

    @Bin(order = 2728, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity28;

    @Bin(order = 2729, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity29;

    @Bin(order = 2730, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity30;

    @Bin(order = 2731, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity31;

    @Bin(order = 2732, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity32;

    @Bin(order = 2733, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity33;

    @Bin(order = 2734, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity34;

    @Bin(order = 2735, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity35;

    @Bin(order = 2736, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity36;

    @Bin(order = 2737, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity37;

    @Bin(order = 2738, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity38;

    @Bin(order = 2739, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity39;

    @Bin(order = 2740, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity40;

    @Bin(order = 2741, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity41;

    @Bin(order = 2742, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity42;

    @Bin(order = 2743, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity43;

    @Bin(order = 2744, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity44;

    @Bin(order = 2745, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity45;

    @Bin(order = 2746, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity46;

    @Bin(order = 2747, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity47;

    @Bin(order = 2748, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity48;

    @Bin(order = 2749, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity49;

    @Bin(order = 2750, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity50;

    @Bin(order = 2751, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity51;

    @Bin(order = 2752, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity52;

    @Bin(order = 2753, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity53;

    @Bin(order = 2754, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity54;

    @Bin(order = 2755, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity55;

    @Bin(order = 2756, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity56;

    @Bin(order = 2757, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity57;

    @Bin(order = 2758, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity58;

    @Bin(order = 2759, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity59;

    @Bin(order = 2760, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity60;

    @Bin(order = 2801, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] lifetimeMileage;

    @Bin(order = 2802, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] maintenance;

    @Bin(order = 2803, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int fuelLevel;

    @Bin(order = 2804, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int oilTemperature;

    @Bin(order = 2805, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int gmpStatus;

    @Bin(order = 2901, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement01;

    @Bin(order = 2902, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement02;

    @Bin(order = 2903, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement03;

    @Bin(order = 2904, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement04;

    @Bin(order = 2905, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement05;

    @Bin(order = 2906, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement06;

    @Bin(order = 2907, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement07;

    @Bin(order = 2908, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement08;

    @Bin(order = 2909, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement09;

    @Bin(order = 2910, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement10;

    @Bin(order = 2911, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement11;

    @Bin(order = 2912, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement12;

    @Bin(order = 2913, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement13;

    @Bin(order = 2914, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement14;

    @Bin(order = 2915, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement15;

    @Bin(order = 2916, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement16;

    @Bin(order = 2917, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement17;

    @Bin(order = 2918, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement18;

    @Bin(order = 2919, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement19;

    @Bin(order = 2920, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement20;

    @Bin(order = 2921, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement21;

    @Bin(order = 2922, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement22;

    @Bin(order = 2923, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement23;

    @Bin(order = 2924, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement24;

    @Bin(order = 2925, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement25;

    @Bin(order = 2926, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement26;

    @Bin(order = 2927, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement27;

    @Bin(order = 2928, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement28;

    @Bin(order = 2929, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement29;

    @Bin(order = 2930, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement30;

    @Bin(order = 2931, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement31;

    @Bin(order = 2932, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement32;

    @Bin(order = 2933, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement33;

    @Bin(order = 2934, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement34;

    @Bin(order = 2935, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement35;

    @Bin(order = 2936, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement36;

    @Bin(order = 2937, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement37;

    @Bin(order = 2938, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement38;

    @Bin(order = 2939, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement39;

    @Bin(order = 2940, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement40;

    @Bin(order = 2941, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement41;

    @Bin(order = 2942, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement42;

    @Bin(order = 2943, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement43;

    @Bin(order = 2944, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement44;

    @Bin(order = 2945, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement45;

    @Bin(order = 2946, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement46;

    @Bin(order = 2947, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement47;

    @Bin(order = 2948, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement48;

    @Bin(order = 2949, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement49;

    @Bin(order = 2950, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement50;

    @Bin(order = 2951, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement51;

    @Bin(order = 2952, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement52;

    @Bin(order = 2953, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement53;

    @Bin(order = 2954, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement54;

    @Bin(order = 2955, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement55;

    @Bin(order = 2956, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement56;

    @Bin(order = 2957, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement57;

    @Bin(order = 2958, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement58;

    @Bin(order = 2959, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement59;

    @Bin(order = 2960, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightIndicatorStatement60;

    @Bin(order = 3001, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement01;

    @Bin(order = 3002, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement02;

    @Bin(order = 3003, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement03;

    @Bin(order = 3004, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement04;

    @Bin(order = 3005, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement05;

    @Bin(order = 3006, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement06;

    @Bin(order = 3007, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement07;

    @Bin(order = 3008, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement08;

    @Bin(order = 3009, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement09;

    @Bin(order = 3010, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement10;

    @Bin(order = 3011, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement11;

    @Bin(order = 3012, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement12;

    @Bin(order = 3013, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement13;

    @Bin(order = 3014, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement14;

    @Bin(order = 3015, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement15;

    @Bin(order = 3016, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement16;

    @Bin(order = 3017, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement17;

    @Bin(order = 3018, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement18;

    @Bin(order = 3019, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement19;

    @Bin(order = 3020, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement20;

    @Bin(order = 3021, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement21;

    @Bin(order = 3022, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement22;

    @Bin(order = 3023, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement23;

    @Bin(order = 3024, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement24;

    @Bin(order = 3025, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement25;

    @Bin(order = 3026, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement26;

    @Bin(order = 3027, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement27;

    @Bin(order = 3028, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement28;

    @Bin(order = 3029, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement29;

    @Bin(order = 3030, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement30;

    @Bin(order = 3031, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement31;

    @Bin(order = 3032, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement32;

    @Bin(order = 3033, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement33;

    @Bin(order = 3034, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement34;

    @Bin(order = 3035, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement35;

    @Bin(order = 3036, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement36;

    @Bin(order = 3037, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement37;

    @Bin(order = 3038, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement38;

    @Bin(order = 3039, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement39;

    @Bin(order = 3040, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement40;

    @Bin(order = 3041, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement41;

    @Bin(order = 3042, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement42;

    @Bin(order = 3043, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement43;

    @Bin(order = 3044, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement44;

    @Bin(order = 3045, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement45;

    @Bin(order = 3046, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement46;

    @Bin(order = 3047, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement47;

    @Bin(order = 3048, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement48;

    @Bin(order = 3049, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement49;

    @Bin(order = 3050, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement50;

    @Bin(order = 3051, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement51;

    @Bin(order = 3052, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement52;

    @Bin(order = 3053, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement53;

    @Bin(order = 3054, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement54;

    @Bin(order = 3055, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement55;

    @Bin(order = 3056, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement56;

    @Bin(order = 3057, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement57;

    @Bin(order = 3058, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement58;

    @Bin(order = 3059, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement59;

    @Bin(order = 3060, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftIndicatorStatement60;

    @Bin(order = 3101, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int ecallTriggering;

    @Bin(order = 3102, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int alertOfFuelLowLevel;

    @Bin(order = 3103, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int alertOfSCRLowLevel;

    @Bin(order = 3104, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] residualAutonomy;
    //</editor-fold>

    @Bin(order = 3201, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int privacyModeV2;

    //<editor-fold desc="HOUR_DATE_FIRST_DATA_COLLECT">

    public int getYearOfCollection() {
        return STARTING_YEAR + yearOfCollection;
    }

    public int getMonthOfCollection() {
        return monthOfCollection;
    }

    public int getDayOfCollection() {
        return dayOfCollection;
    }

    public int getHourOfCollection() {
        return hourOfCollection;
    }

    public int getMinuteOfCollection() {
        return minuteOfCollection;
    }

    public int getSecondOfCollection() {
        return secondOfCollection;
    }
    //</editor-fold>

    //<editor-fold desc="HOUR_DATE_UPSTREAM">
    public int getYearOfTransmission() {
        return STARTING_YEAR + yearOfTransmission;
    }

    public int getMonthOfTransmission() {
        return monthOfTransmission;
    }

    public int getDayOfTransmission() {
        return dayOfTransmission;
    }

    public int getHourOfTransmission() {
        return hourOfTransmission;
    }

    public int getMinuteOfTransmission() {
        return minuteOfTransmission;
    }

    public int getSecondOfTransmission() {
        return secondOfTransmission;
    }
    //</editor-fold>

    public Instant getDateOfCollection() {
        return DateUtils.timeUnitsToInstant(getYearOfCollection(),
                getMonthOfCollection(),
                getDayOfCollection(),
                getHourOfCollection(),
                getMinuteOfCollection(),
                getSecondOfCollection());
    }

    public Instant getDateOfTransmission() {
        return DateUtils.timeUnitsToInstant(getYearOfTransmission(),
                getMonthOfTransmission(),
                getDayOfTransmission(),
                getHourOfTransmission(),
                getMinuteOfTransmission(),
                getSecondOfTransmission());
    }

    public int getIdTrip() {
        return ByteUtils.asInt(idTrip);
    }

    //<editor-fold desc="ID_FRAME">
    public int getIdFrame() {
        return ByteUtils.asInt(idFrame);
    }
    //</editor-fold>

    //<editor-fold desc="PRIVACY_MODE_STATE">
    public int getPrivacyMode() {
        return privacyMode;
    }
    //</editor-fold>

    //<editor-fold desc="HOUR_DATE_EVENT">
    public int getYearOfEvent() {
        return STARTING_YEAR + yearOfEvent;
    }

    public int getMonthOfEvent() {
        return monthOfEvent;
    }

    public int getDayOfEvent() {
        return dayOfEvent;
    }

    public int getHourOfEvent() {
        return hourOfEvent;
    }

    public int getMinuteOfEvent() {
        return minuteOfEvent;
    }

    public int getSecondOfEvent() {
        return secondOfEvent;
    }
    //</editor-fold>

    public Instant getDateOfEvent() {
        return DateUtils.timeUnitsToInstant(getYearOfEvent(),
                getMonthOfEvent(),
                getDayOfEvent(),
                getHourOfEvent(),
                getMinuteOfEvent(),
                getSecondOfEvent());
    }

    //<editor-fold desc="TRIGGER_TYPE">
    public int getTriggerType() {
        return triggerType;
    }
    //</editor-fold>

    //<editor-fold desc="VIN_VEHICLE">
    public String getVin() {
        return ByteUtils.asString(vin);
    }
    //</editor-fold>

    //<editor-fold desc="PREVIOUS_EVENT_FRAME_DATA">
    public BigDecimal getPreviousLifetimeMileage() {
        return BigDecimal.valueOf(ByteUtils.asInt(previousLifetimeMileage) * LIFETIME_MILEAGE_FACTOR).setScale(2, RoundingMode.FLOOR);
    }

    public int getPreviousFuelLevel() {
        return previousFuelLevel;
    }

    public int getPreviousPrivacyMode() {
        return previousPrivacyMode;
    }

    public int getPreviousTriggerType() {
        return previousTriggerType;
    }

    public int getPreviousYearOfEvent() {
        return STARTING_YEAR + previousYearOfEvent;
    }

    public int getPreviousMonthOfEvent() {
        return previousMonthOfEvent;
    }

    public int getPreviousDayOfEvent() {
        return previousDayOfEvent;
    }

    public int getPreviousHourOfEvent() {
        return previousHourOfEvent;
    }

    public int getPreviousMinuteOfEvent() {
        return previousMinuteOfEvent;
    }

    public int getPreviousSecondOfEvent() {
        return previousSecondOfEvent;
    }

    public Instant getPreviousDateOfEvent() {
        return DateUtils.timeUnitsToInstant(false, getPreviousYearOfEvent(),
                getPreviousMonthOfEvent(),
                getPreviousDayOfEvent(),
                getPreviousHourOfEvent(),
                getPreviousMinuteOfEvent(),
                getPreviousSecondOfEvent());
    }

    public int getPreviousIdFrame() {
        return ByteUtils.asInt(previousIdFrame);
    }

    public int getPreviousAltitude() {
        return ByteUtils.asInt(previousAltitude);
    }

    public int getPreviousHeading() {
        return ByteUtils.asInt(previousHeading);
    }

    public int getPreviousLongitude() {
        return ByteUtils.asInt(previousLongitude);
    }

    public int getPreviousLatitude() {
        return ByteUtils.asInt(previousLatitude);
    }

    public int getPreviousGPSSignalQuality() {
        return previousGPSSignalQuality;
    }

    public int getPreviousVehicleLocationType() {
        return previousVehicleLocationType;
    }
    //</editor-fold>

    //<editor-fold desc="GPS_LOCATION">
    public List<Integer> getAltitudes() {
        return CollectionUtils.addAll(
                ByteUtils.asInt(altitude01),
                ByteUtils.asInt(altitude02),
                ByteUtils.asInt(altitude03),
                ByteUtils.asInt(altitude04),
                ByteUtils.asInt(altitude05),
                ByteUtils.asInt(altitude06),
                ByteUtils.asInt(altitude07),
                ByteUtils.asInt(altitude08),
                ByteUtils.asInt(altitude09),
                ByteUtils.asInt(altitude10),
                ByteUtils.asInt(altitude11),
                ByteUtils.asInt(altitude12),
                ByteUtils.asInt(altitude13),
                ByteUtils.asInt(altitude14),
                ByteUtils.asInt(altitude15),
                ByteUtils.asInt(altitude16),
                ByteUtils.asInt(altitude17),
                ByteUtils.asInt(altitude18),
                ByteUtils.asInt(altitude19),
                ByteUtils.asInt(altitude20),
                ByteUtils.asInt(altitude21),
                ByteUtils.asInt(altitude22),
                ByteUtils.asInt(altitude23),
                ByteUtils.asInt(altitude24),
                ByteUtils.asInt(altitude25),
                ByteUtils.asInt(altitude26),
                ByteUtils.asInt(altitude27),
                ByteUtils.asInt(altitude28),
                ByteUtils.asInt(altitude29),
                ByteUtils.asInt(altitude30),
                ByteUtils.asInt(altitude31),
                ByteUtils.asInt(altitude32),
                ByteUtils.asInt(altitude33),
                ByteUtils.asInt(altitude34),
                ByteUtils.asInt(altitude35),
                ByteUtils.asInt(altitude36),
                ByteUtils.asInt(altitude37),
                ByteUtils.asInt(altitude38),
                ByteUtils.asInt(altitude39),
                ByteUtils.asInt(altitude40),
                ByteUtils.asInt(altitude41),
                ByteUtils.asInt(altitude42),
                ByteUtils.asInt(altitude43),
                ByteUtils.asInt(altitude44),
                ByteUtils.asInt(altitude45),
                ByteUtils.asInt(altitude46),
                ByteUtils.asInt(altitude47),
                ByteUtils.asInt(altitude48),
                ByteUtils.asInt(altitude49),
                ByteUtils.asInt(altitude50),
                ByteUtils.asInt(altitude51),
                ByteUtils.asInt(altitude52),
                ByteUtils.asInt(altitude53),
                ByteUtils.asInt(altitude54),
                ByteUtils.asInt(altitude55),
                ByteUtils.asInt(altitude56),
                ByteUtils.asInt(altitude57),
                ByteUtils.asInt(altitude58),
                ByteUtils.asInt(altitude59),
                ByteUtils.asInt(altitude60));
    }

    public List<Integer> getHeadings() {
        return CollectionUtils.addAll(
                ByteUtils.asInt(heading01),
                ByteUtils.asInt(heading02),
                ByteUtils.asInt(heading03),
                ByteUtils.asInt(heading04),
                ByteUtils.asInt(heading05),
                ByteUtils.asInt(heading06),
                ByteUtils.asInt(heading07),
                ByteUtils.asInt(heading08),
                ByteUtils.asInt(heading09),
                ByteUtils.asInt(heading10),
                ByteUtils.asInt(heading11),
                ByteUtils.asInt(heading12),
                ByteUtils.asInt(heading13),
                ByteUtils.asInt(heading14),
                ByteUtils.asInt(heading15),
                ByteUtils.asInt(heading16),
                ByteUtils.asInt(heading17),
                ByteUtils.asInt(heading18),
                ByteUtils.asInt(heading19),
                ByteUtils.asInt(heading20),
                ByteUtils.asInt(heading21),
                ByteUtils.asInt(heading22),
                ByteUtils.asInt(heading23),
                ByteUtils.asInt(heading24),
                ByteUtils.asInt(heading25),
                ByteUtils.asInt(heading26),
                ByteUtils.asInt(heading27),
                ByteUtils.asInt(heading28),
                ByteUtils.asInt(heading29),
                ByteUtils.asInt(heading30),
                ByteUtils.asInt(heading31),
                ByteUtils.asInt(heading32),
                ByteUtils.asInt(heading33),
                ByteUtils.asInt(heading34),
                ByteUtils.asInt(heading35),
                ByteUtils.asInt(heading36),
                ByteUtils.asInt(heading37),
                ByteUtils.asInt(heading38),
                ByteUtils.asInt(heading39),
                ByteUtils.asInt(heading40),
                ByteUtils.asInt(heading41),
                ByteUtils.asInt(heading42),
                ByteUtils.asInt(heading43),
                ByteUtils.asInt(heading44),
                ByteUtils.asInt(heading45),
                ByteUtils.asInt(heading46),
                ByteUtils.asInt(heading47),
                ByteUtils.asInt(heading48),
                ByteUtils.asInt(heading49),
                ByteUtils.asInt(heading50),
                ByteUtils.asInt(heading51),
                ByteUtils.asInt(heading52),
                ByteUtils.asInt(heading53),
                ByteUtils.asInt(heading54),
                ByteUtils.asInt(heading55),
                ByteUtils.asInt(heading56),
                ByteUtils.asInt(heading57),
                ByteUtils.asInt(heading58),
                ByteUtils.asInt(heading59),
                ByteUtils.asInt(heading60)
        );
    }

    public List<Integer> getLatitudes() {
        return CollectionUtils.addAll(
                ByteUtils.asInt(latitude01),
                ByteUtils.asInt(latitude02),
                ByteUtils.asInt(latitude03),
                ByteUtils.asInt(latitude04),
                ByteUtils.asInt(latitude05),
                ByteUtils.asInt(latitude06),
                ByteUtils.asInt(latitude07),
                ByteUtils.asInt(latitude08),
                ByteUtils.asInt(latitude09),
                ByteUtils.asInt(latitude10),
                ByteUtils.asInt(latitude11),
                ByteUtils.asInt(latitude12),
                ByteUtils.asInt(latitude13),
                ByteUtils.asInt(latitude14),
                ByteUtils.asInt(latitude15),
                ByteUtils.asInt(latitude16),
                ByteUtils.asInt(latitude17),
                ByteUtils.asInt(latitude18),
                ByteUtils.asInt(latitude19),
                ByteUtils.asInt(latitude20),
                ByteUtils.asInt(latitude21),
                ByteUtils.asInt(latitude22),
                ByteUtils.asInt(latitude23),
                ByteUtils.asInt(latitude24),
                ByteUtils.asInt(latitude25),
                ByteUtils.asInt(latitude26),
                ByteUtils.asInt(latitude27),
                ByteUtils.asInt(latitude28),
                ByteUtils.asInt(latitude29),
                ByteUtils.asInt(latitude30),
                ByteUtils.asInt(latitude31),
                ByteUtils.asInt(latitude32),
                ByteUtils.asInt(latitude33),
                ByteUtils.asInt(latitude34),
                ByteUtils.asInt(latitude35),
                ByteUtils.asInt(latitude36),
                ByteUtils.asInt(latitude37),
                ByteUtils.asInt(latitude38),
                ByteUtils.asInt(latitude39),
                ByteUtils.asInt(latitude40),
                ByteUtils.asInt(latitude41),
                ByteUtils.asInt(latitude42),
                ByteUtils.asInt(latitude43),
                ByteUtils.asInt(latitude44),
                ByteUtils.asInt(latitude45),
                ByteUtils.asInt(latitude46),
                ByteUtils.asInt(latitude47),
                ByteUtils.asInt(latitude48),
                ByteUtils.asInt(latitude49),
                ByteUtils.asInt(latitude50),
                ByteUtils.asInt(latitude51),
                ByteUtils.asInt(latitude52),
                ByteUtils.asInt(latitude53),
                ByteUtils.asInt(latitude54),
                ByteUtils.asInt(latitude55),
                ByteUtils.asInt(latitude56),
                ByteUtils.asInt(latitude57),
                ByteUtils.asInt(latitude58),
                ByteUtils.asInt(latitude59),
                ByteUtils.asInt(latitude60)
        );
    }

    public List<Integer> getLongitudes() {
        return CollectionUtils.addAll(
                ByteUtils.asInt(longitude01),
                ByteUtils.asInt(longitude02),
                ByteUtils.asInt(longitude03),
                ByteUtils.asInt(longitude04),
                ByteUtils.asInt(longitude05),
                ByteUtils.asInt(longitude06),
                ByteUtils.asInt(longitude07),
                ByteUtils.asInt(longitude08),
                ByteUtils.asInt(longitude09),
                ByteUtils.asInt(longitude10),
                ByteUtils.asInt(longitude11),
                ByteUtils.asInt(longitude12),
                ByteUtils.asInt(longitude13),
                ByteUtils.asInt(longitude14),
                ByteUtils.asInt(longitude15),
                ByteUtils.asInt(longitude16),
                ByteUtils.asInt(longitude17),
                ByteUtils.asInt(longitude18),
                ByteUtils.asInt(longitude19),
                ByteUtils.asInt(longitude20),
                ByteUtils.asInt(longitude21),
                ByteUtils.asInt(longitude22),
                ByteUtils.asInt(longitude23),
                ByteUtils.asInt(longitude24),
                ByteUtils.asInt(longitude25),
                ByteUtils.asInt(longitude26),
                ByteUtils.asInt(longitude27),
                ByteUtils.asInt(longitude28),
                ByteUtils.asInt(longitude29),
                ByteUtils.asInt(longitude30),
                ByteUtils.asInt(longitude31),
                ByteUtils.asInt(longitude32),
                ByteUtils.asInt(longitude33),
                ByteUtils.asInt(longitude34),
                ByteUtils.asInt(longitude35),
                ByteUtils.asInt(longitude36),
                ByteUtils.asInt(longitude37),
                ByteUtils.asInt(longitude38),
                ByteUtils.asInt(longitude39),
                ByteUtils.asInt(longitude40),
                ByteUtils.asInt(longitude41),
                ByteUtils.asInt(longitude42),
                ByteUtils.asInt(longitude43),
                ByteUtils.asInt(longitude44),
                ByteUtils.asInt(longitude45),
                ByteUtils.asInt(longitude46),
                ByteUtils.asInt(longitude47),
                ByteUtils.asInt(longitude48),
                ByteUtils.asInt(longitude49),
                ByteUtils.asInt(longitude50),
                ByteUtils.asInt(longitude51),
                ByteUtils.asInt(longitude52),
                ByteUtils.asInt(longitude53),
                ByteUtils.asInt(longitude54),
                ByteUtils.asInt(longitude55),
                ByteUtils.asInt(longitude56),
                ByteUtils.asInt(longitude57),
                ByteUtils.asInt(longitude58),
                ByteUtils.asInt(longitude59),
                ByteUtils.asInt(longitude60)
        );
    }

    public List<Integer> getGpsSignalQualities() {
        return CollectionUtils.addAll(
                gpsSignalQuality01,
                gpsSignalQuality02,
                gpsSignalQuality03,
                gpsSignalQuality04,
                gpsSignalQuality05,
                gpsSignalQuality06,
                gpsSignalQuality07,
                gpsSignalQuality08,
                gpsSignalQuality09,
                gpsSignalQuality10,
                gpsSignalQuality11,
                gpsSignalQuality12,
                gpsSignalQuality13,
                gpsSignalQuality14,
                gpsSignalQuality15,
                gpsSignalQuality16,
                gpsSignalQuality17,
                gpsSignalQuality18,
                gpsSignalQuality19,
                gpsSignalQuality20,
                gpsSignalQuality21,
                gpsSignalQuality22,
                gpsSignalQuality23,
                gpsSignalQuality24,
                gpsSignalQuality25,
                gpsSignalQuality26,
                gpsSignalQuality27,
                gpsSignalQuality28,
                gpsSignalQuality29,
                gpsSignalQuality30,
                gpsSignalQuality31,
                gpsSignalQuality32,
                gpsSignalQuality33,
                gpsSignalQuality34,
                gpsSignalQuality35,
                gpsSignalQuality36,
                gpsSignalQuality37,
                gpsSignalQuality38,
                gpsSignalQuality39,
                gpsSignalQuality40,
                gpsSignalQuality41,
                gpsSignalQuality42,
                gpsSignalQuality43,
                gpsSignalQuality44,
                gpsSignalQuality45,
                gpsSignalQuality46,
                gpsSignalQuality47,
                gpsSignalQuality48,
                gpsSignalQuality49,
                gpsSignalQuality50,
                gpsSignalQuality51,
                gpsSignalQuality52,
                gpsSignalQuality53,
                gpsSignalQuality54,
                gpsSignalQuality55,
                gpsSignalQuality56,
                gpsSignalQuality57,
                gpsSignalQuality58,
                gpsSignalQuality59,
                gpsSignalQuality60
        );
    }

    public List<Integer> getVehicleLocationTypes() {
        return CollectionUtils.addAll(
                vehicleLocationType01,
                vehicleLocationType02,
                vehicleLocationType03,
                vehicleLocationType04,
                vehicleLocationType05,
                vehicleLocationType06,
                vehicleLocationType07,
                vehicleLocationType08,
                vehicleLocationType09,
                vehicleLocationType10,
                vehicleLocationType11,
                vehicleLocationType12,
                vehicleLocationType13,
                vehicleLocationType14,
                vehicleLocationType15,
                vehicleLocationType16,
                vehicleLocationType17,
                vehicleLocationType18,
                vehicleLocationType19,
                vehicleLocationType20,
                vehicleLocationType21,
                vehicleLocationType22,
                vehicleLocationType23,
                vehicleLocationType24,
                vehicleLocationType25,
                vehicleLocationType26,
                vehicleLocationType27,
                vehicleLocationType28,
                vehicleLocationType29,
                vehicleLocationType30,
                vehicleLocationType31,
                vehicleLocationType32,
                vehicleLocationType33,
                vehicleLocationType34,
                vehicleLocationType35,
                vehicleLocationType36,
                vehicleLocationType37,
                vehicleLocationType38,
                vehicleLocationType39,
                vehicleLocationType40,
                vehicleLocationType41,
                vehicleLocationType42,
                vehicleLocationType43,
                vehicleLocationType44,
                vehicleLocationType45,
                vehicleLocationType46,
                vehicleLocationType47,
                vehicleLocationType48,
                vehicleLocationType49,
                vehicleLocationType50,
                vehicleLocationType51,
                vehicleLocationType52,
                vehicleLocationType53,
                vehicleLocationType54,
                vehicleLocationType55,
                vehicleLocationType56,
                vehicleLocationType57,
                vehicleLocationType58,
                vehicleLocationType59,
                vehicleLocationType60
        );
    }
    //</editor-fold>

    //<editor-fold desc="CRASH_DATA">
    public int getRearHighSpeedCrashInfo() {
        return rearHighSpeedCrashInfo;
    }

    public int getRearMediumSpeedCrashInfo() {
        return rearMediumSpeedCrashInfo;
    }

    public int getRearSlowSpeedCrashInfo() {
        return rearSlowSpeedCrashInfo;
    }

    public int getRearReparabilitySpeedCrashInfo() {
        return rearReparabilitySpeedCrashInfo;
    }

    public int getPedestrianCrashInfo() {
        return pedestrianCrashInfo;
    }

    public int getHighSpeedFrontCrashInfo() {
        return highSpeedFrontCrashInfo;
    }

    public int getMediumSpeedN1FrontCrashInfo() {
        return mediumSpeedN1FrontCrashInfo;
    }

    public int getMediumSpeedN2FrontCrashInfo() {
        return mediumSpeedN2FrontCrashInfo;
    }

    public int getLowSpeedFrontCrashInfo() {
        return lowSpeedFrontCrashInfo;
    }

    public int getFrontReparabilityCrashInfo() {
        return frontReparabilityCrashInfo;
    }

    public int getRearHighSpeedLateralCrashInfo() {
        return rearHighSpeedLateralCrashInfo;
    }

    public int getRearMediumSpeedLateralCrashInfo() {
        return rearMediumSpeedLateralCrashInfo;
    }

    public int getRearLowSpeedLateralCrashInfo() {
        return rearLowSpeedLateralCrashInfo;
    }

    public int getRearRepairabilityCrashInfo() {
        return rearRepairabilityCrashInfo;
    }

    public int getTippedOver() {
        return tippedOver;
    }
    //</editor-fold>

    //<editor-fold desc="ADAS_DATA">
    public List<Integer> getRearParkings() {
        return CollectionUtils.addAll(
                rearParking01,
                rearParking02,
                rearParking03,
                rearParking04,
                rearParking05,
                rearParking06,
                rearParking07,
                rearParking08,
                rearParking09,
                rearParking10,
                rearParking11,
                rearParking12,
                rearParking13,
                rearParking14,
                rearParking15,
                rearParking16,
                rearParking17,
                rearParking18,
                rearParking19,
                rearParking20,
                rearParking21,
                rearParking22,
                rearParking23,
                rearParking24,
                rearParking25,
                rearParking26,
                rearParking27,
                rearParking28,
                rearParking29,
                rearParking30,
                rearParking31,
                rearParking32,
                rearParking33,
                rearParking34,
                rearParking35,
                rearParking36,
                rearParking37,
                rearParking38,
                rearParking39,
                rearParking40,
                rearParking41,
                rearParking42,
                rearParking43,
                rearParking44,
                rearParking45,
                rearParking46,
                rearParking47,
                rearParking48,
                rearParking49,
                rearParking50,
                rearParking51,
                rearParking52,
                rearParking53,
                rearParking54,
                rearParking55,
                rearParking56,
                rearParking57,
                rearParking58,
                rearParking59,
                rearParking60
        );
    }

    public List<Integer> getFrontParkings() {
        return CollectionUtils.addAll(
                frontParking01,
                frontParking02,
                frontParking03,
                frontParking04,
                frontParking05,
                frontParking06,
                frontParking07,
                frontParking08,
                frontParking09,
                frontParking10,
                frontParking11,
                frontParking12,
                frontParking13,
                frontParking14,
                frontParking15,
                frontParking16,
                frontParking17,
                frontParking18,
                frontParking19,
                frontParking20,
                frontParking21,
                frontParking22,
                frontParking23,
                frontParking24,
                frontParking25,
                frontParking26,
                frontParking27,
                frontParking28,
                frontParking29,
                frontParking30,
                frontParking31,
                frontParking32,
                frontParking33,
                frontParking34,
                frontParking35,
                frontParking36,
                frontParking37,
                frontParking38,
                frontParking39,
                frontParking40,
                frontParking41,
                frontParking42,
                frontParking43,
                frontParking44,
                frontParking45,
                frontParking46,
                frontParking47,
                frontParking48,
                frontParking49,
                frontParking50,
                frontParking51,
                frontParking52,
                frontParking53,
                frontParking54,
                frontParking55,
                frontParking56,
                frontParking57,
                frontParking58,
                frontParking59,
                frontParking60
        );
    }

    public List<Integer> getAdaptiveCruiseControlRegulations() {
        return CollectionUtils.addAll(
                adaptiveCruiseControlRegulation01,
                adaptiveCruiseControlRegulation02,
                adaptiveCruiseControlRegulation03,
                adaptiveCruiseControlRegulation04,
                adaptiveCruiseControlRegulation05,
                adaptiveCruiseControlRegulation06,
                adaptiveCruiseControlRegulation07,
                adaptiveCruiseControlRegulation08,
                adaptiveCruiseControlRegulation09,
                adaptiveCruiseControlRegulation10,
                adaptiveCruiseControlRegulation11,
                adaptiveCruiseControlRegulation12,
                adaptiveCruiseControlRegulation13,
                adaptiveCruiseControlRegulation14,
                adaptiveCruiseControlRegulation15,
                adaptiveCruiseControlRegulation16,
                adaptiveCruiseControlRegulation17,
                adaptiveCruiseControlRegulation18,
                adaptiveCruiseControlRegulation19,
                adaptiveCruiseControlRegulation20,
                adaptiveCruiseControlRegulation21,
                adaptiveCruiseControlRegulation22,
                adaptiveCruiseControlRegulation23,
                adaptiveCruiseControlRegulation24,
                adaptiveCruiseControlRegulation25,
                adaptiveCruiseControlRegulation26,
                adaptiveCruiseControlRegulation27,
                adaptiveCruiseControlRegulation28,
                adaptiveCruiseControlRegulation29,
                adaptiveCruiseControlRegulation30,
                adaptiveCruiseControlRegulation31,
                adaptiveCruiseControlRegulation32,
                adaptiveCruiseControlRegulation33,
                adaptiveCruiseControlRegulation34,
                adaptiveCruiseControlRegulation35,
                adaptiveCruiseControlRegulation36,
                adaptiveCruiseControlRegulation37,
                adaptiveCruiseControlRegulation38,
                adaptiveCruiseControlRegulation39,
                adaptiveCruiseControlRegulation40,
                adaptiveCruiseControlRegulation41,
                adaptiveCruiseControlRegulation42,
                adaptiveCruiseControlRegulation43,
                adaptiveCruiseControlRegulation44,
                adaptiveCruiseControlRegulation45,
                adaptiveCruiseControlRegulation46,
                adaptiveCruiseControlRegulation47,
                adaptiveCruiseControlRegulation48,
                adaptiveCruiseControlRegulation49,
                adaptiveCruiseControlRegulation50,
                adaptiveCruiseControlRegulation51,
                adaptiveCruiseControlRegulation52,
                adaptiveCruiseControlRegulation53,
                adaptiveCruiseControlRegulation54,
                adaptiveCruiseControlRegulation55,
                adaptiveCruiseControlRegulation56,
                adaptiveCruiseControlRegulation57,
                adaptiveCruiseControlRegulation58,
                adaptiveCruiseControlRegulation59,
                adaptiveCruiseControlRegulation60
        );
    }

    public List<Integer> getAdvancedEmergencyBrakingSystems() {
        return CollectionUtils.addAll(
                advancedEmergencyBrakingSystem01,
                advancedEmergencyBrakingSystem02,
                advancedEmergencyBrakingSystem03,
                advancedEmergencyBrakingSystem04,
                advancedEmergencyBrakingSystem05,
                advancedEmergencyBrakingSystem06,
                advancedEmergencyBrakingSystem07,
                advancedEmergencyBrakingSystem08,
                advancedEmergencyBrakingSystem09,
                advancedEmergencyBrakingSystem10,
                advancedEmergencyBrakingSystem11,
                advancedEmergencyBrakingSystem12,
                advancedEmergencyBrakingSystem13,
                advancedEmergencyBrakingSystem14,
                advancedEmergencyBrakingSystem15,
                advancedEmergencyBrakingSystem16,
                advancedEmergencyBrakingSystem17,
                advancedEmergencyBrakingSystem18,
                advancedEmergencyBrakingSystem19,
                advancedEmergencyBrakingSystem20,
                advancedEmergencyBrakingSystem21,
                advancedEmergencyBrakingSystem22,
                advancedEmergencyBrakingSystem23,
                advancedEmergencyBrakingSystem24,
                advancedEmergencyBrakingSystem25,
                advancedEmergencyBrakingSystem26,
                advancedEmergencyBrakingSystem27,
                advancedEmergencyBrakingSystem28,
                advancedEmergencyBrakingSystem29,
                advancedEmergencyBrakingSystem30,
                advancedEmergencyBrakingSystem31,
                advancedEmergencyBrakingSystem32,
                advancedEmergencyBrakingSystem33,
                advancedEmergencyBrakingSystem34,
                advancedEmergencyBrakingSystem35,
                advancedEmergencyBrakingSystem36,
                advancedEmergencyBrakingSystem37,
                advancedEmergencyBrakingSystem38,
                advancedEmergencyBrakingSystem39,
                advancedEmergencyBrakingSystem40,
                advancedEmergencyBrakingSystem41,
                advancedEmergencyBrakingSystem42,
                advancedEmergencyBrakingSystem43,
                advancedEmergencyBrakingSystem44,
                advancedEmergencyBrakingSystem45,
                advancedEmergencyBrakingSystem46,
                advancedEmergencyBrakingSystem47,
                advancedEmergencyBrakingSystem48,
                advancedEmergencyBrakingSystem49,
                advancedEmergencyBrakingSystem50,
                advancedEmergencyBrakingSystem51,
                advancedEmergencyBrakingSystem52,
                advancedEmergencyBrakingSystem53,
                advancedEmergencyBrakingSystem54,
                advancedEmergencyBrakingSystem55,
                advancedEmergencyBrakingSystem56,
                advancedEmergencyBrakingSystem57,
                advancedEmergencyBrakingSystem58,
                advancedEmergencyBrakingSystem59,
                advancedEmergencyBrakingSystem60
        );
    }

    public List<Integer> getLaneDepartureWarnings() {
        return CollectionUtils.addAll(
                laneDepartureWarning01,
                laneDepartureWarning02,
                laneDepartureWarning03,
                laneDepartureWarning04,
                laneDepartureWarning05,
                laneDepartureWarning06,
                laneDepartureWarning07,
                laneDepartureWarning08,
                laneDepartureWarning09,
                laneDepartureWarning10,
                laneDepartureWarning11,
                laneDepartureWarning12,
                laneDepartureWarning13,
                laneDepartureWarning14,
                laneDepartureWarning15,
                laneDepartureWarning16,
                laneDepartureWarning17,
                laneDepartureWarning18,
                laneDepartureWarning19,
                laneDepartureWarning20,
                laneDepartureWarning21,
                laneDepartureWarning22,
                laneDepartureWarning23,
                laneDepartureWarning24,
                laneDepartureWarning25,
                laneDepartureWarning26,
                laneDepartureWarning27,
                laneDepartureWarning28,
                laneDepartureWarning29,
                laneDepartureWarning30,
                laneDepartureWarning31,
                laneDepartureWarning32,
                laneDepartureWarning33,
                laneDepartureWarning34,
                laneDepartureWarning35,
                laneDepartureWarning36,
                laneDepartureWarning37,
                laneDepartureWarning38,
                laneDepartureWarning39,
                laneDepartureWarning40,
                laneDepartureWarning41,
                laneDepartureWarning42,
                laneDepartureWarning43,
                laneDepartureWarning44,
                laneDepartureWarning45,
                laneDepartureWarning46,
                laneDepartureWarning47,
                laneDepartureWarning48,
                laneDepartureWarning49,
                laneDepartureWarning50,
                laneDepartureWarning51,
                laneDepartureWarning52,
                laneDepartureWarning53,
                laneDepartureWarning54,
                laneDepartureWarning55,
                laneDepartureWarning56,
                laneDepartureWarning57,
                laneDepartureWarning58,
                laneDepartureWarning59,
                laneDepartureWarning60
        );
    }

    public List<Integer> getRespectOfInterVehicleTimeAssists() {
        return CollectionUtils.addAll(
                respectOfInterVehicleTimeAssist01,
                respectOfInterVehicleTimeAssist02,
                respectOfInterVehicleTimeAssist03,
                respectOfInterVehicleTimeAssist04,
                respectOfInterVehicleTimeAssist05,
                respectOfInterVehicleTimeAssist06,
                respectOfInterVehicleTimeAssist07,
                respectOfInterVehicleTimeAssist08,
                respectOfInterVehicleTimeAssist09,
                respectOfInterVehicleTimeAssist10,
                respectOfInterVehicleTimeAssist11,
                respectOfInterVehicleTimeAssist12,
                respectOfInterVehicleTimeAssist13,
                respectOfInterVehicleTimeAssist14,
                respectOfInterVehicleTimeAssist15,
                respectOfInterVehicleTimeAssist16,
                respectOfInterVehicleTimeAssist17,
                respectOfInterVehicleTimeAssist18,
                respectOfInterVehicleTimeAssist19,
                respectOfInterVehicleTimeAssist20,
                respectOfInterVehicleTimeAssist21,
                respectOfInterVehicleTimeAssist22,
                respectOfInterVehicleTimeAssist23,
                respectOfInterVehicleTimeAssist24,
                respectOfInterVehicleTimeAssist25,
                respectOfInterVehicleTimeAssist26,
                respectOfInterVehicleTimeAssist27,
                respectOfInterVehicleTimeAssist28,
                respectOfInterVehicleTimeAssist29,
                respectOfInterVehicleTimeAssist30,
                respectOfInterVehicleTimeAssist31,
                respectOfInterVehicleTimeAssist32,
                respectOfInterVehicleTimeAssist33,
                respectOfInterVehicleTimeAssist34,
                respectOfInterVehicleTimeAssist35,
                respectOfInterVehicleTimeAssist36,
                respectOfInterVehicleTimeAssist37,
                respectOfInterVehicleTimeAssist38,
                respectOfInterVehicleTimeAssist39,
                respectOfInterVehicleTimeAssist40,
                respectOfInterVehicleTimeAssist41,
                respectOfInterVehicleTimeAssist42,
                respectOfInterVehicleTimeAssist43,
                respectOfInterVehicleTimeAssist44,
                respectOfInterVehicleTimeAssist45,
                respectOfInterVehicleTimeAssist46,
                respectOfInterVehicleTimeAssist47,
                respectOfInterVehicleTimeAssist48,
                respectOfInterVehicleTimeAssist49,
                respectOfInterVehicleTimeAssist50,
                respectOfInterVehicleTimeAssist51,
                respectOfInterVehicleTimeAssist52,
                respectOfInterVehicleTimeAssist53,
                respectOfInterVehicleTimeAssist54,
                respectOfInterVehicleTimeAssist55,
                respectOfInterVehicleTimeAssist56,
                respectOfInterVehicleTimeAssist57,
                respectOfInterVehicleTimeAssist58,
                respectOfInterVehicleTimeAssist59,
                respectOfInterVehicleTimeAssist60);
    }

    public List<Integer> getTriggeringOfESPs() {
        return CollectionUtils.addAll(
                triggeringOfESP01,
                triggeringOfESP02,
                triggeringOfESP03,
                triggeringOfESP04,
                triggeringOfESP05,
                triggeringOfESP06,
                triggeringOfESP07,
                triggeringOfESP08,
                triggeringOfESP09,
                triggeringOfESP10,
                triggeringOfESP11,
                triggeringOfESP12,
                triggeringOfESP13,
                triggeringOfESP14,
                triggeringOfESP15,
                triggeringOfESP16,
                triggeringOfESP17,
                triggeringOfESP18,
                triggeringOfESP19,
                triggeringOfESP20,
                triggeringOfESP21,
                triggeringOfESP22,
                triggeringOfESP23,
                triggeringOfESP24,
                triggeringOfESP25,
                triggeringOfESP26,
                triggeringOfESP27,
                triggeringOfESP28,
                triggeringOfESP29,
                triggeringOfESP30,
                triggeringOfESP31,
                triggeringOfESP32,
                triggeringOfESP33,
                triggeringOfESP34,
                triggeringOfESP35,
                triggeringOfESP36,
                triggeringOfESP37,
                triggeringOfESP38,
                triggeringOfESP39,
                triggeringOfESP40,
                triggeringOfESP41,
                triggeringOfESP42,
                triggeringOfESP43,
                triggeringOfESP44,
                triggeringOfESP45,
                triggeringOfESP46,
                triggeringOfESP47,
                triggeringOfESP48,
                triggeringOfESP49,
                triggeringOfESP50,
                triggeringOfESP51,
                triggeringOfESP52,
                triggeringOfESP53,
                triggeringOfESP54,
                triggeringOfESP55,
                triggeringOfESP56,
                triggeringOfESP57,
                triggeringOfESP58,
                triggeringOfESP59,
                triggeringOfESP60);
    }

    public List<Integer> getTriggeringOfABSs() {
        return CollectionUtils.addAll(
                triggeringOfABS01,
                triggeringOfABS02,
                triggeringOfABS03,
                triggeringOfABS04,
                triggeringOfABS05,
                triggeringOfABS06,
                triggeringOfABS07,
                triggeringOfABS08,
                triggeringOfABS09,
                triggeringOfABS10,
                triggeringOfABS11,
                triggeringOfABS12,
                triggeringOfABS13,
                triggeringOfABS14,
                triggeringOfABS15,
                triggeringOfABS16,
                triggeringOfABS17,
                triggeringOfABS18,
                triggeringOfABS19,
                triggeringOfABS20,
                triggeringOfABS21,
                triggeringOfABS22,
                triggeringOfABS23,
                triggeringOfABS24,
                triggeringOfABS25,
                triggeringOfABS26,
                triggeringOfABS27,
                triggeringOfABS28,
                triggeringOfABS29,
                triggeringOfABS30,
                triggeringOfABS31,
                triggeringOfABS32,
                triggeringOfABS33,
                triggeringOfABS34,
                triggeringOfABS35,
                triggeringOfABS36,
                triggeringOfABS37,
                triggeringOfABS38,
                triggeringOfABS39,
                triggeringOfABS40,
                triggeringOfABS41,
                triggeringOfABS42,
                triggeringOfABS43,
                triggeringOfABS44,
                triggeringOfABS45,
                triggeringOfABS46,
                triggeringOfABS47,
                triggeringOfABS48,
                triggeringOfABS49,
                triggeringOfABS50,
                triggeringOfABS51,
                triggeringOfABS52,
                triggeringOfABS53,
                triggeringOfABS54,
                triggeringOfABS55,
                triggeringOfABS56,
                triggeringOfABS57,
                triggeringOfABS58,
                triggeringOfABS59,
                triggeringOfABS60);
    }

    public List<Integer> getElectricBrakeServices() {
        return CollectionUtils.addAll(
                electricBrakeService01,
                electricBrakeService02,
                electricBrakeService03,
                electricBrakeService04,
                electricBrakeService05,
                electricBrakeService06,
                electricBrakeService07,
                electricBrakeService08,
                electricBrakeService09,
                electricBrakeService10,
                electricBrakeService11,
                electricBrakeService12,
                electricBrakeService13,
                electricBrakeService14,
                electricBrakeService15,
                electricBrakeService16,
                electricBrakeService17,
                electricBrakeService18,
                electricBrakeService19,
                electricBrakeService20,
                electricBrakeService21,
                electricBrakeService22,
                electricBrakeService23,
                electricBrakeService24,
                electricBrakeService25,
                electricBrakeService26,
                electricBrakeService27,
                electricBrakeService28,
                electricBrakeService29,
                electricBrakeService30,
                electricBrakeService31,
                electricBrakeService32,
                electricBrakeService33,
                electricBrakeService34,
                electricBrakeService35,
                electricBrakeService36,
                electricBrakeService37,
                electricBrakeService38,
                electricBrakeService39,
                electricBrakeService40,
                electricBrakeService41,
                electricBrakeService42,
                electricBrakeService43,
                electricBrakeService44,
                electricBrakeService45,
                electricBrakeService46,
                electricBrakeService47,
                electricBrakeService48,
                electricBrakeService49,
                electricBrakeService50,
                electricBrakeService51,
                electricBrakeService52,
                electricBrakeService53,
                electricBrakeService54,
                electricBrakeService55,
                electricBrakeService56,
                electricBrakeService57,
                electricBrakeService58,
                electricBrakeService59,
                electricBrakeService60);
    }

    public List<Integer> getAdvancedSpeedRegulatorAndLimits() {
        return CollectionUtils.addAll(
                advancedSpeedRegulatorAndLimit01,
                advancedSpeedRegulatorAndLimit02,
                advancedSpeedRegulatorAndLimit03,
                advancedSpeedRegulatorAndLimit04,
                advancedSpeedRegulatorAndLimit05,
                advancedSpeedRegulatorAndLimit06,
                advancedSpeedRegulatorAndLimit07,
                advancedSpeedRegulatorAndLimit08,
                advancedSpeedRegulatorAndLimit09,
                advancedSpeedRegulatorAndLimit10,
                advancedSpeedRegulatorAndLimit11,
                advancedSpeedRegulatorAndLimit12,
                advancedSpeedRegulatorAndLimit13,
                advancedSpeedRegulatorAndLimit14,
                advancedSpeedRegulatorAndLimit15,
                advancedSpeedRegulatorAndLimit16,
                advancedSpeedRegulatorAndLimit17,
                advancedSpeedRegulatorAndLimit18,
                advancedSpeedRegulatorAndLimit19,
                advancedSpeedRegulatorAndLimit20,
                advancedSpeedRegulatorAndLimit21,
                advancedSpeedRegulatorAndLimit22,
                advancedSpeedRegulatorAndLimit23,
                advancedSpeedRegulatorAndLimit24,
                advancedSpeedRegulatorAndLimit25,
                advancedSpeedRegulatorAndLimit26,
                advancedSpeedRegulatorAndLimit27,
                advancedSpeedRegulatorAndLimit28,
                advancedSpeedRegulatorAndLimit29,
                advancedSpeedRegulatorAndLimit30,
                advancedSpeedRegulatorAndLimit31,
                advancedSpeedRegulatorAndLimit32,
                advancedSpeedRegulatorAndLimit33,
                advancedSpeedRegulatorAndLimit34,
                advancedSpeedRegulatorAndLimit35,
                advancedSpeedRegulatorAndLimit36,
                advancedSpeedRegulatorAndLimit37,
                advancedSpeedRegulatorAndLimit38,
                advancedSpeedRegulatorAndLimit39,
                advancedSpeedRegulatorAndLimit40,
                advancedSpeedRegulatorAndLimit41,
                advancedSpeedRegulatorAndLimit42,
                advancedSpeedRegulatorAndLimit43,
                advancedSpeedRegulatorAndLimit44,
                advancedSpeedRegulatorAndLimit45,
                advancedSpeedRegulatorAndLimit46,
                advancedSpeedRegulatorAndLimit47,
                advancedSpeedRegulatorAndLimit48,
                advancedSpeedRegulatorAndLimit49,
                advancedSpeedRegulatorAndLimit50,
                advancedSpeedRegulatorAndLimit51,
                advancedSpeedRegulatorAndLimit52,
                advancedSpeedRegulatorAndLimit53,
                advancedSpeedRegulatorAndLimit54,
                advancedSpeedRegulatorAndLimit55,
                advancedSpeedRegulatorAndLimit56,
                advancedSpeedRegulatorAndLimit57,
                advancedSpeedRegulatorAndLimit58,
                advancedSpeedRegulatorAndLimit59,
                advancedSpeedRegulatorAndLimit60);
    }

    public List<Integer> getRightLaneKeepingAssists() {
        return CollectionUtils.addAll(
                rightLaneKeepingAssist01,
                rightLaneKeepingAssist02,
                rightLaneKeepingAssist03,
                rightLaneKeepingAssist04,
                rightLaneKeepingAssist05,
                rightLaneKeepingAssist06,
                rightLaneKeepingAssist07,
                rightLaneKeepingAssist08,
                rightLaneKeepingAssist09,
                rightLaneKeepingAssist10,
                rightLaneKeepingAssist11,
                rightLaneKeepingAssist12,
                rightLaneKeepingAssist13,
                rightLaneKeepingAssist14,
                rightLaneKeepingAssist15,
                rightLaneKeepingAssist16,
                rightLaneKeepingAssist17,
                rightLaneKeepingAssist18,
                rightLaneKeepingAssist19,
                rightLaneKeepingAssist20,
                rightLaneKeepingAssist21,
                rightLaneKeepingAssist22,
                rightLaneKeepingAssist23,
                rightLaneKeepingAssist24,
                rightLaneKeepingAssist25,
                rightLaneKeepingAssist26,
                rightLaneKeepingAssist27,
                rightLaneKeepingAssist28,
                rightLaneKeepingAssist29,
                rightLaneKeepingAssist30,
                rightLaneKeepingAssist31,
                rightLaneKeepingAssist32,
                rightLaneKeepingAssist33,
                rightLaneKeepingAssist34,
                rightLaneKeepingAssist35,
                rightLaneKeepingAssist36,
                rightLaneKeepingAssist37,
                rightLaneKeepingAssist38,
                rightLaneKeepingAssist39,
                rightLaneKeepingAssist40,
                rightLaneKeepingAssist41,
                rightLaneKeepingAssist42,
                rightLaneKeepingAssist43,
                rightLaneKeepingAssist44,
                rightLaneKeepingAssist45,
                rightLaneKeepingAssist46,
                rightLaneKeepingAssist47,
                rightLaneKeepingAssist48,
                rightLaneKeepingAssist49,
                rightLaneKeepingAssist50,
                rightLaneKeepingAssist51,
                rightLaneKeepingAssist52,
                rightLaneKeepingAssist53,
                rightLaneKeepingAssist54,
                rightLaneKeepingAssist55,
                rightLaneKeepingAssist56,
                rightLaneKeepingAssist57,
                rightLaneKeepingAssist58,
                rightLaneKeepingAssist59,
                rightLaneKeepingAssist60);
    }

    public List<Integer> getLeftLaneKeepingAssists() {
        return CollectionUtils.addAll(
                leftLaneKeepingAssist01,
                leftLaneKeepingAssist02,
                leftLaneKeepingAssist03,
                leftLaneKeepingAssist04,
                leftLaneKeepingAssist05,
                leftLaneKeepingAssist06,
                leftLaneKeepingAssist07,
                leftLaneKeepingAssist08,
                leftLaneKeepingAssist09,
                leftLaneKeepingAssist10,
                leftLaneKeepingAssist11,
                leftLaneKeepingAssist12,
                leftLaneKeepingAssist13,
                leftLaneKeepingAssist14,
                leftLaneKeepingAssist15,
                leftLaneKeepingAssist16,
                leftLaneKeepingAssist17,
                leftLaneKeepingAssist18,
                leftLaneKeepingAssist19,
                leftLaneKeepingAssist20,
                leftLaneKeepingAssist21,
                leftLaneKeepingAssist22,
                leftLaneKeepingAssist23,
                leftLaneKeepingAssist24,
                leftLaneKeepingAssist25,
                leftLaneKeepingAssist26,
                leftLaneKeepingAssist27,
                leftLaneKeepingAssist28,
                leftLaneKeepingAssist29,
                leftLaneKeepingAssist30,
                leftLaneKeepingAssist31,
                leftLaneKeepingAssist32,
                leftLaneKeepingAssist33,
                leftLaneKeepingAssist34,
                leftLaneKeepingAssist35,
                leftLaneKeepingAssist36,
                leftLaneKeepingAssist37,
                leftLaneKeepingAssist38,
                leftLaneKeepingAssist39,
                leftLaneKeepingAssist40,
                leftLaneKeepingAssist41,
                leftLaneKeepingAssist42,
                leftLaneKeepingAssist43,
                leftLaneKeepingAssist44,
                leftLaneKeepingAssist45,
                leftLaneKeepingAssist46,
                leftLaneKeepingAssist47,
                leftLaneKeepingAssist48,
                leftLaneKeepingAssist49,
                leftLaneKeepingAssist50,
                leftLaneKeepingAssist51,
                leftLaneKeepingAssist52,
                leftLaneKeepingAssist53,
                leftLaneKeepingAssist54,
                leftLaneKeepingAssist55,
                leftLaneKeepingAssist56,
                leftLaneKeepingAssist57,
                leftLaneKeepingAssist58,
                leftLaneKeepingAssist59,
                leftLaneKeepingAssist60);
    }

    public List<Integer> getAdvancedSpeedRegulators() {
        return CollectionUtils.addAll(
                advancedSpeedRegulator01,
                advancedSpeedRegulator02,
                advancedSpeedRegulator03,
                advancedSpeedRegulator04,
                advancedSpeedRegulator05,
                advancedSpeedRegulator06,
                advancedSpeedRegulator07,
                advancedSpeedRegulator08,
                advancedSpeedRegulator09,
                advancedSpeedRegulator10,
                advancedSpeedRegulator11,
                advancedSpeedRegulator12,
                advancedSpeedRegulator13,
                advancedSpeedRegulator14,
                advancedSpeedRegulator15,
                advancedSpeedRegulator16,
                advancedSpeedRegulator17,
                advancedSpeedRegulator18,
                advancedSpeedRegulator19,
                advancedSpeedRegulator20,
                advancedSpeedRegulator21,
                advancedSpeedRegulator22,
                advancedSpeedRegulator23,
                advancedSpeedRegulator24,
                advancedSpeedRegulator25,
                advancedSpeedRegulator26,
                advancedSpeedRegulator27,
                advancedSpeedRegulator28,
                advancedSpeedRegulator29,
                advancedSpeedRegulator30,
                advancedSpeedRegulator31,
                advancedSpeedRegulator32,
                advancedSpeedRegulator33,
                advancedSpeedRegulator34,
                advancedSpeedRegulator35,
                advancedSpeedRegulator36,
                advancedSpeedRegulator37,
                advancedSpeedRegulator38,
                advancedSpeedRegulator39,
                advancedSpeedRegulator40,
                advancedSpeedRegulator41,
                advancedSpeedRegulator42,
                advancedSpeedRegulator43,
                advancedSpeedRegulator44,
                advancedSpeedRegulator45,
                advancedSpeedRegulator46,
                advancedSpeedRegulator47,
                advancedSpeedRegulator48,
                advancedSpeedRegulator49,
                advancedSpeedRegulator50,
                advancedSpeedRegulator51,
                advancedSpeedRegulator52,
                advancedSpeedRegulator53,
                advancedSpeedRegulator54,
                advancedSpeedRegulator55,
                advancedSpeedRegulator56,
                advancedSpeedRegulator57,
                advancedSpeedRegulator58,
                advancedSpeedRegulator59,
                advancedSpeedRegulator60);
    }

    public List<Integer> getBlindSpotMonitorings() {
        return CollectionUtils.addAll(
                blindSpotMonitoring01,
                blindSpotMonitoring02,
                blindSpotMonitoring03,
                blindSpotMonitoring04,
                blindSpotMonitoring05,
                blindSpotMonitoring06,
                blindSpotMonitoring07,
                blindSpotMonitoring08,
                blindSpotMonitoring09,
                blindSpotMonitoring10,
                blindSpotMonitoring11,
                blindSpotMonitoring12,
                blindSpotMonitoring13,
                blindSpotMonitoring14,
                blindSpotMonitoring15,
                blindSpotMonitoring16,
                blindSpotMonitoring17,
                blindSpotMonitoring18,
                blindSpotMonitoring19,
                blindSpotMonitoring20,
                blindSpotMonitoring21,
                blindSpotMonitoring22,
                blindSpotMonitoring23,
                blindSpotMonitoring24,
                blindSpotMonitoring25,
                blindSpotMonitoring26,
                blindSpotMonitoring27,
                blindSpotMonitoring28,
                blindSpotMonitoring29,
                blindSpotMonitoring30,
                blindSpotMonitoring31,
                blindSpotMonitoring32,
                blindSpotMonitoring33,
                blindSpotMonitoring34,
                blindSpotMonitoring35,
                blindSpotMonitoring36,
                blindSpotMonitoring37,
                blindSpotMonitoring38,
                blindSpotMonitoring39,
                blindSpotMonitoring40,
                blindSpotMonitoring41,
                blindSpotMonitoring42,
                blindSpotMonitoring43,
                blindSpotMonitoring44,
                blindSpotMonitoring45,
                blindSpotMonitoring46,
                blindSpotMonitoring47,
                blindSpotMonitoring48,
                blindSpotMonitoring49,
                blindSpotMonitoring50,
                blindSpotMonitoring51,
                blindSpotMonitoring52,
                blindSpotMonitoring53,
                blindSpotMonitoring54,
                blindSpotMonitoring55,
                blindSpotMonitoring56,
                blindSpotMonitoring57,
                blindSpotMonitoring58,
                blindSpotMonitoring59,
                blindSpotMonitoring60);
    }

    public List<Integer> getSpeedLimitInformations() {
        return CollectionUtils.addAll(
                speedLimitInformation01,
                speedLimitInformation02,
                speedLimitInformation03,
                speedLimitInformation04,
                speedLimitInformation05,
                speedLimitInformation06,
                speedLimitInformation07,
                speedLimitInformation08,
                speedLimitInformation09,
                speedLimitInformation10,
                speedLimitInformation11,
                speedLimitInformation12,
                speedLimitInformation13,
                speedLimitInformation14,
                speedLimitInformation15,
                speedLimitInformation16,
                speedLimitInformation17,
                speedLimitInformation18,
                speedLimitInformation19,
                speedLimitInformation20,
                speedLimitInformation21,
                speedLimitInformation22,
                speedLimitInformation23,
                speedLimitInformation24,
                speedLimitInformation25,
                speedLimitInformation26,
                speedLimitInformation27,
                speedLimitInformation28,
                speedLimitInformation29,
                speedLimitInformation30,
                speedLimitInformation31,
                speedLimitInformation32,
                speedLimitInformation33,
                speedLimitInformation34,
                speedLimitInformation35,
                speedLimitInformation36,
                speedLimitInformation37,
                speedLimitInformation38,
                speedLimitInformation39,
                speedLimitInformation40,
                speedLimitInformation41,
                speedLimitInformation42,
                speedLimitInformation43,
                speedLimitInformation44,
                speedLimitInformation45,
                speedLimitInformation46,
                speedLimitInformation47,
                speedLimitInformation48,
                speedLimitInformation49,
                speedLimitInformation50,
                speedLimitInformation51,
                speedLimitInformation52,
                speedLimitInformation53,
                speedLimitInformation54,
                speedLimitInformation55,
                speedLimitInformation56,
                speedLimitInformation57,
                speedLimitInformation58,
                speedLimitInformation59,
                speedLimitInformation60);
    }
    //</editor-fold>

    //<editor-fold desc="VEHICLE_DATA">
    public int getRearFogLampsStatement() {
        return rearFogLampsStatement;
    }

    public int getFrontFogLampsStatement() {
        return frontFogLampsStatement;
    }

    public List<Integer> getUnbuckledBeltWarnings() {
        return CollectionUtils.addAll(
                unbuckledBeltWarning01,
                unbuckledBeltWarning02,
                unbuckledBeltWarning03,
                unbuckledBeltWarning04,
                unbuckledBeltWarning05,
                unbuckledBeltWarning06,
                unbuckledBeltWarning07,
                unbuckledBeltWarning08,
                unbuckledBeltWarning09,
                unbuckledBeltWarning10,
                unbuckledBeltWarning11,
                unbuckledBeltWarning12,
                unbuckledBeltWarning13,
                unbuckledBeltWarning14,
                unbuckledBeltWarning15,
                unbuckledBeltWarning16,
                unbuckledBeltWarning17,
                unbuckledBeltWarning18,
                unbuckledBeltWarning19,
                unbuckledBeltWarning20,
                unbuckledBeltWarning21,
                unbuckledBeltWarning22,
                unbuckledBeltWarning23,
                unbuckledBeltWarning24,
                unbuckledBeltWarning25,
                unbuckledBeltWarning26,
                unbuckledBeltWarning27,
                unbuckledBeltWarning28,
                unbuckledBeltWarning29,
                unbuckledBeltWarning30,
                unbuckledBeltWarning31,
                unbuckledBeltWarning32,
                unbuckledBeltWarning33,
                unbuckledBeltWarning34,
                unbuckledBeltWarning35,
                unbuckledBeltWarning36,
                unbuckledBeltWarning37,
                unbuckledBeltWarning38,
                unbuckledBeltWarning39,
                unbuckledBeltWarning40,
                unbuckledBeltWarning41,
                unbuckledBeltWarning42,
                unbuckledBeltWarning43,
                unbuckledBeltWarning44,
                unbuckledBeltWarning45,
                unbuckledBeltWarning46,
                unbuckledBeltWarning47,
                unbuckledBeltWarning48,
                unbuckledBeltWarning49,
                unbuckledBeltWarning50,
                unbuckledBeltWarning51,
                unbuckledBeltWarning52,
                unbuckledBeltWarning53,
                unbuckledBeltWarning54,
                unbuckledBeltWarning55,
                unbuckledBeltWarning56,
                unbuckledBeltWarning57,
                unbuckledBeltWarning58,
                unbuckledBeltWarning59,
                unbuckledBeltWarning60);
    }

    public BigDecimal getOutsideTemperature() {
        return BigDecimal.valueOf(outsideTemperature * OUTSIDE_TEMPERATURE_FACTOR + TEMPERATURE_OFFSET).setScale(2, RoundingMode.FLOOR);
    }

    public BigDecimal getFuelInstantConsumption() {
        return BigDecimal.valueOf(ByteUtils.asInt(fuelInstantConsumption) * FUEL_INSTANT_CONSUMPTION_FACTOR).setScale(2, RoundingMode.FLOOR);
    }

    public BigDecimal getFuelTotalConsumption() {
        return BigDecimal.valueOf(ByteUtils.asInt(fuelTotalConsumption) * FUEL_TOTAL_CONSUMPTION_FACTOR).setScale(3, RoundingMode.FLOOR);
    }

    public int getIgnition() {
        return ignition;
    }

    public List<BigDecimal> getLongitudinalSpeeds() {
        return CollectionUtils.addAll(
                Formula.toLongitudinalSpeed(longitudinalSpeed01),
                Formula.toLongitudinalSpeed(longitudinalSpeed02),
                Formula.toLongitudinalSpeed(longitudinalSpeed03),
                Formula.toLongitudinalSpeed(longitudinalSpeed04),
                Formula.toLongitudinalSpeed(longitudinalSpeed05),
                Formula.toLongitudinalSpeed(longitudinalSpeed06),
                Formula.toLongitudinalSpeed(longitudinalSpeed07),
                Formula.toLongitudinalSpeed(longitudinalSpeed08),
                Formula.toLongitudinalSpeed(longitudinalSpeed09),
                Formula.toLongitudinalSpeed(longitudinalSpeed10),
                Formula.toLongitudinalSpeed(longitudinalSpeed11),
                Formula.toLongitudinalSpeed(longitudinalSpeed12),
                Formula.toLongitudinalSpeed(longitudinalSpeed13),
                Formula.toLongitudinalSpeed(longitudinalSpeed14),
                Formula.toLongitudinalSpeed(longitudinalSpeed15),
                Formula.toLongitudinalSpeed(longitudinalSpeed16),
                Formula.toLongitudinalSpeed(longitudinalSpeed17),
                Formula.toLongitudinalSpeed(longitudinalSpeed18),
                Formula.toLongitudinalSpeed(longitudinalSpeed19),
                Formula.toLongitudinalSpeed(longitudinalSpeed20),
                Formula.toLongitudinalSpeed(longitudinalSpeed21),
                Formula.toLongitudinalSpeed(longitudinalSpeed22),
                Formula.toLongitudinalSpeed(longitudinalSpeed23),
                Formula.toLongitudinalSpeed(longitudinalSpeed24),
                Formula.toLongitudinalSpeed(longitudinalSpeed25),
                Formula.toLongitudinalSpeed(longitudinalSpeed26),
                Formula.toLongitudinalSpeed(longitudinalSpeed27),
                Formula.toLongitudinalSpeed(longitudinalSpeed28),
                Formula.toLongitudinalSpeed(longitudinalSpeed29),
                Formula.toLongitudinalSpeed(longitudinalSpeed30),
                Formula.toLongitudinalSpeed(longitudinalSpeed31),
                Formula.toLongitudinalSpeed(longitudinalSpeed32),
                Formula.toLongitudinalSpeed(longitudinalSpeed33),
                Formula.toLongitudinalSpeed(longitudinalSpeed34),
                Formula.toLongitudinalSpeed(longitudinalSpeed35),
                Formula.toLongitudinalSpeed(longitudinalSpeed36),
                Formula.toLongitudinalSpeed(longitudinalSpeed37),
                Formula.toLongitudinalSpeed(longitudinalSpeed38),
                Formula.toLongitudinalSpeed(longitudinalSpeed39),
                Formula.toLongitudinalSpeed(longitudinalSpeed40),
                Formula.toLongitudinalSpeed(longitudinalSpeed41),
                Formula.toLongitudinalSpeed(longitudinalSpeed42),
                Formula.toLongitudinalSpeed(longitudinalSpeed43),
                Formula.toLongitudinalSpeed(longitudinalSpeed44),
                Formula.toLongitudinalSpeed(longitudinalSpeed45),
                Formula.toLongitudinalSpeed(longitudinalSpeed46),
                Formula.toLongitudinalSpeed(longitudinalSpeed47),
                Formula.toLongitudinalSpeed(longitudinalSpeed48),
                Formula.toLongitudinalSpeed(longitudinalSpeed49),
                Formula.toLongitudinalSpeed(longitudinalSpeed50),
                Formula.toLongitudinalSpeed(longitudinalSpeed51),
                Formula.toLongitudinalSpeed(longitudinalSpeed52),
                Formula.toLongitudinalSpeed(longitudinalSpeed53),
                Formula.toLongitudinalSpeed(longitudinalSpeed54),
                Formula.toLongitudinalSpeed(longitudinalSpeed55),
                Formula.toLongitudinalSpeed(longitudinalSpeed56),
                Formula.toLongitudinalSpeed(longitudinalSpeed57),
                Formula.toLongitudinalSpeed(longitudinalSpeed58),
                Formula.toLongitudinalSpeed(longitudinalSpeed59),
                Formula.toLongitudinalSpeed(longitudinalSpeed60));
    }

    public List<Integer> getLuminosities() {
        return CollectionUtils.addAll(
                luminosity01,
                luminosity02,
                luminosity03,
                luminosity04,
                luminosity05,
                luminosity06,
                luminosity07,
                luminosity08,
                luminosity09,
                luminosity10,
                luminosity11,
                luminosity12,
                luminosity13,
                luminosity14,
                luminosity15,
                luminosity16,
                luminosity17,
                luminosity18,
                luminosity19,
                luminosity20,
                luminosity21,
                luminosity22,
                luminosity23,
                luminosity24,
                luminosity25,
                luminosity26,
                luminosity27,
                luminosity28,
                luminosity29,
                luminosity30,
                luminosity31,
                luminosity32,
                luminosity33,
                luminosity34,
                luminosity35,
                luminosity36,
                luminosity37,
                luminosity38,
                luminosity39,
                luminosity40,
                luminosity41,
                luminosity42,
                luminosity43,
                luminosity44,
                luminosity45,
                luminosity46,
                luminosity47,
                luminosity48,
                luminosity49,
                luminosity50,
                luminosity51,
                luminosity52,
                luminosity53,
                luminosity54,
                luminosity55,
                luminosity56,
                luminosity57,
                luminosity58,
                luminosity59,
                luminosity60);
    }

    public BigDecimal getLifetimeMileage() {
        return BigDecimal.valueOf(ByteUtils.asInt(lifetimeMileage) * LIFETIME_MILEAGE_FACTOR).setScale(2, RoundingMode.FLOOR);
    }

    public int getMileageBeforeMaintenanceSign() {
        // 11000000 00000000 00000000 00000000
        int maintenanceAsInt = ByteUtils.asInt(maintenance);
        return ByteUtils.extractMSBFromInt(maintenanceAsInt, 30);
    }

    public int getMileageBeforeMaintenance() {
        // 00111111 11111111 11000000 00000000
        int maintenanceAsInt = ByteUtils.asInt(maintenance);
        return ByteUtils.extractLSBFromInt(ByteUtils.extractMSBFromInt(maintenanceAsInt, 14), 16) * MILEAGE_BEFORE_MAINTENANCE_FACTOR;
    }

    public int getDaysBeforeMaintenanceSign() {
        // 00000000 00000000 00110000 00000000
        int maintenanceAsInt = ByteUtils.asInt(maintenance);
        return ByteUtils.extractMSBFromInt(ByteUtils.extractLSBFromInt(maintenanceAsInt, 14), 12);
    }

    public int getDaysBeforeMaintenance() {
        // 00000000 00000000 00001111 11111111
        int maintenanceAsInt = ByteUtils.asInt(maintenance);
        return ByteUtils.extractLSBFromInt(maintenanceAsInt, 12);
    }

    public int getFuelLevel() {
        return fuelLevel;
    }

    public int getOilTemperature() {
        return oilTemperature + TEMPERATURE_OFFSET;
    }

    public int getGmpStatus() {
        return gmpStatus;
    }

    public List<Integer> getRightIndicatorStatements() {
        return CollectionUtils.addAll(
                rightIndicatorStatement01,
                rightIndicatorStatement02,
                rightIndicatorStatement03,
                rightIndicatorStatement04,
                rightIndicatorStatement05,
                rightIndicatorStatement06,
                rightIndicatorStatement07,
                rightIndicatorStatement08,
                rightIndicatorStatement09,
                rightIndicatorStatement10,
                rightIndicatorStatement11,
                rightIndicatorStatement12,
                rightIndicatorStatement13,
                rightIndicatorStatement14,
                rightIndicatorStatement15,
                rightIndicatorStatement16,
                rightIndicatorStatement17,
                rightIndicatorStatement18,
                rightIndicatorStatement19,
                rightIndicatorStatement20,
                rightIndicatorStatement21,
                rightIndicatorStatement22,
                rightIndicatorStatement23,
                rightIndicatorStatement24,
                rightIndicatorStatement25,
                rightIndicatorStatement26,
                rightIndicatorStatement27,
                rightIndicatorStatement28,
                rightIndicatorStatement29,
                rightIndicatorStatement30,
                rightIndicatorStatement31,
                rightIndicatorStatement32,
                rightIndicatorStatement33,
                rightIndicatorStatement34,
                rightIndicatorStatement35,
                rightIndicatorStatement36,
                rightIndicatorStatement37,
                rightIndicatorStatement38,
                rightIndicatorStatement39,
                rightIndicatorStatement40,
                rightIndicatorStatement41,
                rightIndicatorStatement42,
                rightIndicatorStatement43,
                rightIndicatorStatement44,
                rightIndicatorStatement45,
                rightIndicatorStatement46,
                rightIndicatorStatement47,
                rightIndicatorStatement48,
                rightIndicatorStatement49,
                rightIndicatorStatement50,
                rightIndicatorStatement51,
                rightIndicatorStatement52,
                rightIndicatorStatement53,
                rightIndicatorStatement54,
                rightIndicatorStatement55,
                rightIndicatorStatement56,
                rightIndicatorStatement57,
                rightIndicatorStatement58,
                rightIndicatorStatement59,
                rightIndicatorStatement60);
    }

    public List<Integer> getLeftIndicatorStatements() {
        return CollectionUtils.addAll(
                leftIndicatorStatement01,
                leftIndicatorStatement02,
                leftIndicatorStatement03,
                leftIndicatorStatement04,
                leftIndicatorStatement05,
                leftIndicatorStatement06,
                leftIndicatorStatement07,
                leftIndicatorStatement08,
                leftIndicatorStatement09,
                leftIndicatorStatement10,
                leftIndicatorStatement11,
                leftIndicatorStatement12,
                leftIndicatorStatement13,
                leftIndicatorStatement14,
                leftIndicatorStatement15,
                leftIndicatorStatement16,
                leftIndicatorStatement17,
                leftIndicatorStatement18,
                leftIndicatorStatement19,
                leftIndicatorStatement20,
                leftIndicatorStatement21,
                leftIndicatorStatement22,
                leftIndicatorStatement23,
                leftIndicatorStatement24,
                leftIndicatorStatement25,
                leftIndicatorStatement26,
                leftIndicatorStatement27,
                leftIndicatorStatement28,
                leftIndicatorStatement29,
                leftIndicatorStatement30,
                leftIndicatorStatement31,
                leftIndicatorStatement32,
                leftIndicatorStatement33,
                leftIndicatorStatement34,
                leftIndicatorStatement35,
                leftIndicatorStatement36,
                leftIndicatorStatement37,
                leftIndicatorStatement38,
                leftIndicatorStatement39,
                leftIndicatorStatement40,
                leftIndicatorStatement41,
                leftIndicatorStatement42,
                leftIndicatorStatement43,
                leftIndicatorStatement44,
                leftIndicatorStatement45,
                leftIndicatorStatement46,
                leftIndicatorStatement47,
                leftIndicatorStatement48,
                leftIndicatorStatement49,
                leftIndicatorStatement50,
                leftIndicatorStatement51,
                leftIndicatorStatement52,
                leftIndicatorStatement53,
                leftIndicatorStatement54,
                leftIndicatorStatement55,
                leftIndicatorStatement56,
                leftIndicatorStatement57,
                leftIndicatorStatement58,
                leftIndicatorStatement59,
                leftIndicatorStatement60);
    }

    public int getEcallTriggering() {
        return ecallTriggering;
    }

    public int getAlertOfFuelLowLevel() {
        return alertOfFuelLowLevel;
    }

    public int getAlertOfSCRLowLevel() {
        return alertOfSCRLowLevel;
    }

    public int getResidualAutonomy() {
        return ByteUtils.asInt(residualAutonomy);
    }
    //</editor-fold>

    public int getPrivacyModeV2() {
        return privacyModeV2;
    }
}

