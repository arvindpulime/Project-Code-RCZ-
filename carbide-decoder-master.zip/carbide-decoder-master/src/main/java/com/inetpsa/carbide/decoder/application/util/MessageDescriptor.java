package com.inetpsa.carbide.decoder.application.util;

import com.inetpsa.carbide.decoder.infrastructure.util.Constant;
import com.inetpsa.carbide.domain.interfaces.enums.MessageType;
import com.inetpsa.carbide.domain.interfaces.enums.ServiceType;

import java.util.Arrays;
import java.util.EnumSet;
import java.util.List;
import java.util.NoSuchElementException;

public enum MessageDescriptor {

    ADAS(ServiceType.ICE, MessageType.ADAS, Constant.V1_V2, Structure.ADAS),
    ADAS_BEV(ServiceType.BEV, MessageType.ADAS, Constant.V1_V2, Structure.ADAS),
    ADAS_PHEV(ServiceType.PHEV, MessageType.ADAS, Constant.V1_V2, Structure.ADAS),

    BATTERY_BEV(ServiceType.BEV, MessageType.BATTERY, Constant.V1_V2, Structure.BATTERY),
    BATTERY_PHEV(ServiceType.PHEV, MessageType.BATTERY, Constant.V1_V2, Structure.BATTERY),

    BATTERY_SOH_BEV(ServiceType.BEV, MessageType.BATTERY_SOH, Constant.V1_V2, Structure.BATTERY_SOH),
    BATTERY_SOH_PHEV(ServiceType.PHEV, MessageType.BATTERY_SOH, Constant.V1_V2, Structure.BATTERY_SOH),

    BATTERY_STATUS_DETAILS_BEV(ServiceType.BEV, MessageType.BATTERY_STATUS_DETAILS, Constant.V1_V2, Structure.BATTERY_STATUS_DETAILS),
    BATTERY_STATUS_DETAILS_PHEV(ServiceType.PHEV, MessageType.BATTERY_STATUS_DETAILS, Constant.V1_V2, Structure.BATTERY_STATUS_DETAILS),

    BATTERY_STATUS_SUMMARY_BEV(ServiceType.BEV, MessageType.BATTERY_STATUS_SUMMARY, Constant.V1_V2, Structure.BATTERY_STATUS_SUMMARY),
    BATTERY_STATUS_SUMMARY_PHEV(ServiceType.PHEV, MessageType.BATTERY_STATUS_SUMMARY, Constant.V1_V2, Structure.BATTERY_STATUS_SUMMARY),

    BATTERY_VOLTAGE_DETAILS_BEV(ServiceType.BEV, MessageType.BATTERY_VOLTAGE_DETAILS, Constant.V1_V2, Structure.BATTERY_VOLTAGE_DETAILS),
    BATTERY_VOLTAGE_DETAILS_PHEV(ServiceType.PHEV, MessageType.BATTERY_VOLTAGE_DETAILS, Constant.V1_V2, Structure.BATTERY_VOLTAGE_DETAILS),

    BATTERY_VOLTAGE_SUMMARY_BEV(ServiceType.BEV, MessageType.BATTERY_VOLTAGE_SUMMARY, Constant.V1_V2, Structure.BATTERY_VOLTAGE_SUMMARY),
    BATTERY_VOLTAGE_SUMMARY_PHEV(ServiceType.PHEV, MessageType.BATTERY_VOLTAGE_SUMMARY, Constant.V1_V2, Structure.BATTERY_VOLTAGE_SUMMARY),

    CRASH(ServiceType.ICE, MessageType.CRASH, Constant.V1_V2, Structure.CRASH),
    CRASH_BEV(ServiceType.BEV, MessageType.CRASH, Constant.V1_V2, Structure.CRASH),
    CRASH_PHEV(ServiceType.PHEV, MessageType.CRASH, Constant.V1_V2, Structure.CRASH),

    DOORS_STATUS(ServiceType.ICE, MessageType.DOORS_STATUS, Constant.V1_V2, Structure.DOORS_STATUS),
    DOORS_STATUS_BEV(ServiceType.BEV, MessageType.DOORS_STATUS, Constant.V1_V2, Structure.DOORS_STATUS),
    DOORS_STATUS_PHEV(ServiceType.PHEV, MessageType.DOORS_STATUS, Constant.V1_V2, Structure.DOORS_STATUS),

    ECOACHING_BEV(ServiceType.BEV, MessageType.ECOACHING, Constant.V1_V2, Structure.ECOACHING),
    ECOACHING_PHEV(ServiceType.PHEV, MessageType.ECOACHING, Constant.V1_V2, Structure.ECOACHING),

    EXTENSION(ServiceType.ICE, MessageType.EXTENSION, Constant.V1_V2, Structure.EXTENSION),
    EXTENSION_BEV(ServiceType.BEV, MessageType.EXTENSION, Constant.V1_V2, Structure.EXTENSION),
    EXTENSION_PHEV(ServiceType.PHEV, MessageType.EXTENSION, Constant.V1_V2, Structure.EXTENSION),

    EVENT_ALERT(ServiceType.ICE, MessageType.EVENT_ALERT, Constant.V1_V2, Structure.EVENT, Structure.JDA),
    EVENT_ALERT_BEV(ServiceType.BEV, MessageType.EVENT_ALERT, Constant.V1_V2, Structure.EVENT, Structure.JDA, Structure.CFM_LEV),
    EVENT_ALERT_PHEV(ServiceType.PHEV, MessageType.EVENT_ALERT, Constant.V1_V2, Structure.EVENT, Structure.JDA, Structure.CFM_LEV),

    EVENT_STOP(ServiceType.ICE, MessageType.EVENT_STOP, Constant.V1_V2, Structure.EVENT, Structure.JDA),
    EVENT_STOP_BEV(ServiceType.BEV, MessageType.EVENT_STOP, Constant.V1_V2, Structure.EVENT, Structure.JDA, Structure.CFM_LEV),
    EVENT_STOP_PHEV(ServiceType.PHEV, MessageType.EVENT_STOP, Constant.V1_V2, Structure.EVENT, Structure.JDA, Structure.CFM_LEV),

    EVENT_START(ServiceType.ICE, MessageType.EVENT_START, Constant.V1_V2, Structure.EVENT, Structure.JDA),
    EVENT_START_BEV(ServiceType.BEV, MessageType.EVENT_START, Constant.V1_V2, Structure.EVENT, Structure.JDA, Structure.CFM_LEV),
    EVENT_START_PHEV(ServiceType.PHEV, MessageType.EVENT_START, Constant.V1_V2, Structure.EVENT, Structure.JDA, Structure.CFM_LEV),

    EVENT_CRASH(ServiceType.ICE, MessageType.EVENT_CRASH, Constant.V1_V2, Structure.EVENT, Structure.JDA),
    EVENT_CRASH_BEV(ServiceType.BEV, MessageType.EVENT_CRASH, Constant.V1_V2, Structure.EVENT, Structure.JDA, Structure.CFM_LEV),
    EVENT_CRASH_PHEV(ServiceType.PHEV, MessageType.EVENT_CRASH, Constant.V1_V2, Structure.EVENT, Structure.JDA, Structure.CFM_LEV),

    EVENT_PRIVACY(ServiceType.ICE, MessageType.EVENT_PRIVACY, Constant.V1_V2, Structure.EVENT, Structure.JDA),
    EVENT_PRIVACY_BEV(ServiceType.BEV, MessageType.EVENT_PRIVACY, Constant.V1_V2, Structure.EVENT, Structure.JDA, Structure.CFM_LEV),
    EVENT_PRIVACY_PHEV(ServiceType.PHEV, MessageType.EVENT_PRIVACY, Constant.V1_V2, Structure.EVENT, Structure.JDA, Structure.CFM_LEV),

    JDD(ServiceType.ICE, MessageType.JDD, Constant.V1_V2, Structure.JDD),
    JDD_BEV(ServiceType.BEV, MessageType.JDD, Constant.V1_V2, Structure.JDD),
    JDD_PHEV(ServiceType.PHEV, MessageType.JDD, Constant.V1_V2, Structure.JDD),

    JDA(ServiceType.ICE, MessageType.JDA, Constant.V1_V2, Structure.JDA),
    JDA_BEV(ServiceType.BEV, MessageType.JDA, Constant.V1_V2, Structure.JDA),
    JDA_PHEV(ServiceType.PHEV, MessageType.JDA, Constant.V1_V2, Structure.JDA),

    LOCALIZATION(ServiceType.ICE, MessageType.LOCALIZATION, Constant.V1_V2, Structure.LOCALIZATION),
    LOCALIZATION_BEV(ServiceType.BEV, MessageType.LOCALIZATION, Constant.V1_V2, Structure.LOCALIZATION),
    LOCALIZATION_PHEV(ServiceType.PHEV, MessageType.LOCALIZATION, Constant.V1_V2, Structure.LOCALIZATION),

    MAINTENANCE_STATUS(ServiceType.ICE, MessageType.MAINTENANCE_STATUS, Constant.V1_V2, Structure.MAINTENANCE_STATUS),
    MAINTENANCE_STATUS_BEV(ServiceType.BEV, MessageType.MAINTENANCE_STATUS, Constant.V1_V2, Structure.MAINTENANCE_STATUS),
    MAINTENANCE_STATUS_PHEV(ServiceType.PHEV, MessageType.MAINTENANCE_STATUS, Constant.V1_V2, Structure.MAINTENANCE_STATUS),

    PERIODIC(ServiceType.ICE, MessageType.PERIODIC, Constant.V1_V2, Structure.PERIODIC),
    PERIODIC_BEV(ServiceType.BEV, MessageType.PERIODIC, Constant.V1_V2, Structure.PERIODIC, Structure.CFM_LEV),
    PERIODIC_PHEV(ServiceType.PHEV, MessageType.PERIODIC, Constant.V1_V2, Structure.PERIODIC, Structure.CFM_LEV),

    PRIVACY(ServiceType.ICE, MessageType.PRIVACY, Constant.V1_V2, Structure.PRIVACY),
    PRIVACY_BEV(ServiceType.BEV, MessageType.PRIVACY, Constant.V1_V2, Structure.PRIVACY),
    PRIVACY_PHEV(ServiceType.PHEV, MessageType.PRIVACY, Constant.V1_V2, Structure.PRIVACY),

    THERMAL_CONDITIONING_BEV(ServiceType.BEV, MessageType.THERMAL_CONDITIONING, Constant.V1_V2, Structure.THERMAL_CONDITIONING),
    THERMAL_CONDITIONING_PHEV(ServiceType.PHEV, MessageType.THERMAL_CONDITIONING, Constant.V1_V2, Structure.THERMAL_CONDITIONING),

    TRIP_BEV(ServiceType.BEV, MessageType.TRIP, Constant.V1_V2, Structure.TRIP),
    TRIP_PHEV(ServiceType.PHEV, MessageType.TRIP, Constant.V1_V2, Structure.TRIP),

    USAGE_STATUS(ServiceType.ICE, MessageType.USAGE_STATUS, Constant.V1, Structure.USAGE_STATUS),
    USAGE_STATUS_BEV(ServiceType.BEV, MessageType.USAGE_STATUS, Constant.V1, Structure.USAGE_STATUS),
    USAGE_STATUS_PHEV(ServiceType.PHEV, MessageType.USAGE_STATUS, Constant.V1, Structure.USAGE_STATUS),

    USAGE_STATUS_V2(ServiceType.ICE, MessageType.USAGE_STATUS, Constant.V2, Structure.USAGE_STATUS_V2),
    USAGE_STATUS_BEV_V2(ServiceType.BEV, MessageType.USAGE_STATUS, Constant.V2, Structure.USAGE_STATUS_V2),
    USAGE_STATUS_PHEV_V2(ServiceType.PHEV, MessageType.USAGE_STATUS, Constant.V2, Structure.USAGE_STATUS_V2),

    VEHICLE_STATUS(ServiceType.ICE, MessageType.VEHICLE_STATUS, Constant.V1, Structure.VEHICLE_STATUS),
    VEHICLE_STATUS_BEV(ServiceType.BEV, MessageType.VEHICLE_STATUS, Constant.V1, Structure.VEHICLE_STATUS),
    VEHICLE_STATUS_PHEV(ServiceType.PHEV, MessageType.VEHICLE_STATUS, Constant.V1, Structure.VEHICLE_STATUS),

    VEHICLE_STATUS_V2(ServiceType.ICE, MessageType.VEHICLE_STATUS, Constant.V2, Structure.VEHICLE_STATUS_V2),
    VEHICLE_STATUS_BEV_V2(ServiceType.BEV, MessageType.VEHICLE_STATUS, Constant.V2, Structure.VEHICLE_STATUS_V2),
    VEHICLE_STATUS_PHEV_V2(ServiceType.PHEV, MessageType.VEHICLE_STATUS, Constant.V2, Structure.VEHICLE_STATUS_V2);

    private final int serviceType;
    private final int messageType;
    private final EnumSet<Schema> schemas;
    private final Structure[] structures;

    MessageDescriptor(int serviceType, int messageType, EnumSet<Schema> schemas, Structure... structures) {
        this.serviceType = serviceType;
        this.messageType = messageType;
        this.schemas = schemas;
        this.structures = structures;
    }

    public int getServiceType() {
        return serviceType;
    }

    public int getMessageType() {
        return messageType;
    }

    public EnumSet<Schema> getSchemas() {
        return schemas;
    }

    public List<Structure> getStructures() {
        return Arrays.asList(structures);
    }

    public static MessageDescriptor findBy(int serviceType, int messageType, Schema schema) {
        return Arrays.stream(MessageDescriptor.values())
                .filter(descriptor -> descriptor.getServiceType() == serviceType
                        && descriptor.getMessageType() == messageType
                        && descriptor.getSchemas().contains(schema))
                .findFirst()
                .orElseThrow(() -> new NoSuchElementException("No message descriptor for serviceType=" + String.format("0x%02X", serviceType) + " / messageType=" + String.format("0x%02X", messageType) + " / schema=" + schema));
    }

    @Override
    public String toString() {
        return name() + " (serviceType=" + String.format("0x%02X", serviceType) + ", messageType=" + String.format("0x%02X", messageType) + ")";
    }
}