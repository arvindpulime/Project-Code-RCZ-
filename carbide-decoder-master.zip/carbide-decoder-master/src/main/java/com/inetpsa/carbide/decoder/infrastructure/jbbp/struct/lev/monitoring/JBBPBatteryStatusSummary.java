package com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.lev.monitoring;

import com.igormaznitsa.jbbp.io.JBBPBitNumber;
import com.igormaznitsa.jbbp.io.JBBPBitOrder;
import com.igormaznitsa.jbbp.mapper.Bin;
import com.igormaznitsa.jbbp.mapper.BinType;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.JBBPData;
import com.inetpsa.carbide.decoder.infrastructure.util.ByteUtils;
import lombok.Setter;

import java.math.BigDecimal;
import java.math.RoundingMode;

import static com.inetpsa.carbide.decoder.infrastructure.util.Factor.*;
import static com.inetpsa.carbide.decoder.infrastructure.util.Offset.BATTERY_PROBEID_OFFSET;
import static com.inetpsa.carbide.decoder.infrastructure.util.Offset.HV_BATTERY_TEMP_OFFSET;

@Setter
public class JBBPBatteryStatusSummary implements JBBPData {

    @Bin(order = 101, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int code;

    @Bin(order = 102, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int chargeMode;

    @Bin(order = 103, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int chargeState;

    @Bin(order = 104, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int powertrainMode;

    @Bin(order = 105, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] totalEnergy;

    @Bin(order = 106, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] remainingEnergy;

    @Bin(order = 107, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] remainingCapacity;

    @Bin(order = 108, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] stateOfCharge;

    @Bin(order = 109, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int averageTemperature;

    @Bin(order = 110, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int maxTemperature;

    @Bin(order = 111, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int minTemperature;

    @Bin(order = 112, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeWithMaxTemperature;

    @Bin(order = 113, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeWithMinTemperature;

    public int getCode() {
        return code;
    }

    public int getChargeMode() {
        return chargeMode;
    }

    public int getChargeState() {
        return chargeState;
    }

    public int getPowertrainMode() {
        return powertrainMode;
    }

    public int getTotalEnergy() {
        return ByteUtils.asInt(totalEnergy) * BATTERY_TOTAL_ENERGY_FACTOR;
    }

    public int getRemainingEnergy() {
        return ByteUtils.asInt(remainingEnergy) * BATTERY_REMAINING_ENERGY_FACTOR;
    }

    public BigDecimal getRemainingCapacity() {
        return BigDecimal.valueOf(ByteUtils.asInt(remainingCapacity) * BATTERY_REMAINING_CAPACITY_FACTOR).setScale(3, RoundingMode.FLOOR);
    }

    public BigDecimal getStateOfCharge() {
        return BigDecimal.valueOf(ByteUtils.asInt(stateOfCharge) * HV_BATTERY_SOC_FACTOR).setScale(2, RoundingMode.FLOOR);
    }

    public int getAverageTemperature() {
        return averageTemperature + HV_BATTERY_TEMP_OFFSET;
    }

    public int getMaxTemperature() {
        return maxTemperature + HV_BATTERY_TEMP_OFFSET;
    }

    public int getMinTemperature() {
        return minTemperature + HV_BATTERY_TEMP_OFFSET;
    }

    public int getProbeWithMaxTemperature() {
        return probeWithMaxTemperature + BATTERY_PROBEID_OFFSET;
    }

    public int getProbeWithMinTemperature() {
        return probeWithMinTemperature + BATTERY_PROBEID_OFFSET;
    }
}
