package com.inetpsa.carbide.decoder.infrastructure.util;

public final class Offset {

    private Offset() {
    }

    public static final int TEMPERATURE_OFFSET = -40;

    public static final int HV_BATTERY_TEMP_OFFSET = -40;

    public static final int BATTERY_CELLID_OFFSET = 1;

    public static final int BATTERY_PROBEID_OFFSET = 1;

    public static final int TORQUE_OFFSET = -100;

    public static final int MASTER_CYLINDER_OFFSET = -55;

    public static final int LONGITUDINAL_ACCELERATION_OFFSET = -14;

    public static final int BATTERY_VOLTAGE_OFFSET = 5;
}
