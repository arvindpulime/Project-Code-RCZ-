package com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.global.troubleshooting;

import com.igormaznitsa.jbbp.io.JBBPBitNumber;
import com.igormaznitsa.jbbp.io.JBBPBitOrder;
import com.igormaznitsa.jbbp.mapper.Bin;
import com.igormaznitsa.jbbp.mapper.BinType;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.JBBPData;
import com.inetpsa.carbide.decoder.infrastructure.util.ByteUtils;
import lombok.Setter;

import static com.inetpsa.carbide.decoder.infrastructure.util.Factor.SEC_TO_MS_FACTOR;
import static com.inetpsa.carbide.decoder.infrastructure.util.Factor.TIME_REFERENCE_FACTOR;

@Setter
public class JBBPJDD implements JBBPData {

    @Bin(order = 101, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int code;

    @Bin(order = 102, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] frameId;

    @Bin(order = 103, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] errorCode;

    @Bin(order = 104, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] timeReference;

    @Bin(order = 105, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] kilometer;

    @Bin(order = 106, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] lifeSituation;

    @Bin(order = 107, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int dtcState;

    @Bin(order = 108, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int messageType;

    public int getCode() {
        return code;
    }

    public int getFrameId() {
        return ByteUtils.asInt(frameId);
    }

    public int getErrorCode() {
        return ByteUtils.asInt(errorCode);
    }

    public int getTimeReference() {
        return (int) (ByteUtils.asInt(timeReference) * SEC_TO_MS_FACTOR * TIME_REFERENCE_FACTOR);
    }

    public int getKilometer() {
        return ByteUtils.asInt(kilometer);
    }

    public int getLifeSituation() {
        return ByteUtils.asInt(lifeSituation);
    }

    public int getDtcState() {
        return dtcState;
    }

    public int getMessageType() {
        return messageType;
    }
}
