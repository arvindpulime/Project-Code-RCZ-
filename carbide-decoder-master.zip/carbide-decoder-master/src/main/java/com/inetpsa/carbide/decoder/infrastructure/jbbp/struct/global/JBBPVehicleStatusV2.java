package com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.global;

import com.igormaznitsa.jbbp.io.JBBPBitOrder;
import com.igormaznitsa.jbbp.mapper.Bin;
import com.igormaznitsa.jbbp.mapper.BinType;
import com.inetpsa.carbide.decoder.infrastructure.util.ByteUtils;
import lombok.Setter;

import java.math.BigDecimal;
import java.math.RoundingMode;

import static com.inetpsa.carbide.decoder.infrastructure.util.Factor.FUEL_TOTAL_CONSUMPTION_FACTOR;

@Setter
public class JBBPVehicleStatusV2 extends JBBPVehicleStatus {

    @Bin(order = 112, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] fuelTotalConsumption;

    public BigDecimal getFuelTotalConsumption() {
        return BigDecimal.valueOf(ByteUtils.asInt(fuelTotalConsumption) * FUEL_TOTAL_CONSUMPTION_FACTOR).setScale(3, RoundingMode.FLOOR);
    }
}
