package com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.legacy;

import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.legacy.JBBPPeriodic;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.DataMapper;
import com.inetpsa.carbide.domain.interfaces.data.legacy.Periodic;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper//(uses = {TimeType.class})
public interface PeriodicMapper extends DataMapper<Periodic, JBBPPeriodic> {

    PeriodicMapper INSTANCE = Mappers.getMapper(PeriodicMapper.class);

    @Override
    @Mapping(target = "gps.altitudes", source = "altitudes")
    @Mapping(target = "gps.headings", source = "headings")
    @Mapping(target = "gps.longitudes", source = "longitudes")
    @Mapping(target = "gps.latitudes", source = "latitudes")
    @Mapping(target = "gps.gpsSignalQualities", source = "gpsSignalQualities")
    @Mapping(target = "gps.vehicleLocationTypes", source = "vehicleLocationTypes")
    @Mapping(target = "crash.rearHighSpeedCrashInfo", source = "rearHighSpeedCrashInfo")
    @Mapping(target = "crash.rearMediumSpeedCrashInfo", source = "rearMediumSpeedCrashInfo")
    @Mapping(target = "crash.rearSlowSpeedCrashInfo", source = "rearSlowSpeedCrashInfo")
    @Mapping(target = "crash.rearReparabilitySpeedCrashInfo", source = "rearReparabilitySpeedCrashInfo")
    @Mapping(target = "crash.highSpeedFrontCrashInfo", source = "highSpeedFrontCrashInfo")
    @Mapping(target = "crash.mediumSpeedN1FrontCrashInfo", source = "mediumSpeedN1FrontCrashInfo")
    @Mapping(target = "crash.mediumSpeedN2FrontCrashInfo", source = "mediumSpeedN2FrontCrashInfo")
    @Mapping(target = "crash.lowSpeedFrontCrashInfo", source = "lowSpeedFrontCrashInfo")
    @Mapping(target = "crash.frontReparabilityCrashInfo", source = "frontReparabilityCrashInfo")
    @Mapping(target = "crash.rearHighSpeedLateralCrashInfo", source = "rearHighSpeedLateralCrashInfo")
    @Mapping(target = "crash.rearMediumSpeedLateralCrashInfo", source = "rearMediumSpeedLateralCrashInfo")
    @Mapping(target = "crash.rearLowSpeedLateralCrashInfo", source = "rearLowSpeedLateralCrashInfo")
    @Mapping(target = "crash.rearRepairabilityCrashInfo", source = "rearRepairabilityCrashInfo")
    @Mapping(target = "crash.tippedOver", source = "tippedOver")
    @Mapping(target = "crash.pedestrianCrashInfos", source = "pedestrianCrashInfos")
    @Mapping(target = "adas.rearParkings", source = "rearParkings")
    @Mapping(target = "adas.frontParkings", source = "frontParkings")
    @Mapping(target = "adas.adaptiveCruiseControlRegulations", source = "adaptiveCruiseControlRegulations")
    @Mapping(target = "adas.advancedEmergencyBrakingSystems", source = "advancedEmergencyBrakingSystems")
    @Mapping(target = "adas.laneDepartureWarnings", source = "laneDepartureWarnings")
    @Mapping(target = "adas.respectOfInterVehicleTimeAssists", source = "respectOfInterVehicleTimeAssists")
    @Mapping(target = "adas.triggeringOfESPs", source = "triggeringOfESPs")
    @Mapping(target = "adas.triggeringOfABSs", source = "triggeringOfABSs")
    @Mapping(target = "adas.electricBrakeServices", source = "electricBrakeServices")
    @Mapping(target = "adas.advancedSpeedRegulatorAndLimits", source = "advancedSpeedRegulatorAndLimits")
    @Mapping(target = "adas.rightLaneKeepingAssists", source = "rightLaneKeepingAssists")
    @Mapping(target = "adas.leftLaneKeepingAssists", source = "leftLaneKeepingAssists")
    @Mapping(target = "adas.advancedSpeedRegulators", source = "advancedSpeedRegulators")
    @Mapping(target = "adas.blindSpotMonitorings", source = "blindSpotMonitorings")
    @Mapping(target = "adas.speedLimitInformations", source = "speedLimitInformations")
    @Mapping(target = "vehicle.rearFogLampsStatements", source = "rearFogLampsStatements")
    @Mapping(target = "vehicle.frontFogLampsStatements", source = "frontFogLampsStatements")
    @Mapping(target = "vehicle.unbuckledBeltWarning", source = "unbuckledBeltWarning")
    @Mapping(target = "vehicle.outsideTemperature", source = "outsideTemperature")
    @Mapping(target = "vehicle.recommendedGearIndicators", source = "recommendedGearIndicators")
    @Mapping(target = "vehicle.fuelInstantConsumptions", source = "fuelInstantConsumptions")
    @Mapping(target = "vehicle.fuelTotalConsumption", source = "fuelTotalConsumption")
    @Mapping(target = "vehicle.ignition", source = "ignition")
    @Mapping(target = "vehicle.gearboxModes", source = "gearboxModes")
    @Mapping(target = "vehicle.engineSpeeds", source = "engineSpeeds")
    @Mapping(target = "vehicle.longitudinalSpeeds", source = "longitudinalSpeeds")
    @Mapping(target = "vehicle.luminosities", source = "luminosities")
    @Mapping(target = "vehicle.vehicleModes", source = "vehicleModes")
    @Mapping(target = "vehicle.hybridModes", source = "hybridModes")
    @Mapping(target = "vehicle.lifetimeMileage", source = "lifetimeMileage")
    @Mapping(target = "vehicle.fuelLevel", source = "fuelLevel")
    @Mapping(target = "vehicle.oilTemperature", source = "oilTemperature")
    @Mapping(target = "vehicle.gmpStatus", source = "gmpStatus")
    Periodic toDto(JBBPPeriodic jBBPPeriodic);
}
