package com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.lev;

import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.lev.JBBPBattery;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.DataMapper;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.qualifier.IntToLocalTime;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.type.TimeConverter;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.type.TimeType;
import com.inetpsa.carbide.domain.interfaces.data.lev.Battery;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(uses = TimeType.class)
public interface BatteryMapper extends DataMapper<Battery, JBBPBattery> {

    BatteryMapper INSTANCE = Mappers.getMapper(BatteryMapper.class);

    @Override
    @Mapping(target = "rtabStartTime", qualifiedBy = {TimeConverter.class, IntToLocalTime.class})
    Battery toDto(JBBPBattery jbbpData);
}
