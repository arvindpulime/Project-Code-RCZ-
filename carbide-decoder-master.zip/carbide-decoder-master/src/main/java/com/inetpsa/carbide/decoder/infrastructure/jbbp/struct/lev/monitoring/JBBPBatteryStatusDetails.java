package com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.lev.monitoring;

import com.igormaznitsa.jbbp.io.JBBPBitOrder;
import com.igormaznitsa.jbbp.mapper.Bin;
import com.igormaznitsa.jbbp.mapper.BinType;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.JBBPData;
import com.inetpsa.carbide.decoder.infrastructure.util.CollectionUtils;
import com.inetpsa.carbide.decoder.infrastructure.util.Formula;
import lombok.Setter;

import java.util.List;

@Setter
public class JBBPBatteryStatusDetails implements JBBPData {

    @Bin(order = 101, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int code;

    @Bin(order = 102, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int totalProbes;

    @Bin(order = 103, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature01;

    @Bin(order = 104, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature02;

    @Bin(order = 105, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature03;

    @Bin(order = 106, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature04;

    @Bin(order = 107, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature05;

    @Bin(order = 108, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature06;

    @Bin(order = 109, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature07;

    @Bin(order = 110, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature08;

    @Bin(order = 111, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature09;

    @Bin(order = 112, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature10;

    @Bin(order = 113, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature11;

    @Bin(order = 114, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature12;

    @Bin(order = 115, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature13;

    @Bin(order = 116, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature14;

    @Bin(order = 117, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature15;

    @Bin(order = 118, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature16;

    @Bin(order = 119, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature17;

    @Bin(order = 120, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature18;

    @Bin(order = 121, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature19;

    @Bin(order = 122, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature20;

    @Bin(order = 123, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature21;

    @Bin(order = 124, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature22;

    @Bin(order = 125, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature23;

    @Bin(order = 126, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature24;

    @Bin(order = 127, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature25;

    @Bin(order = 128, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature26;

    @Bin(order = 129, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature27;

    @Bin(order = 130, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature28;

    @Bin(order = 131, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature29;

    @Bin(order = 132, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature30;

    @Bin(order = 133, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature31;

    @Bin(order = 134, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature32;

    @Bin(order = 135, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature33;

    @Bin(order = 136, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature34;

    @Bin(order = 137, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature35;

    @Bin(order = 138, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature36;

    @Bin(order = 139, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature37;

    @Bin(order = 140, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature38;

    @Bin(order = 141, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature39;

    @Bin(order = 142, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature40;

    @Bin(order = 143, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature41;

    @Bin(order = 144, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature42;

    @Bin(order = 145, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature43;

    @Bin(order = 146, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature44;

    @Bin(order = 147, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature45;

    @Bin(order = 148, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature46;

    @Bin(order = 149, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature47;

    @Bin(order = 150, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature48;

    @Bin(order = 151, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature49;

    @Bin(order = 152, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature50;

    @Bin(order = 153, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature51;

    @Bin(order = 154, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature52;

    @Bin(order = 155, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature53;

    @Bin(order = 156, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int probeTemperature54;

    public int getCode() {
        return code;
    }

    public int getTotalProbes() {
        return totalProbes;
    }

    public List<Integer> getProbeTemperatures() {
        return CollectionUtils.addAllKeepFirst(
                this.totalProbes,
                Formula.toProbeTemperature(probeTemperature01),
                Formula.toProbeTemperature(probeTemperature02),
                Formula.toProbeTemperature(probeTemperature03),
                Formula.toProbeTemperature(probeTemperature04),
                Formula.toProbeTemperature(probeTemperature05),
                Formula.toProbeTemperature(probeTemperature06),
                Formula.toProbeTemperature(probeTemperature07),
                Formula.toProbeTemperature(probeTemperature08),
                Formula.toProbeTemperature(probeTemperature09),
                Formula.toProbeTemperature(probeTemperature10),
                Formula.toProbeTemperature(probeTemperature11),
                Formula.toProbeTemperature(probeTemperature12),
                Formula.toProbeTemperature(probeTemperature13),
                Formula.toProbeTemperature(probeTemperature14),
                Formula.toProbeTemperature(probeTemperature15),
                Formula.toProbeTemperature(probeTemperature16),
                Formula.toProbeTemperature(probeTemperature17),
                Formula.toProbeTemperature(probeTemperature18),
                Formula.toProbeTemperature(probeTemperature19),
                Formula.toProbeTemperature(probeTemperature20),
                Formula.toProbeTemperature(probeTemperature21),
                Formula.toProbeTemperature(probeTemperature22),
                Formula.toProbeTemperature(probeTemperature23),
                Formula.toProbeTemperature(probeTemperature24),
                Formula.toProbeTemperature(probeTemperature25),
                Formula.toProbeTemperature(probeTemperature26),
                Formula.toProbeTemperature(probeTemperature27),
                Formula.toProbeTemperature(probeTemperature28),
                Formula.toProbeTemperature(probeTemperature29),
                Formula.toProbeTemperature(probeTemperature30),
                Formula.toProbeTemperature(probeTemperature31),
                Formula.toProbeTemperature(probeTemperature32),
                Formula.toProbeTemperature(probeTemperature33),
                Formula.toProbeTemperature(probeTemperature34),
                Formula.toProbeTemperature(probeTemperature35),
                Formula.toProbeTemperature(probeTemperature36),
                Formula.toProbeTemperature(probeTemperature37),
                Formula.toProbeTemperature(probeTemperature38),
                Formula.toProbeTemperature(probeTemperature39),
                Formula.toProbeTemperature(probeTemperature40),
                Formula.toProbeTemperature(probeTemperature41),
                Formula.toProbeTemperature(probeTemperature42),
                Formula.toProbeTemperature(probeTemperature43),
                Formula.toProbeTemperature(probeTemperature44),
                Formula.toProbeTemperature(probeTemperature45),
                Formula.toProbeTemperature(probeTemperature46),
                Formula.toProbeTemperature(probeTemperature47),
                Formula.toProbeTemperature(probeTemperature48),
                Formula.toProbeTemperature(probeTemperature49),
                Formula.toProbeTemperature(probeTemperature50),
                Formula.toProbeTemperature(probeTemperature51),
                Formula.toProbeTemperature(probeTemperature52),
                Formula.toProbeTemperature(probeTemperature53),
                Formula.toProbeTemperature(probeTemperature54));
    }
}
