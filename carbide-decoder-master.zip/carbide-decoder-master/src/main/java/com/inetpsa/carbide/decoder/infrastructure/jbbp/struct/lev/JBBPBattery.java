package com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.lev;

import com.igormaznitsa.jbbp.io.JBBPBitNumber;
import com.igormaznitsa.jbbp.io.JBBPBitOrder;
import com.igormaznitsa.jbbp.mapper.Bin;
import com.igormaznitsa.jbbp.mapper.BinType;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.JBBPData;
import com.inetpsa.carbide.decoder.infrastructure.util.ByteUtils;
import lombok.Setter;

import static com.inetpsa.carbide.decoder.infrastructure.util.Factor.*;

@Setter
public final class JBBPBattery implements JBBPData {

    @Bin(order = 101, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int code;

    @Bin(order = 102, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int chargeState;

    @Bin(order = 103, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int chargeMode;

    @Bin(order = 104, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int plugState;

    @Bin(order = 105, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] rtabStartTime;

    @Bin(order = 106, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int loadLevel;

    @Bin(order = 107, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int fuelLevel;

    @Bin(order = 108, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] autonomy;

    @Bin(order = 109, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] zevAutonomy;

    @Bin(order = 110, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_7, bitOrder = JBBPBitOrder.MSB0)
    private int remainingChargeTime;

    @Bin(order = 111, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int zevChargeGain;

    public int getCode() {
        return code;
    }

    public int getChargeState() {
        return chargeState;
    }

    public int getChargeMode() {
        return chargeMode;
    }

    public int getPlugState() {
        return plugState;
    }

    public int getRtabStartTime() {
        return ByteUtils.asInt(rtabStartTime);
    }

    public int getLoadLevel() {
        return loadLevel;
    }

    public int getFuelLevel() {
        return fuelLevel;
    }

    public int getAutonomy() {
        return ByteUtils.asInt(autonomy);
    }

    public int getZevAutonomy() {
        return ByteUtils.asInt(zevAutonomy) * ZEV_AUTONOMY_FACTOR;
    }

    public int getRemainingChargeTime() {
        return remainingChargeTime * REMAINING_CHARGE_TIME_FACTOR;
    }

    public int getZevChargeGain() {
        return zevChargeGain * ZEV_CHARGE_GAIN_FACTOR;
    }
}
