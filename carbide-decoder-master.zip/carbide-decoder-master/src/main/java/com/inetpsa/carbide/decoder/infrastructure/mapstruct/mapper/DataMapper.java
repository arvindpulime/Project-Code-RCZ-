package com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper;

import com.inetpsa.carbide.decoder.application.exceptions.DecoderException;

public interface DataMapper<D, J> {

    D toDto(J jbbpData) throws DecoderException;
}
