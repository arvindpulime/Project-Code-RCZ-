package com.inetpsa.carbide.decoder.infrastructure.jbbp.struct;

public interface JBBPData {

}
