package com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.lev.monitoring;

import com.igormaznitsa.jbbp.io.JBBPBitOrder;
import com.igormaznitsa.jbbp.mapper.Bin;
import com.igormaznitsa.jbbp.mapper.BinType;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.JBBPData;
import com.inetpsa.carbide.decoder.infrastructure.util.ByteUtils;
import com.inetpsa.carbide.decoder.infrastructure.util.CollectionUtils;
import com.inetpsa.carbide.decoder.infrastructure.util.Formula;
import lombok.Setter;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

import static com.inetpsa.carbide.decoder.infrastructure.util.Factor.HV_BATTERY_INTENSITY_FACTOR;
import static com.inetpsa.carbide.decoder.infrastructure.util.SignalSize.HV_BATTERY_INTENSITY_SIZE;

@Setter
public class JBBPBatteryVoltageDetails implements JBBPData {

    @Bin(order = 101, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int code;

    @Bin(order = 102, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] intensity;

    @Bin(order = 103, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int totalCells;

    @Bin(order = 104, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage001;

    @Bin(order = 105, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage002;

    @Bin(order = 106, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage003;

    @Bin(order = 107, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage004;

    @Bin(order = 108, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage005;

    @Bin(order = 109, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage006;

    @Bin(order = 110, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage007;

    @Bin(order = 111, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage008;

    @Bin(order = 112, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage009;

    @Bin(order = 113, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage010;

    @Bin(order = 114, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage011;

    @Bin(order = 115, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage012;

    @Bin(order = 116, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage013;

    @Bin(order = 117, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage014;

    @Bin(order = 118, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage015;

    @Bin(order = 119, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage016;

    @Bin(order = 120, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage017;

    @Bin(order = 121, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage018;

    @Bin(order = 122, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage019;

    @Bin(order = 123, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage020;

    @Bin(order = 124, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage021;

    @Bin(order = 125, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage022;

    @Bin(order = 126, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage023;

    @Bin(order = 127, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage024;

    @Bin(order = 128, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage025;

    @Bin(order = 129, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage026;

    @Bin(order = 130, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage027;

    @Bin(order = 131, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage028;

    @Bin(order = 132, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage029;

    @Bin(order = 133, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage030;

    @Bin(order = 134, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage031;

    @Bin(order = 135, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage032;

    @Bin(order = 136, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage033;

    @Bin(order = 137, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage034;

    @Bin(order = 138, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage035;

    @Bin(order = 139, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage036;

    @Bin(order = 140, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage037;

    @Bin(order = 141, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage038;

    @Bin(order = 142, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage039;

    @Bin(order = 143, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage040;

    @Bin(order = 144, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage041;

    @Bin(order = 145, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage042;

    @Bin(order = 146, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage043;

    @Bin(order = 147, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage044;

    @Bin(order = 148, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage045;

    @Bin(order = 149, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage046;

    @Bin(order = 150, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage047;

    @Bin(order = 151, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage048;

    @Bin(order = 152, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage049;

    @Bin(order = 153, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage050;

    @Bin(order = 154, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage051;

    @Bin(order = 155, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage052;

    @Bin(order = 156, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage053;

    @Bin(order = 157, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage054;

    @Bin(order = 158, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage055;

    @Bin(order = 159, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage056;

    @Bin(order = 160, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage057;

    @Bin(order = 161, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage058;

    @Bin(order = 162, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage059;

    @Bin(order = 163, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage060;

    @Bin(order = 164, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage061;

    @Bin(order = 165, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage062;

    @Bin(order = 166, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage063;

    @Bin(order = 167, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage064;

    @Bin(order = 168, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage065;

    @Bin(order = 169, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage066;

    @Bin(order = 170, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage067;

    @Bin(order = 171, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage068;

    @Bin(order = 172, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage069;

    @Bin(order = 173, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage070;

    @Bin(order = 174, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage071;

    @Bin(order = 175, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage072;

    @Bin(order = 176, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage073;

    @Bin(order = 177, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage074;

    @Bin(order = 178, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage075;

    @Bin(order = 179, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage076;

    @Bin(order = 180, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage077;

    @Bin(order = 181, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage078;

    @Bin(order = 182, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage079;

    @Bin(order = 183, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage080;

    @Bin(order = 184, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage081;

    @Bin(order = 185, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage082;

    @Bin(order = 186, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage083;

    @Bin(order = 187, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage084;

    @Bin(order = 188, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage085;

    @Bin(order = 189, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage086;

    @Bin(order = 190, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage087;

    @Bin(order = 191, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage088;

    @Bin(order = 192, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage089;

    @Bin(order = 193, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage090;

    @Bin(order = 194, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage091;

    @Bin(order = 195, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage092;

    @Bin(order = 196, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage093;

    @Bin(order = 197, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage094;

    @Bin(order = 198, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage095;

    @Bin(order = 199, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage096;

    @Bin(order = 200, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage097;

    @Bin(order = 201, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage098;

    @Bin(order = 202, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage099;

    @Bin(order = 203, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage100;

    @Bin(order = 204, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage101;

    @Bin(order = 205, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage102;

    @Bin(order = 206, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage103;

    @Bin(order = 207, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage104;

    @Bin(order = 208, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage105;

    @Bin(order = 209, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage106;

    @Bin(order = 210, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage107;

    @Bin(order = 211, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellVoltage108;

    public int getCode() {
        return code;
    }

    public BigDecimal getIntensity() {
        return BigDecimal.valueOf(ByteUtils.asSignedInt(intensity, HV_BATTERY_INTENSITY_SIZE) * HV_BATTERY_INTENSITY_FACTOR).setScale(2, RoundingMode.FLOOR);
    }

    public int getTotalCells() {
        return totalCells;
    }

    public List<BigDecimal> getCellVoltages() {
        return CollectionUtils.addAllKeepFirst(
                this.totalCells,
                Formula.toCellVoltage(cellVoltage001),
                Formula.toCellVoltage(cellVoltage002),
                Formula.toCellVoltage(cellVoltage003),
                Formula.toCellVoltage(cellVoltage004),
                Formula.toCellVoltage(cellVoltage005),
                Formula.toCellVoltage(cellVoltage006),
                Formula.toCellVoltage(cellVoltage007),
                Formula.toCellVoltage(cellVoltage008),
                Formula.toCellVoltage(cellVoltage009),
                Formula.toCellVoltage(cellVoltage010),
                Formula.toCellVoltage(cellVoltage011),
                Formula.toCellVoltage(cellVoltage012),
                Formula.toCellVoltage(cellVoltage013),
                Formula.toCellVoltage(cellVoltage014),
                Formula.toCellVoltage(cellVoltage015),
                Formula.toCellVoltage(cellVoltage016),
                Formula.toCellVoltage(cellVoltage017),
                Formula.toCellVoltage(cellVoltage018),
                Formula.toCellVoltage(cellVoltage019),
                Formula.toCellVoltage(cellVoltage020),
                Formula.toCellVoltage(cellVoltage021),
                Formula.toCellVoltage(cellVoltage022),
                Formula.toCellVoltage(cellVoltage023),
                Formula.toCellVoltage(cellVoltage024),
                Formula.toCellVoltage(cellVoltage025),
                Formula.toCellVoltage(cellVoltage026),
                Formula.toCellVoltage(cellVoltage027),
                Formula.toCellVoltage(cellVoltage028),
                Formula.toCellVoltage(cellVoltage029),
                Formula.toCellVoltage(cellVoltage030),
                Formula.toCellVoltage(cellVoltage031),
                Formula.toCellVoltage(cellVoltage032),
                Formula.toCellVoltage(cellVoltage033),
                Formula.toCellVoltage(cellVoltage034),
                Formula.toCellVoltage(cellVoltage035),
                Formula.toCellVoltage(cellVoltage036),
                Formula.toCellVoltage(cellVoltage037),
                Formula.toCellVoltage(cellVoltage038),
                Formula.toCellVoltage(cellVoltage039),
                Formula.toCellVoltage(cellVoltage040),
                Formula.toCellVoltage(cellVoltage041),
                Formula.toCellVoltage(cellVoltage042),
                Formula.toCellVoltage(cellVoltage043),
                Formula.toCellVoltage(cellVoltage044),
                Formula.toCellVoltage(cellVoltage045),
                Formula.toCellVoltage(cellVoltage046),
                Formula.toCellVoltage(cellVoltage047),
                Formula.toCellVoltage(cellVoltage048),
                Formula.toCellVoltage(cellVoltage049),
                Formula.toCellVoltage(cellVoltage050),
                Formula.toCellVoltage(cellVoltage051),
                Formula.toCellVoltage(cellVoltage052),
                Formula.toCellVoltage(cellVoltage053),
                Formula.toCellVoltage(cellVoltage054),
                Formula.toCellVoltage(cellVoltage055),
                Formula.toCellVoltage(cellVoltage056),
                Formula.toCellVoltage(cellVoltage057),
                Formula.toCellVoltage(cellVoltage058),
                Formula.toCellVoltage(cellVoltage059),
                Formula.toCellVoltage(cellVoltage060),
                Formula.toCellVoltage(cellVoltage061),
                Formula.toCellVoltage(cellVoltage062),
                Formula.toCellVoltage(cellVoltage063),
                Formula.toCellVoltage(cellVoltage064),
                Formula.toCellVoltage(cellVoltage065),
                Formula.toCellVoltage(cellVoltage066),
                Formula.toCellVoltage(cellVoltage067),
                Formula.toCellVoltage(cellVoltage068),
                Formula.toCellVoltage(cellVoltage069),
                Formula.toCellVoltage(cellVoltage070),
                Formula.toCellVoltage(cellVoltage071),
                Formula.toCellVoltage(cellVoltage072),
                Formula.toCellVoltage(cellVoltage073),
                Formula.toCellVoltage(cellVoltage074),
                Formula.toCellVoltage(cellVoltage075),
                Formula.toCellVoltage(cellVoltage076),
                Formula.toCellVoltage(cellVoltage077),
                Formula.toCellVoltage(cellVoltage078),
                Formula.toCellVoltage(cellVoltage079),
                Formula.toCellVoltage(cellVoltage080),
                Formula.toCellVoltage(cellVoltage081),
                Formula.toCellVoltage(cellVoltage082),
                Formula.toCellVoltage(cellVoltage083),
                Formula.toCellVoltage(cellVoltage084),
                Formula.toCellVoltage(cellVoltage085),
                Formula.toCellVoltage(cellVoltage086),
                Formula.toCellVoltage(cellVoltage087),
                Formula.toCellVoltage(cellVoltage088),
                Formula.toCellVoltage(cellVoltage089),
                Formula.toCellVoltage(cellVoltage090),
                Formula.toCellVoltage(cellVoltage091),
                Formula.toCellVoltage(cellVoltage092),
                Formula.toCellVoltage(cellVoltage093),
                Formula.toCellVoltage(cellVoltage094),
                Formula.toCellVoltage(cellVoltage095),
                Formula.toCellVoltage(cellVoltage096),
                Formula.toCellVoltage(cellVoltage097),
                Formula.toCellVoltage(cellVoltage098),
                Formula.toCellVoltage(cellVoltage099),
                Formula.toCellVoltage(cellVoltage100),
                Formula.toCellVoltage(cellVoltage101),
                Formula.toCellVoltage(cellVoltage102),
                Formula.toCellVoltage(cellVoltage103),
                Formula.toCellVoltage(cellVoltage104),
                Formula.toCellVoltage(cellVoltage105),
                Formula.toCellVoltage(cellVoltage106),
                Formula.toCellVoltage(cellVoltage107),
                Formula.toCellVoltage(cellVoltage108));
    }
}
