package com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.lev;

import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.lev.JBBPThermalConditioning;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.DataMapper;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.qualifier.IntToBoolean;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.qualifier.IntToLocalTime;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.type.BooleanConverter;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.type.BooleanType;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.type.TimeConverter;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.type.TimeType;
import com.inetpsa.carbide.domain.interfaces.data.lev.ThermalConditioning;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(uses = {TimeType.class, BooleanType.class})
public interface ThermalConditioningMapper extends DataMapper<ThermalConditioning, JBBPThermalConditioning> {

    ThermalConditioningMapper INSTANCE = Mappers.getMapper(ThermalConditioningMapper.class);

    @Override
    @Mapping(target = "week1PrecondTime", qualifiedBy = {TimeConverter.class, IntToLocalTime.class})
    @Mapping(target = "week2PrecondTime", qualifiedBy = {TimeConverter.class, IntToLocalTime.class})
    @Mapping(target = "week3PrecondTime", qualifiedBy = {TimeConverter.class, IntToLocalTime.class})
    @Mapping(target = "week4PrecondTime", qualifiedBy = {TimeConverter.class, IntToLocalTime.class})
    @Mapping(target = "week1PrecondActivation", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "week1Day1PrecondActivation", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "week1Day2PrecondActivation", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "week1Day3PrecondActivation", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "week1Day4PrecondActivation", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "week1Day5PrecondActivation", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "week1Day6PrecondActivation", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "week1Day7PrecondActivation", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "week2PrecondActivation", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "week2Day1PrecondActivation", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "week2Day2PrecondActivation", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "week2Day3PrecondActivation", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "week2Day4PrecondActivation", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "week2Day5PrecondActivation", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "week2Day6PrecondActivation", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "week2Day7PrecondActivation", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "week3PrecondActivation", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "week3Day1PrecondActivation", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "week3Day2PrecondActivation", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "week3Day3PrecondActivation", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "week3Day4PrecondActivation", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "week3Day5PrecondActivation", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "week3Day6PrecondActivation", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "week3Day7PrecondActivation", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "week4PrecondActivation", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "week4Day1PrecondActivation", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "week4Day2PrecondActivation", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "week4Day3PrecondActivation", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "week4Day4PrecondActivation", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "week4Day5PrecondActivation", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "week4Day6PrecondActivation", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "week4Day7PrecondActivation", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    ThermalConditioning toDto(JBBPThermalConditioning jbbpData);
}
