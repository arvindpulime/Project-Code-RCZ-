package com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.legacy;

import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.legacy.JBBPEvent;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.DataMapper;
import com.inetpsa.carbide.domain.interfaces.data.legacy.Event;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper
public interface EventMapper extends DataMapper<Event, JBBPEvent> {

    EventMapper INSTANCE = Mappers.getMapper(EventMapper.class);

    @Override
    @Mapping(target = "previous.previousLifetimeMileage", source = "previousLifetimeMileage")
    @Mapping(target = "previous.previousFuelLevel", source = "previousFuelLevel")
    @Mapping(target = "previous.previousPrivacyMode", source = "previousPrivacyMode")
    @Mapping(target = "previous.previousTriggerType", source = "previousTriggerType")
    @Mapping(target = "previous.previousDateOfEvent", source = "previousDateOfEvent")
    @Mapping(target = "previous.previousIdFrame", source = "previousIdFrame")
    @Mapping(target = "previous.previousAltitude", source = "previousAltitude")
    @Mapping(target = "previous.previousHeading", source = "previousHeading")
    @Mapping(target = "previous.previousLongitude", source = "previousLongitude")
    @Mapping(target = "previous.previousLatitude", source = "previousLatitude")
    @Mapping(target = "previous.previousGPSSignalQuality", source = "previousGPSSignalQuality")
    @Mapping(target = "previous.previousVehicleLocationType", source = "previousVehicleLocationType")
    @Mapping(target = "gps.altitudes", source = "altitudes")
    @Mapping(target = "gps.headings", source = "headings")
    @Mapping(target = "gps.longitudes", source = "longitudes")
    @Mapping(target = "gps.latitudes", source = "latitudes")
    @Mapping(target = "gps.gpsSignalQualities", source = "gpsSignalQualities")
    @Mapping(target = "gps.vehicleLocationTypes", source = "vehicleLocationTypes")
    @Mapping(target = "crash.rearHighSpeedCrashInfo", source = "rearHighSpeedCrashInfo")
    @Mapping(target = "crash.rearMediumSpeedCrashInfo", source = "rearMediumSpeedCrashInfo")
    @Mapping(target = "crash.rearSlowSpeedCrashInfo", source = "rearSlowSpeedCrashInfo")
    @Mapping(target = "crash.rearReparabilitySpeedCrashInfo", source = "rearReparabilitySpeedCrashInfo")
    @Mapping(target = "crash.pedestrianCrashInfo", source = "pedestrianCrashInfo")
    @Mapping(target = "crash.highSpeedFrontCrashInfo", source = "highSpeedFrontCrashInfo")
    @Mapping(target = "crash.mediumSpeedN1FrontCrashInfo", source = "mediumSpeedN1FrontCrashInfo")
    @Mapping(target = "crash.mediumSpeedN2FrontCrashInfo", source = "mediumSpeedN2FrontCrashInfo")
    @Mapping(target = "crash.lowSpeedFrontCrashInfo", source = "lowSpeedFrontCrashInfo")
    @Mapping(target = "crash.frontReparabilityCrashInfo", source = "frontReparabilityCrashInfo")
    @Mapping(target = "crash.rearHighSpeedLateralCrashInfo", source = "rearHighSpeedLateralCrashInfo")
    @Mapping(target = "crash.rearMediumSpeedLateralCrashInfo", source = "rearMediumSpeedLateralCrashInfo")
    @Mapping(target = "crash.rearLowSpeedLateralCrashInfo", source = "rearLowSpeedLateralCrashInfo")
    @Mapping(target = "crash.rearRepairabilityCrashInfo", source = "rearRepairabilityCrashInfo")
    @Mapping(target = "crash.tippedOver", source = "tippedOver")
    @Mapping(target = "adas.rearParkings", source = "rearParkings")
    @Mapping(target = "adas.frontParkings", source = "frontParkings")
    @Mapping(target = "adas.adaptiveCruiseControlRegulations", source = "adaptiveCruiseControlRegulations")
    @Mapping(target = "adas.advancedEmergencyBrakingSystems", source = "advancedEmergencyBrakingSystems")
    @Mapping(target = "adas.laneDepartureWarnings", source = "laneDepartureWarnings")
    @Mapping(target = "adas.respectOfInterVehicleTimeAssists", source = "respectOfInterVehicleTimeAssists")
    @Mapping(target = "adas.triggeringOfESPs", source = "triggeringOfESPs")
    @Mapping(target = "adas.triggeringOfABSs", source = "triggeringOfABSs")
    @Mapping(target = "adas.electricBrakeServices", source = "electricBrakeServices")
    @Mapping(target = "adas.advancedSpeedRegulatorAndLimits", source = "advancedSpeedRegulatorAndLimits")
    @Mapping(target = "adas.rightLaneKeepingAssists", source = "rightLaneKeepingAssists")
    @Mapping(target = "adas.leftLaneKeepingAssists", source = "leftLaneKeepingAssists")
    @Mapping(target = "adas.advancedSpeedRegulators", source = "advancedSpeedRegulators")
    @Mapping(target = "adas.blindSpotMonitorings", source = "blindSpotMonitorings")
    @Mapping(target = "adas.speedLimitInformations", source = "speedLimitInformations")
    @Mapping(target = "vehicle.rearFogLampsStatement", source = "rearFogLampsStatement")
    @Mapping(target = "vehicle.frontFogLampsStatement", source = "frontFogLampsStatement")
    @Mapping(target = "vehicle.unbuckledBeltWarnings", source = "unbuckledBeltWarnings")
    @Mapping(target = "vehicle.outsideTemperature", source = "outsideTemperature")
    @Mapping(target = "vehicle.fuelInstantConsumption", source = "fuelInstantConsumption")
    @Mapping(target = "vehicle.fuelTotalConsumption", source = "fuelTotalConsumption")
    @Mapping(target = "vehicle.ignition", source = "ignition")
    @Mapping(target = "vehicle.longitudinalSpeeds", source = "longitudinalSpeeds")
    @Mapping(target = "vehicle.luminosities", source = "luminosities")
    @Mapping(target = "vehicle.lifetimeMileage", source = "lifetimeMileage")
    @Mapping(target = "vehicle.mileageBeforeMaintenanceSign", source = "mileageBeforeMaintenanceSign")
    @Mapping(target = "vehicle.mileageBeforeMaintenance", source = "mileageBeforeMaintenance")
    @Mapping(target = "vehicle.daysBeforeMaintenanceSign", source = "daysBeforeMaintenanceSign")
    @Mapping(target = "vehicle.daysBeforeMaintenance", source = "daysBeforeMaintenance")
    @Mapping(target = "vehicle.fuelLevel", source = "fuelLevel")
    @Mapping(target = "vehicle.oilTemperature", source = "oilTemperature")
    @Mapping(target = "vehicle.gmpStatus", source = "gmpStatus")
    @Mapping(target = "vehicle.rightIndicatorStatements", source = "rightIndicatorStatements")
    @Mapping(target = "vehicle.leftIndicatorStatements", source = "leftIndicatorStatements")
    @Mapping(target = "vehicle.ecallTriggering", source = "ecallTriggering")
    @Mapping(target = "vehicle.alertOfFuelLowLevel", source = "alertOfFuelLowLevel")
    @Mapping(target = "vehicle.alertOfSCRLowLevel", source = "alertOfSCRLowLevel")
    @Mapping(target = "vehicle.residualAutonomy", source = "residualAutonomy")
    Event toDto(JBBPEvent jBBPEvent);
}
