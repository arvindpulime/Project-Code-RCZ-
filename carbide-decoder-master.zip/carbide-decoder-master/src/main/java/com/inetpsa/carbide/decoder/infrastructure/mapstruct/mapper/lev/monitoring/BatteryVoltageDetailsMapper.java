package com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.lev.monitoring;

import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.lev.monitoring.JBBPBatteryVoltageDetails;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.DataMapper;
import com.inetpsa.carbide.domain.interfaces.data.lev.monitoring.BatteryVoltageDetails;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface BatteryVoltageDetailsMapper extends DataMapper<BatteryVoltageDetails, JBBPBatteryVoltageDetails> {

    BatteryVoltageDetailsMapper INSTANCE = Mappers.getMapper(BatteryVoltageDetailsMapper.class);
}
