package com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.global;

import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.global.JBBPUsageStatus;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.global.JBBPUsageStatusV2;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.DataMapper;
import com.inetpsa.carbide.domain.interfaces.data.global.UsageStatus;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface UsageStatusMapperV2 extends DataMapper<UsageStatus, JBBPUsageStatusV2> {

    UsageStatusMapperV2 INSTANCE = Mappers.getMapper(UsageStatusMapperV2.class);
}
