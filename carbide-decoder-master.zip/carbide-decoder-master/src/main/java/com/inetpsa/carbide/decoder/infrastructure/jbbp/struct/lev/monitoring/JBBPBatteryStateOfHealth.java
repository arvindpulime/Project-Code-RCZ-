package com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.lev.monitoring;

import com.igormaznitsa.jbbp.io.JBBPBitOrder;
import com.igormaznitsa.jbbp.mapper.Bin;
import com.igormaznitsa.jbbp.mapper.BinType;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.JBBPData;
import com.inetpsa.carbide.decoder.infrastructure.util.ByteUtils;
import lombok.Setter;

import java.math.BigDecimal;
import java.math.RoundingMode;

import static com.inetpsa.carbide.decoder.infrastructure.util.Constant.RELAY_DMG_COUNTER;
import static com.inetpsa.carbide.decoder.infrastructure.util.Factor.*;

@Setter
public class JBBPBatteryStateOfHealth implements JBBPData {

    @Bin(order = 101, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int code;

    @Bin(order = 102, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int capacitySoH;

    @Bin(order = 103, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int resistanceSoH;

    @Bin(order = 104, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] insulationResistance;

    @Bin(order = 105, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int totalProbes;

    @Bin(order = 106, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int totalCells;

    @Bin(order = 107, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] opTimeOverTemp;

    @Bin(order = 108, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] positiveChargeExchanged;

    @Bin(order = 109, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] negativeChargeExchanged;

    @Bin(order = 110, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] negativeChargeExchangedForPlugin;

    @Bin(order = 111, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] positiveEnergyExchanged;

    @Bin(order = 112, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] negativeEnergyExchanged;

    @Bin(order = 113, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] negativeEnergyExchangedForPlugin;

    @Bin(order = 114, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] opTimeOverChargePower;

    @Bin(order = 115, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] opTimeOverDischargePower;

    @Bin(order = 116, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] opTimeOverVoltageRange;

    @Bin(order = 117, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] opTimeBatteryChargeWithHighTemp;

    @Bin(order = 118, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] opTimeBatteryDischargeWithHighTemp;

    @Bin(order = 119, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] mainRelayDamageCounter;

    @Bin(order = 120, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] quickChargeRelayDamageCounter;

    public int getCode() {
        return code;
    }

    public int getCapacitySoH() {
        return capacitySoH;
    }

    public int getResistanceSoH() {
        return resistanceSoH;
    }

    public int getInsulationResistance() {
        return ByteUtils.asInt(insulationResistance);
    }

    public int getTotalProbes() {
        return totalProbes;
    }

    public int getTotalCells() {
        return totalCells;
    }

    public BigDecimal getOpTimeOverTemp() {
        return BigDecimal.valueOf(ByteUtils.asInt(opTimeOverTemp) * OPERATING_TIME_OVER_TEMP_FACTOR).setScale(2, RoundingMode.FLOOR);
    }

    public int getPositiveChargeExchanged() {
        return ByteUtils.asInt(positiveChargeExchanged) * ELECTRIC_CHARGE_EXCHANGE_FACTOR;
    }

    public int getNegativeChargeExchanged() {
        return ByteUtils.asInt(negativeChargeExchanged) * ELECTRIC_CHARGE_EXCHANGE_FACTOR;
    }

    public int getNegativeChargeExchangedForPlugin() {
        return ByteUtils.asInt(negativeChargeExchangedForPlugin) * ELECTRIC_CHARGE_EXCHANGE_FACTOR;
    }

    public int getPositiveEnergyExchanged() {
        return ByteUtils.asInt(positiveEnergyExchanged) * ENERGY_EXCHANGE_FACTOR;
    }

    public int getNegativeEnergyExchanged() {
        return ByteUtils.asInt(negativeEnergyExchanged) * ENERGY_EXCHANGE_FACTOR;
    }

    public int getNegativeEnergyExchangedForPlugin() {
        return ByteUtils.asInt(negativeEnergyExchangedForPlugin) * ENERGY_EXCHANGE_FACTOR;
    }

    public BigDecimal getOpTimeOverChargePower() {
        return BigDecimal.valueOf(ByteUtils.asInt(opTimeOverChargePower) * OPERATING_TIME_OVER_CHARGE_FACTOR).setScale(2, RoundingMode.FLOOR);
    }

    public BigDecimal getOpTimeOverDischargePower() {
        return BigDecimal.valueOf(ByteUtils.asInt(opTimeOverDischargePower) * OPERATING_TIME_OVER_CHARGE_FACTOR).setScale(2, RoundingMode.FLOOR);
    }

    public BigDecimal getOpTimeOverVoltageRange() {
        return BigDecimal.valueOf(ByteUtils.asInt(opTimeOverVoltageRange) * OPERATING_TIME_OVER_VOLTAGE_FACTOR).setScale(2, RoundingMode.FLOOR);
    }

    public BigDecimal getOpTimeBatteryChargeWithHighTemp() {
        return BigDecimal.valueOf(ByteUtils.asInt(opTimeBatteryChargeWithHighTemp) * OPERATING_TIME_WITH_HIGH_TEMP_FACTOR).setScale(2, RoundingMode.FLOOR);
    }

    public BigDecimal getOpTimeBatteryDischargeWithHighTemp() {
        return BigDecimal.valueOf(ByteUtils.asInt(opTimeBatteryDischargeWithHighTemp) * OPERATING_TIME_WITH_HIGH_TEMP_FACTOR).setScale(2, RoundingMode.FLOOR);
    }

    public int getMainRelayDamageCounter() {
        return ByteUtils.asInt(mainRelayDamageCounter) * RELAY_DMG_COUNTER;
    }

    public int getQuickChargeRelayDamageCounter() {
        return ByteUtils.asInt(quickChargeRelayDamageCounter) * RELAY_DMG_COUNTER;
    }
}
