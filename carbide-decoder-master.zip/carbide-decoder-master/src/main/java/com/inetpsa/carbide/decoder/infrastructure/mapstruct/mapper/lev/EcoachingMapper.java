package com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.lev;

import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.lev.JBBPEcoaching;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.DataMapper;
import com.inetpsa.carbide.domain.interfaces.data.lev.Ecoaching;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface EcoachingMapper extends DataMapper<Ecoaching, JBBPEcoaching> {

    EcoachingMapper INSTANCE = Mappers.getMapper(EcoachingMapper.class);
}
