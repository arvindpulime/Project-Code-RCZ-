package com.inetpsa.carbide.decoder.application.util;

import java.util.Arrays;
import java.util.EnumSet;
import java.util.NoSuchElementException;

public enum Schema {
    V1(2), V2(3);

    private final int protocolVersion;

    Schema(int protocolVersion) {
        this.protocolVersion = protocolVersion;
    }

    public int protocolVersion() {
        return protocolVersion;
    }

    public static Schema fromProtocolVersion(int protocolVersion) {
        return Arrays.stream(values()).filter(schema -> schema.protocolVersion() == protocolVersion)
                .findFirst()
                .orElseThrow(() -> new NoSuchElementException("Invalid protocol version: " + protocolVersion));
    }
}
