package com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.lev.monitoring;

import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.lev.monitoring.JBBPBatteryStateOfHealth;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.DataMapper;
import com.inetpsa.carbide.domain.interfaces.data.lev.monitoring.BatteryStateOfHealth;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface BatteryStateOfHealthMapper extends DataMapper<BatteryStateOfHealth, JBBPBatteryStateOfHealth> {

    BatteryStateOfHealthMapper INSTANCE = Mappers.getMapper(BatteryStateOfHealthMapper.class);
}
