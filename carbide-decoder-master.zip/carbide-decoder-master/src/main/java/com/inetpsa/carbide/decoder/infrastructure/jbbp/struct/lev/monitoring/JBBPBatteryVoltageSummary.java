package com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.lev.monitoring;

import com.igormaznitsa.jbbp.io.JBBPBitOrder;
import com.igormaznitsa.jbbp.mapper.Bin;
import com.igormaznitsa.jbbp.mapper.BinType;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.JBBPData;
import com.inetpsa.carbide.decoder.infrastructure.util.ByteUtils;
import lombok.Setter;

import java.math.BigDecimal;
import java.math.RoundingMode;

import static com.inetpsa.carbide.decoder.infrastructure.util.Factor.*;
import static com.inetpsa.carbide.decoder.infrastructure.util.SignalSize.HV_BATTERY_INTENSITY_SIZE;
import static com.inetpsa.carbide.decoder.infrastructure.util.Offset.BATTERY_CELLID_OFFSET;

@Setter
public class JBBPBatteryVoltageSummary implements JBBPData {

    @Bin(order = 101, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int code;

    @Bin(order = 102, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] intensity;

    @Bin(order = 103, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] voltage;

    @Bin(order = 104, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int cellWithMaxVoltage;

    @Bin(order = 105, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellMaxVoltage;

    @Bin(order = 106, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int cellWithMinVoltage;

    @Bin(order = 107, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] cellMinVoltage;

    public int getCode() {
        return code;
    }

    public BigDecimal getIntensity() {
        return BigDecimal.valueOf(ByteUtils.asSignedInt(intensity, HV_BATTERY_INTENSITY_SIZE) * HV_BATTERY_INTENSITY_FACTOR).setScale(2, RoundingMode.FLOOR);
    }

    public BigDecimal getVoltage() {
        return BigDecimal.valueOf(ByteUtils.asInt(voltage) * HV_BATTERY_VOLTAGE_FACTOR).setScale(2, RoundingMode.FLOOR);
    }

    public int getCellWithMaxVoltage() {
        return cellWithMaxVoltage + BATTERY_CELLID_OFFSET;
    }

    public BigDecimal getCellMaxVoltage() {
        return BigDecimal.valueOf(ByteUtils.asInt(cellMaxVoltage) * HV_BATTERY_CELL_VOLTAGE_FACTOR).setScale(3, RoundingMode.FLOOR);
    }

    public int getCellWithMinVoltage() {
        return cellWithMinVoltage + BATTERY_CELLID_OFFSET;
    }

    public BigDecimal getCellMinVoltage() {
        return BigDecimal.valueOf(ByteUtils.asInt(cellMinVoltage) * HV_BATTERY_CELL_VOLTAGE_FACTOR).setScale(3, RoundingMode.FLOOR);
    }
}
