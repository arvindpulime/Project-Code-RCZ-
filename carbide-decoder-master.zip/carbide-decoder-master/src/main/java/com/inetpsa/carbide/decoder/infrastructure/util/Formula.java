package com.inetpsa.carbide.decoder.infrastructure.util;

import java.math.BigDecimal;
import java.math.RoundingMode;

import static com.inetpsa.carbide.decoder.infrastructure.util.Factor.*;
import static com.inetpsa.carbide.decoder.infrastructure.util.Offset.TEMPERATURE_OFFSET;

public final class Formula {

    private Formula() {
    }

    public static BigDecimal toLongitudinalSpeed(byte[] rawData) {
        return BigDecimal.valueOf(ByteUtils.asInt(rawData) * LONGITUDINAL_SPEED_FACTOR).setScale(2, RoundingMode.FLOOR);
    }

    public static BigDecimal toFuelInstantConsumption(byte[] rawData) {
        return BigDecimal.valueOf(ByteUtils.asInt(rawData) * FUEL_INSTANT_CONSUMPTION_FACTOR).setScale(2, RoundingMode.FLOOR);
    }

    public static BigDecimal toEngineSpeed(byte[] rawData) {
        return BigDecimal.valueOf(ByteUtils.asInt(rawData) * ENGINE_SPEED_FACTOR).setScale(3, RoundingMode.FLOOR);
    }

    public static BigDecimal toCellVoltage(byte[] rawData) {
        return BigDecimal.valueOf(ByteUtils.asInt(rawData) * HV_BATTERY_CELL_VOLTAGE_FACTOR).setScale(3, RoundingMode.FLOOR);
    }

    public static int toProbeTemperature(int rawData) {
        return rawData + TEMPERATURE_OFFSET;
    }
}
