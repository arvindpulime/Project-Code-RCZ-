package com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.global;

import com.igormaznitsa.jbbp.io.JBBPBitNumber;
import com.igormaznitsa.jbbp.io.JBBPBitOrder;
import com.igormaznitsa.jbbp.mapper.Bin;
import com.igormaznitsa.jbbp.mapper.BinType;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.JBBPData;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class JBBPCrash implements JBBPData {

    @Bin(order = 101, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int code;

    @Bin(order = 102, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int frontRepairabilityCrashDetected;

    @Bin(order = 103, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int frontLowSpeedCrashDetected;

    @Bin(order = 104, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int frontMediumSpeedN1CrashDetected;

    @Bin(order = 105, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int frontMediumSpeedN2CrashDetected;

    @Bin(order = 106, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int frontHighSpeedCrashDetected;

    @Bin(order = 107, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int lateralRepairabilityCrashDetected;

    @Bin(order = 108, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int lateralLowSpeedCrashDetected;

    @Bin(order = 109, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int lateralMediumSpeedCrashDetected;

    @Bin(order = 110, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int lateralHighSpeedCrashDetected;

    @Bin(order = 111, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int rearRepairabilityCrashDetected;

    @Bin(order = 112, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int rearLowSpeedCrashDetected;

    @Bin(order = 113, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int rearMediumSpeedCrashDetected;

    @Bin(order = 114, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int rearHighSpeedCrashDetected;

    @Bin(order = 115, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int tippedOver;

    @Bin(order = 116, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int crashDetected;

    @Bin(order = 117, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_7, bitOrder = JBBPBitOrder.MSB0)
    private int ecallRequest;

    @Bin(order = 118, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int pedestrianCrashDetected;
}
