package com.inetpsa.carbide.decoder.application.services;

import com.inetpsa.carbide.decoder.application.exceptions.DecoderException;
import com.inetpsa.carbide.decoder.application.util.Structure;
import com.inetpsa.carbide.domain.interfaces.data.Data;
import org.seedstack.business.Service;

@Service
public interface DecoderService {

    Data decode(Structure structure, byte[] structureData) throws DecoderException;
}
