package com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.lev;

import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.lev.JBBPTrip;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.DataMapper;
import com.inetpsa.carbide.domain.interfaces.data.lev.Trip;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface TripMapper extends DataMapper<Trip, JBBPTrip> {

    TripMapper INSTANCE = Mappers.getMapper(TripMapper.class);
}
