package com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.global;

import com.igormaznitsa.jbbp.io.JBBPBitOrder;
import com.igormaznitsa.jbbp.mapper.Bin;
import com.igormaznitsa.jbbp.mapper.BinType;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.JBBPData;
import lombok.Setter;

@Setter
public class JBBPPrivacy implements JBBPData {

    @Bin(order = 101, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int code;

    @Bin(order = 102, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int type;

    @Bin(order = 103, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int status;

    @Bin(order = 104, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int requestedStatus;

    @Bin(order = 105, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int applicableStatus;

    public int getCode() {
        return code;
    }

    public int getType() {
        return type;
    }

    public int getStatus() {
        return status;
    }

    public int getRequestedStatus() {
        return requestedStatus;
    }

    public int getApplicableStatus() {
        return applicableStatus;
    }
}
