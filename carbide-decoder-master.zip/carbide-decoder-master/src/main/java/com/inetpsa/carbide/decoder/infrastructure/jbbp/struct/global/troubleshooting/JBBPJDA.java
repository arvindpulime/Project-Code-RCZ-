package com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.global.troubleshooting;

import com.google.common.primitives.Bytes;
import com.igormaznitsa.jbbp.io.JBBPBitOrder;
import com.igormaznitsa.jbbp.mapper.Bin;
import com.igormaznitsa.jbbp.mapper.BinType;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.JBBPData;
import com.inetpsa.carbide.decoder.infrastructure.util.Alert;
import com.inetpsa.carbide.decoder.infrastructure.util.ByteUtils;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

import static com.inetpsa.carbide.decoder.infrastructure.util.ByteUtils.BITS_PER_BYTE;

@Setter
public class JBBPJDA implements JBBPData {

    @Bin(order = 101, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int code;

    @Bin(order = 102, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int eeaVersion;

    @Bin(order = 103, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] alertBlock1;

    @Bin(order = 104, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] alertBlock2;

    @Bin(order = 105, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] alertBlock3;

    public int getCode() {
        return code;
    }

    public int getEeaVersion() {
        return eeaVersion;
    }

    public String[] getAlerts() {
        List<String> alerts = new ArrayList<>();
        final byte[] concat = Bytes.concat(alertBlock1, alertBlock2, alertBlock3);
        for (int i = 0; i < concat.length * BITS_PER_BYTE; i++) {
            if (ByteUtils.isSet(concat, i)) {
                alerts.add(Alert.fromIndex(i).value());
            }
        }
        return alerts.toArray(new String[0]);
    }
}
