package com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.global;

import com.igormaznitsa.jbbp.io.JBBPBitNumber;
import com.igormaznitsa.jbbp.io.JBBPBitOrder;
import com.igormaznitsa.jbbp.mapper.Bin;
import com.igormaznitsa.jbbp.mapper.BinType;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.JBBPData;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class JBBPAdas implements JBBPData {

    @Bin(order = 101, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int code;

    @Bin(order = 102, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rearParkingAssist;

    @Bin(order = 103, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int frontParkingAssist;

    @Bin(order = 104, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem;

    @Bin(order = 105, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int adaptiveCruiseControl;

    @Bin(order = 106, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning;

    @Bin(order = 107, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist;

    @Bin(order = 108, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int electronicStabilityProgram;

    @Bin(order = 109, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int recommenderGearIndicator;

    @Bin(order = 110, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulator;

    @Bin(order = 111, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int speedRegulatorStatus;

    @Bin(order = 112, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation;

    @Bin(order = 113, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring;

    @Bin(order = 114, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist;

    @Bin(order = 115, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist;

    @Bin(order = 116, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int antiBrakingSystem;

    @Bin(order = 117, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService;
}
