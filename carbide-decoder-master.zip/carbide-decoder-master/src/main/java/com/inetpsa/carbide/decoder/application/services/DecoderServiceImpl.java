package com.inetpsa.carbide.decoder.application.services;

import com.inetpsa.carbide.decoder.application.exceptions.DecoderException;
import com.inetpsa.carbide.decoder.application.util.Structure;
import com.inetpsa.carbide.decoder.application.util.StructureMap;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.parser.ParserFactory;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.JBBPData;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.JBBPHeader;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.JBBPHeaderV2;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.global.*;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.global.troubleshooting.JBBPJDA;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.global.troubleshooting.JBBPJDD;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.legacy.JBBPEvent;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.legacy.JBBPExtension;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.legacy.JBBPLEV;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.legacy.JBBPPeriodic;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.lev.JBBPBattery;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.lev.JBBPEcoaching;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.lev.JBBPThermalConditioning;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.lev.JBBPTrip;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.lev.monitoring.*;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.HeaderMapper;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.HeaderMapperV2;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.global.*;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.global.troubleshooting.JDAMapper;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.global.troubleshooting.JDDMapper;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.legacy.EventMapper;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.legacy.ExtensionMapper;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.legacy.LEVMapper;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.legacy.PeriodicMapper;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.lev.BatteryMapper;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.lev.EcoachingMapper;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.lev.ThermalConditioningMapper;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.lev.TripMapper;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.lev.monitoring.*;
import com.inetpsa.carbide.domain.interfaces.data.Data;

public class DecoderServiceImpl implements DecoderService {

    @Override
    public Data decode(Structure structure, byte[] structureData) throws DecoderException {
        JBBPData jbbpData = parse(structure, structureData);
        Data data = null;
        switch (structure) {
            case HEADER:
                data = HeaderMapper.INSTANCE.toDto((JBBPHeader) jbbpData);
                break;
            case HEADER_V2:
                data = HeaderMapperV2.INSTANCE.toDto((JBBPHeaderV2) jbbpData);
                break;
            case BATTERY:
                data = BatteryMapper.INSTANCE.toDto((JBBPBattery) jbbpData);
                break;
            case ECOACHING:
                data = EcoachingMapper.INSTANCE.toDto((JBBPEcoaching) jbbpData);
                break;
            case THERMAL_CONDITIONING:
                data = ThermalConditioningMapper.INSTANCE.toDto((JBBPThermalConditioning) jbbpData);
                break;
            case TRIP:
                data = TripMapper.INSTANCE.toDto((JBBPTrip) jbbpData);
                break;
            case LOCALIZATION:
                data = LocalizationMapper.INSTANCE.toDto((JBBPLocalization) jbbpData);
                break;
            case JDA:
                data = JDAMapper.INSTANCE.toDto((JBBPJDA) jbbpData);
                break;
            case JDD:
                data = JDDMapper.INSTANCE.toDto((JBBPJDD) jbbpData);
                break;
            case PRIVACY:
                data = PrivacyMapper.INSTANCE.toDto((JBBPPrivacy) jbbpData);
                break;
            case EXTENSION:
                data = ExtensionMapper.INSTANCE.toDto((JBBPExtension) jbbpData);
                break;
            case VEHICLE_STATUS:
                data = VehicleStatusMapper.INSTANCE.toDto((JBBPVehicleStatus) jbbpData);
                break;
            case VEHICLE_STATUS_V2:
                data = VehicleStatusMapperV2.INSTANCE.toDto((JBBPVehicleStatusV2) jbbpData);
                break;
            case MAINTENANCE_STATUS:
                data = MaintenanceStatusMapper.INSTANCE.toDto((JBBPMaintenanceStatus) jbbpData);
                break;
            case DOORS_STATUS:
                data = DoorsStatusMapper.INSTANCE.toDto((JBBPDoorsStatus) jbbpData);
                break;
            case USAGE_STATUS:
                data = UsageStatusMapper.INSTANCE.toDto((JBBPUsageStatus) jbbpData);
                break;
            case USAGE_STATUS_V2:
                data = UsageStatusMapperV2.INSTANCE.toDto((JBBPUsageStatusV2) jbbpData);
                break;
            case BATTERY_VOLTAGE_SUMMARY:
                data = BatteryVoltageSummaryMapper.INSTANCE.toDto((JBBPBatteryVoltageSummary) jbbpData);
                break;
            case BATTERY_VOLTAGE_DETAILS:
                data = BatteryVoltageDetailsMapper.INSTANCE.toDto((JBBPBatteryVoltageDetails) jbbpData);
                break;
            case BATTERY_STATUS_SUMMARY:
                data = BatteryStatusSummaryMapper.INSTANCE.toDto((JBBPBatteryStatusSummary) jbbpData);
                break;
            case BATTERY_STATUS_DETAILS:
                data = BatteryStatusDetailsMapper.INSTANCE.toDto((JBBPBatteryStatusDetails) jbbpData);
                break;
            case BATTERY_SOH:
                data = BatteryStateOfHealthMapper.INSTANCE.toDto((JBBPBatteryStateOfHealth) jbbpData);
                break;
            case CRASH:
                data = CrashMapper.INSTANCE.toDto((JBBPCrash) jbbpData);
                break;
            case ADAS:
                data = AdasMapper.INSTANCE.toDto((JBBPAdas) jbbpData);
                break;
            case PERIODIC:
                data = PeriodicMapper.INSTANCE.toDto((JBBPPeriodic) jbbpData);
                break;
            case EVENT:
                data = EventMapper.INSTANCE.toDto((JBBPEvent) jbbpData);
                break;
            case CFM_LEV:
                data = LEVMapper.INSTANCE.toDto((JBBPLEV) jbbpData);
                break;
        }
        return data;
    }

    private JBBPData parse(Structure structure, byte[] structureData) throws DecoderException {
        try {
            return (JBBPData) ParserFactory.create(structure).parse(structureData).mapTo(StructureMap.jbbpClass(structure).newInstance());
        } catch (Exception e) {
            throw new DecoderException("Binary parser exception", e);
        }
    }
}
