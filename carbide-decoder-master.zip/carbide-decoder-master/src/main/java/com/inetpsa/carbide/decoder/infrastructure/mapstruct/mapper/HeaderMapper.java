package com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper;

import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.JBBPHeader;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.qualifier.IntToBoolean;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.qualifier.IntToDuration;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.qualifier.IntToInstant;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.type.BooleanConverter;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.type.BooleanType;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.type.TimeConverter;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.type.TimeType;
import com.inetpsa.carbide.domain.interfaces.data.Header;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(uses = {TimeType.class, BooleanType.class})
public interface HeaderMapper extends DataMapper<Header, JBBPHeader> {

    HeaderMapper INSTANCE = Mappers.getMapper(HeaderMapper.class);

    @Override
    @Mapping(target = "dateOfCollection", qualifiedBy = {TimeConverter.class, IntToInstant.class})
    @Mapping(target = "timeSinceSessionStart", qualifiedBy = {TimeConverter.class, IntToDuration.class})
    @Mapping(target = "gnssTimestamp", qualifiedBy = {TimeConverter.class, IntToInstant.class})
    @Mapping(target = "gnssTimefix", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "timeSync", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    Header toDto(JBBPHeader jbbpData);
}