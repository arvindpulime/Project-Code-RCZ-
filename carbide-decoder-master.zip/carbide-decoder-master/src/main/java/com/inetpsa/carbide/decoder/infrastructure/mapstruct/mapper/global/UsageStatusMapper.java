package com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.global;

import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.global.JBBPUsageStatus;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.DataMapper;
import com.inetpsa.carbide.domain.interfaces.data.global.UsageStatus;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface UsageStatusMapper extends DataMapper<UsageStatus, JBBPUsageStatus> {

    UsageStatusMapper INSTANCE = Mappers.getMapper(UsageStatusMapper.class);
}
