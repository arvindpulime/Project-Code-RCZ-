package com.inetpsa.carbide.decoder.application.util;

import com.inetpsa.carbide.decoder.infrastructure.jbbp.parser.ParserFormat;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.parser.ParserFormatLegacy;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.JBBPHeader;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.JBBPHeaderV2;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.global.*;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.global.troubleshooting.JBBPJDA;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.global.troubleshooting.JBBPJDD;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.legacy.JBBPEvent;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.legacy.JBBPExtension;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.legacy.JBBPLEV;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.legacy.JBBPPeriodic;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.lev.JBBPBattery;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.lev.JBBPEcoaching;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.lev.JBBPThermalConditioning;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.lev.JBBPTrip;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.lev.monitoring.*;

import java.util.Collections;
import java.util.EnumMap;
import java.util.Map;

public final class StructureMap {

    private static final Map<Structure, Class<?>> jbbpClass;
    private static final Map<Structure, String> parserFormat;

    private StructureMap() {
    }

    static {
        EnumMap<Structure, Class<?>> staticMap = new EnumMap<>(Structure.class);
        staticMap.put(Structure.ADAS, JBBPAdas.class);
        staticMap.put(Structure.BATTERY, JBBPBattery.class);
        staticMap.put(Structure.BATTERY_SOH, JBBPBatteryStateOfHealth.class);
        staticMap.put(Structure.BATTERY_STATUS_DETAILS, JBBPBatteryStatusDetails.class);
        staticMap.put(Structure.BATTERY_STATUS_SUMMARY, JBBPBatteryStatusSummary.class);
        staticMap.put(Structure.BATTERY_VOLTAGE_DETAILS, JBBPBatteryVoltageDetails.class);
        staticMap.put(Structure.BATTERY_VOLTAGE_SUMMARY, JBBPBatteryVoltageSummary.class);
        staticMap.put(Structure.CFM_LEV, JBBPLEV.class);
        staticMap.put(Structure.CRASH, JBBPCrash.class);
        staticMap.put(Structure.DOORS_STATUS, JBBPDoorsStatus.class);
        staticMap.put(Structure.ECOACHING, JBBPEcoaching.class);
        staticMap.put(Structure.EVENT, JBBPEvent.class);
        staticMap.put(Structure.EXTENSION, JBBPExtension.class);
        staticMap.put(Structure.HEADER, JBBPHeader.class);
        staticMap.put(Structure.HEADER_V2, JBBPHeaderV2.class);
        staticMap.put(Structure.JDA, JBBPJDA.class);
        staticMap.put(Structure.JDD, JBBPJDD.class);
        staticMap.put(Structure.LOCALIZATION, JBBPLocalization.class);
        staticMap.put(Structure.MAINTENANCE_STATUS, JBBPMaintenanceStatus.class);
        staticMap.put(Structure.PERIODIC, JBBPPeriodic.class);
        staticMap.put(Structure.PRIVACY, JBBPPrivacy.class);
        staticMap.put(Structure.THERMAL_CONDITIONING, JBBPThermalConditioning.class);
        staticMap.put(Structure.TRIP, JBBPTrip.class);
        staticMap.put(Structure.USAGE_STATUS, JBBPUsageStatus.class);
        staticMap.put(Structure.USAGE_STATUS_V2, JBBPUsageStatusV2.class);
        staticMap.put(Structure.VEHICLE_STATUS, JBBPVehicleStatus.class);
        staticMap.put(Structure.VEHICLE_STATUS_V2, JBBPVehicleStatusV2.class);
        jbbpClass = Collections.unmodifiableMap(staticMap);
    }

    static {
        EnumMap<Structure, String> staticMap = new EnumMap<>(Structure.class);
        staticMap.put(Structure.ADAS, ParserFormat.ADAS);
        staticMap.put(Structure.BATTERY, ParserFormat.BATTERY);
        staticMap.put(Structure.BATTERY_SOH, ParserFormat.BATTERY_SOH);
        staticMap.put(Structure.BATTERY_STATUS_DETAILS, ParserFormat.BATTERY_STATUS_DETAILS);
        staticMap.put(Structure.BATTERY_STATUS_SUMMARY, ParserFormat.BATTERY_STATUS_SUMMARY);
        staticMap.put(Structure.BATTERY_VOLTAGE_DETAILS, ParserFormat.BATTERY_VOLTAGE_DETAILS);
        staticMap.put(Structure.BATTERY_VOLTAGE_SUMMARY, ParserFormat.BATTERY_VOLTAGE_SUMMARY);
        staticMap.put(Structure.CFM_LEV, ParserFormatLegacy.CFM_LEV);
        staticMap.put(Structure.CRASH, ParserFormat.CRASH);
        staticMap.put(Structure.DOORS_STATUS, ParserFormat.DOORS_STATUS);
        staticMap.put(Structure.ECOACHING, ParserFormat.ECOACHING);
        staticMap.put(Structure.EVENT, ParserFormatLegacy.EVENT);
        staticMap.put(Structure.EXTENSION, ParserFormat.EXTENSION);
        staticMap.put(Structure.HEADER, ParserFormat.HEADER);
        staticMap.put(Structure.HEADER_V2, ParserFormat.HEADER_V2);
        staticMap.put(Structure.JDA, ParserFormat.JDA);
        staticMap.put(Structure.JDD, ParserFormat.JDD);
        staticMap.put(Structure.LOCALIZATION, ParserFormat.LOCALIZATION);
        staticMap.put(Structure.MAINTENANCE_STATUS, ParserFormat.MAINTENANCE_STATUS);
        staticMap.put(Structure.PERIODIC, ParserFormatLegacy.PERIODIC);
        staticMap.put(Structure.PRIVACY, ParserFormat.PRIVACY);
        staticMap.put(Structure.THERMAL_CONDITIONING, ParserFormat.THERMAL_CONDITIONING);
        staticMap.put(Structure.TRIP, ParserFormat.TRIP);
        staticMap.put(Structure.USAGE_STATUS, ParserFormat.USAGE_STATUS);
        staticMap.put(Structure.USAGE_STATUS_V2, ParserFormat.USAGE_STATUS_V2);
        staticMap.put(Structure.VEHICLE_STATUS, ParserFormat.VEHICLE_STATUS);
        staticMap.put(Structure.VEHICLE_STATUS_V2, ParserFormat.VEHICLE_STATUS_V2);
        parserFormat = Collections.unmodifiableMap(staticMap);
    }

    public static Class<?> jbbpClass(Structure structure) {
        return jbbpClass.get(structure);
    }

    public static String parserFormat(Structure structure) {
        return parserFormat.get(structure);
    }
}
