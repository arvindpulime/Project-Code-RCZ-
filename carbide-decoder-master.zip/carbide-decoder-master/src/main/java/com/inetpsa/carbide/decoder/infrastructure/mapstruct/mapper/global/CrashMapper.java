package com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.global;

import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.global.JBBPCrash;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.DataMapper;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.qualifier.IntToBoolean;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.type.BooleanConverter;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.type.BooleanType;
import com.inetpsa.carbide.domain.interfaces.data.global.Crash;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(uses = BooleanType.class)
public interface CrashMapper extends DataMapper<Crash, JBBPCrash> {

    CrashMapper INSTANCE = Mappers.getMapper(CrashMapper.class);

    @Override
    @Mapping(target = "frontRepairabilityCrashDetected", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "frontLowSpeedCrashDetected", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "frontMediumSpeedN1CrashDetected", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "frontMediumSpeedN2CrashDetected", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "frontHighSpeedCrashDetected", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "lateralRepairabilityCrashDetected", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "lateralLowSpeedCrashDetected", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "lateralMediumSpeedCrashDetected", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "lateralHighSpeedCrashDetected", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "rearRepairabilityCrashDetected", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "rearLowSpeedCrashDetected", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "rearMediumSpeedCrashDetected", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "rearHighSpeedCrashDetected", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "tippedOver", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "crashDetected", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    @Mapping(target = "pedestrianCrashDetected", qualifiedBy = {BooleanConverter.class, IntToBoolean.class})
    Crash toDto(JBBPCrash jbbpData);
}
