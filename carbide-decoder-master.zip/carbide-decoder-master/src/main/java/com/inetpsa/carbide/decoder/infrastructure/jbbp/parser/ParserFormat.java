package com.inetpsa.carbide.decoder.infrastructure.jbbp.parser;

public final class ParserFormat {

    private ParserFormat() {
    }

    //<editor-fold desc="Schema V1 / Protocol version 2">
    public static final String HEADER = "ubyte code;" +
            "ubyte protocolVersion;" +
            "ubyte[17] vin;" +
            "ubyte[2] sessionId;" +
            "ubyte[4] messageId;" +
            "ubyte serviceType;" +
            "ubyte messageType;" +
            "ubyte[4] dateOfCollection;" +
            "ubyte messageVersion;" +
            "ubyte[3] messageLength;" +
            "ubyte[4] timeSinceSessionStart;" +
            "ubyte[4] gnssTimestamp;" +
            "bit:1 gnssTimefix;" +
            "bit:1 timeSync;" +
            "bit:2 privacyStatus;" +
            "bit:2 requestedPrivacyStatus;" +
            "bit:2 applicablePrivacyStatus;";

    public static final String BATTERY = "ubyte code;" +
            "bit:3 chargeState;" +
            "bit:3 chargeMode;" +
            "bit:2 plugState;" +
            "ubyte[2] rtabStartTime;" +
            "ubyte loadLevel;" +
            "ubyte fuelLevel;" +
            "ubyte[2] autonomy;" +
            "ubyte[2] zevAutonomy;" +
            "bit:7 remainingChargeTime;" +
            "ubyte zevChargeGain;";

    public static final String THERMAL_CONDITIONING = "ubyte code;" +
            "bit:4 precondActivation;" +
            "bit:1 week1PrecondActivation;" +
            "ubyte[2] week1PrecondTime;" +
            "bit:1 week1Day1PrecondActivation;" +
            "bit:1 week1Day2PrecondActivation;" +
            "bit:1 week1Day3PrecondActivation;" +
            "bit:1 week1Day4PrecondActivation;" +
            "bit:1 week1Day5PrecondActivation;" +
            "bit:1 week1Day6PrecondActivation;" +
            "bit:1 week1Day7PrecondActivation;" +
            "bit:1 week2PrecondActivation;" +
            "ubyte[2] week2PrecondTime;" +
            "bit:1 week2Day1PrecondActivation;" +
            "bit:1 week2Day2PrecondActivation;" +
            "bit:1 week2Day3PrecondActivation;" +
            "bit:1 week2Day4PrecondActivation;" +
            "bit:1 week2Day5PrecondActivation;" +
            "bit:1 week2Day6PrecondActivation;" +
            "bit:1 week2Day7PrecondActivation;" +
            "bit:1 week3PrecondActivation;" +
            "ubyte[2] week3PrecondTime;" +
            "bit:1 week3Day1PrecondActivation;" +
            "bit:1 week3Day2PrecondActivation;" +
            "bit:1 week3Day3PrecondActivation;" +
            "bit:1 week3Day4PrecondActivation;" +
            "bit:1 week3Day5PrecondActivation;" +
            "bit:1 week3Day6PrecondActivation;" +
            "bit:1 week3Day7PrecondActivation;" +
            "bit:1 week4PrecondActivation;" +
            "ubyte[2] week4PrecondTime;" +
            "bit:1 week4Day1PrecondActivation;" +
            "bit:1 week4Day2PrecondActivation;" +
            "bit:1 week4Day3PrecondActivation;" +
            "bit:1 week4Day4PrecondActivation;" +
            "bit:1 week4Day5PrecondActivation;" +
            "bit:1 week4Day6PrecondActivation;" +
            "bit:1 week4Day7PrecondActivation;";

    public static final String TRIP = "ubyte code;" +
            "ubyte[2] avgFuelConsumption;" +
            "ubyte[2] zevAvgPowerConsumption;" +
            "ubyte zevUtilization;" +
            "ubyte[2] distanceTraveled;" +
            "ubyte[2] duration;";

    public static final String ECOACHING = "ubyte code;" +
            "bit:4 globalScore;" +
            "bit:4 accelScore;" +
            "bit:4 brakeScore;" +
            "bit:4 climateComfortScore;" +
            "bit:4 coldEngineScore;" +
            "bit:4 tirePressureScore;" +
            "bit:4 slopeScore;" +
            "bit:4 speedScore;" +
            "bit:4 startStopScore;";

    public static final String LOCALIZATION = "ubyte code;" +
            "ubyte[4] validities;" +
            "ubyte[4] positionalDilution;" +
            "ubyte[4] horizontalDilution;" +
            "ubyte[4] verticalDilution;" +
            "ubyte[2] usedSatellite;" +
            "ubyte[2] trackedSatellite;" +
            "ubyte[2] visibleSatellite;" +
            "ubyte fixStatus;" +
            "ubyte[4] gnssDate;" +
            "ubyte[8] latitude;" +
            "ubyte[8] longitude;" +
            "ubyte[8] altitude;" +
            "ubyte[4] courseAngle;" +
            "ubyte[4] speed;" +
            "ubyte[4] horizontalError;" +
            "ubyte[4] altitudeError;" +
            "ubyte[4] speedError;" +
            "ubyte[8] drLatitude;" +
            "ubyte[8] drLongitude;" +
            "ubyte[4] drHeading;" +
            "ubyte[4] drSpeed;";

    public static final String JDA = "ubyte code;" +
            "ubyte eeaVersion;" +
            "ubyte[7] alertBlock1;" +
            "ubyte[7] alertBlock2;" +
            "ubyte[7] alertBlock3;";

    public static final String JDD = "ubyte code;" +
            "ubyte[2] frameId;" +
            "ubyte[3] errorCode;" +
            "ubyte[4] timeReference;" +
            "ubyte[3] kilometer;" +
            "ubyte[3] lifeSituation;" +
            "bit:1 dtcState;" +
            "bit:1 messageType;";

    public static final String PRIVACY = "ubyte code;" +
            "ubyte type;" +
            "ubyte status;" +
            "ubyte requestedStatus;" +
            "ubyte applicableStatus;";

    public static final String EXTENSION = "ubyte code;" +
            "ubyte torque;" +
            "ubyte[2] engineSpeed;" +
            "ubyte driversWill;" +
            "ubyte[2] odometerSpeed;" +
            "ubyte engineOilLevel;" +
            "ubyte engineAirTemperature;" +
            "ubyte engineWaterTemperature;" +
            "ubyte engineOilTemperature;" +
            "ubyte[2] yawSpeed;" +
            "ubyte[2] lateralAcceleration;" +
            "ubyte longitudinalAcceleration;" +
            "bit:2 driverSeatBeltState;" +
            "bit:2 passengerSeatBeltState;" +
            "bit:2 rainSensorState;" +
            "bit:2 powerTrainState;" +
            "ubyte[2] steeringWheelAngle;" +
            "ubyte[2] batteryVoltage;" +
            "ubyte[2] masterCylinder;" +
            "bit:4 gearboxEffectiveRatio;" +
            "bit:4 gearboxCalculatedRatio;" +
            "bit:3 gearboxMode;" +
            "bit:1 stopIndicator;" +
            "bit:1 serviceIndicator;" +
            "bit:1 breakPedalState;";

    public static final String VEHICLE_STATUS = "ubyte code;" +
            "ubyte outsideTemperature;" +
            "ubyte[3] lifetimeMileage;" +
            "ubyte auxiliaryBatterySoC;" +
            "ubyte fuelLevel;" +
            "ubyte[2] residualAutonomy;" +
            "ubyte chargeState;" +
            "ubyte[2] zevAutonomy;" +
            "bit:5 electricNetworkState;" +
            "bit:2 sevMainStatus;" +
            "bit:1 luminosity;";

    public static final String MAINTENANCE_STATUS = "ubyte code;" +
            "bit:1 serviceLight;" +
            "bit:1 maintenanceLight;" +
            "bit:1 maintenanceLightMode;" +
            "bit:3 maintenanceType;" +
            "bit:1 mileageToMaintenanceSign;" +
            "bit:1 daysToMaintenanceSign;" +
            "ubyte[2] mileageToMaintenance;" +
            "ubyte[2] daysToMaintenance;";

    public static final String DOORS_STATUS = "ubyte code;" +
            "bit:6 lockingStatus;" +
            "bit:1 bootLockingStatus;" +
            "bit:1 rearLockingStatus;" +
            "bit:1 bootOpeningStatus;" +
            "bit:1 driverOpeningStatus;" +
            "bit:1 rearRightOpeningStatus;" +
            "bit:1 rearLeftOpeningStatus;" +
            "bit:1 driverEstimatedOpeningStatus;" +
            "bit:1 passengerOpeningStatus;" +
            "bit:1 rearWindowOpeningStatus;" +
            "bit:1 retractableRoofPosition;";

    public static final String BATTERY_VOLTAGE_SUMMARY = "ubyte code;" +
            "ubyte[2] intensity;" +
            "ubyte[2] voltage;" +
            "ubyte cellWithMaxVoltage;" +
            "ubyte[2] cellMaxVoltage;" +
            "ubyte cellWithMinVoltage;" +
            "ubyte[2] cellMinVoltage;";

    public static final String BATTERY_VOLTAGE_DETAILS = "ubyte code;" +
            "ubyte[2] intensity;" +
            "ubyte totalCells;" +
            "ubyte[2] cellVoltage001;" +
            "ubyte[2] cellVoltage002;" +
            "ubyte[2] cellVoltage003;" +
            "ubyte[2] cellVoltage004;" +
            "ubyte[2] cellVoltage005;" +
            "ubyte[2] cellVoltage006;" +
            "ubyte[2] cellVoltage007;" +
            "ubyte[2] cellVoltage008;" +
            "ubyte[2] cellVoltage009;" +
            "ubyte[2] cellVoltage010;" +
            "ubyte[2] cellVoltage011;" +
            "ubyte[2] cellVoltage012;" +
            "ubyte[2] cellVoltage013;" +
            "ubyte[2] cellVoltage014;" +
            "ubyte[2] cellVoltage015;" +
            "ubyte[2] cellVoltage016;" +
            "ubyte[2] cellVoltage017;" +
            "ubyte[2] cellVoltage018;" +
            "ubyte[2] cellVoltage019;" +
            "ubyte[2] cellVoltage020;" +
            "ubyte[2] cellVoltage021;" +
            "ubyte[2] cellVoltage022;" +
            "ubyte[2] cellVoltage023;" +
            "ubyte[2] cellVoltage024;" +
            "ubyte[2] cellVoltage025;" +
            "ubyte[2] cellVoltage026;" +
            "ubyte[2] cellVoltage027;" +
            "ubyte[2] cellVoltage028;" +
            "ubyte[2] cellVoltage029;" +
            "ubyte[2] cellVoltage030;" +
            "ubyte[2] cellVoltage031;" +
            "ubyte[2] cellVoltage032;" +
            "ubyte[2] cellVoltage033;" +
            "ubyte[2] cellVoltage034;" +
            "ubyte[2] cellVoltage035;" +
            "ubyte[2] cellVoltage036;" +
            "ubyte[2] cellVoltage037;" +
            "ubyte[2] cellVoltage038;" +
            "ubyte[2] cellVoltage039;" +
            "ubyte[2] cellVoltage040;" +
            "ubyte[2] cellVoltage041;" +
            "ubyte[2] cellVoltage042;" +
            "ubyte[2] cellVoltage043;" +
            "ubyte[2] cellVoltage044;" +
            "ubyte[2] cellVoltage045;" +
            "ubyte[2] cellVoltage046;" +
            "ubyte[2] cellVoltage047;" +
            "ubyte[2] cellVoltage048;" +
            "ubyte[2] cellVoltage049;" +
            "ubyte[2] cellVoltage050;" +
            "ubyte[2] cellVoltage051;" +
            "ubyte[2] cellVoltage052;" +
            "ubyte[2] cellVoltage053;" +
            "ubyte[2] cellVoltage054;" +
            "ubyte[2] cellVoltage055;" +
            "ubyte[2] cellVoltage056;" +
            "ubyte[2] cellVoltage057;" +
            "ubyte[2] cellVoltage058;" +
            "ubyte[2] cellVoltage059;" +
            "ubyte[2] cellVoltage060;" +
            "ubyte[2] cellVoltage061;" +
            "ubyte[2] cellVoltage062;" +
            "ubyte[2] cellVoltage063;" +
            "ubyte[2] cellVoltage064;" +
            "ubyte[2] cellVoltage065;" +
            "ubyte[2] cellVoltage066;" +
            "ubyte[2] cellVoltage067;" +
            "ubyte[2] cellVoltage068;" +
            "ubyte[2] cellVoltage069;" +
            "ubyte[2] cellVoltage070;" +
            "ubyte[2] cellVoltage071;" +
            "ubyte[2] cellVoltage072;" +
            "ubyte[2] cellVoltage073;" +
            "ubyte[2] cellVoltage074;" +
            "ubyte[2] cellVoltage075;" +
            "ubyte[2] cellVoltage076;" +
            "ubyte[2] cellVoltage077;" +
            "ubyte[2] cellVoltage078;" +
            "ubyte[2] cellVoltage079;" +
            "ubyte[2] cellVoltage080;" +
            "ubyte[2] cellVoltage081;" +
            "ubyte[2] cellVoltage082;" +
            "ubyte[2] cellVoltage083;" +
            "ubyte[2] cellVoltage084;" +
            "ubyte[2] cellVoltage085;" +
            "ubyte[2] cellVoltage086;" +
            "ubyte[2] cellVoltage087;" +
            "ubyte[2] cellVoltage088;" +
            "ubyte[2] cellVoltage089;" +
            "ubyte[2] cellVoltage090;" +
            "ubyte[2] cellVoltage091;" +
            "ubyte[2] cellVoltage092;" +
            "ubyte[2] cellVoltage093;" +
            "ubyte[2] cellVoltage094;" +
            "ubyte[2] cellVoltage095;" +
            "ubyte[2] cellVoltage096;" +
            "ubyte[2] cellVoltage097;" +
            "ubyte[2] cellVoltage098;" +
            "ubyte[2] cellVoltage099;" +
            "ubyte[2] cellVoltage100;" +
            "ubyte[2] cellVoltage101;" +
            "ubyte[2] cellVoltage102;" +
            "ubyte[2] cellVoltage103;" +
            "ubyte[2] cellVoltage104;" +
            "ubyte[2] cellVoltage105;" +
            "ubyte[2] cellVoltage106;" +
            "ubyte[2] cellVoltage107;" +
            "ubyte[2] cellVoltage108;";

    public static final String BATTERY_STATUS_SUMMARY = "ubyte code;" +
            "bit:5 chargeMode;" +
            "bit:3 chargeState;" +
            "ubyte powertrainMode;" +
            "ubyte[2] totalEnergy;" +
            "ubyte[2] remainingEnergy;" +
            "ubyte[3] remainingCapacity;" +
            "ubyte[2] stateOfCharge;" +
            "ubyte averageTemperature;" +
            "ubyte maxTemperature;" +
            "ubyte minTemperature;" +
            "ubyte probeWithMaxTemperature;" +
            "ubyte probeWithMinTemperature;";

    public static final String BATTERY_STATUS_DETAILS = "ubyte code;" +
            "ubyte totalProbes;" +
            "ubyte probeTemperature01;" +
            "ubyte probeTemperature02;" +
            "ubyte probeTemperature03;" +
            "ubyte probeTemperature04;" +
            "ubyte probeTemperature05;" +
            "ubyte probeTemperature06;" +
            "ubyte probeTemperature07;" +
            "ubyte probeTemperature08;" +
            "ubyte probeTemperature09;" +
            "ubyte probeTemperature10;" +
            "ubyte probeTemperature11;" +
            "ubyte probeTemperature12;" +
            "ubyte probeTemperature13;" +
            "ubyte probeTemperature14;" +
            "ubyte probeTemperature15;" +
            "ubyte probeTemperature16;" +
            "ubyte probeTemperature17;" +
            "ubyte probeTemperature18;" +
            "ubyte probeTemperature19;" +
            "ubyte probeTemperature20;" +
            "ubyte probeTemperature21;" +
            "ubyte probeTemperature22;" +
            "ubyte probeTemperature23;" +
            "ubyte probeTemperature24;" +
            "ubyte probeTemperature25;" +
            "ubyte probeTemperature26;" +
            "ubyte probeTemperature27;" +
            "ubyte probeTemperature28;" +
            "ubyte probeTemperature29;" +
            "ubyte probeTemperature30;" +
            "ubyte probeTemperature31;" +
            "ubyte probeTemperature32;" +
            "ubyte probeTemperature33;" +
            "ubyte probeTemperature34;" +
            "ubyte probeTemperature35;" +
            "ubyte probeTemperature36;" +
            "ubyte probeTemperature37;" +
            "ubyte probeTemperature38;" +
            "ubyte probeTemperature39;" +
            "ubyte probeTemperature40;" +
            "ubyte probeTemperature41;" +
            "ubyte probeTemperature42;" +
            "ubyte probeTemperature43;" +
            "ubyte probeTemperature44;" +
            "ubyte probeTemperature45;" +
            "ubyte probeTemperature46;" +
            "ubyte probeTemperature47;" +
            "ubyte probeTemperature48;" +
            "ubyte probeTemperature49;" +
            "ubyte probeTemperature50;" +
            "ubyte probeTemperature51;" +
            "ubyte probeTemperature52;" +
            "ubyte probeTemperature53;" +
            "ubyte probeTemperature54;";

    public static final String BATTERY_SOH = "ubyte code;" +
            "ubyte capacitySoH;" +
            "ubyte resistanceSoH;" +
            "ubyte[2] insulationResistance;" +
            "ubyte totalProbes;" +
            "ubyte totalCells;" +
            "ubyte[2] opTimeOverTemp;" +
            "ubyte[2] positiveChargeExchanged;" +
            "ubyte[2] negativeChargeExchanged;" +
            "ubyte[2] negativeChargeExchangedForPlugin;" +
            "ubyte[2] positiveEnergyExchanged;" +
            "ubyte[2] negativeEnergyExchanged;" +
            "ubyte[2] negativeEnergyExchangedForPlugin;" +
            "ubyte[2] opTimeOverChargePower;" +
            "ubyte[2] opTimeOverDischargePower;" +
            "ubyte[2] opTimeOverVoltageRange;" +
            "ubyte[2] opTimeBatteryChargeWithHighTemp;" +
            "ubyte[2] opTimeBatteryDischargeWithHighTemp;" +
            "ubyte[2] mainRelayDamageCounter;" +
            "ubyte[2] quickChargeRelayDamageCounter;";

    public static final String CRASH = "ubyte code;" +
            "bit:2 frontRepairabilityCrashDetected;" +
            "bit:1 frontLowSpeedCrashDetected;" +
            "bit:1 frontMediumSpeedN1CrashDetected;" +
            "bit:1 frontMediumSpeedN2CrashDetected;" +
            "bit:1 frontHighSpeedCrashDetected;" +
            "bit:1 lateralRepairabilityCrashDetected;" +
            "bit:1 lateralLowSpeedCrashDetected;" +
            "bit:1 lateralMediumSpeedCrashDetected;" +
            "bit:1 lateralHighSpeedCrashDetected;" +
            "bit:1 rearRepairabilityCrashDetected;" +
            "bit:1 rearLowSpeedCrashDetected;" +
            "bit:1 rearMediumSpeedCrashDetected;" +
            "bit:1 rearHighSpeedCrashDetected;" +
            "bit:1 tippedOver;" +
            "bit:1 crashDetected;" +
            "bit:7 ecallRequest;" +
            "bit:1 pedestrianCrashDetected;";

    public static final String ADAS = "ubyte code;" +
            "bit:3 rearParkingAssist;" +
            "bit:3 frontParkingAssist;" +
            "bit:2 advancedEmergencyBrakingSystem;" +
            "bit:3 adaptiveCruiseControl;" +
            "bit:2 laneDepartureWarning;" +
            "bit:2 respectOfInterVehicleTimeAssist;" +
            "bit:1 electronicStabilityProgram;" +
            "bit:2 recommenderGearIndicator;" +
            "bit:4 advancedSpeedRegulator;" +
            "bit:2 speedRegulatorStatus;" +
            "ubyte speedLimitInformation;" +
            "bit:3 blindSpotMonitoring;" +
            "bit:2 rightLaneKeepingAssist;" +
            "bit:2 leftLaneKeepingAssist;" +
            "bit:1 antiBrakingSystem;" +
            "bit:1 electricBrakeService;";

    public static final String USAGE_STATUS = "ubyte code;" +
            "ubyte torque;" +
            "bit:1 brakePedalSwitch;" +
            "bit:3 gearboxMode;" +
            "bit:4 gearboxRatio;" +
            "ubyte[2] engineSpeed;" +
            "ubyte driversWill;" +
            "ubyte[2] odometerSpeed;" +
            "ubyte[2] yawSpeed;" +
            "ubyte[2] lateralAcceleration;" +
            "ubyte longitudinalAcceleration;" +
            "ubyte[2] steeringWheelAngle;" +
            "ubyte[2] masterCylinderPressure;" +
            "ubyte powertrainStatus;" +
            "ubyte[2] phevEngineSpeed;" +
            "ubyte[2] bevEngineSpeed;";
    //</editor-fold>

    //<editor-fold desc="Schema V2 / Protocol version 3">
    public static final String HEADER_V2 = HEADER +
            "ubyte triggerType;";

    public static final String VEHICLE_STATUS_V2 = VEHICLE_STATUS +
            "ubyte[4] fuelTotalConsumption;";

    public static final String USAGE_STATUS_V2 = "ubyte code;" +
            "ubyte torque;" +
            "bit:1 brakePedalSwitch;" +
            "bit:3 gearboxMode;" +
            "bit:4 gearboxRatio;" +
            "ubyte[2] engineSpeed;" +
            "ubyte driversWill;" +
            "ubyte[2] odometerSpeed;" +
            "ubyte[2] yawSpeed;" +
            "ubyte[2] lateralAcceleration;" +
            "ubyte longitudinalAcceleration;" +
            "ubyte[2] steeringWheelAngle;" +
            "ubyte[2] masterCylinderPressure;" +
            "bit:4 currentPropulsion;" +
            "bit:4 powertrainStatus;" +
            "ubyte[2] phevEngineSpeed;" +
            "ubyte[2] bevEngineSpeed;";
    //</editor-fold>
}
