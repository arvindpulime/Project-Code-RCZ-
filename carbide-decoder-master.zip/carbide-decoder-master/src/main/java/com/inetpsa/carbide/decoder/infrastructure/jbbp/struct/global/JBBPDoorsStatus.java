package com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.global;

import com.igormaznitsa.jbbp.io.JBBPBitNumber;
import com.igormaznitsa.jbbp.io.JBBPBitOrder;
import com.igormaznitsa.jbbp.mapper.Bin;
import com.igormaznitsa.jbbp.mapper.BinType;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.JBBPData;
import lombok.Setter;

@Setter
public class JBBPDoorsStatus implements JBBPData {

    @Bin(order = 101, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int code;

    @Bin(order = 102, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_6, bitOrder = JBBPBitOrder.MSB0)
    private int lockingStatus;

    @Bin(order = 103, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int bootLockingStatus;

    @Bin(order = 104, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int rearLockingStatus;

    @Bin(order = 105, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int bootOpeningStatus;

    @Bin(order = 106, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int driverOpeningStatus;

    @Bin(order = 107, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int rearRightOpeningStatus;

    @Bin(order = 108, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int rearLeftOpeningStatus;

    @Bin(order = 109, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int driverEstimatedOpeningStatus;

    @Bin(order = 110, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int passengerOpeningStatus;

    @Bin(order = 111, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int rearWindowOpeningStatus;

    @Bin(order = 112, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int retractableRoofPosition;

    public int getCode() {
        return code;
    }

    public int getLockingStatus() {
        return lockingStatus;
    }

    public int getBootLockingStatus() {
        return bootLockingStatus;
    }

    public int getRearLockingStatus() {
        return rearLockingStatus;
    }

    public int getBootOpeningStatus() {
        return bootOpeningStatus;
    }

    public int getDriverOpeningStatus() {
        return driverOpeningStatus;
    }

    public int getRearRightOpeningStatus() {
        return rearRightOpeningStatus;
    }

    public int getRearLeftOpeningStatus() {
        return rearLeftOpeningStatus;
    }

    public int getDriverEstimatedOpeningStatus() {
        return driverEstimatedOpeningStatus;
    }

    public int getPassengerOpeningStatus() {
        return passengerOpeningStatus;
    }

    public int getRearWindowOpeningStatus() {
        return rearWindowOpeningStatus;
    }

    public int getRetractableRoofPosition() {
        return retractableRoofPosition;
    }
}
