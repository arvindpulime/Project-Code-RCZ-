package com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.global;

import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.global.JBBPVehicleStatus;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.global.JBBPVehicleStatusV2;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.DataMapper;
import com.inetpsa.carbide.domain.interfaces.data.global.VehicleStatus;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface VehicleStatusMapperV2 extends DataMapper<VehicleStatus, JBBPVehicleStatusV2> {

    VehicleStatusMapperV2 INSTANCE = Mappers.getMapper(VehicleStatusMapperV2.class);
}
