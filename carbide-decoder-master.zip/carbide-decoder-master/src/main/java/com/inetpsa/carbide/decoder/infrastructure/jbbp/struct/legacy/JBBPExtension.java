package com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.legacy;

import com.igormaznitsa.jbbp.io.JBBPBitNumber;
import com.igormaznitsa.jbbp.io.JBBPBitOrder;
import com.igormaznitsa.jbbp.mapper.Bin;
import com.igormaznitsa.jbbp.mapper.BinType;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.JBBPData;
import com.inetpsa.carbide.decoder.infrastructure.util.ByteUtils;
import lombok.Setter;

import java.math.BigDecimal;
import java.math.RoundingMode;

import static com.inetpsa.carbide.decoder.infrastructure.util.Factor.*;
import static com.inetpsa.carbide.decoder.infrastructure.util.Offset.*;

@Setter
public class JBBPExtension implements JBBPData {

    @Bin(order = 101, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int code;

    @Bin(order = 102, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int torque;

    @Bin(order = 103, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] engineSpeed;

    @Bin(order = 104, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int driversWill;

    @Bin(order = 105, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] odometerSpeed;

    @Bin(order = 106, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int engineOilLevel;

    @Bin(order = 107, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int engineAirTemperature;

    @Bin(order = 108, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int engineWaterTemperature;

    @Bin(order = 109, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int engineOilTemperature;

    @Bin(order = 110, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] yawSpeed;

    @Bin(order = 111, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] lateralAcceleration;

    @Bin(order = 112, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int longitudinalAcceleration;

    @Bin(order = 113, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int driverSeatBeltState;

    @Bin(order = 114, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int passengerSeatBeltState;

    @Bin(order = 115, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rainSensorState;

    @Bin(order = 116, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int powerTrainState;

    @Bin(order = 117, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] steeringWheelAngle;

    @Bin(order = 118, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] batteryVoltage;

    @Bin(order = 119, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] masterCylinder;

    @Bin(order = 120, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int gearboxEffectiveRatio;

    @Bin(order = 121, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int gearboxCalculatedRatio;

    @Bin(order = 122, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int gearboxMode;

    @Bin(order = 123, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int stopIndicator;

    @Bin(order = 124, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int serviceIndicator;

    @Bin(order = 125, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int breakPedalState;

    public int getCode() {
        return code;
    }

    public int getTorque() {
        return torque * TORQUE_FACTOR + TORQUE_OFFSET;
    }

    public BigDecimal getEngineSpeed() {
        return BigDecimal.valueOf(ByteUtils.asInt(engineSpeed) * ENGINE_SPEED_FACTOR).setScale(3, RoundingMode.FLOOR);
    }

    public BigDecimal getDriversWill() {
        return BigDecimal.valueOf(driversWill * DRIVERS_WILL_FACTOR).setScale(2, RoundingMode.FLOOR);
    }

    public BigDecimal getOdometerSpeed() {
        return BigDecimal.valueOf(ByteUtils.asInt(odometerSpeed) * ODOMETER_SPEED_FACTOR).setScale(2, RoundingMode.FLOOR);
    }

    public int getEngineOilLevel() {
        return engineOilLevel * ENGINE_OIL_LEVEL_FACTOR;
    }

    public int getEngineAirTemperature() {
        return engineAirTemperature + TEMPERATURE_OFFSET;
    }

    public int getEngineWaterTemperature() {
        return engineWaterTemperature + TEMPERATURE_OFFSET;
    }

    public int getEngineOilTemperature() {
        return engineOilTemperature + TEMPERATURE_OFFSET;
    }

    public BigDecimal getYawSpeed() {
        return BigDecimal.valueOf(ByteUtils.asSignedInt(yawSpeed) * YAW_SPEED_FACTOR).setScale(2, RoundingMode.FLOOR);
    }

    public BigDecimal getLateralAcceleration() {
        return BigDecimal.valueOf(ByteUtils.asSignedInt(lateralAcceleration) * LATERAL_ACCELERATION_FACTOR).setScale(2, RoundingMode.FLOOR);
    }

    public BigDecimal getLongitudinalAcceleration() {
        return BigDecimal.valueOf(longitudinalAcceleration * LONGITUDINAL_ACCELERATION_FACTOR + LONGITUDINAL_ACCELERATION_OFFSET).setScale(2, RoundingMode.FLOOR);
    }

    public int getDriverSeatBeltState() {
        return driverSeatBeltState;
    }

    public int getPassengerSeatBeltState() {
        return passengerSeatBeltState;
    }

    public int getRainSensorState() {
        return rainSensorState;
    }

    public int getPowerTrainState() {
        return powerTrainState;
    }

    public BigDecimal getSteeringWheelAngle() {
        return BigDecimal.valueOf(ByteUtils.asSignedInt(steeringWheelAngle) * STEERING_WHEEL_ANGLE_FACTOR).setScale(2, RoundingMode.FLOOR);
    }

    public BigDecimal getBatteryVoltage() {
        return BigDecimal.valueOf(ByteUtils.asInt(batteryVoltage) * BATTERY_VOLTAGE_FACTOR + BATTERY_VOLTAGE_OFFSET).setScale(2, RoundingMode.FLOOR);
    }

    public BigDecimal getMasterCylinder() {
        return BigDecimal.valueOf(ByteUtils.asInt(masterCylinder) * MASTER_CYLINDER_FACTOR + MASTER_CYLINDER_OFFSET).setScale(2, RoundingMode.FLOOR);
    }

    public int getGearboxEffectiveRatio() {
        return gearboxEffectiveRatio;
    }

    public int getGearboxCalculatedRatio() {
        return gearboxCalculatedRatio;
    }

    public int getGearboxMode() {
        return gearboxMode;
    }

    public int getStopIndicator() {
        return stopIndicator;
    }

    public int getServiceIndicator() {
        return serviceIndicator;
    }

    public int getBreakPedalState() {
        return breakPedalState;
    }
}
