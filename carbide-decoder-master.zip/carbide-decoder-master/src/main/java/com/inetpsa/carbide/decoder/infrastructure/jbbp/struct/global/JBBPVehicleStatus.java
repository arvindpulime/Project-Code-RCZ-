package com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.global;

import com.igormaznitsa.jbbp.io.JBBPBitNumber;
import com.igormaznitsa.jbbp.io.JBBPBitOrder;
import com.igormaznitsa.jbbp.mapper.Bin;
import com.igormaznitsa.jbbp.mapper.BinType;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.JBBPData;
import com.inetpsa.carbide.decoder.infrastructure.util.ByteUtils;
import lombok.Setter;

import java.math.BigDecimal;
import java.math.RoundingMode;

import static com.inetpsa.carbide.decoder.infrastructure.util.Factor.*;
import static com.inetpsa.carbide.decoder.infrastructure.util.Offset.TEMPERATURE_OFFSET;

@Setter
public class JBBPVehicleStatus implements JBBPData {

    @Bin(order = 101, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int code;

    @Bin(order = 102, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int outsideTemperature;

    @Bin(order = 103, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] lifetimeMileage;

    @Bin(order = 104, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int auxiliaryBatterySoC;

    @Bin(order = 105, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int fuelLevel;

    @Bin(order = 106, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] residualAutonomy;

    @Bin(order = 107, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int chargeState;

    @Bin(order = 108, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] zevAutonomy;

    @Bin(order = 109, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int electricNetworkState;

    @Bin(order = 110, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int sevMainStatus;

    @Bin(order = 111, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity;

    public int getCode() {
        return code;
    }

    public BigDecimal getOutsideTemperature() {
        return BigDecimal.valueOf(outsideTemperature * OUTSIDE_TEMPERATURE_FACTOR + TEMPERATURE_OFFSET).setScale(2, RoundingMode.FLOOR);
    }

    public BigDecimal getLifetimeMileage() {
        return BigDecimal.valueOf(ByteUtils.asInt(lifetimeMileage) * LIFETIME_MILEAGE_FACTOR).setScale(2, RoundingMode.FLOOR);
    }

    public BigDecimal getAuxiliaryBatterySoC() {
        return BigDecimal.valueOf(auxiliaryBatterySoC * AUXILIARY_BATTERY_SOC_FACTOR).setScale(2, RoundingMode.FLOOR);
    }

    public int getFuelLevel() {
        return fuelLevel;
    }

    public int getResidualAutonomy() {
        return ByteUtils.asInt(residualAutonomy);
    }

    public int getChargeState() {
        return chargeState;
    }

    public int getZevAutonomy() {
        return ByteUtils.asInt(zevAutonomy) * ZEV_AUTONOMY_FACTOR;
    }

    public int getElectricNetworkState() {
        return electricNetworkState;
    }

    public int getSevMainStatus() {
        return sevMainStatus;
    }

    public int getLuminosity() {
        return luminosity;
    }
}
