package com.inetpsa.carbide.decoder.infrastructure.jbbp.parser;

import com.igormaznitsa.jbbp.JBBPParser;
import com.igormaznitsa.jbbp.io.JBBPBitOrder;
import com.inetpsa.carbide.decoder.application.util.Structure;
import com.inetpsa.carbide.decoder.application.util.StructureMap;

public final class ParserFactory {

    private ParserFactory() {
    }

    public static JBBPParser create(Structure structure) {
        return JBBPParser.prepare(StructureMap.parserFormat(structure), JBBPBitOrder.MSB0);
    }
}
