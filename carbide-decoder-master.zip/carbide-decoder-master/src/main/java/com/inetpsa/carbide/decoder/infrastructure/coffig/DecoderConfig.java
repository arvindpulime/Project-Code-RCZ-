package com.inetpsa.carbide.decoder.infrastructure.coffig;

import org.seedstack.coffig.Config;

@Config("decoder")
public class DecoderConfig {

}
