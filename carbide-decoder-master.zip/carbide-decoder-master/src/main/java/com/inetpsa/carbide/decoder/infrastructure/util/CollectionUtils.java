package com.inetpsa.carbide.decoder.infrastructure.util;

import java.util.Arrays;
import java.util.List;

public final class CollectionUtils {

    private CollectionUtils() {
    }

    @SafeVarargs
    public static <T> List<T> addAll(T... elements) {
        return Arrays.asList(elements);
    }

    /**
     * Add a maximum number of items from the supplied array to a list.
     * If this number exceeds the size of the list, none will be removed.
     *
     * @param numToKeep Number of elements to keep
     * @param elements  The supplied array
     * @param <T>       Type of the items
     * @return A list of items
     */
    @SafeVarargs
    public static <T> List<T> addAllKeepFirst(int numToKeep, T... elements) {
        final List<T> list = Arrays.asList(elements);
        return list.subList(0, Math.min(numToKeep, list.size()));
    }
}
