package com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.global;

import com.igormaznitsa.jbbp.io.JBBPBitNumber;
import com.igormaznitsa.jbbp.io.JBBPBitOrder;
import com.igormaznitsa.jbbp.mapper.Bin;
import com.igormaznitsa.jbbp.mapper.BinType;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.JBBPData;
import com.inetpsa.carbide.decoder.infrastructure.util.ByteUtils;
import lombok.Setter;

import java.math.BigDecimal;
import java.math.RoundingMode;

import static com.inetpsa.carbide.decoder.infrastructure.util.Factor.*;
import static com.inetpsa.carbide.decoder.infrastructure.util.Offset.*;
import static com.inetpsa.carbide.decoder.infrastructure.util.SignalSize.BEV_ENGINE_SPEED_SIZE;
import static com.inetpsa.carbide.decoder.infrastructure.util.SignalSize.PHEV_ENGINE_SPEED_SIZE;

@Setter
public class JBBPUsageStatus implements JBBPData {

    @Bin(order = 101, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int code;

    @Bin(order = 102, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int torque;

    @Bin(order = 103, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int brakePedalSwitch;

    @Bin(order = 104, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int gearboxMode;

    @Bin(order = 105, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int gearboxRatio;

    @Bin(order = 106, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] engineSpeed;

    @Bin(order = 107, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int driversWill;

    @Bin(order = 108, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] odometerSpeed;

    @Bin(order = 109, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] yawSpeed;

    @Bin(order = 110, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] lateralAcceleration;

    @Bin(order = 111, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int longitudinalAcceleration;

    @Bin(order = 112, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] steeringWheelAngle;

    @Bin(order = 113, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] masterCylinderPressure;

    @Bin(order = 114, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int powertrainStatus;

    @Bin(order = 115, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] phevEngineSpeed;

    @Bin(order = 116, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] bevEngineSpeed;

    public int getCode() {
        return code;
    }

    public int getTorque() {
        return torque * TORQUE_FACTOR + TORQUE_OFFSET;
    }

    public int getBrakePedalSwitch() {
        return brakePedalSwitch;
    }

    public int getGearboxMode() {
        return gearboxMode;
    }

    public int getGearboxRatio() {
        return gearboxRatio;
    }

    public BigDecimal getEngineSpeed() {
        return BigDecimal.valueOf(ByteUtils.asInt(engineSpeed) * ENGINE_SPEED_FACTOR).setScale(3, RoundingMode.FLOOR);
    }

    public BigDecimal getDriversWill() {
        return BigDecimal.valueOf(driversWill * DRIVERS_WILL_FACTOR).setScale(2, RoundingMode.FLOOR);
    }

    public BigDecimal getOdometerSpeed() {
        return BigDecimal.valueOf(ByteUtils.asInt(odometerSpeed) * ODOMETER_SPEED_FACTOR).setScale(2, RoundingMode.FLOOR);
    }

    public BigDecimal getYawSpeed() {
        return BigDecimal.valueOf(ByteUtils.asSignedInt(yawSpeed) * YAW_SPEED_FACTOR).setScale(2, RoundingMode.FLOOR);
    }

    public BigDecimal getLateralAcceleration() {
        return BigDecimal.valueOf(ByteUtils.asSignedInt(lateralAcceleration) * LATERAL_ACCELERATION_FACTOR).setScale(2, RoundingMode.FLOOR);
    }

    public BigDecimal getLongitudinalAcceleration() {
        return BigDecimal.valueOf(longitudinalAcceleration * LONGITUDINAL_ACCELERATION_FACTOR + LONGITUDINAL_ACCELERATION_OFFSET).setScale(2, RoundingMode.FLOOR);
    }

    public BigDecimal getSteeringWheelAngle() {
        return BigDecimal.valueOf(ByteUtils.asSignedInt(steeringWheelAngle) * STEERING_WHEEL_ANGLE_FACTOR).setScale(2, RoundingMode.FLOOR);
    }

    public BigDecimal getMasterCylinderPressure() {
        return BigDecimal.valueOf(ByteUtils.asInt(masterCylinderPressure) * MASTER_CYLINDER_FACTOR + MASTER_CYLINDER_OFFSET).setScale(2, RoundingMode.FLOOR);
    }

    public int getPowertrainStatus() {
        return powertrainStatus;
    }

    public int getPhevEngineSpeed() {
        return ByteUtils.asSignedInt(phevEngineSpeed, PHEV_ENGINE_SPEED_SIZE);
    }

    public int getBevEngineSpeed() {
        return ByteUtils.asSignedInt(bevEngineSpeed, BEV_ENGINE_SPEED_SIZE) * BEV_ENGINE_SPEED_FACTOR;
    }
}
