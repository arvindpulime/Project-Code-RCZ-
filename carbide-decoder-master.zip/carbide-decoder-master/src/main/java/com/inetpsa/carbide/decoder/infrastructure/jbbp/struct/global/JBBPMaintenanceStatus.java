package com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.global;

import com.igormaznitsa.jbbp.io.JBBPBitNumber;
import com.igormaznitsa.jbbp.io.JBBPBitOrder;
import com.igormaznitsa.jbbp.mapper.Bin;
import com.igormaznitsa.jbbp.mapper.BinType;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.JBBPData;
import com.inetpsa.carbide.decoder.infrastructure.util.ByteUtils;
import lombok.Setter;

import static com.inetpsa.carbide.decoder.infrastructure.util.Constant.SIGN_PLUS;
import static com.inetpsa.carbide.decoder.infrastructure.util.Factor.MILEAGE_BEFORE_MAINTENANCE_FACTOR;

@Setter
public class JBBPMaintenanceStatus implements JBBPData {

    @Bin(order = 101, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int code;

    @Bin(order = 102, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int serviceLight;

    @Bin(order = 103, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int maintenanceLight;

    @Bin(order = 104, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int maintenanceLightMode;

    @Bin(order = 105, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int maintenanceType;

    @Bin(order = 106, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int mileageToMaintenanceSign;

    @Bin(order = 107, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int daysToMaintenanceSign;

    @Bin(order = 108, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] mileageToMaintenance;

    @Bin(order = 109, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] daysToMaintenance;

    public int getCode() {
        return code;
    }

    public int getServiceLight() {
        return serviceLight;
    }

    public int getMaintenanceLight() {
        return maintenanceLight;
    }

    public int getMaintenanceLightMode() {
        return maintenanceLightMode;
    }

    public int getMaintenanceType() {
        return maintenanceType;
    }

    public int getMileageToMaintenance() {
        final int mileageToMaintenance = ByteUtils.asInt(this.mileageToMaintenance) * MILEAGE_BEFORE_MAINTENANCE_FACTOR;
        if (mileageToMaintenanceSign == SIGN_PLUS) {
            return mileageToMaintenance;
        }
        return mileageToMaintenance * (-1);
    }

    public int getDaysToMaintenance() {
        if (daysToMaintenanceSign == SIGN_PLUS) {
            return ByteUtils.asInt(daysToMaintenance);
        }
        return ByteUtils.asInt(daysToMaintenance) * (-1);
    }
}
