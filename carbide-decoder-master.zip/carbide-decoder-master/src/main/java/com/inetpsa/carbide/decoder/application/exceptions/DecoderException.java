package com.inetpsa.carbide.decoder.application.exceptions;

public class DecoderException extends Exception {

    public DecoderException() {
        super();
    }

    public DecoderException(String message) {
        super(message);
    }

    public DecoderException(String message, Throwable cause) {
        super(message, cause);
    }
}
