package com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.lev.monitoring;

import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.lev.monitoring.JBBPBatteryStatusSummary;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.DataMapper;
import com.inetpsa.carbide.domain.interfaces.data.lev.monitoring.BatteryStatusSummary;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface BatteryStatusSummaryMapper extends DataMapper<BatteryStatusSummary, JBBPBatteryStatusSummary> {

    BatteryStatusSummaryMapper INSTANCE = Mappers.getMapper(BatteryStatusSummaryMapper.class);
}
