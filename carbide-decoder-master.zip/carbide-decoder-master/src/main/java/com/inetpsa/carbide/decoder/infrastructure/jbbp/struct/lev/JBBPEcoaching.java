package com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.lev;

import com.igormaznitsa.jbbp.io.JBBPBitNumber;
import com.igormaznitsa.jbbp.io.JBBPBitOrder;
import com.igormaznitsa.jbbp.mapper.Bin;
import com.igormaznitsa.jbbp.mapper.BinType;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.JBBPData;
import lombok.Setter;

@Setter
public final class JBBPEcoaching implements JBBPData {

    @Bin(order = 101, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int code;

    @Bin(order = 102, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int globalScore;

    @Bin(order = 103, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int accelScore;

    @Bin(order = 104, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int brakeScore;

    @Bin(order = 105, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int climateComfortScore;

    @Bin(order = 106, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int coldEngineScore;

    @Bin(order = 107, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int tirePressureScore;

    @Bin(order = 108, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int slopeScore;

    @Bin(order = 109, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int speedScore;

    @Bin(order = 110, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int startStopScore;

    public int getCode() {
        return code;
    }

    public int getGlobalScore() {
        return globalScore;
    }

    public int getAccelScore() {
        return accelScore;
    }

    public int getBrakeScore() {
        return brakeScore;
    }

    public int getClimateComfortScore() {
        return climateComfortScore;
    }

    public int getColdEngineScore() {
        return coldEngineScore;
    }

    public int getTirePressureScore() {
        return tirePressureScore;
    }

    public int getSlopeScore() {
        return slopeScore;
    }

    public int getSpeedScore() {
        return speedScore;
    }

    public int getStartStopScore() {
        return startStopScore;
    }
}
