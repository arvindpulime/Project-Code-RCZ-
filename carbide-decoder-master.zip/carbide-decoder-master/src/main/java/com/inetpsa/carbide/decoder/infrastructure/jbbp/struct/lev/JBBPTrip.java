package com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.lev;

import com.igormaznitsa.jbbp.io.JBBPBitOrder;
import com.igormaznitsa.jbbp.mapper.Bin;
import com.igormaznitsa.jbbp.mapper.BinType;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.JBBPData;
import com.inetpsa.carbide.decoder.infrastructure.util.ByteUtils;
import lombok.Setter;

import java.math.BigDecimal;
import java.math.RoundingMode;

import static com.inetpsa.carbide.decoder.infrastructure.util.Factor.AVG_FUEL_CONSUMPTION_FACTOR;
import static com.inetpsa.carbide.decoder.infrastructure.util.Factor.ZEV_AVG_POWER_CONSUMPTION_FACTOR;

@Setter
public final class JBBPTrip implements JBBPData {

    @Bin(order = 101, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int code;

    @Bin(order = 102, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] avgFuelConsumption;

    @Bin(order = 103, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] zevAvgPowerConsumption;

    @Bin(order = 104, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int zevUtilization;

    @Bin(order = 105, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] distanceTraveled;

    @Bin(order = 106, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] duration;

    public int getCode() {
        return code;
    }

    public BigDecimal getAvgFuelConsumption() {
        return BigDecimal.valueOf(ByteUtils.asInt(avgFuelConsumption) * AVG_FUEL_CONSUMPTION_FACTOR).setScale(2, RoundingMode.FLOOR);
    }

    public BigDecimal getZevAvgPowerConsumption() {
        return BigDecimal.valueOf(ByteUtils.asInt(zevAvgPowerConsumption) * ZEV_AVG_POWER_CONSUMPTION_FACTOR).setScale(2, RoundingMode.FLOOR);
    }

    public int getZevUtilization() {
        return zevUtilization;
    }

    public int getDistanceTraveled() {
        return ByteUtils.asInt(distanceTraveled);
    }

    public int getDuration() {
        return ByteUtils.asInt(duration);
    }
}
