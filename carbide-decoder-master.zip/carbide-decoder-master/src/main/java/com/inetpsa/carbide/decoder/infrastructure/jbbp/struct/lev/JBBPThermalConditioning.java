package com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.lev;

import com.igormaznitsa.jbbp.io.JBBPBitNumber;
import com.igormaznitsa.jbbp.io.JBBPBitOrder;
import com.igormaznitsa.jbbp.mapper.Bin;
import com.igormaznitsa.jbbp.mapper.BinType;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.JBBPData;
import com.inetpsa.carbide.decoder.infrastructure.util.ByteUtils;
import lombok.Setter;

@Setter
public final class JBBPThermalConditioning implements JBBPData {

    @Bin(order = 101, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int code;

    @Bin(order = 102, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int precondActivation;

    @Bin(order = 103, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int week1PrecondActivation;

    @Bin(order = 104, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] week1PrecondTime;

    @Bin(order = 105, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int week1Day1PrecondActivation;

    @Bin(order = 106, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int week1Day2PrecondActivation;

    @Bin(order = 107, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int week1Day3PrecondActivation;

    @Bin(order = 108, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int week1Day4PrecondActivation;

    @Bin(order = 109, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int week1Day5PrecondActivation;

    @Bin(order = 110, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int week1Day6PrecondActivation;

    @Bin(order = 111, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int week1Day7PrecondActivation;

    @Bin(order = 112, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int week2PrecondActivation;

    @Bin(order = 113, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] week2PrecondTime;

    @Bin(order = 114, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int week2Day1PrecondActivation;

    @Bin(order = 115, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int week2Day2PrecondActivation;

    @Bin(order = 116, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int week2Day3PrecondActivation;

    @Bin(order = 117, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int week2Day4PrecondActivation;

    @Bin(order = 118, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int week2Day5PrecondActivation;

    @Bin(order = 119, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int week2Day6PrecondActivation;

    @Bin(order = 120, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int week2Day7PrecondActivation;

    @Bin(order = 121, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int week3PrecondActivation;

    @Bin(order = 122, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] week3PrecondTime;

    @Bin(order = 123, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int week3Day1PrecondActivation;

    @Bin(order = 124, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int week3Day2PrecondActivation;

    @Bin(order = 125, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int week3Day3PrecondActivation;

    @Bin(order = 126, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int week3Day4PrecondActivation;

    @Bin(order = 127, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int week3Day5PrecondActivation;

    @Bin(order = 128, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int week3Day6PrecondActivation;

    @Bin(order = 129, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int week3Day7PrecondActivation;

    @Bin(order = 130, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int week4PrecondActivation;

    @Bin(order = 131, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] week4PrecondTime;

    @Bin(order = 132, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int week4Day1PrecondActivation;

    @Bin(order = 133, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int week4Day2PrecondActivation;

    @Bin(order = 134, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int week4Day3PrecondActivation;

    @Bin(order = 135, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int week4Day4PrecondActivation;

    @Bin(order = 136, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int week4Day5PrecondActivation;

    @Bin(order = 137, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int week4Day6PrecondActivation;

    @Bin(order = 138, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int week4Day7PrecondActivation;

    public int getCode() {
        return code;
    }

    public int getPrecondActivation() {
        return precondActivation;
    }

    public int getWeek1PrecondActivation() {
        return week1PrecondActivation;
    }

    public int getWeek1PrecondTime() {
        return ByteUtils.asInt(week1PrecondTime);
    }

    public int getWeek1Day1PrecondActivation() {
        return week1Day1PrecondActivation;
    }

    public int getWeek1Day2PrecondActivation() {
        return week1Day2PrecondActivation;
    }

    public int getWeek1Day3PrecondActivation() {
        return week1Day3PrecondActivation;
    }

    public int getWeek1Day4PrecondActivation() {
        return week1Day4PrecondActivation;
    }

    public int getWeek1Day5PrecondActivation() {
        return week1Day5PrecondActivation;
    }

    public int getWeek1Day6PrecondActivation() {
        return week1Day6PrecondActivation;
    }

    public int getWeek1Day7PrecondActivation() {
        return week1Day7PrecondActivation;
    }

    public int getWeek2PrecondActivation() {
        return week2PrecondActivation;
    }

    public int getWeek2PrecondTime() {
        return ByteUtils.asInt(week2PrecondTime);
    }

    public int getWeek2Day1PrecondActivation() {
        return week2Day1PrecondActivation;
    }

    public int getWeek2Day2PrecondActivation() {
        return week2Day2PrecondActivation;
    }

    public int getWeek2Day3PrecondActivation() {
        return week2Day3PrecondActivation;
    }

    public int getWeek2Day4PrecondActivation() {
        return week2Day4PrecondActivation;
    }

    public int getWeek2Day5PrecondActivation() {
        return week2Day5PrecondActivation;
    }

    public int getWeek2Day6PrecondActivation() {
        return week2Day6PrecondActivation;
    }

    public int getWeek2Day7PrecondActivation() {
        return week2Day7PrecondActivation;
    }

    public int getWeek3PrecondActivation() {
        return week3PrecondActivation;
    }

    public int getWeek3PrecondTime() {
        return ByteUtils.asInt(week3PrecondTime);
    }

    public int getWeek3Day1PrecondActivation() {
        return week3Day1PrecondActivation;
    }

    public int getWeek3Day2PrecondActivation() {
        return week3Day2PrecondActivation;
    }

    public int getWeek3Day3PrecondActivation() {
        return week3Day3PrecondActivation;
    }

    public int getWeek3Day4PrecondActivation() {
        return week3Day4PrecondActivation;
    }

    public int getWeek3Day5PrecondActivation() {
        return week3Day5PrecondActivation;
    }

    public int getWeek3Day6PrecondActivation() {
        return week3Day6PrecondActivation;
    }

    public int getWeek3Day7PrecondActivation() {
        return week3Day7PrecondActivation;
    }

    public int getWeek4PrecondActivation() {
        return week4PrecondActivation;
    }

    public int getWeek4PrecondTime() {
        return ByteUtils.asInt(week4PrecondTime);
    }

    public int getWeek4Day1PrecondActivation() {
        return week4Day1PrecondActivation;
    }

    public int getWeek4Day2PrecondActivation() {
        return week4Day2PrecondActivation;
    }

    public int getWeek4Day3PrecondActivation() {
        return week4Day3PrecondActivation;
    }

    public int getWeek4Day4PrecondActivation() {
        return week4Day4PrecondActivation;
    }

    public int getWeek4Day5PrecondActivation() {
        return week4Day5PrecondActivation;
    }

    public int getWeek4Day6PrecondActivation() {
        return week4Day6PrecondActivation;
    }

    public int getWeek4Day7PrecondActivation() {
        return week4Day7PrecondActivation;
    }
}
