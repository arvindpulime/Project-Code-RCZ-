package com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.legacy;

import com.igormaznitsa.jbbp.io.JBBPBitNumber;
import com.igormaznitsa.jbbp.io.JBBPBitOrder;
import com.igormaznitsa.jbbp.mapper.Bin;
import com.igormaznitsa.jbbp.mapper.BinType;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.JBBPData;
import com.inetpsa.carbide.decoder.infrastructure.util.ByteUtils;
import com.inetpsa.carbide.decoder.infrastructure.util.CollectionUtils;
import com.inetpsa.carbide.decoder.infrastructure.util.DateUtils;
import com.inetpsa.carbide.decoder.infrastructure.util.Formula;
import lombok.Setter;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.List;

import static com.inetpsa.carbide.decoder.infrastructure.util.Constant.STARTING_YEAR;
import static com.inetpsa.carbide.decoder.infrastructure.util.Factor.*;
import static com.inetpsa.carbide.decoder.infrastructure.util.Offset.TEMPERATURE_OFFSET;

@Setter
public class JBBPPeriodic implements JBBPData {

    @Bin(order = 1, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_6, bitOrder = JBBPBitOrder.MSB0)
    private int yearOfCollection;

    @Bin(order = 2, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int monthOfCollection;

    @Bin(order = 3, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int dayOfCollection;

    @Bin(order = 4, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int hourOfCollection;

    @Bin(order = 5, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_6, bitOrder = JBBPBitOrder.MSB0)
    private int minuteOfCollection;

    @Bin(order = 6, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_6, bitOrder = JBBPBitOrder.MSB0)
    private int secondOfCollection;
    //</editor-fold>

    //<editor-fold desc="HOUR_DATE_UPSTREAM">
    @Bin(order = 7, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_6, bitOrder = JBBPBitOrder.MSB0)
    private int yearOfTransmission;

    @Bin(order = 8, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int monthOfTransmission;

    @Bin(order = 9, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int dayOfTransmission;

    @Bin(order = 10, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int hourOfTransmission;

    @Bin(order = 11, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_6, bitOrder = JBBPBitOrder.MSB0)
    private int minuteOfTransmission;

    @Bin(order = 12, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_6, bitOrder = JBBPBitOrder.MSB0)
    private int secondOfTransmission;

    @Bin(order = 13, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] idTrip;

    @Bin(order = 14, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] idFrame;

    @Bin(order = 15, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int privacyMode01;

    @Bin(order = 16, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private int privacyMode02;

    @Bin(order = 17, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int rebootCounter;

    //<editor-fold desc="VIN_VEHICLE">
    @Bin(order = 18, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] vin;
    //</editor-fold>

    //<editor-fold desc="GPS_LOCATION">
    @Bin(order = 101, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude01;

    @Bin(order = 102, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude02;

    @Bin(order = 103, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude03;

    @Bin(order = 104, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude04;

    @Bin(order = 105, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude05;

    @Bin(order = 106, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude06;

    @Bin(order = 107, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude07;

    @Bin(order = 108, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude08;

    @Bin(order = 109, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude09;

    @Bin(order = 110, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude10;

    @Bin(order = 201, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading01;

    @Bin(order = 202, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading02;

    @Bin(order = 203, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading03;

    @Bin(order = 204, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading04;

    @Bin(order = 205, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading05;

    @Bin(order = 206, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading06;

    @Bin(order = 207, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading07;

    @Bin(order = 208, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading08;

    @Bin(order = 209, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading09;

    @Bin(order = 210, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading10;

    @Bin(order = 211, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading11;

    @Bin(order = 212, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading12;

    @Bin(order = 213, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading13;

    @Bin(order = 214, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading14;

    @Bin(order = 215, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading15;

    @Bin(order = 216, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading16;

    @Bin(order = 217, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading17;

    @Bin(order = 218, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading18;

    @Bin(order = 219, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading19;

    @Bin(order = 220, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading20;

    @Bin(order = 221, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading21;

    @Bin(order = 222, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading22;

    @Bin(order = 223, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading23;

    @Bin(order = 224, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading24;

    @Bin(order = 225, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading25;

    @Bin(order = 226, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading26;

    @Bin(order = 227, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading27;

    @Bin(order = 228, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading28;

    @Bin(order = 229, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading29;

    @Bin(order = 230, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading30;

    @Bin(order = 231, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading31;

    @Bin(order = 232, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading32;

    @Bin(order = 233, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading33;

    @Bin(order = 234, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading34;

    @Bin(order = 235, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading35;

    @Bin(order = 236, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading36;

    @Bin(order = 237, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading37;

    @Bin(order = 238, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading38;

    @Bin(order = 239, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading39;

    @Bin(order = 240, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading40;

    @Bin(order = 241, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading41;

    @Bin(order = 242, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading42;

    @Bin(order = 243, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading43;

    @Bin(order = 244, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading44;

    @Bin(order = 245, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading45;

    @Bin(order = 246, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading46;

    @Bin(order = 247, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading47;

    @Bin(order = 248, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading48;

    @Bin(order = 249, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading49;

    @Bin(order = 250, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading50;

    @Bin(order = 251, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading51;

    @Bin(order = 252, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading52;

    @Bin(order = 253, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading53;

    @Bin(order = 254, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading54;

    @Bin(order = 255, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading55;

    @Bin(order = 256, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading56;

    @Bin(order = 257, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading57;

    @Bin(order = 258, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading58;

    @Bin(order = 259, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading59;

    @Bin(order = 260, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] heading60;

    @Bin(order = 301, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude01;

    @Bin(order = 302, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude01;

    @Bin(order = 303, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude02;

    @Bin(order = 304, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude02;

    @Bin(order = 305, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude03;

    @Bin(order = 306, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude03;

    @Bin(order = 307, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude04;

    @Bin(order = 308, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude04;

    @Bin(order = 309, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude05;

    @Bin(order = 310, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude05;

    @Bin(order = 311, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude06;

    @Bin(order = 312, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude06;

    @Bin(order = 313, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude07;

    @Bin(order = 314, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude07;

    @Bin(order = 315, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude08;

    @Bin(order = 316, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude08;

    @Bin(order = 317, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude09;

    @Bin(order = 318, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude09;

    @Bin(order = 319, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude10;

    @Bin(order = 320, type = BinType.BYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude10;

    @Bin(order = 501, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality01;

    @Bin(order = 502, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality02;

    @Bin(order = 503, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality03;

    @Bin(order = 504, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality04;

    @Bin(order = 505, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality05;

    @Bin(order = 506, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality06;

    @Bin(order = 507, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality07;

    @Bin(order = 508, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality08;

    @Bin(order = 509, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality09;

    @Bin(order = 510, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int gpsSignalQuality10;

    @Bin(order = 601, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType01;

    @Bin(order = 602, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType02;

    @Bin(order = 603, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType03;

    @Bin(order = 604, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType04;

    @Bin(order = 605, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType05;

    @Bin(order = 606, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType06;

    @Bin(order = 607, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType07;

    @Bin(order = 608, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType08;

    @Bin(order = 609, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType09;

    @Bin(order = 610, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleLocationType10;
    //</editor-fold>

    //<editor-fold desc="CRASH_DATA">
    @Bin(order = 700, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rearHighSpeedCrashInfo;

    @Bin(order = 701, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rearMediumSpeedCrashInfo;

    @Bin(order = 702, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rearSlowSpeedCrashInfo;

    @Bin(order = 703, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rearReparabilitySpeedCrashInfo;

    @Bin(order = 704, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int pedestrianCrashInfo01;

    @Bin(order = 705, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int pedestrianCrashInfo02;

    @Bin(order = 706, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int pedestrianCrashInfo03;

    @Bin(order = 707, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int highSpeedFrontCrashInfo;

    @Bin(order = 708, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int mediumSpeedN1FrontCrashInfo;

    @Bin(order = 709, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int mediumSpeedN2FrontCrashInfo;

    @Bin(order = 710, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int lowSpeedFrontCrashInfo;

    @Bin(order = 711, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int frontReparabilityCrashInfo;

    @Bin(order = 712, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rearHighSpeedLateralCrashInfo;

    @Bin(order = 713, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rearMediumSpeedLateralCrashInfo;

    @Bin(order = 714, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rearLowSpeedLateralCrashInfo;

    @Bin(order = 715, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int rearRepairabilityCrashInfo;

    @Bin(order = 716, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int tippedOver;
    //</editor-fold>

    //<editor-fold desc="ADAS_DATA">
    @Bin(order = 801, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private byte rearParking01Part1;

    @Bin(order = 802, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private byte rearParking01Part2;

    @Bin(order = 803, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private byte rearParking02Part1;

    @Bin(order = 804, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private byte rearParking02Part2;

    @Bin(order = 805, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private byte rearParking03Part1;

    @Bin(order = 806, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private byte rearParking03Part2;

    @Bin(order = 901, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private byte frontParking01Part1;

    @Bin(order = 902, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private byte frontParking01Part2;

    @Bin(order = 903, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private byte frontParking02Part1;

    @Bin(order = 904, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private byte frontParking02Part2;

    @Bin(order = 905, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private byte frontParking03Part1;

    @Bin(order = 906, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private byte frontParking03Part2;

    @Bin(order = 1001, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private byte adaptiveCruiseControlRegulation01Part1;

    @Bin(order = 1002, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private byte adaptiveCruiseControlRegulation01Part2;

    @Bin(order = 1003, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private byte adaptiveCruiseControlRegulation02Part1;

    @Bin(order = 1004, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private byte adaptiveCruiseControlRegulation02Part2;

    @Bin(order = 1005, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private byte adaptiveCruiseControlRegulation03Part1;

    @Bin(order = 1006, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private byte adaptiveCruiseControlRegulation03Part2;

    @Bin(order = 1101, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem01;

    @Bin(order = 1102, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem02;

    @Bin(order = 1103, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedEmergencyBrakingSystem03;

    @Bin(order = 1201, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning01;

    @Bin(order = 1202, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning02;

    @Bin(order = 1203, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int laneDepartureWarning03;

    @Bin(order = 1301, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist01;

    @Bin(order = 1302, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist02;

    @Bin(order = 1303, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int respectOfInterVehicleTimeAssist03;

    @Bin(order = 1401, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP01;

    @Bin(order = 1402, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP02;

    @Bin(order = 1403, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfESP03;

    @Bin(order = 1501, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS01;

    @Bin(order = 1502, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS02;

    @Bin(order = 1503, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int triggeringOfABS03;

    @Bin(order = 1601, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService01;

    @Bin(order = 1602, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService02;

    @Bin(order = 1603, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int electricBrakeService03;

    @Bin(order = 1701, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit01;

    @Bin(order = 1702, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit02;

    @Bin(order = 1703, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int advancedSpeedRegulatorAndLimit03;

    @Bin(order = 1801, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist01;

    @Bin(order = 1802, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist02;

    @Bin(order = 1803, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int rightLaneKeepingAssist03;

    @Bin(order = 1901, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist01;

    @Bin(order = 1902, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist02;

    @Bin(order = 1903, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_5, bitOrder = JBBPBitOrder.MSB0)
    private int leftLaneKeepingAssist03;

    @Bin(order = 2001, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] advancedSpeedRegulator01Part1;

    @Bin(order = 2001, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private byte advancedSpeedRegulator01Part2;

    @Bin(order = 2002, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] advancedSpeedRegulator02Part1;

    @Bin(order = 2002, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private byte advancedSpeedRegulator02Part2;

    @Bin(order = 2003, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] advancedSpeedRegulator03Part1;

    @Bin(order = 2003, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    private byte advancedSpeedRegulator03Part2;

    @Bin(order = 2101, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring01;

    @Bin(order = 2102, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring02;

    @Bin(order = 2103, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int blindSpotMonitoring03;

    @Bin(order = 2201, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation01;

    @Bin(order = 2202, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation02;

    @Bin(order = 2203, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int speedLimitInformation03;
    //</editor-fold>

    //<editor-fold desc="VEHICLE_DATA">
    @Bin(order = 2301, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rearFogLampsStatement01;

    @Bin(order = 2302, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int rearFogLampsStatement02;

    @Bin(order = 2303, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int frontFogLampsStatement01;

    @Bin(order = 2304, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int frontFogLampsStatement02;

    @Bin(order = 2401, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int unbuckledBeltWarning;

    @Bin(order = 2501, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int outsideTemperature;

    @Bin(order = 2511, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int recommendedGearIndicator01;

    @Bin(order = 2512, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int recommendedGearIndicator02;

    @Bin(order = 2513, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int recommendedGearIndicator03;

    @Bin(order = 2514, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int recommendedGearIndicator04;

    @Bin(order = 2515, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int recommendedGearIndicator05;

    @Bin(order = 2516, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int recommendedGearIndicator06;

    @Bin(order = 2521, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] fuelInstantConsumption01;

    @Bin(order = 2522, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] fuelInstantConsumption02;

    @Bin(order = 2523, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] fuelInstantConsumption03;

    @Bin(order = 2524, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] fuelInstantConsumption04;

    @Bin(order = 2525, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] fuelInstantConsumption05;

    @Bin(order = 2526, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] fuelInstantConsumption06;

    @Bin(order = 2531, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] fuelTotalConsumption;

    @Bin(order = 2532, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int ignition;

    @Bin(order = 2541, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int gearboxMode01;

    @Bin(order = 2542, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int gearboxMode02;

    @Bin(order = 2543, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int gearboxMode03;

    @Bin(order = 2544, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int gearboxMode04;

    @Bin(order = 2545, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int gearboxMode05;

    @Bin(order = 2546, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_4, bitOrder = JBBPBitOrder.MSB0)
    private int gearboxMode06;

    @Bin(order = 2551, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] engineSpeed01;

    @Bin(order = 2552, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] engineSpeed02;

    @Bin(order = 2553, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] engineSpeed03;

    @Bin(order = 2554, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] engineSpeed04;

    @Bin(order = 2555, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] engineSpeed05;

    @Bin(order = 2556, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] engineSpeed06;

    @Bin(order = 2601, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed01;

    @Bin(order = 2602, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed02;

    @Bin(order = 2603, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed03;

    @Bin(order = 2604, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed04;

    @Bin(order = 2605, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed05;

    @Bin(order = 2606, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed06;

    @Bin(order = 2607, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed07;

    @Bin(order = 2608, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed08;

    @Bin(order = 2609, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed09;

    @Bin(order = 2610, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed10;

    @Bin(order = 2611, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed11;

    @Bin(order = 2612, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed12;

    @Bin(order = 2613, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed13;

    @Bin(order = 2614, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed14;

    @Bin(order = 2615, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed15;

    @Bin(order = 2616, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed16;

    @Bin(order = 2617, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed17;

    @Bin(order = 2618, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed18;

    @Bin(order = 2619, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed19;

    @Bin(order = 2620, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed20;

    @Bin(order = 2621, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed21;

    @Bin(order = 2622, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed22;

    @Bin(order = 2623, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed23;

    @Bin(order = 2624, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed24;

    @Bin(order = 2625, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed25;

    @Bin(order = 2626, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed26;

    @Bin(order = 2627, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed27;

    @Bin(order = 2628, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed28;

    @Bin(order = 2629, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed29;

    @Bin(order = 2630, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed30;

    @Bin(order = 2631, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed31;

    @Bin(order = 2632, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed32;

    @Bin(order = 2633, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed33;

    @Bin(order = 2634, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed34;

    @Bin(order = 2635, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed35;

    @Bin(order = 2636, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed36;

    @Bin(order = 2637, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed37;

    @Bin(order = 2638, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed38;

    @Bin(order = 2639, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed39;

    @Bin(order = 2640, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed40;

    @Bin(order = 2641, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed41;

    @Bin(order = 2642, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed42;

    @Bin(order = 2643, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed43;

    @Bin(order = 2644, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed44;

    @Bin(order = 2645, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed45;

    @Bin(order = 2646, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed46;

    @Bin(order = 2647, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed47;

    @Bin(order = 2648, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed48;

    @Bin(order = 2649, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed49;

    @Bin(order = 2650, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed50;

    @Bin(order = 2651, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed51;

    @Bin(order = 2652, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed52;

    @Bin(order = 2653, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed53;

    @Bin(order = 2654, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed54;

    @Bin(order = 2655, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed55;

    @Bin(order = 2656, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed56;

    @Bin(order = 2657, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed57;

    @Bin(order = 2658, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed58;

    @Bin(order = 2659, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed59;

    @Bin(order = 2660, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitudinalSpeed60;

    @Bin(order = 2701, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity01;

    @Bin(order = 2702, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int luminosity02;

    @Bin(order = 2711, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleMode01;

    @Bin(order = 2712, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleMode02;

    @Bin(order = 2713, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleMode03;

    @Bin(order = 2714, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleMode04;

    @Bin(order = 2715, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleMode05;

    @Bin(order = 2716, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int vehicleMode06;

    @Bin(order = 2801, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] lifetimeMileage;

    @Bin(order = 2803, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int fuelLevel;

    @Bin(order = 2804, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int oilTemperature;

    @Bin(order = 2805, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_3, bitOrder = JBBPBitOrder.MSB0)
    private int gmpStatus;

    @Bin(order = 2901, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int privacyMode01V2;

    @Bin(order = 2902, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    private int privacyMode02V2;

    public Instant getDateOfCollection() {
        return DateUtils.timeUnitsToInstant(STARTING_YEAR + yearOfCollection,
                monthOfCollection,
                dayOfCollection,
                hourOfCollection,
                minuteOfCollection,
                secondOfCollection);

        // return dateOfCollection;
    }

    public Instant getDateOfTransmission() {
        return DateUtils.timeUnitsToInstant(STARTING_YEAR + yearOfTransmission,
                monthOfTransmission,
                dayOfTransmission,
                hourOfTransmission,
                minuteOfTransmission,
                secondOfTransmission);
        //return dateOfTransmission;
    }

    public int getIdTrip() {
        return ByteUtils.asInt(idTrip);
    }

    public int getIdFrame() {
        return ByteUtils.asInt(idFrame);
    }

    public int getPrivacyMode01() {
        return privacyMode01;
    }

    public int getPrivacyMode02() {
        return privacyMode02;
    }

    public int getRebootCounter() {
        return rebootCounter;
    }

    public String getVin() {
        return ByteUtils.asString(vin);
    }

    public List<Integer> getAltitudes() {
        return CollectionUtils.addAll(
                ByteUtils.asInt(altitude01),
                ByteUtils.asInt(altitude02),
                ByteUtils.asInt(altitude03),
                ByteUtils.asInt(altitude04),
                ByteUtils.asInt(altitude05),
                ByteUtils.asInt(altitude06),
                ByteUtils.asInt(altitude07),
                ByteUtils.asInt(altitude08),
                ByteUtils.asInt(altitude09),
                ByteUtils.asInt(altitude10));
    }

    public List<Integer> getHeadings() {
        return CollectionUtils.addAll(
                ByteUtils.asInt(heading01),
                ByteUtils.asInt(heading02),
                ByteUtils.asInt(heading03),
                ByteUtils.asInt(heading04),
                ByteUtils.asInt(heading05),
                ByteUtils.asInt(heading06),
                ByteUtils.asInt(heading07),
                ByteUtils.asInt(heading08),
                ByteUtils.asInt(heading09),
                ByteUtils.asInt(heading10),
                ByteUtils.asInt(heading11),
                ByteUtils.asInt(heading12),
                ByteUtils.asInt(heading13),
                ByteUtils.asInt(heading14),
                ByteUtils.asInt(heading15),
                ByteUtils.asInt(heading16),
                ByteUtils.asInt(heading17),
                ByteUtils.asInt(heading18),
                ByteUtils.asInt(heading19),
                ByteUtils.asInt(heading20),
                ByteUtils.asInt(heading21),
                ByteUtils.asInt(heading22),
                ByteUtils.asInt(heading23),
                ByteUtils.asInt(heading24),
                ByteUtils.asInt(heading25),
                ByteUtils.asInt(heading26),
                ByteUtils.asInt(heading27),
                ByteUtils.asInt(heading28),
                ByteUtils.asInt(heading29),
                ByteUtils.asInt(heading30),
                ByteUtils.asInt(heading31),
                ByteUtils.asInt(heading32),
                ByteUtils.asInt(heading33),
                ByteUtils.asInt(heading34),
                ByteUtils.asInt(heading35),
                ByteUtils.asInt(heading36),
                ByteUtils.asInt(heading37),
                ByteUtils.asInt(heading38),
                ByteUtils.asInt(heading39),
                ByteUtils.asInt(heading40),
                ByteUtils.asInt(heading41),
                ByteUtils.asInt(heading42),
                ByteUtils.asInt(heading43),
                ByteUtils.asInt(heading44),
                ByteUtils.asInt(heading45),
                ByteUtils.asInt(heading46),
                ByteUtils.asInt(heading47),
                ByteUtils.asInt(heading48),
                ByteUtils.asInt(heading49),
                ByteUtils.asInt(heading50),
                ByteUtils.asInt(heading51),
                ByteUtils.asInt(heading52),
                ByteUtils.asInt(heading53),
                ByteUtils.asInt(heading54),
                ByteUtils.asInt(heading55),
                ByteUtils.asInt(heading56),
                ByteUtils.asInt(heading57),
                ByteUtils.asInt(heading58),
                ByteUtils.asInt(heading59),
                ByteUtils.asInt(heading60));
    }

    public List<Integer> getLongitudes() {
        return CollectionUtils.addAll(
                ByteUtils.asInt(longitude01),
                ByteUtils.asInt(longitude02),
                ByteUtils.asInt(longitude03),
                ByteUtils.asInt(longitude04),
                ByteUtils.asInt(longitude05),
                ByteUtils.asInt(longitude06),
                ByteUtils.asInt(longitude07),
                ByteUtils.asInt(longitude08),
                ByteUtils.asInt(longitude09),
                ByteUtils.asInt(longitude10));
    }

    public List<Integer> getLatitudes() {
        return CollectionUtils.addAll(
                ByteUtils.asInt(latitude01),
                ByteUtils.asInt(latitude02),
                ByteUtils.asInt(latitude03),
                ByteUtils.asInt(latitude04),
                ByteUtils.asInt(latitude05),
                ByteUtils.asInt(latitude06),
                ByteUtils.asInt(latitude07),
                ByteUtils.asInt(latitude08),
                ByteUtils.asInt(latitude09),
                ByteUtils.asInt(latitude10));
    }

    public List<Integer> getGpsSignalQualities() {
        return CollectionUtils.addAll(
                gpsSignalQuality01,
                gpsSignalQuality02,
                gpsSignalQuality03,
                gpsSignalQuality04,
                gpsSignalQuality05,
                gpsSignalQuality06,
                gpsSignalQuality07,
                gpsSignalQuality08,
                gpsSignalQuality09,
                gpsSignalQuality10);
    }

    public List<Integer> getVehicleLocationTypes() {
        return CollectionUtils.addAll(
                vehicleLocationType01,
                vehicleLocationType02,
                vehicleLocationType03,
                vehicleLocationType04,
                vehicleLocationType05,
                vehicleLocationType06,
                vehicleLocationType07,
                vehicleLocationType08,
                vehicleLocationType09,
                vehicleLocationType10);
    }

    public int getRearHighSpeedCrashInfo() {
        return rearHighSpeedCrashInfo;
    }

    public int getRearMediumSpeedCrashInfo() {
        return rearMediumSpeedCrashInfo;
    }

    public int getRearSlowSpeedCrashInfo() {
        return rearSlowSpeedCrashInfo;
    }

    public int getRearReparabilitySpeedCrashInfo() {
        return rearReparabilitySpeedCrashInfo;
    }

    public List<Integer> getPedestrianCrashInfos() {
        return CollectionUtils.addAll(
                pedestrianCrashInfo01,
                pedestrianCrashInfo02,
                pedestrianCrashInfo03);
    }

    public int getHighSpeedFrontCrashInfo() {
        return highSpeedFrontCrashInfo;
    }

    public int getMediumSpeedN1FrontCrashInfo() {
        return mediumSpeedN1FrontCrashInfo;
    }

    public int getMediumSpeedN2FrontCrashInfo() {
        return mediumSpeedN2FrontCrashInfo;
    }

    public int getLowSpeedFrontCrashInfo() {
        return lowSpeedFrontCrashInfo;
    }

    public int getFrontReparabilityCrashInfo() {
        return frontReparabilityCrashInfo;
    }

    public int getRearHighSpeedLateralCrashInfo() {
        return rearHighSpeedLateralCrashInfo;
    }

    public int getRearMediumSpeedLateralCrashInfo() {
        return rearMediumSpeedLateralCrashInfo;
    }

    public int getRearLowSpeedLateralCrashInfo() {
        return rearLowSpeedLateralCrashInfo;
    }

    public int getRearRepairabilityCrashInfo() {
        return rearRepairabilityCrashInfo;
    }

    public int getTippedOver() {
        return tippedOver;
    }

    public List<Integer> getRearParkings() {
        return CollectionUtils.addAll(
                ByteUtils.nineBitsAsInt(rearParking01Part1, rearParking01Part2),
                ByteUtils.nineBitsAsInt(rearParking02Part1, rearParking02Part2),
                ByteUtils.nineBitsAsInt(rearParking03Part1, rearParking03Part2));
    }

    public int getFrontParking01() {
        return ByteUtils.nineBitsAsInt(frontParking01Part1, frontParking01Part2);
    }

    public int getFrontParking02() {
        return ByteUtils.nineBitsAsInt(frontParking02Part1, frontParking02Part2);
    }

    public int getFrontParking03() {
        return ByteUtils.nineBitsAsInt(frontParking03Part1, frontParking03Part2);
    }

    public List<Integer> getFrontParkings() {
        return CollectionUtils.addAll(
                ByteUtils.nineBitsAsInt(frontParking01Part1, frontParking01Part2),
                ByteUtils.nineBitsAsInt(frontParking02Part1, frontParking02Part2),
                ByteUtils.nineBitsAsInt(frontParking03Part1, frontParking03Part2));
    }

    public List<Integer> getAdaptiveCruiseControlRegulations() {
        return CollectionUtils.addAll(
                ByteUtils.nineBitsAsInt(adaptiveCruiseControlRegulation01Part1, adaptiveCruiseControlRegulation01Part2),
                ByteUtils.nineBitsAsInt(adaptiveCruiseControlRegulation02Part1, adaptiveCruiseControlRegulation02Part2),
                ByteUtils.nineBitsAsInt(adaptiveCruiseControlRegulation03Part1, adaptiveCruiseControlRegulation03Part2));
    }

    public List<Integer> getAdvancedEmergencyBrakingSystems() {
        return CollectionUtils.addAll(
                advancedEmergencyBrakingSystem01,
                advancedEmergencyBrakingSystem02,
                advancedEmergencyBrakingSystem03);
    }

    public List<Integer> getLaneDepartureWarnings() {
        return CollectionUtils.addAll(
                laneDepartureWarning01,
                laneDepartureWarning02,
                laneDepartureWarning03);
    }

    public List<Integer> getRespectOfInterVehicleTimeAssists() {
        return CollectionUtils.addAll(
                respectOfInterVehicleTimeAssist01,
                respectOfInterVehicleTimeAssist02,
                respectOfInterVehicleTimeAssist03);
    }

    public List<Integer> getTriggeringOfESPs() {
        return CollectionUtils.addAll(
                triggeringOfESP01,
                triggeringOfESP02,
                triggeringOfESP02);
    }

    public List<Integer> getTriggeringOfABSs() {
        return CollectionUtils.addAll(
                triggeringOfABS01,
                triggeringOfABS02,
                triggeringOfABS03);
    }

    public List<Integer> getElectricBrakeServices() {
        return CollectionUtils.addAll(
                electricBrakeService01,
                electricBrakeService02,
                electricBrakeService03);
    }

    public List<Integer> getAdvancedSpeedRegulatorAndLimits() {
        return CollectionUtils.addAll(
                advancedSpeedRegulatorAndLimit01,
                advancedSpeedRegulatorAndLimit02,
                advancedSpeedRegulatorAndLimit03);
    }

    public List<Integer> getRightLaneKeepingAssists() {
        return CollectionUtils.addAll(
                rightLaneKeepingAssist01,
                rightLaneKeepingAssist02,
                rightLaneKeepingAssist03);
    }

    public List<Integer> getLeftLaneKeepingAssists() {
        return CollectionUtils.addAll(
                leftLaneKeepingAssist01,
                leftLaneKeepingAssist02,
                leftLaneKeepingAssist03);
    }

    public List<Integer> getAdvancedSpeedRegulators() {
        return CollectionUtils.addAll(
                ByteUtils.seventeenBitsAsInt(advancedSpeedRegulator01Part1, advancedSpeedRegulator01Part2),
                ByteUtils.seventeenBitsAsInt(advancedSpeedRegulator02Part1, advancedSpeedRegulator02Part2),
                ByteUtils.seventeenBitsAsInt(advancedSpeedRegulator03Part1, advancedSpeedRegulator03Part2));
    }

    public List<Integer> getBlindSpotMonitorings() {
        return CollectionUtils.addAll(
                blindSpotMonitoring01,
                blindSpotMonitoring02,
                blindSpotMonitoring03);
    }

    public List<Integer> getSpeedLimitInformations() {
        return CollectionUtils.addAll(
                speedLimitInformation01,
                speedLimitInformation02,
                speedLimitInformation03);
    }

    public List<Integer> getRearFogLampsStatements() {
        return CollectionUtils.addAll(
                rearFogLampsStatement01,
                rearFogLampsStatement02);
    }

    public List<Integer> getFrontFogLampsStatements() {
        return CollectionUtils.addAll(
                frontFogLampsStatement01,
                frontFogLampsStatement02);
    }

    public int getUnbuckledBeltWarning() {
        return unbuckledBeltWarning;
    }

    public BigDecimal getOutsideTemperature() {
        return BigDecimal.valueOf(outsideTemperature * OUTSIDE_TEMPERATURE_FACTOR + TEMPERATURE_OFFSET).setScale(2, RoundingMode.FLOOR);
    }

    public List<Integer> getRecommendedGearIndicators() {
        return CollectionUtils.addAll(
                recommendedGearIndicator01,
                recommendedGearIndicator02,
                recommendedGearIndicator03,
                recommendedGearIndicator04,
                recommendedGearIndicator05,
                recommendedGearIndicator06);
    }

    public List<BigDecimal> getFuelInstantConsumptions() {
        return CollectionUtils.addAll(
                Formula.toFuelInstantConsumption(fuelInstantConsumption01),
                Formula.toFuelInstantConsumption(fuelInstantConsumption02),
                Formula.toFuelInstantConsumption(fuelInstantConsumption03),
                Formula.toFuelInstantConsumption(fuelInstantConsumption04),
                Formula.toFuelInstantConsumption(fuelInstantConsumption05),
                Formula.toFuelInstantConsumption(fuelInstantConsumption06));
    }

    public BigDecimal getFuelTotalConsumption() {
        return BigDecimal.valueOf(ByteUtils.asInt(fuelTotalConsumption) * FUEL_TOTAL_CONSUMPTION_FACTOR).setScale(3, RoundingMode.FLOOR);
    }

    public int getIgnition() {
        return ignition;
    }

    public List<Integer> getGearboxModes() {
        return CollectionUtils.addAll(
                gearboxMode01,
                gearboxMode02,
                gearboxMode03,
                gearboxMode04,
                gearboxMode05,
                gearboxMode06);
    }

    public List<BigDecimal> getEngineSpeeds() {
        return CollectionUtils.addAll(
                Formula.toEngineSpeed(engineSpeed01),
                Formula.toEngineSpeed(engineSpeed02),
                Formula.toEngineSpeed(engineSpeed03),
                Formula.toEngineSpeed(engineSpeed04),
                Formula.toEngineSpeed(engineSpeed05),
                Formula.toEngineSpeed(engineSpeed06));
    }

    public List<BigDecimal> getLongitudinalSpeeds() {
        return CollectionUtils.addAll(
                Formula.toLongitudinalSpeed(longitudinalSpeed01),
                Formula.toLongitudinalSpeed(longitudinalSpeed02),
                Formula.toLongitudinalSpeed(longitudinalSpeed03),
                Formula.toLongitudinalSpeed(longitudinalSpeed04),
                Formula.toLongitudinalSpeed(longitudinalSpeed05),
                Formula.toLongitudinalSpeed(longitudinalSpeed06),
                Formula.toLongitudinalSpeed(longitudinalSpeed07),
                Formula.toLongitudinalSpeed(longitudinalSpeed08),
                Formula.toLongitudinalSpeed(longitudinalSpeed09),
                Formula.toLongitudinalSpeed(longitudinalSpeed10),
                Formula.toLongitudinalSpeed(longitudinalSpeed11),
                Formula.toLongitudinalSpeed(longitudinalSpeed12),
                Formula.toLongitudinalSpeed(longitudinalSpeed13),
                Formula.toLongitudinalSpeed(longitudinalSpeed14),
                Formula.toLongitudinalSpeed(longitudinalSpeed15),
                Formula.toLongitudinalSpeed(longitudinalSpeed16),
                Formula.toLongitudinalSpeed(longitudinalSpeed17),
                Formula.toLongitudinalSpeed(longitudinalSpeed18),
                Formula.toLongitudinalSpeed(longitudinalSpeed19),
                Formula.toLongitudinalSpeed(longitudinalSpeed20),
                Formula.toLongitudinalSpeed(longitudinalSpeed21),
                Formula.toLongitudinalSpeed(longitudinalSpeed22),
                Formula.toLongitudinalSpeed(longitudinalSpeed23),
                Formula.toLongitudinalSpeed(longitudinalSpeed24),
                Formula.toLongitudinalSpeed(longitudinalSpeed25),
                Formula.toLongitudinalSpeed(longitudinalSpeed26),
                Formula.toLongitudinalSpeed(longitudinalSpeed27),
                Formula.toLongitudinalSpeed(longitudinalSpeed28),
                Formula.toLongitudinalSpeed(longitudinalSpeed29),
                Formula.toLongitudinalSpeed(longitudinalSpeed30),
                Formula.toLongitudinalSpeed(longitudinalSpeed31),
                Formula.toLongitudinalSpeed(longitudinalSpeed32),
                Formula.toLongitudinalSpeed(longitudinalSpeed33),
                Formula.toLongitudinalSpeed(longitudinalSpeed34),
                Formula.toLongitudinalSpeed(longitudinalSpeed35),
                Formula.toLongitudinalSpeed(longitudinalSpeed36),
                Formula.toLongitudinalSpeed(longitudinalSpeed37),
                Formula.toLongitudinalSpeed(longitudinalSpeed38),
                Formula.toLongitudinalSpeed(longitudinalSpeed39),
                Formula.toLongitudinalSpeed(longitudinalSpeed40),
                Formula.toLongitudinalSpeed(longitudinalSpeed41),
                Formula.toLongitudinalSpeed(longitudinalSpeed42),
                Formula.toLongitudinalSpeed(longitudinalSpeed43),
                Formula.toLongitudinalSpeed(longitudinalSpeed44),
                Formula.toLongitudinalSpeed(longitudinalSpeed45),
                Formula.toLongitudinalSpeed(longitudinalSpeed46),
                Formula.toLongitudinalSpeed(longitudinalSpeed47),
                Formula.toLongitudinalSpeed(longitudinalSpeed48),
                Formula.toLongitudinalSpeed(longitudinalSpeed49),
                Formula.toLongitudinalSpeed(longitudinalSpeed50),
                Formula.toLongitudinalSpeed(longitudinalSpeed51),
                Formula.toLongitudinalSpeed(longitudinalSpeed52),
                Formula.toLongitudinalSpeed(longitudinalSpeed53),
                Formula.toLongitudinalSpeed(longitudinalSpeed54),
                Formula.toLongitudinalSpeed(longitudinalSpeed55),
                Formula.toLongitudinalSpeed(longitudinalSpeed56),
                Formula.toLongitudinalSpeed(longitudinalSpeed57),
                Formula.toLongitudinalSpeed(longitudinalSpeed58),
                Formula.toLongitudinalSpeed(longitudinalSpeed59),
                Formula.toLongitudinalSpeed(longitudinalSpeed60));
    }

    public List<Integer> getLuminosities() {
        return CollectionUtils.addAll(
                luminosity01,
                luminosity02);
    }

    public List<Integer> getVehicleModes() {
        return CollectionUtils.addAll(
                vehicleMode01,
                vehicleMode02,
                vehicleMode03,
                vehicleMode04,
                vehicleMode05,
                vehicleMode06);
    }

    /**
     * @deprecated hybridModes replaced with vehicleModes
     */
    @Deprecated
    public List<Integer> getHybridModes() {
        return getVehicleModes();
    }

    public BigDecimal getLifetimeMileage() {
        return BigDecimal.valueOf(ByteUtils.asInt(lifetimeMileage) * LIFETIME_MILEAGE_FACTOR).setScale(2, RoundingMode.FLOOR);
    }

    public int getFuelLevel() {
        return fuelLevel;
    }

    public int getOilTemperature() {
        return oilTemperature + TEMPERATURE_OFFSET;
    }

    public int getGmpStatus() {
        return gmpStatus;
    }

    public int getPrivacyMode01V2() {
        return privacyMode01V2;
    }

    public int getPrivacyMode02V2() {
        return privacyMode02V2;
    }
}
