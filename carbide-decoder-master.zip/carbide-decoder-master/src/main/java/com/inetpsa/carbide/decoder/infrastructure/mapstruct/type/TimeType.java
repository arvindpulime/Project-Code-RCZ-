package com.inetpsa.carbide.decoder.infrastructure.mapstruct.type;

import com.inetpsa.carbide.decoder.infrastructure.mapstruct.qualifier.IntToDuration;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.qualifier.IntToInstant;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.qualifier.IntToLocalTime;

import java.time.Duration;
import java.time.Instant;
import java.time.LocalTime;

@TimeConverter
public class TimeType {

    private static final int INVALID_MIDNIGHT = 1440;
    private static final int INVALID_TIME_OF_DAY = 0x7FF;
    private static final long SEC_PER_MIN = 60L;

    @IntToDuration
    public Duration toDuration(int millisElapsed) {
        return Duration.ofMillis(millisElapsed);
    }

    @IntToInstant
    public Instant toInstant(int epoch) {
        return Instant.ofEpochSecond(epoch);
    }

    @IntToLocalTime
    public static LocalTime toTimeOfDay(int minutesOfDay) {
        if (minutesOfDay != INVALID_MIDNIGHT && minutesOfDay != INVALID_TIME_OF_DAY) {
            return LocalTime.ofSecondOfDay(minutesOfDay * SEC_PER_MIN);
        } else if (minutesOfDay == INVALID_TIME_OF_DAY) {
            return LocalTime.MAX;
        }
        return LocalTime.MIDNIGHT;
    }
}