package com.inetpsa.carbide.decoder.infrastructure.util;

import com.inetpsa.carbide.decoder.application.util.Schema;

import java.util.EnumSet;

public final class Constant {

    private Constant() {
    }

    public static final EnumSet<Schema> V1 = EnumSet.of(Schema.V1);
    public static final EnumSet<Schema> V1_V2 = EnumSet.of(Schema.V1, Schema.V2);
    public static final EnumSet<Schema> V2 = EnumSet.of(Schema.V2);

    public static final int SIGN_PLUS = 0;
    public static final int STARTING_YEAR = 2000;
    public static final int RELAY_DMG_COUNTER = 200;
}
