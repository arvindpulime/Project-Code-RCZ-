package com.inetpsa.carbide.decoder.infrastructure.util;

public final class Factor {

    private Factor() {
    }

    public static final double LONGITUDINAL_SPEED_FACTOR = 0.01;

    public static final double FUEL_INSTANT_CONSUMPTION_FACTOR = 0.1;

    public static final double FUEL_TOTAL_CONSUMPTION_FACTOR = 0.008;

    public static final double OUTSIDE_TEMPERATURE_FACTOR = 0.5;

    public static final double LIFETIME_MILEAGE_FACTOR = 0.1;

    public static final double ENGINE_SPEED_FACTOR = 0.125;

    public static final int MILEAGE_BEFORE_MAINTENANCE_FACTOR = 20;

    public static final int SEC_TO_MS_FACTOR = 1000;

    public static final double TIME_REFERENCE_FACTOR = 0.1;

    public static final int TORQUE_FACTOR = 2;

    public static final double DRIVERS_WILL_FACTOR = 0.5;

    public static final double ODOMETER_SPEED_FACTOR = 0.01;

    public static final int ENGINE_OIL_LEVEL_FACTOR = 3;

    public static final double YAW_SPEED_FACTOR = 0.1;

    public static final double LATERAL_ACCELERATION_FACTOR = 0.05;

    public static final double LONGITUDINAL_ACCELERATION_FACTOR = 0.08;

    public static final double STEERING_WHEEL_ANGLE_FACTOR = 0.1;

    public static final double BATTERY_VOLTAGE_FACTOR = 0.01;

    public static final double MASTER_CYLINDER_FACTOR = 0.1;

    public static final int ZEV_AUTONOMY_FACTOR = 2;

    public static final int REMAINING_CHARGE_TIME_FACTOR = 5;

    public static final int ZEV_CHARGE_GAIN_FACTOR = 2;

    public static final double AVG_FUEL_CONSUMPTION_FACTOR = 0.1;

    public static final double ZEV_AVG_POWER_CONSUMPTION_FACTOR = 0.1;

    public static final int BEV_ENGINE_SPEED_FACTOR = 10;

    public static final int RESIDUAL_ENERGY_FACTOR = 32;

    public static final int TOTAL_ENERGY_FACTOR = 32;

    public static final double AUXILIARY_BATTERY_SOC_FACTOR = 0.5;

    public static final double HV_BATTERY_INTENSITY_FACTOR = 0.4;

    public static final double HV_BATTERY_VOLTAGE_FACTOR = 0.25;

    public static final double HV_BATTERY_CELL_VOLTAGE_FACTOR = 0.001;

    public static final double HV_BATTERY_SOC_FACTOR = 0.1;

    public static final int BATTERY_TOTAL_ENERGY_FACTOR = 32;

    public static final int BATTERY_REMAINING_ENERGY_FACTOR = 32;

    public static final double BATTERY_REMAINING_CAPACITY_FACTOR = 0.001;

    public static final double OPERATING_TIME_OVER_TEMP_FACTOR = 0.1;

    public static final double OPERATING_TIME_OVER_CHARGE_FACTOR = 0.1;

    public static final double OPERATING_TIME_OVER_VOLTAGE_FACTOR = 0.1;

    public static final double OPERATING_TIME_WITH_HIGH_TEMP_FACTOR = 0.1;

    public static final int ELECTRIC_CHARGE_EXCHANGE_FACTOR = 125;

    public static final int ENERGY_EXCHANGE_FACTOR = 35;
}
