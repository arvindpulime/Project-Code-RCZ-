package com.inetpsa.carbide.decoder.infrastructure.mapstruct.type;

import com.inetpsa.carbide.decoder.infrastructure.mapstruct.qualifier.ToSignalValidityList;
import com.inetpsa.carbide.domain.interfaces.data.global.LocalizationSignalValidity;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@SignalValidityConverter
public class SignalValidityType {

    @ToSignalValidityList
    public List<LocalizationSignalValidity> toSignalValidityList(List<Integer> signalValidityList) {
        return signalValidityList.stream().map(LocalizationSignalValidity::fromOrdinal)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
    }
}
