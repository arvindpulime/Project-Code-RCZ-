package com.inetpsa.carbide.decoder.infrastructure.mapstruct.type;

import com.inetpsa.carbide.decoder.infrastructure.mapstruct.qualifier.IntToBoolean;

@BooleanConverter
public class BooleanType {

    @IntToBoolean
    public Boolean toBoolean(int someInt) {
        return someInt == 1;
    }
}
