package com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.global;

import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.global.JBBPMaintenanceStatus;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.DataMapper;
import com.inetpsa.carbide.domain.interfaces.data.global.MaintenanceStatus;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface MaintenanceStatusMapper extends DataMapper<MaintenanceStatus, JBBPMaintenanceStatus> {

    MaintenanceStatusMapper INSTANCE = Mappers.getMapper(MaintenanceStatusMapper.class);
}
