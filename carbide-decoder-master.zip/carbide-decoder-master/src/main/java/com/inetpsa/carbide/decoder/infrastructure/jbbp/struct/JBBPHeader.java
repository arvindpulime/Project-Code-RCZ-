package com.inetpsa.carbide.decoder.infrastructure.jbbp.struct;

import com.igormaznitsa.jbbp.io.JBBPBitNumber;
import com.igormaznitsa.jbbp.io.JBBPBitOrder;
import com.igormaznitsa.jbbp.mapper.Bin;
import com.igormaznitsa.jbbp.mapper.BinType;
import com.inetpsa.carbide.decoder.infrastructure.util.ByteUtils;
import lombok.Setter;

@Setter
public  class JBBPHeader implements JBBPData {

    @Bin(order = 1, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    protected int code;

    @Bin(order = 2, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    protected int protocolVersion;

    @Bin(order = 3, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    protected byte[] vin;

    @Bin(order = 4, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    protected byte[] sessionId;

    @Bin(order = 5, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    protected byte[] messageId;

    @Bin(order = 6, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    protected int serviceType;

    @Bin(order = 7, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    protected int messageType;

    @Bin(order = 8, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    protected byte[] dateOfCollection;

    @Bin(order = 9, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    protected int messageVersion;

    @Bin(order = 10, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    protected byte[] messageLength;

    @Bin(order = 11, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    protected byte[] timeSinceSessionStart;

    @Bin(order = 12, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    protected byte[] gnssTimestamp;

    @Bin(order = 13, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    protected int gnssTimefix;

    @Bin(order = 14, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_1, bitOrder = JBBPBitOrder.MSB0)
    protected int timeSync;

    @Bin(order = 15, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    protected int privacyStatus;

    @Bin(order = 16, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    protected int requestedPrivacyStatus;

    @Bin(order = 17, type = BinType.BIT, bitNumber = JBBPBitNumber.BITS_2, bitOrder = JBBPBitOrder.MSB0)
    protected int applicablePrivacyStatus;

    public int getCode() {
        return code;
    }

    public int getProtocolVersion() {
        return protocolVersion;
    }

    public String getVin() {
        return ByteUtils.asString(vin);
    }

    public int getSessionId() {
        return ByteUtils.asInt(sessionId);
    }

    public int getMessageId() {
        return ByteUtils.asInt(messageId);
    }

    public int getServiceType() {
        return serviceType;
    }

    public int getMessageType() {
        return messageType;
    }

    public int getDateOfCollection() {
        return ByteUtils.asInt(dateOfCollection);
    }

    public int getMessageVersion() {
        return messageVersion;
    }

    public int getMessageLength() {
        return ByteUtils.asInt(messageLength);
    }

    public int getTimeSinceSessionStart() {
        return ByteUtils.asInt(timeSinceSessionStart);
    }

    public int getGnssTimestamp() {
        return ByteUtils.asInt(gnssTimestamp);
    }

    public int getGnssTimefix() {
        return gnssTimefix;
    }

    public int getTimeSync() {
        return timeSync;
    }

    public int getPrivacyStatus() {
        return privacyStatus;
    }

    public int getRequestedPrivacyStatus() {
        return requestedPrivacyStatus;
    }

    public int getApplicablePrivacyStatus() {
        return applicablePrivacyStatus;
    }
}
