package com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.global;

import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.global.JBBPPrivacy;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.DataMapper;
import com.inetpsa.carbide.domain.interfaces.data.global.Privacy;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface PrivacyMapper extends DataMapper<Privacy, JBBPPrivacy> {

    PrivacyMapper INSTANCE = Mappers.getMapper(PrivacyMapper.class);
}
