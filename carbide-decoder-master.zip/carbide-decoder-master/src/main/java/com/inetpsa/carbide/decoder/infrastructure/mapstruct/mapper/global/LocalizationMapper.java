package com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.global;

import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.global.JBBPLocalization;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.DataMapper;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.qualifier.IntToDuration;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.qualifier.ToSignalValidityList;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.type.SignalValidityConverter;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.type.SignalValidityType;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.type.TimeConverter;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.type.TimeType;
import com.inetpsa.carbide.domain.interfaces.data.global.Localization;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(uses = {TimeType.class, SignalValidityType.class})
public interface LocalizationMapper extends DataMapper<Localization, JBBPLocalization> {

    LocalizationMapper INSTANCE = Mappers.getMapper(LocalizationMapper.class);

    @Override
    @Mapping(target = "gnssDate", qualifiedBy = {TimeConverter.class, IntToDuration.class})
    @Mapping(target = "validities", qualifiedBy = {SignalValidityConverter.class, ToSignalValidityList.class})
    Localization toDto(JBBPLocalization jbbpData);
}
