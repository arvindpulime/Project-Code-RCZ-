package com.inetpsa.carbide.decoder.infrastructure.util;

import com.google.common.io.BaseEncoding;

import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;

public final class ByteUtils {

    public static final int BITS_PER_BYTE = 8;

    private ByteUtils() {
    }

    public static byte[] fromString(String val) {
        return BaseEncoding.base16().decode(val);
    }

    /**
     * Convert native 32 bits value or unsigned value to an int.
     *
     * @param byteArray Representation of the binary data
     * @return An int
     */
    public static int asInt(byte[] byteArray) {
        if (byteArray != null) {
            return new BigInteger(1, byteArray).intValue();
        }
        return 0;
    }

    /**
     * Convert a signed 8 or 16 or 24 bits value to an int
     *
     * @param byteArray Representation of the binary data
     * @return An int
     */
    public static int asSignedInt(byte[] byteArray) {
        return asSignedInt(byteArray, byteArray.length * BITS_PER_BYTE);
    }

    /**
     * Convert a signed N bits value (< 32 bits) to an int
     *
     * @param byteArray  Representation of the binary data
     * @param bitsToKeep Numbers of bits representing the binary data
     * @return An int
     */
    public static int asSignedInt(byte[] byteArray, int bitsToKeep) {
        if (byteArray != null) {
            int nthPowMask = 1 << (bitsToKeep - 1); // mask to check whether the leftmost bit is set (among bitsToKeep)
            final int output = new BigInteger(byteArray).intValue();
            if ((output & nthPowMask) == nthPowMask) {
                return output | -(1 << bitsToKeep); // if leftmost bit is set, neg. number -> invert with mask for Int32
            }
            return output;
        }
        return 0;
    }

    /**
     * Retrieve an int value from a 9 bits representation.<br>
     * <i>e.g.</i> 00111000 0 will give 112
     *
     * @param part1 First 8 bits
     * @param part2 Last bit
     * @return The int value corresponding to the 9 bits
     */
    public static int nineBitsAsInt(byte part1, byte part2) {
        return (part1 & 0xFF) << 1 | (part2 & 0xFF);
    }

    /**
     * Retrieve an int value from a 17 bits representation.<br>
     * <i>e.g.</i> 00000001 00000000 0 will give 512
     *
     * @param part1 First 16 bits
     * @param part2 Last bit
     * @return The int value corresponding to the 17 bits
     */
    public static int seventeenBitsAsInt(byte[] part1, byte part2) {
        return (part1[0] & 0xFF) << 9 | (part1[1] & 0xFF) << 1 | (part2 & 0xFF);
    }

    /**
     * Converting 8 bytes array to Double
     *
     * @param byteArray - should contain * bytes
     * @return The Double value of 8 bytes given array
     */
    public static Double asDouble(byte[] byteArray) {
        if (byteArray != null) {
            return ByteBuffer.wrap(byteArray).getDouble();
        }
        return 0d;
    }

    /**
     * Converting 4 bytes array to Float
     *
     * @param byteArray - should contain 4 bytes
     * @return The float value of 4 byte given array
     */
    public static Float asFloat(byte[] byteArray) {
        if (byteArray != null) {
            return ByteBuffer.wrap(byteArray).getFloat();
        }
        return 0f;
    }

    /**
     * Convert a byte array to a String encoded in ASCII
     *
     * @param byteArray A byte array
     * @return The String value encoded in ASCII corresponding to the byte array
     */
    public static String asString(byte[] byteArray) {
        if (byteArray != null) {
            return new String(byteArray, StandardCharsets.US_ASCII);
        }
        return "";
    }

    /**
     * Extract least significant bits (LSB) from an int by keeping N less significant bits (LSB)
     *
     * @param value      The int value
     * @param bitsToKeep The number of LSB bits to keep
     * @return The new int value
     */
    public static int extractLSBFromInt(int value, int bitsToKeep) {
        return value & ((1 << bitsToKeep) - 1);
    }

    /**
     * Extract most significant bits (MSB) from an int by ditching N less significant bits (LSB)
     *
     * @param value       The int value
     * @param bitsToDitch The number of LSB bits to ditch
     * @return The new int value
     */
    public static int extractMSBFromInt(int value, int bitsToDitch) {
        return value >>> bitsToDitch;
    }

    /**
     * The method interface expects the caller to provide the byte array that stores the bit string, the position in the bit string where bit value needs to be retrieved.
     * The first statement calculates the array index, "posByte", of the source byte that holds the bit to be retrieved.
     * The second statement calculates the bit position, "posBit", in the source byte where the bit value needs to be retrieved.
     * The third statement fetches the source byte into a temporary variable, "valByte".
     * The fourth statement gets the bit value from "valByte" at the bit position of "posBit".
     *
     * @param data The byte array
     * @param pos  The index of the bit to check
     * @return true if the bit is set, false otherwise
     */
    public static boolean isSet(byte[] data, int pos) {
        int posByte = pos / BITS_PER_BYTE;
        int posBit = pos % BITS_PER_BYTE;
        byte valByte = data[posByte];
        return (valByte >> (BITS_PER_BYTE - (posBit + 1)) & 0x0001) == 1;
    }
}
