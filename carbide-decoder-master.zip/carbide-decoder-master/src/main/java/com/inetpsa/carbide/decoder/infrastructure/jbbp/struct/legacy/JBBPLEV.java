package com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.legacy;

import com.igormaznitsa.jbbp.io.JBBPBitOrder;
import com.igormaznitsa.jbbp.mapper.Bin;
import com.igormaznitsa.jbbp.mapper.BinType;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.JBBPData;
import com.inetpsa.carbide.decoder.infrastructure.util.ByteUtils;
import lombok.Setter;

import java.math.BigDecimal;
import java.math.RoundingMode;

import static com.inetpsa.carbide.decoder.infrastructure.util.Factor.*;
import static com.inetpsa.carbide.decoder.infrastructure.util.SignalSize.BEV_ENGINE_SPEED_SIZE;
import static com.inetpsa.carbide.decoder.infrastructure.util.SignalSize.PHEV_ENGINE_SPEED_SIZE;

@Setter
public class JBBPLEV implements JBBPData {

    @Bin(order = 101, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int code;

    @Bin(order = 102, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] phevEngineSpeed;

    @Bin(order = 103, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int hybridGmpStatus;

    @Bin(order = 104, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] bevEngineSpeed;

    @Bin(order = 105, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] residualEnergy;

    @Bin(order = 106, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] totalEnergy;

    @Bin(order = 107, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int batteryInternalResistanceHealth;

    @Bin(order = 108, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] batteryLoadLevel;

    @Bin(order = 109, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int batteryCapacityHealth;

    @Bin(order = 110, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] zevAutonomy;

    public int getCode() {
        return code;
    }

    public int getPhevEngineSpeed() {
        return ByteUtils.asSignedInt(phevEngineSpeed, PHEV_ENGINE_SPEED_SIZE);
    }

    public int getHybridGmpStatus() {
        return hybridGmpStatus;
    }

    public int getBevEngineSpeed() {
        return ByteUtils.asSignedInt(bevEngineSpeed, BEV_ENGINE_SPEED_SIZE) * BEV_ENGINE_SPEED_FACTOR;
    }

    public int getResidualEnergy() {
        return ByteUtils.asInt(residualEnergy) * RESIDUAL_ENERGY_FACTOR;
    }

    public int getTotalEnergy() {
        return ByteUtils.asInt(totalEnergy) * TOTAL_ENERGY_FACTOR;
    }

    public int getBatteryInternalResistanceHealth() {
        return batteryInternalResistanceHealth;
    }

    public BigDecimal getBatteryLoadLevel() {
        return BigDecimal.valueOf(ByteUtils.asInt(batteryLoadLevel) * HV_BATTERY_SOC_FACTOR).setScale(2, RoundingMode.FLOOR);
    }

    public int getBatteryCapacityHealth() {
        return batteryCapacityHealth;
    }

    public int getZevAutonomy() {
        return ByteUtils.asInt(zevAutonomy) * ZEV_AUTONOMY_FACTOR;
    }
}
