package com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.legacy;

import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.legacy.JBBPLEV;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.DataMapper;
import com.inetpsa.carbide.domain.interfaces.data.legacy.LEV;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface LEVMapper extends DataMapper<LEV, JBBPLEV> {

    LEVMapper INSTANCE = Mappers.getMapper(LEVMapper.class);
}
