package com.inetpsa.carbide.decoder.infrastructure.util;

public final class SignalSize {

    private SignalSize() {
    }

    public static final int HV_BATTERY_INTENSITY_SIZE = 11;
    public static final int PHEV_ENGINE_SPEED_SIZE = 14;
    public static final int BEV_ENGINE_SPEED_SIZE = 12;
}
