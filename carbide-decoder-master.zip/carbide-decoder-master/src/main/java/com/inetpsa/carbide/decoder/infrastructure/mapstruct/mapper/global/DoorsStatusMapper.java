package com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.global;

import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.global.JBBPDoorsStatus;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.DataMapper;
import com.inetpsa.carbide.domain.interfaces.data.global.DoorsStatus;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper
public interface DoorsStatusMapper extends DataMapper<DoorsStatus, JBBPDoorsStatus> {

    DoorsStatusMapper INSTANCE = Mappers.getMapper(DoorsStatusMapper.class);
}
