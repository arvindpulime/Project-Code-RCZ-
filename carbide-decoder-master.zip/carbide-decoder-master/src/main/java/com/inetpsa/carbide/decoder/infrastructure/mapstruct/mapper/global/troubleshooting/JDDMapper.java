package com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.global.troubleshooting;

import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.global.troubleshooting.JBBPJDD;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.mapper.DataMapper;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.qualifier.IntToDuration;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.type.TimeConverter;
import com.inetpsa.carbide.decoder.infrastructure.mapstruct.type.TimeType;
import com.inetpsa.carbide.domain.interfaces.data.global.troubleshooting.JDD;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(uses = {TimeType.class})
public interface JDDMapper extends DataMapper<JDD, JBBPJDD> {

    JDDMapper INSTANCE = Mappers.getMapper(JDDMapper.class);

    @Override
    @Mapping(target = "timeReference", qualifiedBy = {TimeConverter.class, IntToDuration.class})
    JDD toDto(JBBPJDD jbbpData);
}
