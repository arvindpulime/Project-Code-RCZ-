package com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.global;

import com.igormaznitsa.jbbp.io.JBBPBitOrder;
import com.igormaznitsa.jbbp.mapper.Bin;
import com.igormaznitsa.jbbp.mapper.BinType;
import com.inetpsa.carbide.decoder.infrastructure.jbbp.struct.JBBPData;
import com.inetpsa.carbide.decoder.infrastructure.util.ByteUtils;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

import static com.inetpsa.carbide.decoder.infrastructure.util.ByteUtils.BITS_PER_BYTE;

@Setter
public class JBBPLocalization implements JBBPData {

    @Bin(order = 101, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int code;

    @Bin(order = 102, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] validities;

    @Bin(order = 103, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] positionalDilution;

    @Bin(order = 104, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] horizontalDilution;

    @Bin(order = 105, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] verticalDilution;

    @Bin(order = 106, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] usedSatellite;

    @Bin(order = 107, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] trackedSatellite;

    @Bin(order = 108, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] visibleSatellite;

    @Bin(order = 109, type = BinType.UBYTE, bitOrder = JBBPBitOrder.MSB0)
    private int fixStatus;

    @Bin(order = 110, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] gnssDate;

    @Bin(order = 111, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] latitude;

    @Bin(order = 112, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] longitude;

    @Bin(order = 113, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitude;

    @Bin(order = 114, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] courseAngle;

    @Bin(order = 115, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] speed;

    @Bin(order = 116, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] horizontalError;

    @Bin(order = 117, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] altitudeError;

    @Bin(order = 118, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] speedError;

    @Bin(order = 119, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] drLatitude;

    @Bin(order = 120, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] drLongitude;

    @Bin(order = 121, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] drHeading;

    @Bin(order = 122, type = BinType.UBYTE_ARRAY, bitOrder = JBBPBitOrder.MSB0)
    private byte[] drSpeed;

    public int getCode() {
        return code;
    }

    public List<Integer> getValidities() {
        List<Integer> validityCodes = new ArrayList<>();
        for (int i = 0; i < validities.length * BITS_PER_BYTE; i++) {
            if (((validities[validities.length - 1 - (i / BITS_PER_BYTE)] & 0xFF) & (1 << (i % BITS_PER_BYTE))) > 0) {
                validityCodes.add(i);
            }
        }
        return validityCodes;
    }

    public float getPositionalDilution() {
        return ByteUtils.asFloat(positionalDilution);
    }

    public float getHorizontalDilution() {
        return ByteUtils.asFloat(horizontalDilution);
    }

    public float getVerticalDilution() {
        return ByteUtils.asFloat(verticalDilution);
    }

    public int getUsedSatellite() {
        return ByteUtils.asInt(usedSatellite);
    }

    public int getTrackedSatellite() {
        return ByteUtils.asInt(trackedSatellite);
    }

    public int getVisibleSatellite() {
        return ByteUtils.asInt(visibleSatellite);
    }

    public int getFixStatus() {
        return fixStatus;
    }

    public int getGnssDate() {
        return ByteUtils.asInt(gnssDate);
    }

    public double getLatitude() {
        return ByteUtils.asDouble(latitude);
    }

    public double getLongitude() {
        return ByteUtils.asDouble(longitude);
    }

    public double getAltitude() {
        return ByteUtils.asDouble(altitude);
    }

    public float getCourseAngle() {
        return ByteUtils.asInt(courseAngle);
    }

    public float getSpeed() {
        return ByteUtils.asInt(speed);
    }

    public float getHorizontalError() {
        return ByteUtils.asInt(horizontalError);
    }

    public float getAltitudeError() {
        return ByteUtils.asInt(altitudeError);
    }

    public float getSpeedError() {
        return ByteUtils.asInt(speedError);
    }

    public double getDrLatitude() {
        return ByteUtils.asDouble(drLatitude);
    }

    public double getDrLongitude() {
        return ByteUtils.asDouble(drLongitude);
    }

    public float getDrHeading() {
        return ByteUtils.asFloat(drHeading);
    }

    public float getDrSpeed() {
        return ByteUtils.asFloat(drSpeed);
    }
}
