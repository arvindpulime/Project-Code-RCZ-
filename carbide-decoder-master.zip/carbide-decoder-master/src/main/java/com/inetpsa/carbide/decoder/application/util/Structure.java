package com.inetpsa.carbide.decoder.application.util;

import com.inetpsa.carbide.decoder.infrastructure.util.Constant;

import java.util.Arrays;
import java.util.EnumSet;
import java.util.NoSuchElementException;

public enum Structure {
    // Protocol 2
    HEADER(Constant.V1, 0x01, 44),
    PERIODIC(Constant.V1_V2, 0x16, 492),
    EVENT(Constant.V1_V2, 0x17, 1562),
    LOCALIZATION(Constant.V1_V2, 0x20, 96),
    JDA(Constant.V1_V2, 0x21, 23),
    JDD(Constant.V1_V2, 0x22, 17),
    EXTENSION(Constant.V1_V2, 0x23, 25),
    BATTERY(Constant.V1_V2, 0x24, 12),
    THERMAL_CONDITIONING(Constant.V1_V2, 0x25, 14),
    TRIP(Constant.V1_V2, 0x26, 10),
    ECOACHING(Constant.V1_V2, 0x27, 6),
    PRIVACY(Constant.V1_V2, 0x29, 5),
    CFM_LEV(Constant.V1_V2, 0x2A, 16),
    VEHICLE_STATUS(Constant.V1, 0x2B, 13),
    MAINTENANCE_STATUS(Constant.V1_V2, 0x2C, 6),
    DOORS_STATUS(Constant.V1_V2, 0x2D, 3),
    BATTERY_VOLTAGE_SUMMARY(Constant.V1_V2, 0x2E, 11),
    BATTERY_VOLTAGE_DETAILS(Constant.V1_V2, 0x2F, 220),
    BATTERY_STATUS_SUMMARY(Constant.V1_V2, 0x30, 17),
    BATTERY_STATUS_DETAILS(Constant.V1_V2, 0x31, 56),
    BATTERY_SOH(Constant.V1_V2, 0x32, 35),
    CRASH(Constant.V1_V2, 0x33, 4),
    ADAS(Constant.V1_V2, 0x34, 7),
    USAGE_STATUS(Constant.V1, 0x35, 22),
    // Protocol 3
    HEADER_V2(Constant.V2, 0x01, 45),
    VEHICLE_STATUS_V2(Constant.V2, 0x2B, 17),
    USAGE_STATUS_V2(Constant.V2, 0x35, 22),

    AUTHORIZATIONS(Constant.V1_V2, 0x28);

    /**
     * Set of compatibility between structures and schemas
     */
    private final EnumSet<Schema> schemas;
    /**
     * First byte indicating which type of structure it is
     */
    private final int code;
    /**
     * Length in bytes
     */
    private int length;

    Structure(EnumSet<Schema> schemas, int code) {
        this.schemas = schemas;
        this.code = code;
    }

    Structure(EnumSet<Schema> schemas, int code, int length) {
        this.schemas = schemas;
        this.code = code;
        this.length = length;
    }

    public EnumSet<Schema> schemas() {
        return schemas;
    }

    public int code() {
        return code;
    }

    public int length() {
        return length;
    }

    public static Structure fromSchemaAndCode(Schema schema, int code) {
        return Arrays.stream(values()).filter(struct -> struct.schemas().contains(schema) && struct.code() == code)
                .findFirst()
                .orElseThrow(() -> new NoSuchElementException("Invalid structure: " + String.format("0x%02X", code)));
    }
}
