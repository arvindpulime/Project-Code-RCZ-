package com.inetpsa.carbide.domain.interfaces.data.global;

import java.util.Arrays;

public enum LocalizationSignalValidity {
    POSITIONAL_DILUTION,
    HORIZONTAL_DILUTION,
    VERTICAL_DILUTION,
    USED_SATELLITE,
    TRACKED_SATELLITE,
    VISIBLE_SATELLITE,
    GNSS_LATITUDE,
    GNSS_LONGITUDE,
    GNSS_ALTITUDE,
    GNSS_HEADING,
    GNSS_SPEED,
    GNSS_ERROR_HORIZONTAL,
    GNSS_ERROR_ALTITUDE,
    GNSS_ERROR_SPEED,
    DR_LATITUDE,
    DR_LONGITUDE,
    DR_HEADING,
    DR_SPEED;

    public static LocalizationSignalValidity fromOrdinal(int index) {
        return Arrays.stream(values()).filter(v -> v.ordinal() == index).findFirst().orElse(null);
    }
}
