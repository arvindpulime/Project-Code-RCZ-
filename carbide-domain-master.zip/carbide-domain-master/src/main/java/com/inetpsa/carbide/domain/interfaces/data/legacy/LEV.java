package com.inetpsa.carbide.domain.interfaces.data.legacy;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.inetpsa.carbide.domain.interfaces.data.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;

@NoArgsConstructor
@Getter
@Setter
@ToString
@JsonFilter("LevFilter")
public class LEV implements Data {

    private int phevEngineSpeed;
    private int hybridGmpStatus;
    private int bevEngineSpeed;
    private int residualEnergy;
    private int totalEnergy;
    private int batteryInternalResistanceHealth;
    private BigDecimal batteryLoadLevel;
    private int batteryCapacityHealth;
    private int zevAutonomy;
}
