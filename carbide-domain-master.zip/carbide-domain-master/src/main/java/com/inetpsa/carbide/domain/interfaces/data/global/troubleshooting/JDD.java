package com.inetpsa.carbide.domain.interfaces.data.global.troubleshooting;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.inetpsa.carbide.domain.interfaces.data.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.time.Duration;

@NoArgsConstructor
@Getter
@Setter
@ToString
@JsonFilter("LevFilter")
public class JDD implements Data {

    private Integer frameId;
    private Integer errorCode;
    private Duration timeReference;
    private Integer kilometer;
    private Integer lifeSituation;
    private Integer dtcState;
    private Integer messageType;
}
