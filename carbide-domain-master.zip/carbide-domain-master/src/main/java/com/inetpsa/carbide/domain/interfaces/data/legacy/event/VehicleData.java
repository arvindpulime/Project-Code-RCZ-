package com.inetpsa.carbide.domain.interfaces.data.legacy.event;

import com.fasterxml.jackson.annotation.JsonFilter;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.util.List;

@NoArgsConstructor
@Getter
@Setter
@ToString
@JsonFilter("LevFilter")
public class VehicleData {

    private int rearFogLampsStatement;
    private int frontFogLampsStatement;
    private List<Integer> unbuckledBeltWarnings;
    private BigDecimal outsideTemperature;
    private BigDecimal fuelInstantConsumption;
    private BigDecimal fuelTotalConsumption;
    private int ignition;
    private List<BigDecimal> longitudinalSpeeds;
    private List<Integer> luminosities;
    private BigDecimal lifetimeMileage;
    private int mileageBeforeMaintenanceSign;
    private int mileageBeforeMaintenance;
    private int daysBeforeMaintenanceSign;
    private int daysBeforeMaintenance;
    private int fuelLevel;
    private int oilTemperature;
    private int gmpStatus;
    private List<Integer> rightIndicatorStatements;
    private List<Integer> leftIndicatorStatements;
    private int ecallTriggering;
    private int alertOfFuelLowLevel;
    private int alertOfSCRLowLevel;
    private int residualAutonomy;
}
