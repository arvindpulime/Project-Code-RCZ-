package com.inetpsa.carbide.domain.interfaces.data.global;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.inetpsa.carbide.domain.interfaces.data.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@ToString
@JsonFilter("LevFilter")
public class MaintenanceStatus implements Data {

    private Integer serviceLight;
    private Integer maintenanceLight;
    private Integer maintenanceLightMode;
    private Integer maintenanceType;
    private Integer mileageToMaintenance;
    private Integer daysToMaintenance;
}
