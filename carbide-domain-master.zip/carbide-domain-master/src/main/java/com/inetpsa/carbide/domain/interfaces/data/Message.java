package com.inetpsa.carbide.domain.interfaces.data;

import com.inetpsa.carbide.domain.interfaces.data.global.*;
import com.inetpsa.carbide.domain.interfaces.data.global.troubleshooting.JDA;
import com.inetpsa.carbide.domain.interfaces.data.global.troubleshooting.JDD;
import com.inetpsa.carbide.domain.interfaces.data.legacy.Event;
import com.inetpsa.carbide.domain.interfaces.data.legacy.Extension;
import com.inetpsa.carbide.domain.interfaces.data.legacy.LEV;
import com.inetpsa.carbide.domain.interfaces.data.legacy.Periodic;
import com.inetpsa.carbide.domain.interfaces.data.lev.Battery;
import com.inetpsa.carbide.domain.interfaces.data.lev.Ecoaching;
import com.inetpsa.carbide.domain.interfaces.data.lev.ThermalConditioning;
import com.inetpsa.carbide.domain.interfaces.data.lev.Trip;
import com.inetpsa.carbide.domain.interfaces.data.lev.monitoring.*;
import lombok.ToString;

@ToString
public final class Message {

    private Header header;
    private Adas adas;
    private Battery battery;
    private BatteryVoltageSummary batteryVoltageSummary;
    private BatteryVoltageDetails batteryVoltageDetails;
    private BatteryStatusSummary batteryStatusSummary;
    private BatteryStatusDetails batteryStatusDetails;
    private BatteryStateOfHealth batteryStateOfHealth;
    private Crash crash;
    private DoorsStatus doorsStatus;
    private Ecoaching ecoaching;
    private Event event;
    private Periodic periodic;
    private Extension extension;
    private LEV lev;
    private JDA jda;
    private JDD jdd;
    private Localization localization;
    private MaintenanceStatus maintenanceStatus;
    private Privacy privacy;
    private ThermalConditioning thermalConditioning;
    private Trip trip;
    private UsageStatus usageStatus;
    private VehicleStatus vehicleStatus;
    private Authorizations authorizations;

    private Message() {
    }

    private Message(Header header) {
        this.header = header;
    }

    public static Message create() {
        return new Message();
    }

    public static Message create(Header header) {
        return new Message(header);
    }

    public Header getHeader() {
        return header;
    }

    public Message header(Header header) {
        this.header = header;
        return this;
    }

    public Message adas(Adas adas) {
        this.adas = adas;
        return this;
    }

    public Message battery(Battery battery) {
        this.battery = battery;
        return this;
    }

    public Message batteryVoltageSummary(BatteryVoltageSummary batteryVoltageSummary) {
        this.batteryVoltageSummary = batteryVoltageSummary;
        return this;
    }

    public Message batteryVoltageDetails(BatteryVoltageDetails batteryVoltageDetails) {
        this.batteryVoltageDetails = batteryVoltageDetails;
        return this;
    }

    public Message batteryStatusSummary(BatteryStatusSummary batteryStatusSummary) {
        this.batteryStatusSummary = batteryStatusSummary;
        return this;
    }

    public Message batteryStatusDetails(BatteryStatusDetails batteryStatusDetails) {
        this.batteryStatusDetails = batteryStatusDetails;
        return this;
    }

    public Message batteryStateOfHealth(BatteryStateOfHealth batteryStateOfHealth) {
        this.batteryStateOfHealth = batteryStateOfHealth;
        return this;
    }

    public Message crash(Crash crash) {
        this.crash = crash;
        return this;
    }

    public Message doorsStatus(DoorsStatus doorsStatus) {
        this.doorsStatus = doorsStatus;
        return this;
    }

    public Message ecoaching(Ecoaching ecoaching) {
        this.ecoaching = ecoaching;
        return this;
    }

    public Message event(Event event) {
        this.event = event;
        return this;
    }

    public Message periodic(Periodic periodic) {
        this.periodic = periodic;
        return this;
    }

    public Message extension(Extension extension) {
        this.extension = extension;
        return this;
    }

    public Message lev(LEV lev) {
        this.lev = lev;
        return this;
    }

    public Message jda(JDA jda) {
        this.jda = jda;
        return this;
    }

    public Message jdd(JDD jdd) {
        this.jdd = jdd;
        return this;
    }

    public Message localization(Localization localization) {
        this.localization = localization;
        return this;
    }

    public Message maintenanceStatus(MaintenanceStatus maintenanceStatus) {
        this.maintenanceStatus = maintenanceStatus;
        return this;
    }

    public Message privacy(Privacy privacy) {
        this.privacy = privacy;
        return this;
    }

    public Message thermalConditioning(ThermalConditioning thermalConditioning) {
        this.thermalConditioning = thermalConditioning;
        return this;
    }

    public Message trip(Trip trip) {
        this.trip = trip;
        return this;
    }

    public Message usageStatus(UsageStatus usageStatus) {
        this.usageStatus = usageStatus;
        return this;
    }

    public Message vehicleStatus(VehicleStatus vehicleStatus) {
        this.vehicleStatus = vehicleStatus;
        return this;
    }

    public Message authorizations(Authorizations authorizations) {
        this.authorizations = authorizations;
        return this;
    }
}
