package com.inetpsa.carbide.domain.interfaces.data.legacy.event;

import com.fasterxml.jackson.annotation.JsonFilter;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@ToString
@JsonFilter("LevFilter")
public class CrashData {

    private int rearHighSpeedCrashInfo;
    private int rearMediumSpeedCrashInfo;
    private int rearSlowSpeedCrashInfo;
    private int rearReparabilitySpeedCrashInfo;
    private int pedestrianCrashInfo;
    private int highSpeedFrontCrashInfo;
    private int mediumSpeedN1FrontCrashInfo;
    private int mediumSpeedN2FrontCrashInfo;
    private int lowSpeedFrontCrashInfo;
    private int frontReparabilityCrashInfo;
    private int rearHighSpeedLateralCrashInfo;
    private int rearMediumSpeedLateralCrashInfo;
    private int rearLowSpeedLateralCrashInfo;
    private int rearRepairabilityCrashInfo;
    private int tippedOver;
}
