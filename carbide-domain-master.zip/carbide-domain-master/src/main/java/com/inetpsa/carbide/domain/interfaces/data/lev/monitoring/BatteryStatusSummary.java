package com.inetpsa.carbide.domain.interfaces.data.lev.monitoring;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.inetpsa.carbide.domain.interfaces.data.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;

@NoArgsConstructor
@Getter
@Setter
@ToString
@JsonFilter("LevFilter")
public class BatteryStatusSummary implements Data {

    private Integer chargeMode;
    private Integer chargeState;
    private Integer powertrainMode;
    private Integer totalEnergy;
    private Integer remainingEnergy;
    private BigDecimal remainingCapacity;
    private BigDecimal stateOfCharge;
    private Integer averageTemperature;
    private Integer maxTemperature;
    private Integer minTemperature;
    private Integer probeWithMaxTemperature;
    private Integer probeWithMinTemperature;
}
