package com.inetpsa.carbide.domain.interfaces.data.global;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.inetpsa.carbide.domain.interfaces.data.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@ToString
@JsonFilter("LevFilter")
public class DoorsStatus implements Data {

    private Integer lockingStatus;
    private Integer bootLockingStatus;
    private Integer rearLockingStatus;
    private Integer bootOpeningStatus;
    private Integer driverOpeningStatus;
    private Integer rearRightOpeningStatus;
    private Integer rearLeftOpeningStatus;
    private Integer driverEstimatedOpeningStatus;
    private Integer passengerOpeningStatus;
    private Integer rearWindowOpeningStatus;
    private Integer retractableRoofPosition;
}
