package com.inetpsa.carbide.domain.interfaces.data.lev.monitoring;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.inetpsa.carbide.domain.interfaces.data.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@NoArgsConstructor
@Getter
@Setter
@ToString
@JsonFilter("LevFilter")
public class BatteryStatusDetails implements Data {

    List<Integer> probeTemperatures;
}
