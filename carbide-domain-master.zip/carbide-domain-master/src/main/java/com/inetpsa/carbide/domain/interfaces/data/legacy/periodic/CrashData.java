package com.inetpsa.carbide.domain.interfaces.data.legacy.periodic;

import com.fasterxml.jackson.annotation.JsonFilter;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@NoArgsConstructor
@Getter
@Setter
@ToString
@JsonFilter("LevFilter")
public class CrashData {

    private int rearHighSpeedCrashInfo;
    private int rearMediumSpeedCrashInfo;
    private int rearSlowSpeedCrashInfo;
    private int rearReparabilitySpeedCrashInfo;
    private int highSpeedFrontCrashInfo;
    private int mediumSpeedN1FrontCrashInfo;
    private int mediumSpeedN2FrontCrashInfo;
    private int lowSpeedFrontCrashInfo;
    private int frontReparabilityCrashInfo;
    private int rearHighSpeedLateralCrashInfo;
    private int rearMediumSpeedLateralCrashInfo;
    private int rearLowSpeedLateralCrashInfo;
    private int rearRepairabilityCrashInfo;
    private int tippedOver;
    private List<Integer> pedestrianCrashInfos;
}
