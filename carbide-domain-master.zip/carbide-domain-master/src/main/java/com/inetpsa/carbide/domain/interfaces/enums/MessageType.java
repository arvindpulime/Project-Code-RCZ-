package com.inetpsa.carbide.domain.interfaces.enums;

public final class MessageType {

    private MessageType() {
    }

    public static final int
            PERIODIC = 0x36,
            EVENT_ALERT = 0x37,
            EVENT_STOP = 0x38,
            EVENT_START = 0x39,
            EVENT_CRASH = 0x3A,
            EVENT_PRIVACY = 0x3B,
            JDD = 0x41,
            EXTENSION = 0x42,
            JDA = 0x43,
            BATTERY = 0x44,
            THERMAL_CONDITIONING = 0x45,
            TRIP = 0x46,
            ECOACHING = 0x47,
            LOCALIZATION = 0x48,
            PRIVACY = 0x49,
            VEHICLE_STATUS = 0x4A,
            MAINTENANCE_STATUS = 0x4B,
            DOORS_STATUS = 0x4C,
            BATTERY_VOLTAGE_SUMMARY = 0x4D,
            BATTERY_VOLTAGE_DETAILS = 0x4E,
            BATTERY_STATUS_SUMMARY = 0x4F,
            BATTERY_STATUS_DETAILS = 0x50,
            BATTERY_SOH = 0x51,
            CRASH = 0x52,
            ADAS = 0x53,
            USAGE_STATUS = 0x54;
}
