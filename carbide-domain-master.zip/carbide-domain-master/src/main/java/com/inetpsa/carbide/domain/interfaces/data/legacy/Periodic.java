package com.inetpsa.carbide.domain.interfaces.data.legacy;

import com.inetpsa.carbide.domain.interfaces.data.Data;
import com.inetpsa.carbide.domain.interfaces.data.legacy.periodic.AdasData;
import com.inetpsa.carbide.domain.interfaces.data.legacy.periodic.CrashData;
import com.inetpsa.carbide.domain.interfaces.data.legacy.periodic.GpsData;
import com.inetpsa.carbide.domain.interfaces.data.legacy.periodic.VehicleData;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.time.Instant;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class Periodic implements Data {

    private Instant dateOfCollection;
    private Instant dateOfTransmission;
    private int idTrip;
    private int idFrame;
    private int privacyMode01;
    private int privacyMode02;
    private int rebootCounter;
    private String vin;
    private GpsData gps;
    private CrashData crash;
    private AdasData adas;
    private VehicleData vehicle;
    private int privacyMode01V2;
    private int privacyMode02V2;
}
