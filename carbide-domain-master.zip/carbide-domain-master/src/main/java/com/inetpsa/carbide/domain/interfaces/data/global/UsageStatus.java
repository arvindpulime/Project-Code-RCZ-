package com.inetpsa.carbide.domain.interfaces.data.global;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.inetpsa.carbide.domain.interfaces.data.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;

@NoArgsConstructor
@Getter
@Setter
@ToString
@JsonFilter("LevFilter")
public class UsageStatus implements Data {

    private Integer torque;
    private Integer brakePedalSwitch;
    private Integer gearboxMode;
    private Integer gearboxRatio;
    private BigDecimal engineSpeed;
    private BigDecimal driversWill;
    private BigDecimal odometerSpeed;
    private BigDecimal yawSpeed;
    private BigDecimal lateralAcceleration;
    private BigDecimal longitudinalAcceleration;
    private BigDecimal steeringWheelAngle;
    private BigDecimal masterCylinderPressure;
    private Integer currentPropulsion;
    private Integer powertrainStatus;
    private Integer phevEngineSpeed;
    private Integer bevEngineSpeed;
}

