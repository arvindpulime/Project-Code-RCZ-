package com.inetpsa.carbide.domain.interfaces.data.legacy.event;

import com.fasterxml.jackson.annotation.JsonFilter;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.time.Instant;

@NoArgsConstructor
@Getter
@Setter
@ToString
@JsonFilter("LevFilter")
public class PreviousData {

    private BigDecimal previousLifetimeMileage;
    private int previousFuelLevel;
    private int previousPrivacyMode;
    private int previousTriggerType;
    private Instant previousDateOfEvent;
    private int previousIdFrame;
    private int previousAltitude;
    private int previousHeading;
    private int previousLongitude;
    private int previousLatitude;
    private int previousGPSSignalQuality;
    private int previousVehicleLocationType;
}
