package com.inetpsa.carbide.domain.interfaces.enums;

public final class ServiceType {

    public static final int ICE = 0x18;
    public static final int BEV = 0x19;
    public static final int PHEV = 0x1A;
}
