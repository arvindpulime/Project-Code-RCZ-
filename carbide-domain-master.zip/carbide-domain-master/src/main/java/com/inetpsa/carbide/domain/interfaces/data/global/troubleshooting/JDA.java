package com.inetpsa.carbide.domain.interfaces.data.global.troubleshooting;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.inetpsa.carbide.domain.interfaces.data.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@ToString
@JsonFilter("LevFilter")
public class JDA implements Data {

    private Integer eeaVersion;
    private String[] alerts;
}
