package com.inetpsa.carbide.domain.interfaces.data.global;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.inetpsa.carbide.domain.interfaces.data.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@ToString
@JsonFilter("LevFilter")
public class Crash implements Data {

    private Boolean frontRepairabilityCrashDetected;
    private Boolean frontLowSpeedCrashDetected;
    private Boolean frontMediumSpeedN1CrashDetected;
    private Boolean frontMediumSpeedN2CrashDetected;
    private Boolean frontHighSpeedCrashDetected;
    private Boolean lateralRepairabilityCrashDetected;
    private Boolean lateralLowSpeedCrashDetected;
    private Boolean lateralMediumSpeedCrashDetected;
    private Boolean lateralHighSpeedCrashDetected;
    private Boolean rearRepairabilityCrashDetected;
    private Boolean rearLowSpeedCrashDetected;
    private Boolean rearMediumSpeedCrashDetected;
    private Boolean rearHighSpeedCrashDetected;
    private Boolean tippedOver;
    private Boolean crashDetected;
    private Integer ecallRequest;
    private Boolean pedestrianCrashDetected;
}