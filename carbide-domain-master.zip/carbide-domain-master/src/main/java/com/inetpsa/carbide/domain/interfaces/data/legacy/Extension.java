package com.inetpsa.carbide.domain.interfaces.data.legacy;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.inetpsa.carbide.domain.interfaces.data.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;

@NoArgsConstructor
@Getter
@Setter
@ToString
@JsonFilter("LevFilter")
public class Extension implements Data {

    private int torque;
    private BigDecimal engineSpeed;
    private BigDecimal driversWill;
    private BigDecimal odometerSpeed;
    private int engineOilLevel;
    private int engineAirTemperature;
    private int engineWaterTemperature;
    private int engineOilTemperature;
    private BigDecimal yawSpeed;
    private BigDecimal lateralAcceleration;
    private BigDecimal longitudinalAcceleration;
    private int driverSeatBeltState;
    private int passengerSeatBeltState;
    private int rainSensorState;
    private int powerTrainState;
    private BigDecimal steeringWheelAngle;
    private BigDecimal batteryVoltage;
    private BigDecimal masterCylinder;
    private int gearboxEffectiveRatio;
    private int gearboxCalculatedRatio;
    private int gearboxMode;
    private int stopIndicator;
    private int serviceIndicator;
    private int breakPedalState;
}
