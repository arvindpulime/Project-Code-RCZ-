package com.inetpsa.carbide.domain.interfaces.data.global;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.inetpsa.carbide.domain.interfaces.data.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@ToString
@JsonFilter("LevFilter")
public class Adas implements Data {

    private Integer rearParkingAssist;
    private Integer frontParkingAssist;
    private Integer advancedEmergencyBrakingSystem;
    private Integer adaptiveCruiseControl;
    private Integer laneDepartureWarning;
    private Integer respectOfInterVehicleTimeAssist;
    private Integer electronicStabilityProgram;
    private Integer recommenderGearIndicator;
    private Integer advancedSpeedRegulator;
    private Integer speedRegulatorStatus;
    private Integer speedLimitInformation;
    private Integer blindSpotMonitoring;
    private Integer rightLaneKeepingAssist;
    private Integer leftLaneKeepingAssist;
    private Integer antiBrakingSystem;
    private Integer electricBrakeService;
}
