package com.inetpsa.carbide.domain.interfaces.data.lev;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.inetpsa.carbide.domain.interfaces.data.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalTime;

@NoArgsConstructor
@Getter
@Setter
@ToString
@JsonFilter("LevFilter")
public final class Battery implements Data {

    private Integer chargeState;
    private Integer chargeMode;
    private Integer plugState;
    private LocalTime rtabStartTime;
    private Integer loadLevel;
    private Integer fuelLevel;
    private Integer autonomy;
    private Integer zevAutonomy;
    private Integer remainingChargeTime;
    private Integer zevChargeGain;
}
