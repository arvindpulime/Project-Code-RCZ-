package com.inetpsa.carbide.domain.interfaces.data;

import lombok.ToString;

import java.beans.Transient;
import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoField;
import java.util.StringJoiner;
import java.util.UUID;

@ToString
public final class Header implements Data {

    private UUID uuid;
    private String crc;
    private Integer protocolVersion;
    private String messageVersion;
    private String vin;
    private Integer serviceType;
    private Integer messageType;
    private Integer sessionId;
    private Duration timeSinceSessionStart;
    private Integer messageId;
    private Instant dateOfCollection;
    private Instant dateOfReception;
    private Instant gnssTimestamp;
    private Boolean gnssTimefix;
    private Boolean timeSync;
    private Integer privacyStatus;
    private Integer requestedPrivacyStatus;
    private Integer applicablePrivacyStatus;
    private Integer messageLength;
    private Integer triggerType;

    public Header() {
        this.messageVersion = getClass().getPackage().getImplementationVersion();
        this.dateOfReception = Instant.now().with(ChronoField.NANO_OF_SECOND, 0);
    }

    public UUID getUuid() {
        return uuid;
    }

    public Header setUuid(UUID uuid) {
        this.uuid = uuid;
        return this;
    }

    public String getCrc() {
        return crc;
    }

    public Header setCrc(String crc) {
        this.crc = crc;
        return this;
    }

    public Integer getProtocolVersion() {
        return protocolVersion;
    }

    public Header setProtocolVersion(Integer protocolVersion) {
        this.protocolVersion = protocolVersion;
        return this;
    }

    public String getMessageVersion() {
        return messageVersion;
    }

    public String getVin() {
        return vin;
    }

    public Header setVin(String vin) {
        this.vin = vin;
        return this;
    }

    public Integer getServiceType() {
        return serviceType;
    }

    public Header setServiceType(Integer serviceType) {
        this.serviceType = serviceType;
        return this;
    }

    public Integer getMessageType() {
        return messageType;
    }

    public Header setMessageType(Integer messageType) {
        this.messageType = messageType;
        return this;
    }

    public Integer getSessionId() {
        return sessionId;
    }

    public Header setSessionId(Integer sessionId) {
        this.sessionId = sessionId;
        return this;
    }

    public Duration getTimeSinceSessionStart() {
        return timeSinceSessionStart;
    }

    public Header setTimeSinceSessionStart(Duration timeSinceSessionStart) {
        this.timeSinceSessionStart = timeSinceSessionStart;
        return this;
    }

    public Integer getMessageId() {
        return messageId;
    }

    public Header setMessageId(Integer messageId) {
        this.messageId = messageId;
        return this;
    }

    public Instant getDateOfCollection() {
        return dateOfCollection;
    }

    public Header setDateOfCollection(Instant dateOfCollection) {
        this.dateOfCollection = dateOfCollection;
        return this;
    }

    public Instant getDateOfReception() {
        return dateOfReception;
    }

    public Instant getGnssTimestamp() {
        return gnssTimestamp;
    }

    public Header setGnssTimestamp(Instant gnssTimestamp) {
        this.gnssTimestamp = gnssTimestamp;
        return this;
    }

    public Boolean getGnssTimefix() {
        return gnssTimefix;
    }

    public Header setGnssTimefix(Boolean gnssTimefix) {
        this.gnssTimefix = gnssTimefix;
        return this;
    }

    public Boolean getTimeSync() {
        return timeSync;
    }

    public Header setTimeSync(Boolean timeSync) {
        this.timeSync = timeSync;
        return this;
    }

    public Integer getPrivacyStatus() {
        return privacyStatus;
    }

    public Header setPrivacyStatus(Integer privacyStatus) {
        this.privacyStatus = privacyStatus;
        return this;
    }

    public Integer getRequestedPrivacyStatus() {
        return requestedPrivacyStatus;
    }

    public Header setRequestedPrivacyStatus(Integer requestedPrivacyStatus) {
        this.requestedPrivacyStatus = requestedPrivacyStatus;
        return this;
    }

    public Integer getApplicablePrivacyStatus() {
        return applicablePrivacyStatus;
    }

    public Header setApplicablePrivacyStatus(Integer applicablePrivacyStatus) {
        this.applicablePrivacyStatus = applicablePrivacyStatus;
        return this;
    }

    @Transient
    public Integer getMessageLength() {
        return messageLength;
    }

    public Header setMessageLength(Integer messageLength) {
        this.messageLength = messageLength;
        return this;
    }

    public Integer getTriggerType() {
        return triggerType;
    }

    public Header setTriggerType(Integer triggerType) {
        this.triggerType = triggerType;
        return this;
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", "[", "]")
                .add("uuid=" + uuid)
                .add("crc='" + crc + "'")
                .add("protocolVersion=" + protocolVersion)
                .add("messageVersion='" + getMessageVersion() + "'")
                .add("vin='" + vin + "'")
                .add("serviceType=" + String.format("0x%02X", serviceType))
                .add("messageType=" + String.format("0x%02X", messageType))
                .add("sessionId=" + sessionId)
                .add("timeSinceSessionStart=" + timeSinceSessionStart)
                .add("messageId=" + messageId)
                .add("dateOfCollection=" + dateOfCollection)
                .add("dateOfReception=" + dateOfReception)
                .add("gnssTimestamp=" + gnssTimestamp)
                .add("gnssTimefix=" + gnssTimefix)
                .add("timeSync=" + timeSync)
                .add("privacyStatus=" + privacyStatus)
                .add("requestedPrivacyStatus=" + requestedPrivacyStatus)
                .add("applicablePrivacyStatus=" + applicablePrivacyStatus)
                .add("messageLength=" + messageLength)
                .add("triggerType=" + triggerType)
                .toString();
    }
}
