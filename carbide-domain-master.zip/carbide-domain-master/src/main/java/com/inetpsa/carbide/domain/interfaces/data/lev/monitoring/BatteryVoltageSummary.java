package com.inetpsa.carbide.domain.interfaces.data.lev.monitoring;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.inetpsa.carbide.domain.interfaces.data.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;

@NoArgsConstructor
@Getter
@Setter
@ToString
@JsonFilter("LevFilter")
public class BatteryVoltageSummary implements Data {

    private BigDecimal intensity;
    private BigDecimal voltage;
    private Integer cellWithMaxVoltage;
    private BigDecimal cellMaxVoltage;
    private Integer cellWithMinVoltage;
    private BigDecimal cellMinVoltage;
}
