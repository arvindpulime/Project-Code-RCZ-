package com.inetpsa.carbide.domain.interfaces.data.lev;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.inetpsa.carbide.domain.interfaces.data.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalTime;

@NoArgsConstructor
@Getter
@Setter
@ToString
@JsonFilter("LevFilter")
public final class ThermalConditioning implements Data {

    private Integer precondActivation;

    private Boolean week1PrecondActivation;
    private LocalTime week1PrecondTime;
    private Boolean week1Day1PrecondActivation;
    private Boolean week1Day2PrecondActivation;
    private Boolean week1Day3PrecondActivation;
    private Boolean week1Day4PrecondActivation;
    private Boolean week1Day5PrecondActivation;
    private Boolean week1Day6PrecondActivation;
    private Boolean week1Day7PrecondActivation;

    private Boolean week2PrecondActivation;
    private LocalTime week2PrecondTime;
    private Boolean week2Day1PrecondActivation;
    private Boolean week2Day2PrecondActivation;
    private Boolean week2Day3PrecondActivation;
    private Boolean week2Day4PrecondActivation;
    private Boolean week2Day5PrecondActivation;
    private Boolean week2Day6PrecondActivation;
    private Boolean week2Day7PrecondActivation;

    private Boolean week3PrecondActivation;
    private LocalTime week3PrecondTime;
    private Boolean week3Day1PrecondActivation;
    private Boolean week3Day2PrecondActivation;
    private Boolean week3Day3PrecondActivation;
    private Boolean week3Day4PrecondActivation;
    private Boolean week3Day5PrecondActivation;
    private Boolean week3Day6PrecondActivation;
    private Boolean week3Day7PrecondActivation;

    private Boolean week4PrecondActivation;
    private LocalTime week4PrecondTime;
    private Boolean week4Day1PrecondActivation;
    private Boolean week4Day2PrecondActivation;
    private Boolean week4Day3PrecondActivation;
    private Boolean week4Day4PrecondActivation;
    private Boolean week4Day5PrecondActivation;
    private Boolean week4Day6PrecondActivation;
    private Boolean week4Day7PrecondActivation;
}
