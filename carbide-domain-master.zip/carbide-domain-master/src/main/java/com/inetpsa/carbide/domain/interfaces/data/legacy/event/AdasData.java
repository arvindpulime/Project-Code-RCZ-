package com.inetpsa.carbide.domain.interfaces.data.legacy.event;

import com.fasterxml.jackson.annotation.JsonFilter;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@NoArgsConstructor
@Getter
@Setter
@ToString
@JsonFilter("LevFilter")
public class AdasData {

    private List<Integer> rearParkings;
    private List<Integer> frontParkings;
    private List<Integer> adaptiveCruiseControlRegulations;
    private List<Integer> advancedEmergencyBrakingSystems;
    private List<Integer> laneDepartureWarnings;
    private List<Integer> respectOfInterVehicleTimeAssists;
    private List<Integer> triggeringOfESPs;
    private List<Integer> triggeringOfABSs;
    private List<Integer> electricBrakeServices;
    private List<Integer> advancedSpeedRegulatorAndLimits;
    private List<Integer> rightLaneKeepingAssists;
    private List<Integer> leftLaneKeepingAssists;
    private List<Integer> advancedSpeedRegulators;
    private List<Integer> blindSpotMonitorings;
    private List<Integer> speedLimitInformations;
}
