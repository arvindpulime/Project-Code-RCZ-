package com.inetpsa.carbide.domain.interfaces.data.lev;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.inetpsa.carbide.domain.interfaces.data.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;

@NoArgsConstructor
@Getter
@Setter
@ToString
@JsonFilter("LevFilter")
public final class Trip implements Data {

    private BigDecimal avgFuelConsumption;
    private BigDecimal zevAvgPowerConsumption;
    private Integer zevUtilization;
    private Integer distanceTraveled;
    private Integer duration;
}
