package com.inetpsa.carbide.domain.interfaces.data.lev.monitoring;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.inetpsa.carbide.domain.interfaces.data.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;

@NoArgsConstructor
@Getter
@Setter
@ToString
@JsonFilter("LevFilter")
public class BatteryStateOfHealth implements Data {

    private Integer capacitySoH;
    private Integer resistanceSoH;
    private Integer insulationResistance;
    private Integer totalProbes;
    private Integer totalCells;
    private BigDecimal opTimeOverTemp;
    private Integer positiveChargeExchanged;
    private Integer negativeChargeExchanged;
    private Integer negativeChargeExchangedForPlugin;
    private Integer positiveEnergyExchanged;
    private Integer negativeEnergyExchanged;
    private Integer negativeEnergyExchangedForPlugin;
    private BigDecimal opTimeOverChargePower;
    private BigDecimal opTimeOverDischargePower;
    private BigDecimal opTimeOverVoltageRange;
    private BigDecimal opTimeBatteryChargeWithHighTemp;
    private BigDecimal opTimeBatteryDischargeWithHighTemp;
    private Integer mainRelayDamageCounter;
    private Integer quickChargeRelayDamageCounter;
}
