package com.inetpsa.carbide.domain.interfaces.data.lev.monitoring;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.inetpsa.carbide.domain.interfaces.data.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.util.List;

@NoArgsConstructor
@Getter
@Setter
@ToString
@JsonFilter("LevFilter")
public class BatteryVoltageDetails implements Data {

    private BigDecimal intensity;
    private List<BigDecimal> cellVoltages;
}
