package com.inetpsa.carbide.domain.interfaces.data.legacy.event;

import com.fasterxml.jackson.annotation.JsonFilter;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@NoArgsConstructor
@Getter
@Setter
@ToString
@JsonFilter("LevFilter")
public class GpsData {

    private List<Integer> altitudes;
    private List<Integer> headings;
    private List<Integer> longitudes;
    private List<Integer> latitudes;
    private List<Integer> gpsSignalQualities;
    private List<Integer> vehicleLocationTypes;
}
