package com.inetpsa.carbide.domain.interfaces.data.global;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.inetpsa.carbide.domain.interfaces.data.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.time.Duration;
import java.util.List;

@NoArgsConstructor
@Getter
@Setter
@ToString
@JsonFilter("LevFilter")
public class Localization implements Data {

    private List<LocalizationSignalValidity> validities;
    private Float positionalDilution;
    private Float horizontalDilution;
    private Float verticalDilution;
    private Integer usedSatellite;
    private Integer trackedSatellite;
    private Integer visibleSatellite;
    private Integer fixStatus;
    private Duration gnssDate;
    private Double latitude;
    private Double longitude;
    private Double altitude;
    private Float courseAngle;
    private Float speed;
    private Float horizontalError;
    private Float altitudeError;
    private Float speedError;
    private Double drLatitude;
    private Double drLongitude;
    private Float drHeading;
    private Float drSpeed;
}
