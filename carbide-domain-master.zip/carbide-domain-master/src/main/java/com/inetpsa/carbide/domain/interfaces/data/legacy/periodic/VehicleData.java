package com.inetpsa.carbide.domain.interfaces.data.legacy.periodic;

import com.fasterxml.jackson.annotation.JsonFilter;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.util.List;

@NoArgsConstructor
@Getter
@Setter
@ToString
@JsonFilter("LevFilter")
public class VehicleData {

    private List<Integer> rearFogLampsStatements;
    private List<Integer> frontFogLampsStatements;
    private int unbuckledBeltWarning;
    private BigDecimal outsideTemperature;
    private List<Integer> recommendedGearIndicators;
    private List<BigDecimal> fuelInstantConsumptions;
    private BigDecimal fuelTotalConsumption;
    private int ignition;
    private List<Integer> gearboxModes;
    private List<BigDecimal> engineSpeeds;
    private List<BigDecimal> longitudinalSpeeds;
    private List<Integer> luminosities;
    private List<Integer> vehicleModes;
    /**
     * @deprecated hybridModes replaced with vehicleModes
     */
    @Deprecated
    private List<Integer> hybridModes;
    private BigDecimal lifetimeMileage;
    private int fuelLevel;
    private int oilTemperature;
    private int gmpStatus;
}
