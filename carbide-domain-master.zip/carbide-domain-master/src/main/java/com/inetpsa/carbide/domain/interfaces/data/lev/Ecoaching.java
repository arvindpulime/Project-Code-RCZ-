package com.inetpsa.carbide.domain.interfaces.data.lev;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.inetpsa.carbide.domain.interfaces.data.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@ToString
@JsonFilter("LevFilter")
public final class Ecoaching implements Data {

    private Integer globalScore;
    private Integer accelScore;
    private Integer brakeScore;
    private Integer climateComfortScore;
    private Integer coldEngineScore;
    private Integer tirePressureScore;
    private Integer slopeScore;
    private Integer speedScore;
    private Integer startStopScore;
}
