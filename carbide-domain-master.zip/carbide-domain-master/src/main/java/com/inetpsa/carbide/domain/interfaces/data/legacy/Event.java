package com.inetpsa.carbide.domain.interfaces.data.legacy;

import com.inetpsa.carbide.domain.interfaces.data.Data;
import com.inetpsa.carbide.domain.interfaces.data.legacy.event.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.time.Instant;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class Event implements Data {

    private Instant dateOfCollection;
    private Instant dateOfTransmission;
    private Integer idTrip;
    private int idFrame;
    private Integer privacyMode;
    private Instant dateOfEvent;
    private int triggerType;
    private String vin;
    private PreviousData previous;
    private GpsData gps;
    private CrashData crash;
    private AdasData adas;
    private VehicleData vehicle;
}
