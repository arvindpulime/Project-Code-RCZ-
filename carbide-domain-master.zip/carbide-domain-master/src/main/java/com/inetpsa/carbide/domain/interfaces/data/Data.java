package com.inetpsa.carbide.domain.interfaces.data;

public interface Data {

}
