package com.inetpsa.carbide.domain.interfaces.data.global;

import com.fasterxml.jackson.annotation.JsonFilter;
import com.inetpsa.carbide.domain.interfaces.data.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;

@NoArgsConstructor
@Getter
@Setter
@ToString
@JsonFilter("LevFilter")
public class VehicleStatus implements Data {

    private BigDecimal outsideTemperature;
    private BigDecimal lifetimeMileage;
    private BigDecimal auxiliaryBatterySoC;
    private Integer fuelLevel;
    private Integer residualAutonomy;
    private Integer chargeState;
    private Integer zevAutonomy;
    private Integer electricNetworkState;
    private Integer sevMainStatus;
    private Integer luminosity;
    private BigDecimal fuelTotalConsumption;
}
