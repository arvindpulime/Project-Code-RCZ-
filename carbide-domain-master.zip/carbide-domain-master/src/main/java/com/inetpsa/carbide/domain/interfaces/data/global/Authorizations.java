package com.inetpsa.carbide.domain.interfaces.data.global;

import com.inetpsa.carbide.domain.interfaces.data.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@NoArgsConstructor
@Getter
@Setter
@ToString
public class Authorizations implements Data {

    private String[] fds;
}
