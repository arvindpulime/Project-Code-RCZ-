package com.inetpsa.carbide.infrastructure.kafka;

import org.apache.kafka.common.header.Header;
import org.seedstack.business.Service;

import java.util.List;
import java.util.UUID;

@Service
public interface KafkaProducerService {

    void produce(UUID uuid, String topic, String key, String message, List<Header> headers);
}
