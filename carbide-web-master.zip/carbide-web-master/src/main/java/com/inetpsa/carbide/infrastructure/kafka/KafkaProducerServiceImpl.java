package com.inetpsa.carbide.infrastructure.kafka;

import com.inetpsa.carbide.application.enums.ProcessStatus;
import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.errors.RetriableException;
import org.apache.kafka.common.header.Header;
import org.seedstack.seed.LifecycleListener;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.List;
import java.util.UUID;

public class KafkaProducerServiceImpl implements KafkaProducerService, LifecycleListener {

    @Logging
    private Logger logger;

    @Inject
    @Named("kafkaJsonProducer")
    private Producer<String, String> producer;

    @Override
    public void produce(UUID uuid, String topic, String key, String message, List<Header> headers) {
        producer.send(new ProducerRecord<>(topic, null, key, message, headers), new KafkaCallback(uuid));
    }

    private class KafkaCallback implements Callback {

        private UUID uuid;

        private KafkaCallback(UUID uuid) {
            this.uuid = uuid;
        }

        @Override
        public void onCompletion(RecordMetadata metadata, Exception exception) {
            if (exception == null) {
                logger.info("[{}] published to topic={} / partition={} / offset={}",
                        this.uuid,
                        metadata.topic(),
                        metadata.partition(),
                        metadata.offset());
                logger.info("[{}] status={}", this.uuid, ProcessStatus.SUCCESS);
            } else if (exception instanceof RetriableException) {
                logger.warn("[{}] Error while publishing. Cause: {} : {}. Retrying...",
                        this.uuid,
                        exception.getClass().getTypeName(),
                        exception.getMessage());
            } else {
                logger.error("[{}] Unrecoverable error while publishing",
                        this.uuid,
                        exception);
            }
        }
    }
}
