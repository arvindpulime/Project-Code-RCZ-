package com.inetpsa.carbide.application.data;

import com.google.common.io.BaseEncoding;
import com.inetpsa.carbide.application.exceptions.StructureException;
import com.inetpsa.carbide.application.util.IntegrityUtils;
import com.inetpsa.carbide.decoder.application.util.Schema;
import com.inetpsa.carbide.decoder.application.util.Structure;

import java.util.*;

import static com.inetpsa.carbide.decoder.application.util.Structure.HEADER;
import static com.inetpsa.carbide.decoder.infrastructure.jbbp.parser.ParserFormat.HEADER_V2;

public final class BinDataHolder {

    private final static int CRC_LGTH_BYTES = 2;

    private byte[] header;
    private byte[] payload;
    /**
     * LinkedHashMap keeps insertion order
     */
    private final LinkedHashMap<Structure, byte[]> payloadStructure = new LinkedHashMap<>();
    private byte[] authorizations;
    private byte[] crc;

    /**
     * Creates a binary data wrapper.
     *
     * @param data The original binary data
     * @return The binary data wrapper
     * @throws StructureException If validation on the structure has failed
     */
    public static BinDataHolder from(byte[] data, Schema schema) throws StructureException {
        return new BinDataHolder(data, schema);
    }

    private BinDataHolder(byte[] data, Schema schema) throws StructureException {
        this.crc = copyOfRange(data, data.length - CRC_LGTH_BYTES, data.length);
        checkCrc(data);

        final int headerLength = inferHeaderLength(schema);
        this.header = copyOfRange(data, 0, headerLength);

        payload = copyOfRange(data, headerLength, data.length - CRC_LGTH_BYTES);
        splitIntoOrderedStructures(payload, schema);
    }

    private int inferHeaderLength(Schema schema) {
        if (schema == Schema.V2) {
            return Structure.HEADER_V2.length();
        }
        return Structure.HEADER.length();
    }

    private void splitIntoOrderedStructures(byte[] payload, Schema schema) throws StructureException {
        int currentIndex = 0;
        while (currentIndex < payload.length) {
            Structure structure = Structure.fromSchemaAndCode(schema, payload[currentIndex]);
            if (structure != Structure.AUTHORIZATIONS) {
                byte[] binary = copyOfRange(payload, currentIndex, currentIndex + structure.length());
                payloadStructure.put(structure, binary);
                currentIndex += binary.length;
            } else {
                authorizations = copyOfRange(payload, currentIndex, payload.length);
                currentIndex = payload.length;
            }
        }
    }

    private void checkCrc(byte[] data) throws StructureException {
        String calculatedCrc = IntegrityUtils.calculateCrc(data);
        if (!getCrcAsString().equalsIgnoreCase(calculatedCrc)) {
            throw new StructureException("Canceling : CRC failed. E=" + getCrcAsString() + " A=" + calculatedCrc);
        }
    }

    private byte[] copyOfRange(byte[] data, int start, int end) throws StructureException {
        try {
            return Arrays.copyOfRange(data, start, end);
        } catch (ArrayIndexOutOfBoundsException | IllegalArgumentException e) {
            throw new StructureException("Canceling : Binary data split failed", e);
        }
    }

    public byte[] getHeader() {
        return header;
    }

    public List<Structure> getPayloadStructureList() {
        return new ArrayList<>(payloadStructure.keySet());
    }

    public Map<Structure, byte[]> getPayloadStructure() {
        return payloadStructure;
    }

    public String getAuthorizationAsString() {
        // remove first byte (code)
        final byte[] cleanAuth = Arrays.copyOfRange(authorizations, 1, authorizations.length);
        return new String(cleanAuth);
    }

    public int getPayloadLength() {
        return payload.length;
    }

    public String getCrcAsString() {
        return BaseEncoding.base16().encode(crc).toUpperCase();
    }
}
