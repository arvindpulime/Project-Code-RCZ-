package com.inetpsa.carbide.interfaces.rest.monitoring;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;

@Path("/")
public class AliveResource {

    @GET
    public Response alive() {
        return Response.ok().build();
    }
}
