package com.inetpsa.carbide.application.util;

import java.util.regex.Pattern;

public final class Constant {

    public static final Pattern MATCHER_VIN = Pattern.compile("[a-zA-Z0-9]{17}");
}
