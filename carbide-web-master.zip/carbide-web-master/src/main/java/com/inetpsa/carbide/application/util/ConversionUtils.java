package com.inetpsa.carbide.application.util;

import com.google.common.io.BaseEncoding;

public final class ConversionUtils {

    private ConversionUtils() {
    }

    public static String byteArrayToHexString(byte[] bin) {
        return BaseEncoding.base16().encode(bin);
    }

    public static byte[] hexStringToByteArray(String hex) {
        return BaseEncoding.base16().decode(hex);
    }
}
