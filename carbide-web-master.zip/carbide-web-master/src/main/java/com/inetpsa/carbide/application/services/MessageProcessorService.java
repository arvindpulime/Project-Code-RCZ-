package com.inetpsa.carbide.application.services;

import com.inetpsa.carbide.application.exceptions.DataException;
import com.inetpsa.carbide.application.exceptions.StructureException;
import com.inetpsa.carbide.decoder.application.exceptions.DecoderException;
import com.inetpsa.carbide.decoder.application.util.Schema;
import com.inetpsa.carbide.domain.interfaces.data.Message;
import com.inetpsa.carbide.serializer.application.exceptions.SerializationException;
import org.seedstack.business.Service;

import java.util.UUID;

@Service
public interface MessageProcessorService {

    Message process(UUID frameId, byte[] binary, Schema schema) throws StructureException, DecoderException, DataException;

    String serialize(UUID frameId, Message message) throws SerializationException;

    void publish(UUID frameId, Message message, String json);
}
