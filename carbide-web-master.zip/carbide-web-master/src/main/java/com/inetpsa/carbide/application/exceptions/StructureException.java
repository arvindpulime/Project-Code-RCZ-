package com.inetpsa.carbide.application.exceptions;

public class StructureException extends Exception {

    public StructureException() {
        super();
    }

    public StructureException(String message) {
        super(message);
    }

    public StructureException(String message, Throwable cause) {
        super(message, cause);
    }
}
