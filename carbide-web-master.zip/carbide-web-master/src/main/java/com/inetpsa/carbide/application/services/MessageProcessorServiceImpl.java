package com.inetpsa.carbide.application.services;

import com.codahale.metrics.annotation.Metered;
import com.google.common.io.BaseEncoding;
import com.inetpsa.carbide.application.coffig.AppConfig;
import com.inetpsa.carbide.application.data.BinDataHolder;
import com.inetpsa.carbide.application.exceptions.DataException;
import com.inetpsa.carbide.application.exceptions.StructureException;
import com.inetpsa.carbide.application.util.IntegrityUtils;
import com.inetpsa.carbide.application.util.ValidationUtils;
import com.inetpsa.carbide.decoder.application.exceptions.DecoderException;
import com.inetpsa.carbide.decoder.application.util.MessageDescriptor;
import com.inetpsa.carbide.decoder.application.util.Schema;
import com.inetpsa.carbide.decoder.application.util.Structure;
import com.inetpsa.carbide.domain.interfaces.data.Header;
import com.inetpsa.carbide.domain.interfaces.data.Message;
import com.inetpsa.carbide.domain.interfaces.data.global.Authorizations;
import com.inetpsa.carbide.infrastructure.kafka.KafkaProducerService;
import com.inetpsa.carbide.serializer.application.exceptions.SerializationException;
import com.inetpsa.carbide.serializer.application.service.SerializerService;
import org.apache.kafka.common.header.internals.RecordHeader;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class MessageProcessorServiceImpl implements MessageProcessorService {

    @Configuration
    private AppConfig config;

    @Logging
    private Logger logger;

    @Inject
    private DataParserService parserService;

    @Inject
    private SerializerService serializerService;

    @Inject
    private KafkaProducerService producerService;

    @Metered(name = "2. MESSAGE PROCESSING", absolute = true)
    @Override
    public Message process(UUID messageId, byte[] binary, Schema schema) throws StructureException, DecoderException, DataException {
        String hexa = BaseEncoding.base16().encode(binary);
        logger.info("[{}] input={}", messageId, hexa);
        BinDataHolder binDataHolder = BinDataHolder.from(binary, schema);

        Header header = parserService.parseHeader(binDataHolder.getHeader(), schema);
        header.setCrc(binDataHolder.getCrcAsString());
        header.setUuid(messageId);
        logger.debug("[{}] header={}", messageId, header);
        checkVin(header);
        checkMessageLength(header.getMessageLength(), binDataHolder.getPayloadLength());

        MessageDescriptor messageDescriptor = MessageDescriptor.findBy(header.getServiceType(), header.getMessageType(), schema);
        logger.info("[{}] type={}", messageId, messageDescriptor);
        checkPayloadStructure(binDataHolder, messageDescriptor);

        Message message = parserService.parsePayload(binDataHolder.getPayloadStructure());
        message.header(header);

        Authorizations authorizations = parserService.parseAuthorizations(binDataHolder.getAuthorizationAsString());
        message.authorizations(authorizations);
        return message;
    }

    @Metered(name = "3. MESSAGE SERIALIZATION", absolute = true)
    public String serialize(UUID messageId, Message message) throws SerializationException {
        String json = serializerService.serialize(message);
        logger.debug("[{}] output={}", messageId, json);
        return json;
    }

    @Metered(name = "4. MESSAGE PUBLICATION", absolute = true)
    public void publish(UUID messageId, Message message, String json) {
        final String vin = message.getHeader().getVin();
        List<org.apache.kafka.common.header.Header> headers = addKafkaHeaders(vin, message, json);
        logger.info("[{}] publishing using key='{}'", messageId, vin);
        producerService.produce(messageId, config.getKafkaTopics().getJsonLev(), vin, json, headers);
    }

    /**
     * Message length includes payload + authorizations data.
     *
     * @param expectedMessageLength  The length indicated in the header
     * @param effectiveMessageLength The length calculated from excluding Header and CRC
     * @throws DataException If message length is not what was expected
     */
    private void checkMessageLength(int expectedMessageLength, int effectiveMessageLength) throws DataException {
        if (expectedMessageLength != effectiveMessageLength) {
            throw new DataException("Canceling : Invalid payload length E=" + expectedMessageLength + " A=" + effectiveMessageLength);
        }
    }

    private void checkVin(Header header) throws DataException {
        String vin = header.getVin();
        if (!ValidationUtils.checkVin(vin)) {
            throw new DataException("Canceling : Invalid VIN=" + vin);
        }
    }

    private void checkPayloadStructure(BinDataHolder binDataHolder, MessageDescriptor messageDescriptor) throws StructureException {
        List<Structure> expectedStructureList = messageDescriptor.getStructures();
        List<Structure> effectiveStructureList = binDataHolder.getPayloadStructureList();
        if (!expectedStructureList.equals(effectiveStructureList)) {
            throw new StructureException("Unexpected payload structure for " + messageDescriptor);
        }
    }

    private List<org.apache.kafka.common.header.Header> addKafkaHeaders(String vin, Message message, String json) {
        List<org.apache.kafka.common.header.Header> headers = new ArrayList<>();
        // Hash
        String hash;
        if ((hash = IntegrityUtils.generateHash(vin, json)) != null) {
            final org.apache.kafka.common.header.Header _hs256 = new RecordHeader("HS256", hash.getBytes());
            headers.add(_hs256);
        }
        // uuid
        final String uuid = String.valueOf(message.getHeader().getUuid());
        if (uuid != null) {
            final org.apache.kafka.common.header.Header _uuid = new RecordHeader("UUID", uuid.getBytes());
            headers.add(_uuid);
        }
        // VIN
        final org.apache.kafka.common.header.Header _vin = new RecordHeader("VIN", vin.getBytes());
        headers.add(_vin);
        // SessionId
        final String sessionId = String.valueOf(message.getHeader().getSessionId());
        if (sessionId != null) {
            final org.apache.kafka.common.header.Header _sessionId = new RecordHeader("SESSION_ID", sessionId.getBytes());
            headers.add(_sessionId);
        }
        // MessageId
        final String messageId = String.valueOf(message.getHeader().getMessageId());
        if (messageId != null) {
            final org.apache.kafka.common.header.Header _messageId = new RecordHeader("MESSAGE_ID", messageId.getBytes());
            headers.add(_messageId);
        }
        // Service type
        final String serviceType = String.valueOf(message.getHeader().getServiceType());
        if (serviceType != null) {
            final org.apache.kafka.common.header.Header _serviceType = new RecordHeader("SERVICE_TYPE", serviceType.getBytes());
            headers.add(_serviceType);
        }
        // Message type
        final String messageType = String.valueOf(message.getHeader().getMessageType());
        if (messageType != null) {
            final org.apache.kafka.common.header.Header _messageType = new RecordHeader("MESSAGE_TYPE", messageType.getBytes());
            headers.add(_messageType);
        }
        return headers;
    }
}
