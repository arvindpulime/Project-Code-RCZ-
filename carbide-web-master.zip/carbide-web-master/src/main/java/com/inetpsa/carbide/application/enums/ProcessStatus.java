package com.inetpsa.carbide.application.enums;

public enum ProcessStatus {
    SUCCESS, ERROR
}