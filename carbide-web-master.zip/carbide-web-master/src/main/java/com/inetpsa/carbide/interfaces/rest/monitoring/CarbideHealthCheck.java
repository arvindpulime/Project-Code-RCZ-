package com.inetpsa.carbide.interfaces.rest.monitoring;

import com.codahale.metrics.health.HealthCheck;

import javax.inject.Named;

@Named("health")
public class CarbideHealthCheck extends HealthCheck {

    @Override
    protected Result check() throws Exception {
        return Result.healthy(getClass().getPackage().getImplementationVersion());
    }
}