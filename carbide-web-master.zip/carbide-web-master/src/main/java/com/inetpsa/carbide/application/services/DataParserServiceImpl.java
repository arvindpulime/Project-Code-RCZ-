package com.inetpsa.carbide.application.services;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.inetpsa.carbide.application.util.ConversionUtils;
import com.inetpsa.carbide.decoder.application.exceptions.DecoderException;
import com.inetpsa.carbide.decoder.application.services.DecoderService;
import com.inetpsa.carbide.decoder.application.util.Schema;
import com.inetpsa.carbide.decoder.application.util.Structure;
import com.inetpsa.carbide.domain.interfaces.data.Data;
import com.inetpsa.carbide.domain.interfaces.data.Header;
import com.inetpsa.carbide.domain.interfaces.data.Message;
import com.inetpsa.carbide.domain.interfaces.data.global.*;
import com.inetpsa.carbide.domain.interfaces.data.global.troubleshooting.JDA;
import com.inetpsa.carbide.domain.interfaces.data.global.troubleshooting.JDD;
import com.inetpsa.carbide.domain.interfaces.data.legacy.Event;
import com.inetpsa.carbide.domain.interfaces.data.legacy.Extension;
import com.inetpsa.carbide.domain.interfaces.data.legacy.LEV;
import com.inetpsa.carbide.domain.interfaces.data.legacy.Periodic;
import com.inetpsa.carbide.domain.interfaces.data.lev.Battery;
import com.inetpsa.carbide.domain.interfaces.data.lev.Ecoaching;
import com.inetpsa.carbide.domain.interfaces.data.lev.ThermalConditioning;
import com.inetpsa.carbide.domain.interfaces.data.lev.Trip;
import com.inetpsa.carbide.domain.interfaces.data.lev.monitoring.*;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import javax.inject.Inject;
import java.util.Map;
import java.util.StringJoiner;

public class DataParserServiceImpl implements DataParserService {

    @Logging
    private Logger logger;

    private static final ObjectMapper MAPPER = new ObjectMapper();

    @Inject
    private DecoderService decoderService;

    @Override
    public Header parseHeader(byte[] binaryHeader, Schema schema) throws DecoderException {
        if (schema == Schema.V2) {
            return (Header) decoderService.decode(Structure.HEADER_V2, binaryHeader);
        }
        return (Header) decoderService.decode(Structure.HEADER, binaryHeader);
    }

    @Override
    public Message parsePayload(Map<Structure, byte[]> payloadStructure) throws DecoderException {
        final boolean debugEnabled = logger.isDebugEnabled();
        Message message = Message.create();
        StringJoiner stringJoiner = new StringJoiner(" | ", "[", "]");
        for (Map.Entry<Structure, byte[]> entry : payloadStructure.entrySet()) {
            if (debugEnabled) {
                stringJoiner.add(entry.getKey() + ":" + ConversionUtils.byteArrayToHexString(entry.getValue()));
            }
            Data data = decoderService.decode(entry.getKey(), entry.getValue());
            appendData(entry.getKey(), message, data);
        }
        logger.debug("StructureList: {}", stringJoiner);
        return message;
    }

    @Override
    public Authorizations parseAuthorizations(String authAsString) {
        Authorizations authorizations;
        try {
            authorizations = MAPPER.readValue(MAPPER.readTree(authAsString).get("auth").toString(), Authorizations.class);
        } catch (Exception e) {
            logger.warn("Could not parse authorizations: {}", authAsString);
            authorizations = new Authorizations();
        }
        return authorizations;
    }

    private void appendData(Structure structure, Message message, Data data) {
        switch (structure) {
            case BATTERY:
                message.battery((Battery) data);
                break;
            case THERMAL_CONDITIONING:
                message.thermalConditioning((ThermalConditioning) data);
                break;
            case PRIVACY:
                message.privacy((Privacy) data);
                break;
            case LOCALIZATION:
                message.localization((Localization) data);
                break;
            case BATTERY_VOLTAGE_SUMMARY:
                message.batteryVoltageSummary((BatteryVoltageSummary) data);
                break;
            case BATTERY_VOLTAGE_DETAILS:
                message.batteryVoltageDetails((BatteryVoltageDetails) data);
                break;
            case BATTERY_STATUS_SUMMARY:
                message.batteryStatusSummary((BatteryStatusSummary) data);
                break;
            case BATTERY_STATUS_DETAILS:
                message.batteryStatusDetails((BatteryStatusDetails) data);
                break;
            case BATTERY_SOH:
                message.batteryStateOfHealth((BatteryStateOfHealth) data);
                break;
            case TRIP:
                message.trip((Trip) data);
                break;
            case ECOACHING:
                message.ecoaching((Ecoaching) data);
                break;
            case JDA:
                message.jda((JDA) data);
                break;
            case JDD:
                message.jdd((JDD) data);
                break;
            case EXTENSION:
                message.extension((Extension) data);
                break;
            case VEHICLE_STATUS:
            case VEHICLE_STATUS_V2:
                message.vehicleStatus((VehicleStatus) data);
                break;
            case USAGE_STATUS:
            case USAGE_STATUS_V2:
                message.usageStatus((UsageStatus) data);
                break;
            case MAINTENANCE_STATUS:
                message.maintenanceStatus((MaintenanceStatus) data);
                break;
            case DOORS_STATUS:
                message.doorsStatus((DoorsStatus) data);
                break;
            case PERIODIC:
                message.periodic((Periodic) data);
                break;
            case EVENT:
                message.event((Event) data);
                break;
            case CFM_LEV:
                message.lev((LEV) data);
                break;
            case CRASH:
                message.crash((Crash) data);
                break;
            case ADAS:
                message.adas((Adas) data);
                break;
            default:
                break;
        }
    }
}
