package com.inetpsa.carbide.application.util;

public final class ValidationUtils {

    public static boolean checkVin(String vin) {
        return vin != null && Constant.MATCHER_VIN.matcher(vin).matches();
    }
}
