package com.inetpsa.carbide.application.services;

import com.inetpsa.carbide.decoder.application.exceptions.DecoderException;
import com.inetpsa.carbide.decoder.application.util.Schema;
import com.inetpsa.carbide.decoder.application.util.Structure;
import com.inetpsa.carbide.domain.interfaces.data.Header;
import com.inetpsa.carbide.domain.interfaces.data.Message;
import com.inetpsa.carbide.domain.interfaces.data.global.Authorizations;
import org.seedstack.business.Service;

import java.util.Map;

/**
 * Binary data processing.
 */
@Service
public interface DataParserService {

    Header parseHeader(byte[] headerBin, Schema schema) throws DecoderException;

    Message parsePayload(Map<Structure, byte[]> payloadStructure) throws DecoderException;

    Authorizations parseAuthorizations(String authorizations);
}
