package com.inetpsa.carbide.infrastructure.mqtt;

import com.codahale.metrics.annotation.Metered;
import com.inetpsa.carbide.application.enums.ProcessStatus;
import com.inetpsa.carbide.application.services.MessageProcessorService;
import com.inetpsa.carbide.decoder.application.util.Schema;
import com.inetpsa.carbide.domain.interfaces.data.Message;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.seedstack.mqtt.MqttListener;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import javax.inject.Inject;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@MqttListener(clients = "${carbide.mqttConfig.clients}", topics = "${carbide.mqttConfig.topics}", qos = "${carbide.mqttConfig.qos}")
public class MqttMessageConsumer implements MqttCallback {

    private static final Pattern TOPIC_PATTERN = Pattern.compile(".*from/uin/(\\p{Alnum}{20})/(\\p{Digit}).*");

    @Logging
    private Logger logger;

    @Inject
    private MessageProcessorService processorService;

    private final UUID messageId = UUID.randomUUID();

    @Metered(name = "1. MESSAGE ARRIVED", absolute = true)
    @Override
    public void messageArrived(String topic, MqttMessage mqttMessage) {
        logger.debug("[{}] topic={}", messageId, topic);
        Matcher m = TOPIC_PATTERN.matcher(topic);
        Schema schema = null;
        if (m.matches()) {
            logger.info("[{}] source={}", messageId, m.group(1));
            schema = Schema.fromProtocolVersion(Integer.parseInt(m.group(2)));
        }
        handleMessage(mqttMessage, schema);
    }

    private void handleMessage(MqttMessage mqttMessage, Schema schema) {
        try {
            Message message = processorService.process(messageId, mqttMessage.getPayload(), schema);
            String json = processorService.serialize(messageId, message);
            processorService.publish(messageId, message, json);
        } catch (Exception e) {
            logger.error("[{}] status={}", messageId, ProcessStatus.ERROR, e);
        }
    }

    @Override
    public void connectionLost(Throwable throwable) {
    }

    @Override
    public void deliveryComplete(IMqttDeliveryToken iMqttDeliveryToken) {
    }
}
