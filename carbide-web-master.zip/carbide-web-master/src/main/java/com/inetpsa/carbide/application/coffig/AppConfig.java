package com.inetpsa.carbide.application.coffig;

import org.seedstack.coffig.Config;

@Config("carbide")
public class AppConfig {

    private final KafkaTopics kafkaTopics = new KafkaTopics();

    @Config("mqttConfig")
    private final MqttConf mqttConfig = new MqttConf();

    public AppConfig() {
    }

    public static class KafkaTopics {

        private String binaryLev;
        private String jsonLev;

        public String getBinaryLev() {
            return binaryLev;
        }

        public String getJsonLev() {
            return jsonLev;
        }
    }

    public static class MqttConf {

        private String clients;
        private String topics;
        private String qos;

        public String getClients() {
            return clients;
        }

        public String getTopics() {
            return topics;
        }

        public String getQos() {
            return qos;
        }
    }

    public KafkaTopics getKafkaTopics() {
        return kafkaTopics;
    }

    public MqttConf getMqttConfig() {
        return mqttConfig;
    }
}
