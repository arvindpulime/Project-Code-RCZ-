package com.inetpsa.carbide.interfaces.rest.test;

import com.inetpsa.carbide.application.services.MessageProcessorService;
import com.inetpsa.carbide.decoder.application.util.Schema;
import com.inetpsa.carbide.domain.interfaces.data.Message;
import org.seedstack.seed.Logging;
import org.slf4j.Logger;

import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.UUID;

import static com.inetpsa.carbide.application.util.ConversionUtils.hexStringToByteArray;

@Path("/test")
public class HttpMessageConsumerResource {

    @Logging
    private Logger logger;

    @Inject
    private MessageProcessorService processorService;

    private UUID messageId;

    @POST
    @Consumes(MediaType.TEXT_PLAIN)
    @Produces(MediaType.APPLICATION_JSON)
    public Response decode(String hex, @QueryParam("p") int protocolVersion) {
        try {
            messageId = UUID.randomUUID();
            logger.info("[{}] test mode, producer disabled", messageId);
            protocolVersion = protocolVersion == 0 ? protocolVersion = 2 : protocolVersion;
            Message message = processorService.process(messageId, hexStringToByteArray(hex), Schema.fromProtocolVersion(protocolVersion));
            String serialized = processorService.serialize(messageId, message);
            return Response.ok(serialized).build();
        } catch (Exception e) {
            logger.error("[{}] test mode, error", messageId, e);
            return Response.serverError().entity(e.getMessage()).build();
        }
    }
}
