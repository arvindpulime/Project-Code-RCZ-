package com.inetpsa.carbide.interfaces.rest.test;

import org.hamcrest.Matchers;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.seedstack.seed.Configuration;
import org.seedstack.seed.testing.junit4.SeedITRunner;
import org.seedstack.seed.undertow.LaunchWithUndertow;

import static io.restassured.RestAssured.expect;

@RunWith(SeedITRunner.class)
@LaunchWithUndertow
public class HttpMessageConsumerResourceTest {

    private static final String TEST_URL = "/test";

    @Configuration("runtime.web.baseUrl")
    private String baseUrl;

    @Test
    public void privacy() {
        expect().statusCode(200).given()
                .body(MessageFixture.PRIVACY_PHEV)
                .when().post(baseUrl + TEST_URL)
                .then().assertThat().body("privacy", Matchers.notNullValue());
    }

    @Test
    public void periodic() {
        expect().statusCode(200).given()
                .body(MessageFixture.PERIODIC_PHEV)
                .when().post(baseUrl + TEST_URL)
                .then().assertThat().body("periodic", Matchers.notNullValue());
    }

    @Test
    public void vehicleStatus() {
        expect().statusCode(200).given()
                .body(MessageFixture.VEHICLE_STATUS_PHEV)
                .when().post(baseUrl + TEST_URL)
                .then().assertThat().body("vehicleStatus", Matchers.notNullValue());
    }

    @Test
    public void vehicleStatusV2() {
        expect().statusCode(200).given()
                .queryParam("p", 3)
                .body(MessageFixture.VEHICLE_STATUS_PHEV_V2)
                .when().post(baseUrl + TEST_URL)
                .then().assertThat().body("vehicleStatus", Matchers.notNullValue());
    }

    @Test
    public void ecoaching() {
        expect().statusCode(200).given()
                .body(MessageFixture.ECOACHING_PHEV)
                .when().post(baseUrl + TEST_URL)
                .then().assertThat().body("ecoaching", Matchers.notNullValue());
    }

    @Test
    public void thermalConditioning() {
        expect().statusCode(200).given()
                .body(MessageFixture.THERMAL_CONDITIONING_PHEV)
                .when().post(baseUrl + TEST_URL)
                .then().assertThat().body("thermalConditioning", Matchers.notNullValue());
    }

    @Test
    public void trip() {
        expect().statusCode(200).given()
                .body(MessageFixture.TRIP_PHEV)
                .when().post(baseUrl + TEST_URL)
                .then().assertThat().body("trip", Matchers.notNullValue());
    }

    @Test
    public void localization() {
        expect().statusCode(200).given()
                .body(MessageFixture.LOCALIZATION_PHEV)
                .when().post(baseUrl + TEST_URL)
                .then().assertThat().body("localization", Matchers.notNullValue());
    }

    @Test
    public void extension() {
        expect().statusCode(200).given()
                .body(MessageFixture.EXTENSION_PHEV)
                .when().post(baseUrl + TEST_URL)
                .then().assertThat().body("extension", Matchers.notNullValue());
    }

    @Test
    public void eventStop() {
        expect().statusCode(200).given()
                .body(MessageFixture.EVENT_STOP_PHEV)
                .when().post(baseUrl + TEST_URL)
                .then().assertThat().body("event", Matchers.notNullValue());
    }

    //    @Ignore("invalid date")
    @Test
    public void eventStart() {
        expect().statusCode(200).given()
                .body(MessageFixture.EVENT_START_PHEV)
                .when().post(baseUrl + TEST_URL)
                .then().assertThat().body("event", Matchers.notNullValue());
    }

    @Test
    public void eventPrivacy() {
        expect().statusCode(200).given()
                .body(MessageFixture.EVENT_PRIVACY_PHEV)
                .when().post(baseUrl + TEST_URL)
                .then().assertThat().body("event", Matchers.notNullValue());
    }

    @Test
    public void eventCrash() {
        expect().statusCode(200).given()
                .body(MessageFixture.EVENT_CRASH_PHEV)
                .when().post(baseUrl + TEST_URL)
                .then().assertThat().body("event", Matchers.notNullValue());
    }

    @Test
    public void maintenanceStatus() {
        expect().statusCode(200).given()
                .body(MessageFixture.MAINTENANCE_STATUS_PHEV)
                .when().post(baseUrl + TEST_URL)
                .then().assertThat().body("maintenanceStatus", Matchers.notNullValue());
    }

    @Test
    public void jdd() {
        expect().statusCode(200).given()
                .body(MessageFixture.JDD_PHEV)
                .when().post(baseUrl + TEST_URL)
                .then().assertThat().body("jdd", Matchers.notNullValue());
    }

    @Test
    public void jda() {
        expect().statusCode(200).given()
                .body(MessageFixture.JDA_PHEV)
                .when().post(baseUrl + TEST_URL)
                .then().assertThat().body("jda", Matchers.notNullValue());
    }

    @Test
    public void doorsStatus() {
        expect().statusCode(200).given()
                .body(MessageFixture.DOORS_STATUS_PHEV)
                .when().post(baseUrl + TEST_URL)
                .then().assertThat().body("doorsStatus", Matchers.notNullValue());
    }

    @Test
    public void battery() {
        expect().statusCode(200).given()
                .body(MessageFixture.BATTERY_PHEV)
                .when().post(baseUrl + TEST_URL)
                .then().assertThat().body("battery", Matchers.notNullValue());
    }

    @Test
    public void batteryVoltageDetails() {
        expect().statusCode(200).given()
                .body(MessageFixture.BATTERY_VOLTAGE_DETAILS_PHEV)
                .when().post(baseUrl + TEST_URL)
                .then().assertThat().body("batteryVoltageDetails", Matchers.notNullValue());
    }

    @Test
    public void batteryVoltageSummary() {
        expect().statusCode(200).given()
                .body(MessageFixture.BATTERY_VOLTAGE_SUMMARY_PHEV)
                .when().post(baseUrl + TEST_URL)
                .then().assertThat().body("batteryVoltageSummary", Matchers.notNullValue());
    }

    @Test
    public void batteryStatusDetails() {
        expect().statusCode(200).given()
                .body(MessageFixture.BATTERY_STATUS_DETAILS_PHEV)
                .when().post(baseUrl + TEST_URL)
                .then().assertThat().body("batteryStatusDetails", Matchers.notNullValue());
    }

    @Test
    public void batteryStatusSummary() {
        expect().statusCode(200).given()
                .body(MessageFixture.BATTERY_STATUS_SUMMARY_PHEV)
                .when().post(baseUrl + TEST_URL)
                .then().assertThat().body("batteryStatusSummary", Matchers.notNullValue());
    }

    @Test
    public void batteryStateOfHealth() {
        expect().statusCode(200).given()
                .body(MessageFixture.BATTERY_SOH_PHEV)
                .when().post(baseUrl + TEST_URL)
                .then().assertThat().body("batteryStateOfHealth", Matchers.notNullValue());
    }

    @Test
    public void adas() {
        expect().statusCode(200).given()
                .body(MessageFixture.ADAS_PHEV)
                .when().post(baseUrl + TEST_URL)
                .then().assertThat().body("adas", Matchers.notNullValue());
    }

    @Test
    public void crash() {
        expect().statusCode(200).given()
                .body(MessageFixture.CRASH_PHEV)
                .when().post(baseUrl + TEST_URL)
                .then().assertThat().body("crash", Matchers.notNullValue());
    }

    @Test
    public void usageStatus() {
        expect().statusCode(200).given()
                .body(MessageFixture.USAGE_STATUS_PHEV)
                .when().post(baseUrl + TEST_URL)
                .then().assertThat().body("usageStatus", Matchers.notNullValue());
    }

    @Test
    public void usageStatusV2() {
        expect().statusCode(200).given()
                .queryParam("p", 3)
                .body(MessageFixture.USAGE_STATUS_PHEV_V2)
                .when().post(baseUrl + TEST_URL)
                .then().assertThat().body("usageStatus", Matchers.notNullValue());
    }
}