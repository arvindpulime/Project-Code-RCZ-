# CARBIDE

## Description

CARBIDE (Car Binary Decoder) receives binary data sent from vehicles using ATBs. Those data can represent events that happened (stop, crash, etc.)
or different states of a vehicle (localization, mileage, fuel, etc.).
Decoding process will transform those data into a readable format such as JSON, before making it available to client applications.

## Modules

* carbide-domain
    > Schema representing CARBIDE outputs
* carbide-decoder
    > Decoding process of binary data
* carbide-serializer
    > Serializing process of decoded data
* carbide-bom
    > CARBIDE dependency management
* carbide-web
    > Main application
    
## Project dependencies

![carbide_build_chain](https://media.github.psa-cloud.com/user/918/files/684be080-b08a-11ea-9e6d-3ac556986d73)

